"""Evidence-first Virginia 3E Readiness evaluator."""
from datetime import datetime
import re


RULE_VERSION = "VA-3E-2026.2"
HQWBL_TYPES = {
    "registered apprenticeship", "internship", "clinical", "entrepreneurship",
    "school-based enterprise", "school based enterprise", "immersion sae",
    "supervised agricultural experience",
}
CREDENTIAL_REGISTRY = {
    "ncrc": {"canonical": "ACT WorkKeys National Career Readiness Certificate", "approved": True, "high_demand": None},
    "workplace readiness": {"canonical": "Workplace Readiness Skills", "approved": True, "high_demand": None},
    "wpr": {"canonical": "Workplace Readiness Skills", "approved": True, "high_demand": None},
    "wise": {"canonical": "W!SE Financial Literacy Certification", "approved": True, "high_demand": None},
    "w!se": {"canonical": "W!SE Financial Literacy Certification", "approved": True, "high_demand": None},
}


def three_e_readiness(db, student_id):
    statuses = {
        row["requirement_key"]: row
        for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ?", (student_id,)).fetchall()
    }
    attempts = db.execute(
        """
        SELECT a.*, u.data_source_type
        FROM test_attempts a
        LEFT JOIN upload_history u ON u.id = a.source_upload_id
        WHERE a.student_id_fk = ?
        """,
        (student_id,),
    ).fetchall()
    courses = db.execute("SELECT * FROM transcript_courses WHERE student_id_fk = ?", (student_id,)).fetchall()

    fields = _custom_fields(db, student_id)
    enrollment = _enrollment_points(courses, fields, attempts)
    employment = _employment_points(statuses, attempts, courses, fields)
    enlistment = _enlistment_points(attempts, fields)
    total = round(enrollment["points"] + employment["points"] + enlistment["points"], 2)
    provisional_total = round(total + sum(item.get("pending_points", 0) for item in (enrollment, employment, enlistment)), 2)
    pathways = [name for name, item in [("Enrollment", enrollment), ("Employment", employment), ("Enlistment", enlistment)] if item["points"] > 0]
    highest = max([("Enrollment", enrollment["points"]), ("Employment", employment["points"]), ("Enlistment", enlistment["points"])], key=lambda item: item[1])
    last_updated = _last_updated(statuses, attempts, courses)

    if total == 0:
        summary = "3E: None"
        status = "No 3E Evidence"
        color = "none"
    elif len(pathways) == 3:
        summary = f"3E: {_fmt(total)} - All 3 Pathways"
        status = "On Track"
        color = _color(total)
    elif len(pathways) >= 2:
        summary = f"3E: {_fmt(total)} - {' + '.join(pathways)}"
        status = "On Track" if total >= 1 else "Building"
        color = _color(total)
    else:
        summary = f"3E: {_fmt(total)} - {pathways[0]}" if pathways else "3E: Needs Review"
        status = "On Track" if total >= 1 else "Building"
        color = _color(total)

    if any(item["needs_review"] for item in [enrollment, employment, enlistment]):
        # Keep documented pathway points visible even when another pathway is
        # incomplete. The detail view names exactly what needs review.
        if total == 0:
            status, summary, color = "Needs Review", "3E: Needs Review", "review"
        else:
            status = "Verified Evidence - Review Remaining"

    return {
        "summary": summary,
        "status": status,
        "color": color,
        "total_points": total,
        "provisional_total_points": provisional_total,
        "highest_pathway": highest[0] if highest[1] > 0 else "",
        "last_updated": last_updated,
        "data_source": _data_source(enrollment, employment, enlistment),
        "rule_version": RULE_VERSION,
        "enrollment": enrollment,
        "employment": employment,
        "enlistment": enlistment,
        "recommended_action": _recommended_action(enrollment, employment, enlistment, total),
    }


def three_e_report_rows(db, grad_class=None, view_filter="all"):
    sql = """
        SELECT s.*
        FROM students s
        JOIN class_grid_members m ON m.student_id_fk = s.id
        WHERE 1=1
    """
    params = []
    if grad_class:
        sql += " AND m.graduation_class = ?"
        params.append(int(grad_class))
    sql += " ORDER BY m.graduation_class, s.last_name, s.first_name"
    rows = []
    for student in db.execute(sql, params).fetchall():
        readiness = three_e_readiness(db, student["id"])
        if view_filter == "no-evidence" and readiness["total_points"] > 0:
            continue
        if view_filter == "close" and not (0 < readiness["total_points"] < 1):
            continue
        paths = sum(item["points"] > 0 for item in (readiness["enrollment"], readiness["employment"], readiness["enlistment"]))
        if view_filter == "review" and not any(item["needs_review"] for item in (readiness["enrollment"], readiness["employment"], readiness["enlistment"])):
            continue
        if view_filter == "one-pathway" and paths != 1:
            continue
        if view_filter == "two-pathways" and paths != 2:
            continue
        if view_filter == "all-pathways" and paths != 3:
            continue
        rows.append({"student": student, "readiness": readiness})
    return rows


def three_e_hover(readiness):
    lines = [
        f"Enrollment: {_fmt(readiness['enrollment']['points'])} - {readiness['enrollment']['evidence'] or 'No evidence'}",
        f"Employment: {_pathway_points_label(readiness['employment'])} - {readiness['employment']['evidence'] or 'No evidence'}",
        f"Enlistment: {_fmt(readiness['enlistment']['points'])} - {readiness['enlistment']['evidence'] or 'No ASVAB score'}",
        f"Total: {_fmt(readiness['total_points'])}",
        f"Last Updated: {readiness['last_updated'] or 'No dated evidence'}",
        f"Data Source: {readiness['data_source'] or 'None'}",
        f"Rule Set: {readiness.get('rule_version', RULE_VERSION)}",
    ]
    reviews = [item.get("review_reason") for item in (readiness["enrollment"], readiness["employment"], readiness["enlistment"]) if item.get("review_reason")]
    if reviews:
        lines.append("Review: " + "; ".join(reviews))
    return "\n".join(lines)


def _enrollment_points(courses, fields, attempts):
    """Award Enrollment only when grades/results and college credit hours are known."""
    associate = _yes(_field(fields, "Associate Degree Earned", "Associate Degree"))
    early_college = _yes(_field(fields, "Early College Scholar Certificate", "Early College Scholar"))
    dual, review = [], []
    for course in courses:
        title, attrs = course["course_title"] or "", course["attributes"] or ""
        text, grade = f"{title} {attrs}".lower(), (course["final_grade"] or "").upper().strip()
        if not ("dual enrollment" in text or re.search(r"\bde\b", text) or " DE" in attrs.upper()):
            continue
        credits = _college_credits(course, fields)
        documented_course = _documented_de_course(title, attrs)
        # Most high-school transcripts carry .5 or 1.0 high-school credit for
        # a DE section. A recognizable college course code is the evidence that
        # the class is credit-bearing; the configured college-credit field can
        # still be used when a district needs to override that assumption.
        qualifying_credit = credits >= 3 or documented_course
        if grade in {"A", "B", "C"} and credits >= 3:
            dual.append((title, grade, credits))
        elif grade in {"A", "B", "C"} and qualifying_credit:
            dual.append((title, grade, 3 if documented_course else credits))
        elif grade and grade not in {"F", "IP", "W"}:
            review.append(f"{title} needs documented college credit hours (3 required)")
        else:
            review.append(f"{title} needs a final qualifying grade and college credit hours")
    exams = _college_ready_exams(attempts, fields)
    evidence, points = [], 0
    dual_b_or_better = [item for item in dual if item[1] in {"A", "B"}]
    dual_c = [item for item in dual if item[1] == "C"]
    if associate:
        points, evidence = 1.25, ["Associate degree documented"]
    elif early_college or len(dual_b_or_better) >= 3 or len(exams) >= 3:
        points = 1.0
        if early_college: evidence.append("Early College Scholar certificate documented")
        if len(dual_b_or_better) >= 3: evidence.append(f"{len(dual_b_or_better)} qualifying dual-enrollment courses with B or higher")
        if len(exams) >= 3: evidence.append(f"{len(exams)} documented college-ready exam results")
    elif dual_b_or_better or exams:
        points = .75
        evidence.append(f"{len(dual_b_or_better)} qualifying dual-enrollment course(s) with B or higher" if dual_b_or_better else f"{len(exams)} documented college-ready exam result(s)")
    elif dual_c or _exam_completion(attempts, fields):
        points, evidence = .5, ["Documented qualifying dual-enrollment C or qualifying exam completion"]
    return _pathway(points, "; ".join(evidence), "Transcript / Exam upload" if evidence else "", review,
        associate_degree="Yes" if associate else "", advanced_evidence="; ".join(exams),
        dual_courses="; ".join(item[0] for item in dual), dual_grades="; ".join(item[1] for item in dual),
        early_college_scholar="Yes" if early_college else "")


def _employment_points(statuses, attempts, courses, fields):
    cte_raw = _field(fields, "CTE Completer", "CTE Completer Status") or _met_requirement_value(
        statuses, "CTE Completer", "CTE Completer Status"
    )
    cte, cte_unknown = _yes(cte_raw), not cte_raw or _normal(cte_raw) == "unknown"
    credential, wbl = _credential_evidence(statuses, attempts, fields), _hqwbl_evidence(courses, attempts, fields)
    high, approved, hqwbl = credential["high_demand"] is True, credential["approved"], bool(wbl and wbl["qualifying"])
    review = []
    if credential["unrecognized"]: review.append("Credential requires district/state approval review")
    if cte_unknown and (approved or wbl): review.append("CTE Completer status is missing or unknown")
    if wbl and not hqwbl: review.append("Work-based learning type is not a documented HQWBL category")
    pending_points = 0
    if cte and high and hqwbl: points = 1.25
    elif cte and ((high and approved) or (approved and hqwbl)): points = 1.0
    elif cte and approved: points = .75
    elif cte and hqwbl: points = .5
    else:
        points = 0
        # Virginia requires CTE Completer evidence for an official Employment
        # pathway award. Keep the earned credential visible as a provisional
        # .75 opportunity instead of silently counting it in the official total.
        if approved and cte_unknown:
            pending_points = .75
    evidence = (["CTE Completer"] if cte else []) + (["Credential: " + credential["name"]] if credential["name"] else []) + ([("HQWBL: " if hqwbl else "WBL review: ") + wbl["label"]] if wbl else [])
    if pending_points:
        evidence.append("Pending CTE Completer review")
    return _pathway(points, "; ".join(evidence), "Credential / CTE / HQWBL upload" if evidence else "", review,
        cte_completer="Yes" if cte else ("Unknown" if cte_unknown else "No"), credential_earned="Yes" if approved else "",
        credential_name=credential["name"], high_demand_credential="Yes" if high else ("Unknown" if credential["high_demand"] is None and credential["name"] else "No"),
        work_based_learning="Yes" if hqwbl else "", work_based_learning_type=wbl["label"] if wbl else "", pending_points=pending_points)


def _enlistment_points(attempts, fields):
    scores = [float(a["score"]) for a in attempts if _is_documented_afqt(a) and a["score"] is not None]
    supplied = _number(_field(fields, "AFQT Score", "ASVAB / AFQT Score"))
    if supplied is not None:
        scores.append(supplied)
    generic_asvab = any("asvab" in f"{a['test_name'] or ''} {a['test_area'] or ''} {a['credential_name'] or ''} {a['raw_score'] or ''}".lower() for a in attempts)
    best = max(scores) if scores else None
    if best is None:
        points = 0
        band = ""
    elif best >= 65:
        points = 1
        band = "65+"
    elif best >= 50:
        points = 0.75
        band = "50-65"
    elif best >= 31:
        points = 0.5
        band = "31-49"
    else:
        points = 0
        band = "Below 31"
    return {
        "points": points,
        "evidence": f"AFQT {int(best)}" if best is not None else "",
        "asvab_score": int(best) if best is not None else "",
        "asvab_band": band,
        "needs_review": generic_asvab and best is None,
        "review_reason": "ASVAB record found without an identifiable AFQT score" if generic_asvab and best is None else "",
        "source": "ASVAB / AFQT upload" if best is not None else "",
    }


def _custom_fields(db, student_id):
    rows = db.execute(
        "SELECT field_key, display_value, score FROM custom_field_values WHERE student_id_fk = ?", (student_id,)
    ).fetchall()
    return {
        _normal(row["field_key"]): str(row["display_value"] if row["display_value"] not in (None, "") else row["score"] or "").strip()
        for row in rows
    }


def _is_documented_afqt(attempt):
    """Recognize named AFQT values and scores from the dedicated local ASVAB upload."""
    label = f"{attempt['test_name'] or ''} {attempt['test_area'] or ''} {attempt['credential_name'] or ''} {attempt['raw_score'] or ''}".lower()
    if "afqt" in label:
        return True
    source = str(attempt["data_source_type"] or "").lower() if "data_source_type" in attempt.keys() else ""
    return "asvab" in label and ("asvab" in source or "3e documentation" in source)


def _field(fields, *names):
    for name in names:
        value = fields.get(_normal(name), "")
        if value:
            return value
    return ""


def _yes(value):
    return _normal(value) in {"yes", "y", "true", "1", "x", "complete", "completed", "earned"}


def _college_credits(course, fields):
    for key in ("college_credits", "credits", "earned_credits"):
        try:
            credits = float(course[key] or 0)
            # 0.5/1.0 reflects high-school credit, not evidence of college credit hours.
            if credits >= 3:
                return credits
        except (KeyError, IndexError, TypeError, ValueError):
            pass
    return _number(_field(fields, "DE College Credits", "Dual Enrollment College Credits")) or 0


def _documented_de_course(title, attrs):
    """Recognize a transcript's named college DE course without guessing from a generic label."""
    text = f"{title or ''} {attrs or ''}"
    return bool(
        re.search(r"\b(?:de|dual\s+enrollment)\b", text, re.I)
        and re.search(r"\b(?:[A-Za-z]{2,12}\s+)?\d{3}[A-Za-z]?\b", text)
    )


def _met_requirement_value(statuses, *keys):
    for key in keys:
        row = statuses.get(key)
        if row and _normal(row["status"]) == "met":
            return row["display_value"] or "Yes"
    return ""


def _college_ready_exams(attempts, fields):
    labels = []
    for attempt in attempts:
        label = f"{attempt['test_name'] or ''} {attempt['test_area'] or ''} {attempt['raw_score'] or ''}"
        if re.search(r"\b(ap|ib|cambridge|clep)\b", label, re.I) and attempt["score"] is not None:
            labels.append(label)
    manual = _field(fields, "College-Ready Exam Results", "College Ready Exam Results")
    if manual:
        labels.extend(value.strip() for value in manual.split(";") if value.strip())
    return list(dict.fromkeys(labels))


def _exam_completion(attempts, fields):
    return bool(_college_ready_exams(attempts, fields) or _field(fields, "Qualifying Exam Completion"))


def _credential_evidence(statuses, attempts, fields):
    names = []
    for key in ("Credential Test", "NCRC", "Workplace Readiness"):
        row = statuses.get(key)
        if row and row["status"] == "Met":
            names.append(row["display_value"] or key)
    for attempt in attempts:
        raw = " ".join(str(attempt[key] or "") for key in ("credential_name", "test_name", "test_area", "raw_score"))
        normalized = _normal(raw)
        # Component rows (Workplace Documents, Graphic Literacy, Applied Math)
        # establish NCRC only through the calculated NCRC status above. They are
        # not separately treated as unnamed industry credentials.
        recognizable = any(alias in normalized for alias in CREDENTIAL_REGISTRY)
        if raw and recognizable and not re.search(r"\b(f|fail|failed)\b", raw.lower()):
            names.append(raw)
    manual = _field(fields, "Credential Earned", "Credential Name", "Industry Credential")
    if manual:
        names.append(manual)
    canonical, approved, high, unknown = [], False, None, False
    for name in names:
        match = next((entry for alias, entry in CREDENTIAL_REGISTRY.items() if alias in _normal(name)), None)
        if match:
            canonical.append(match["canonical"])
            approved = approved or match["approved"]
            if match["high_demand"] is True:
                high = True
        elif name:
            canonical.append(name)
            unknown = True
    manual_high = _field(fields, "Credential High-Demand Status", "High-Demand Credential")
    if manual_high:
        high = True if _yes(manual_high) else False if _normal(manual_high) == "no" else high
    return {"name": "; ".join(dict.fromkeys(canonical)), "approved": approved, "high_demand": high, "unrecognized": unknown}


def _hqwbl_evidence(courses, attempts, fields):
    value = _field(fields, "HQWBL Type", "Work-Based Learning Type", "Work Based Learning Type")
    if not value:
        for row in list(courses) + list(attempts):
            candidates = []
            for key in ("course_title", "attributes", "test_name", "credential_name"):
                try:
                    candidates.append(str(row[key] or ""))
                except (KeyError, IndexError):
                    pass
            candidate = " ".join(candidates)
            if any(kind in _normal(candidate) for kind in HQWBL_TYPES):
                value = candidate
                break
    if not value:
        return None
    return {"label": value, "qualifying": any(kind in _normal(value) for kind in HQWBL_TYPES)}


def _pathway(points, evidence, source, review, **extra):
    result = {"points": points, "pending_points": 0, "evidence": evidence, "needs_review": bool(review), "review_reason": "; ".join(review), "source": source}
    result.update(extra)
    return result


def _last_updated(statuses, attempts, courses):
    dates = []
    for row in statuses.values():
        if row["updated_at"]:
            dates.append(row["updated_at"])
    for attempt in attempts:
        if attempt["test_date"]:
            dates.append(attempt["test_date"])
        elif attempt["created_at"]:
            dates.append(attempt["created_at"])
    for course in courses:
        if course["created_at"]:
            dates.append(course["created_at"])
    if not dates:
        return ""
    value = sorted(str(d) for d in dates)[-1]
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%m/%d/%Y"):
        try:
            return datetime.strptime(value[:19], fmt).strftime("%m/%d/%Y")
        except ValueError:
            pass
    return value[:10]


def _data_source(*items):
    return "; ".join(item["source"] for item in items if item["source"])


def _recommended_action(enrollment, employment, enlistment, total):
    if total >= 1:
        return "Maintain evidence and review for higher 3E pathway totals."
    options = []
    if enrollment["points"] == 0:
        options.append("review AP/Honors/Dual Enrollment transcript evidence")
    if employment["points"] == 0:
        options.append("review credential, WPR/NCRC, CTE completer, or work-based learning evidence")
    if enlistment["points"] == 0:
        options.append("review ASVAB opportunity")
    return "Next opportunity: " + "; ".join(options) if options else "Needs counselor review."


def _color(total):
    if total >= 1:
        return "green"
    if total >= 0.75:
        return "orange"
    if total >= 0.5:
        return "yellow"
    return "none"


def _fmt(value):
    return f"{float(value):.2f}"


def _pathway_points_label(pathway):
    verified = _fmt(pathway["points"])
    pending = pathway.get("pending_points", 0)
    return f"{verified} verified; {_fmt(pending)} pending review" if pending else verified


def _normal(value):
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def _number(value):
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return None
