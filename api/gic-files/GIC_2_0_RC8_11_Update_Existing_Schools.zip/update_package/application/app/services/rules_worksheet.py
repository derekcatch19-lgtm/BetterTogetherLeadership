import csv
import io
import re
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill

from .custom_rule_schema import new_rule_package


REQUIRED_HEADERS = [
    "Category", "Requirement Name", "Rule Type", "Required Value",
    "Evidence Source", "Add to Grid", "Grid Label", "Cohort Start",
    "Cohort End", "Notes",
]
OPTIONAL_HEADERS = [
    "Diploma Plan", "Required or Optional", "Subject Family",
    "Evidence Aliases", "Student Page Section", "Grid Display Type",
]
HEADERS = REQUIRED_HEADERS + OPTIONAL_HEADERS
CATEGORIES = {"credits", "course", "assessment", "credential", "checklist", "custom"}
RULE_TYPES = {
    "subject credits", "total credits", "required course", "must take",
    "must pass", "minimum score", "completion", "credential earned",
    "manual / custom",
}
EVIDENCE_SOURCES = {
    "transcript": "transcript_course",
    "assessment upload": "assessment_attempt",
    "credential upload": "credential_attempt",
    "completion record": "completion_record",
    "custom field": "custom_field",
    "manual confirmation": "manual_confirmation",
}


def blank_rules_worksheet_bytes():
    book = Workbook()
    sheet = book.active
    sheet.title = "Graduation Rules"
    sheet.append(HEADERS)
    examples = [
        ["Credits", "English", "Subject Credits", 4, "Transcript", "No", "", 2028, "", ""],
        ["Credits", "Total Credits", "Total Credits", 22, "Transcript", "No", "", 2028, "", "Standard diploma example"],
        ["Course", "Algebra I or Math I", "Required Course", "Yes", "Transcript", "No", "", 2028, "", "Either course satisfies requirement"],
        ["Assessment", "Civics Assessment", "Must Take", "Yes", "Assessment Upload", "Yes", "CIVICS", 2028, "", "Passing score not required"],
        ["Assessment", "State Mathematics", "Minimum Score", 684, "Assessment Upload", "Yes", "MATH", 2028, "", ""],
        ["Checklist", "CPR", "Completion", "Yes", "Completion Record", "Yes", "CPR", 2028, "", ""],
    ]
    for row in examples:
        sheet.append(row)
    for cell in sheet[1]:
        cell.fill = PatternFill("solid", fgColor="17365D")
        cell.font = Font(color="FFFFFF", bold=True)
    widths = [15, 28, 20, 16, 22, 13, 16, 14, 14, 38]
    for index, width in enumerate(widths, 1):
        sheet.column_dimensions[chr(64 + index)].width = width
    sheet.freeze_panes = "A2"
    help_sheet = book.create_sheet("Instructions")
    help_rows = [
        ("Purpose", "Enter one graduation requirement per row. The upload creates a draft only."),
        ("Category", "Credits, Course, Assessment, Credential, Checklist, or Custom"),
        ("Rule Type", ", ".join(sorted(name.title() for name in RULE_TYPES))),
        ("Evidence Source", ", ".join(name.title() for name in EVIDENCE_SOURCES)),
        ("Add to Grid", "Yes or No. Every rule still appears on the student record."),
        ("Diploma Plan", "Optional plan name. Include a numeric Total Credits row for each package."),
        ("Subject Family", "Use the same family label found in the course-history file, such as Mathematics or Social Studies."),
        ("Evidence Aliases", "Alternate course, test, credential, or completion names separated by semicolons."),
        ("Student Page Section", "Optional heading such as Credits, Required Courses, Assessments, or Credentials / Other."),
        ("Grid Display Type", "Optional checkbox, text, number, score, date, or dropdown."),
        ("Review", "Invalid rows are flagged. Nothing activates until Admin validation, approval, impact preview, and activation."),
    ]
    help_sheet.append(["Field", "Guidance"])
    for row in help_rows:
        help_sheet.append(row)
    for cell in help_sheet[1]:
        cell.fill = PatternFill("solid", fgColor="17365D")
        cell.font = Font(color="FFFFFF", bold=True)
    help_sheet.column_dimensions["A"].width = 22
    help_sheet.column_dimensions["B"].width = 105
    output = io.BytesIO()
    book.save(output)
    return output.getvalue()


def read_rules_worksheet(path):
    path = Path(path)
    if path.suffix.lower() == ".csv":
        text = path.read_text(encoding="utf-8-sig")
        records = list(csv.DictReader(io.StringIO(text)))
        headers = list(records[0].keys()) if records else next(csv.reader(io.StringIO(text)), [])
    elif path.suffix.lower() == ".xlsx":
        book = load_workbook(path, read_only=True, data_only=True)
        sheet = book["Graduation Rules"] if "Graduation Rules" in book.sheetnames else book[book.sheetnames[0]]
        values = list(sheet.iter_rows(values_only=True))
        headers = [str(value or "").strip() for value in (values[0] if values else [])]
        records = [dict(zip(headers, row)) for row in values[1:] if any(value not in (None, "") for value in row)]
        book.close()
    else:
        raise ValueError("Rules worksheets must be XLSX or CSV files.")
    normalized = {_norm_header(name): name for name in headers}
    missing = [header for header in REQUIRED_HEADERS if _norm_header(header) not in normalized]
    if missing:
        raise ValueError("Missing required worksheet columns: " + ", ".join(missing))
    return [
        {header: record.get(normalized.get(_norm_header(header), ""), "") for header in HEADERS}
        for record in records
    ]


def preview_rules_worksheet(records, existing_package=None):
    package = new_rule_package("Worksheet Graduation Rules", "Custom / Other State")
    package["diploma_plans"] = []
    plans = {}
    existing_requirement_keys = {item.get("key") for item in (existing_package or {}).get("requirements", [])}
    existing_evidence_keys = {item.get("key") for item in (existing_package or {}).get("evidence_definitions", [])}
    seen_rows = set()
    seen_rule_keys = set()
    seen_evidence_keys = set()
    invalid = []
    accepted = []
    grid_suggestions = []
    counts = {key: 0 for key in ["Credits", "Course", "Assessment", "Credential", "Checklist", "Custom"]}
    total_credit_value = None

    for row_number, raw in enumerate(records, 2):
        row = {key: _text(value) for key, value in raw.items()}
        category = row["Category"].lower()
        rule_type = row["Rule Type"].lower()
        evidence_source = row["Evidence Source"].lower()
        name = row["Requirement Name"]
        plan_name = row.get("Diploma Plan") or "General Diploma Plan"
        plan_key = _key(plan_name)
        if plan_key not in plans:
            plans[plan_key] = {"key": plan_key, "name": plan_name, "total_credits": None, "requirement_keys": []}
        errors = []
        if category not in CATEGORIES:
            errors.append("Category is not supported.")
        if not name:
            errors.append("Requirement Name is required.")
        if rule_type not in RULE_TYPES:
            errors.append("Rule Type is not supported.")
        if evidence_source not in EVIDENCE_SOURCES:
            errors.append("Evidence Source is not supported.")
        add_to_grid = _yes_no(row["Add to Grid"])
        if add_to_grid is None:
            errors.append("Add to Grid must be Yes or No.")
        cohort_start = _cohort(row["Cohort Start"], "Cohort Start", errors)
        cohort_end = _cohort(row["Cohort End"], "Cohort End", errors)
        if cohort_start and cohort_end and cohort_start > cohort_end:
            errors.append("Cohort Start cannot be after Cohort End.")
        numeric = None
        if rule_type in {"subject credits", "total credits", "minimum score"}:
            numeric = _number(row["Required Value"])
            if numeric is None:
                errors.append("Required Value must be numeric for this Rule Type.")
        identity = (plan_key, category, _key(name), rule_type, str(row["Required Value"]).lower(), evidence_source, cohort_start, cohort_end)
        if identity in seen_rows:
            errors.append("Duplicate worksheet row.")
        seen_rows.add(identity)
        base_rule_key = _key(name)
        rule_key = base_rule_key if plan_name == "General Diploma Plan" else f"{plan_key}_{base_rule_key}"[:56]
        evidence_key = f"{rule_key}_evidence"
        if rule_key in seen_rule_keys:
            errors.append(f"Requirement key collision: {rule_key}.")
        if rule_key in existing_requirement_keys:
            errors.append(f"Requirement key already exists in the current draft: {rule_key}.")
        if evidence_key in seen_evidence_keys or evidence_key in existing_evidence_keys:
            errors.append(f"Evidence key collision: {evidence_key}.")
        if errors:
            invalid.append({"row": row_number, "name": name or "(blank)", "errors": errors})
            continue
        seen_rule_keys.add(rule_key)
        seen_evidence_keys.add(evidence_key)
        counts[row["Category"].title()] += 1
        requirement, evidence = _build_rule(row, rule_key, evidence_key, rule_type, evidence_source, numeric, cohort_start, cohort_end)
        package["requirements"].append(requirement)
        if evidence:
            package["evidence_definitions"].append(evidence)
        plans[plan_key]["requirement_keys"].append(rule_key)
        if rule_type == "total credits":
            plans[plan_key]["total_credits"] = numeric
        if add_to_grid:
            label = row["Grid Label"] or _concise_label(name)
            grid_suggestions.append({"requirement_key": rule_key, "label": label, "type": row.get("Grid Display Type") or _grid_type(rule_type), "required": requirement.get("required", True), "section": requirement.get("display_section", "")})
        accepted.append({"row": row_number, "category": row["Category"].title(), "name": name, "rule_type": row["Rule Type"], "grid": "Yes" if add_to_grid else "No"})
    package["diploma_plans"] = list(plans.values())
    for plan in package["diploma_plans"]:
        if plan["total_credits"] is None:
            invalid.append({"row": "Plan", "name": plan["name"], "errors": ["Add a Total Credits row with a numeric Required Value for this diploma plan."]})
    return {
        "records": len(records), "accepted": accepted, "invalid": invalid,
        "counts": counts, "package": package, "grid_suggestions": grid_suggestions,
    }


def _build_rule(row, key, evidence_key, rule_type, source, numeric, cohort_start, cohort_end):
    evidence_type = EVIDENCE_SOURCES[source]
    aliases = _aliases(row["Requirement Name"])
    aliases.extend(_aliases(row.get("Evidence Aliases", "")))
    aliases = list(dict.fromkeys(alias for alias in aliases if alias))
    evidence = {"key": evidence_key, "label": row["Requirement Name"], "type": evidence_type, "aliases": aliases, "date_required": False}
    requirement = {
        "key": key, "label": row["Requirement Name"], "required": True,
        "diploma_scope": [], "evidence_keys": [evidence_key],
        "cohort_start": cohort_start, "cohort_end": cohort_end,
        "notes": row["Notes"], "worksheet_rule_type": row["Rule Type"],
        "display_section": row.get("Student Page Section") or _default_section(row["Category"]),
    }
    required_text = str(row.get("Required or Optional") or "Required").strip().lower()
    requirement["required"] = required_text not in {"optional", "no", "false", "0"}
    if rule_type == "subject credits":
        family = row.get("Subject Family") or row["Requirement Name"]
        requirement.update({"type": "subject_credits", "operator": ">=", "threshold": numeric, "unit": "credits", "subject_family": family})
        evidence["subject_family"] = family
    elif rule_type == "total credits":
        requirement.update({"type": "credit_total", "operator": ">=", "threshold": numeric, "unit": "credits", "evidence_keys": []})
        evidence = None
    elif rule_type == "required course":
        requirement.update({"type": "required_course", "operator": "checked", "threshold": True})
    elif rule_type in {"must take", "must pass", "minimum score"}:
        requirement.update({"type": "assessment", "operator": "is", "threshold": "Passed", "rule_mode": rule_type.replace(" ", "_")})
        if rule_type == "minimum score":
            evidence["pass_rule"] = {"operator": ">=", "threshold": numeric}
        elif rule_type == "must take":
            evidence["pass_rule"] = {"operator": "nonblank", "threshold": None}
    elif rule_type == "credential earned":
        requirement.update({"type": "credential", "operator": "is", "threshold": "Passed"})
    elif rule_type == "completion":
        requirement.update({"type": "checklist", "operator": "checked", "threshold": True})
    else:
        # Manual / Custom values may be an exact status (Met), a count (2 seals),
        # or a Yes/No completion value. Preserve that meaning instead of treating
        # every nonblank import as complete.
        custom_value = row["Required Value"]
        custom_number = _number(custom_value)
        custom_text = str(custom_value or "").strip().lower()
        if custom_number is not None:
            requirement.update({"type": "text", "operator": ">=", "threshold": custom_number})
        elif custom_text in {"yes", "y", "true", "1", "complete", "completed"}:
            requirement.update({"type": "text", "operator": "checked", "threshold": True})
        else:
            requirement.update({"type": "text", "operator": "is", "threshold": custom_value})
    return requirement, evidence


def _aliases(name):
    parts = re.split(r"\s+(?:or|and/or)\s+|[|;,]", str(name), flags=re.I)
    return [part.strip() for part in parts if part.strip()]


def _norm_header(value):
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def _text(value):
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _key(value):
    return re.sub(r"[^a-z0-9]+", "_", str(value or "").lower()).strip("_")[:56] or "requirement"


def _number(value):
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return None


def _cohort(value, label, errors):
    if not value:
        return None
    try:
        result = int(float(value))
    except ValueError:
        errors.append(f"{label} must be a four-digit graduation year.")
        return None
    if result < 2000 or result > 2200:
        errors.append(f"{label} must be between 2000 and 2200.")
        return None
    return result


def _yes_no(value):
    text = str(value or "").strip().lower()
    if text in {"yes", "y", "true", "1"}:
        return True
    if text in {"no", "n", "false", "0"}:
        return False
    return None


def _concise_label(value):
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return text if len(text) <= 22 else text[:19].rstrip() + "..."


def _grid_type(rule_type):
    return "number" if rule_type in {"subject credits", "total credits", "minimum score"} else "checkbox"


def _default_section(category):
    return {
        "credits": "Credits", "course": "Required Courses",
        "assessment": "Assessments", "credential": "Credentials / Other",
        "checklist": "Credentials / Other", "custom": "Other Requirements",
    }.get(str(category or "").strip().lower(), "Other Requirements")
