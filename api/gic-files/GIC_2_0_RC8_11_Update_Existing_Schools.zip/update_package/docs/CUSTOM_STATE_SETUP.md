# Custom / Other State Setup

This workflow stays local. Graduation documents and student information are not sent to an external AI service.

## Recommended Fast Start: Rules Worksheet

For the easiest code-free setup, open **Customize > Rules Wizard**, download the Graduation Rules Worksheet, and enter one requirement per row. Define the evidence source, student-page section, and whether the requirement should appear on the class grid. Upload the worksheet, correct any validation messages, create the structured draft, validate it, and approve/activate it.

After activation, upload a **Transcript / Course History** spreadsheet with one row per course. The system can create students and class grids while preserving the school's own subject families. Then upload completion, assessment, credential, and local tracking files as evidence.

## Alternative: Analyze Graduation Documents

Open **Customize > Rules Wizard** and upload one or more public graduation documents:

- State graduation requirements
- District handbook or checklist
- Course catalog
- Assessment or competency guide
- Transcript legend
- Local senior requirements

Supported formats are PDF, Word (`.docx`), Excel, CSV, text, and HTML.

The system proposes diploma, credit, assessment, readiness, and local checklist items. Each recommendation shows its source and a confidence label. No recommendation becomes active automatically.

## 2. Review and Activate

Edit or remove suggested wording and add anything the local analyzer did not find. An Admin must select **Approve and Activate Configuration**.

Activation creates suggested tracking fields, grid columns, reports, and agreement checklist items. Existing students are preserved. Newly required fields appear as Missing until evidence is entered or uploaded.

## 3. Configure Tracking Fields

Open **Customize > Custom Fields**. For each field, choose:

- Field name and description
- Checkbox, text, number, date, dropdown, score, or notes
- Completion rule such as `checked`, `nonblank`, `>=20`, or `equals Complete`
- Import aliases used by school spreadsheets
- Whether it is required
- Whether it appears on the grid, profile, and reports

Example:

- Name: `Community Service Hours`
- Type: `number`
- Completion rule: `>=20`
- Import aliases: `Service Hrs, Volunteer Hours, Community Hours`

## 4. Choose Grid Columns

Open **Customize > Grid Columns** and check the fields counselors need on the main class grid. Student Name and Graduation Class always remain visible.

## 5. Import Students and Tracking Data

Use **Student Roster / Class List** or **Existing Graduation Grid** to create students and class grids.

Use **Custom Tracking Spreadsheet** for later updates. Include Student ID whenever possible. Column names are matched to the configured field name or any import alias.

## 6. Build Reports

Open **Customize > Custom Reports**. Choose a field, comparison, and value. Examples:

- Community Service Hours less than 20
- FAFSA Complete is Missing
- Capstone Complete is Missing
- Postsecondary Plan is Undecided

Custom reports appear on the Reports page and can be exported.

## 7. Validate Before Live Use

Use fake students first. Confirm at least one Met and one Not Met example for every required field. The school remains responsible for approving the official graduation rules and verifying calculation results.
