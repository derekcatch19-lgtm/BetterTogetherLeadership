# Graduation Rules Worksheet Guide

The Graduation Rules Worksheet is the recommended setup path for a custom-state school that already knows its graduation requirements. It is an optional path and does not replace State Templates, Analyze Documents Locally, or manual rule building.

## Workflow

1. Sign in with an Admin account.
2. Open Customize and select Rules Wizard.
3. Select Download Blank Rules Worksheet.
4. Enter one requirement per row without changing the column headers.
5. Upload the completed XLSX or CSV worksheet.
6. Review valid rules, invalid rows, cohort ranges, and grid-column suggestions.
7. Correct invalid rows in the worksheet and upload it again. The system does not guess.
8. Select Create Structured Draft.
9. Review the draft in Structured Graduation Rules Builder.
10. Enter or adjust diploma-plan information, then validate, approve, review impact, and activate.

## Worksheet Behavior

- The worksheet is treated as authoritative structured input.
- The document analyzer does not reinterpret worksheet values.
- Uploading creates a preview only.
- Confirming creates a draft only.
- Nothing activates until the existing Admin safeguards are completed.
- Every imported rule participates in student evaluation and appears in the student record.
- Add to Grid controls only whether the requirement is also displayed on the class grid.
- Grid columns are created from approved suggestions only when the rule package is activated.

## Supported Values

Categories: Credits, Course, Assessment, Credential, Checklist, Custom.

Rule types: Subject Credits, Total Credits, Required Course, Must Take, Must Pass, Minimum Score, Completion, Credential Earned, Manual / Custom.

Evidence sources: Transcript, Assessment Upload, Credential Upload, Completion Record, Custom Field, Manual Confirmation.

## Important Distinctions

- Must Take is met when a matching assessment attempt exists, regardless of score.
- Must Pass requires a passing result.
- Minimum Score requires a numeric Required Value and a score at or above that value.
- Required Course uses completed transcript-course evidence and preserves numbers in course names.
- Invalid rows and duplicate keys block draft creation until corrected.


## Recommended Optional Columns

The original worksheet columns remain supported. New schools can also use:

- Diploma Plan: groups rules under Standard, Advanced, College Prep, or another local plan.
- Required or Optional: controls whether the item affects overall status.
- Subject Family: must match the family used in the course-history file, such as Mathematics or Social Studies.
- Evidence Aliases: alternate names separated by semicolons.
- Student Page Section: places the rule under Credits, Required Courses, Assessments, Credentials / Other, or another heading.
- Grid Display Type: checkbox, text, number, score, date, or dropdown.

Every diploma plan must include a Total Credits row with a numeric Required Value.

## Evidence Uploads After Activation

Use **Transcript / Course History** for a spreadsheet with one row per course. Recommended columns are Student ID, First Name, Last Name, Graduation Year, Course Name, Subject Family, Credits Attempted, Credits Earned, Grade, Status, and Completion Date. This import can create students and class grids. It stores real transcript-course evidence and does not create assessment attempts.

Use **CPR/AED completion file** or another completion source for completion records. Use the same requirement name or an Evidence Alias from the worksheet. Assessment and credential files work the same way through their matching upload types.

The student page remains the complete graduation picture. Only requirements marked Add to Grid = Yes appear on the class grid.
