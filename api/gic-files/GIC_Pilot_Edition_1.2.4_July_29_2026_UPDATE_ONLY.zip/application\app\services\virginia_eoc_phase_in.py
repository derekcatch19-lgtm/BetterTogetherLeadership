import hashlib
from datetime import datetime


PHASE_SUBJECTS = {"AlgI", "Geom", "AlgII", "EngRLR"}

SCORE_RULES = {
    "AlgI": {
        "2025-2026": (400, 500, 500),
        "2026-2027": (413, 453, 518),
        "2027-2028": (426, 453, 518),
        "2028-2029": (439, 453, 518),
        "2029-2030+": (453, 453, 518),
    },
    "Geom": {
        "2025-2026": (400, 500, 500),
        "2026-2027": (413, 452, 510),
        "2027-2028": (426, 452, 510),
        "2028-2029": (439, 452, 510),
        "2029-2030+": (452, 452, 510),
    },
    "AlgII": {
        "2025-2026": (400, 500, 500),
        "2026-2027": (411, 443, 505),
        "2027-2028": (422, 443, 505),
        "2028-2029": (433, 443, 505),
        "2029-2030+": (443, 443, 505),
    },
    "EngRLR": {
        "2025-2026": (400, 500, 500),
        "2026-2027": (400, 500, 500),
        "2027-2028": (400, 500, 500),
        "2028-2029": (420, 479, 543),
        "2029-2030": (439, 479, 543),
        "2030-2031": (459, 479, 543),
        "2031-2032+": (479, 479, 543),
    },
}

DEFAULT_WINDOWS = [
    {
        "id": "va-eoc-legacy-through-2026-06-07",
        "state": "Virginia",
        "window_name": "Virginia EOC Legacy Standard",
        "school_year": "2025-2026",
        "start_date": "1900-01-01",
        "end_date": "2026-06-07",
        "assessment_group": "EOC",
        "rule_version": "2025-2026",
        "source_reference": "Virginia 400-point passing standard in effect before Summer EOC 2026",
    },
    {
        "id": "va-summer-eoc-2026",
        "state": "Virginia",
        "window_name": "Summer EOC 2026",
        "school_year": "2025-2026",
        "start_date": "2026-06-08",
        "end_date": "2026-09-30",
        "assessment_group": "EOC",
        "rule_version": "2025-2026",
        "source_reference": "Virginia transition window through September 30, 2026",
    },
    {
        "id": "va-eoc-sy-2026-2027-transition",
        "state": "Virginia",
        "window_name": "2026-2027 EOC Administrations",
        "school_year": "2026-2027",
        "start_date": "2026-10-01",
        "end_date": "2027-09-30",
        "assessment_group": "EOC",
        "rule_version": "2026-2027",
        "source_reference": "School-year assignment window: October 1, 2026-September 30, 2027",
    },
    {
        "id": "va-eoc-sy-2027-2028",
        "state": "Virginia",
        "window_name": "2027-2028 EOC Administrations",
        "school_year": "2027-2028",
        "start_date": "2027-10-01",
        "end_date": "2028-09-30",
        "assessment_group": "EOC",
        "rule_version": "2027-2028",
        "source_reference": "School-year assignment window: October 1, 2027-September 30, 2028",
    },
    {
        "id": "va-eoc-sy-2028-2029",
        "state": "Virginia",
        "window_name": "2028-2029 EOC Administrations",
        "school_year": "2028-2029",
        "start_date": "2028-10-01",
        "end_date": "2029-09-30",
        "assessment_group": "EOC",
        "rule_version": "2028-2029",
        "source_reference": "School-year assignment window: October 1, 2028-September 30, 2029",
    },
    {
        "id": "va-eoc-sy-2029-2030",
        "state": "Virginia",
        "window_name": "2029-2030 EOC Administrations",
        "school_year": "2029-2030",
        "start_date": "2029-10-01",
        "end_date": "2030-09-30",
        "assessment_group": "EOC",
        "rule_version": "2029-2030",
        "source_reference": "School-year assignment window: October 1, 2029-September 30, 2030",
    },
    {
        "id": "va-eoc-sy-2030-2031",
        "state": "Virginia",
        "window_name": "2030-2031 EOC Administrations",
        "school_year": "2030-2031",
        "start_date": "2030-10-01",
        "end_date": "2031-09-30",
        "assessment_group": "EOC",
        "rule_version": "2030-2031",
        "source_reference": "School-year assignment window: October 1, 2030-September 30, 2031",
    },
    {
        "id": "va-eoc-sy-2031-2032",
        "state": "Virginia",
        "window_name": "2031-2032 EOC Administrations",
        "school_year": "2031-2032",
        "start_date": "2031-10-01",
        "end_date": "2032-09-30",
        "assessment_group": "EOC",
        "rule_version": "2031-2032",
        "source_reference": "School-year assignment window: October 1, 2031-September 30, 2032",
    },
]


def ensure_default_windows(db):
    for item in DEFAULT_WINDOWS:
        db.execute(
            """
            INSERT INTO testing_windows
            (id, state, window_name, school_year, start_date, end_date, assessment_group,
             rule_version, source_reference, active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            ON CONFLICT(id) DO UPDATE SET
                state=excluded.state,
                window_name=excluded.window_name,
                school_year=excluded.school_year,
                start_date=excluded.start_date,
                end_date=excluded.end_date,
                assessment_group=excluded.assessment_group,
                rule_version=excluded.rule_version,
                source_reference=excluded.source_reference,
                active=1
            """,
            (
                item["id"], item["state"], item["window_name"], item["school_year"],
                item["start_date"], item["end_date"], item["assessment_group"],
                item["rule_version"], item["source_reference"],
            ),
        )


def parse_test_date(raw):
    text = str(raw or "").strip()
    if not text:
        return None
    text = text.split(" ")[0].strip()
    formats = [
        "%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d", "%Y/%m/%d",
        "%m-%d-%Y", "%m-%d-%y", "%Y%m%d",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def rule_key(subject, school_year):
    if subject == "EngRLR":
        if school_year >= "2031-2032":
            return "2031-2032+"
        return school_year if school_year in SCORE_RULES[subject] else None
    if school_year >= "2029-2030":
        return "2029-2030+"
    return school_year if school_year in SCORE_RULES.get(subject, {}) else None


def score_rule(subject, school_year):
    key = rule_key(subject, school_year)
    values = SCORE_RULES.get(subject, {}).get(key) if key else None
    if not values:
        return None
    passing, proficient, advanced = values
    return {
        "rule_version": key,
        "passing_score": passing,
        "lavc_floor": passing - 25,
        "proficient_score": proficient,
        "advanced_score": advanced,
    }


def performance_level(subject, school_year, score):
    rule = score_rule(subject, school_year)
    if not rule or score is None:
        return ""
    if score < rule["passing_score"]:
        return "Fail/Does Not Meet"
    if score < rule["proficient_score"]:
        return "Pass/Approaching"
    if score < rule["advanced_score"]:
        return "Pass/Proficient"
    return "Pass/Advanced"


def find_testing_window(db, test_date, subject):
    if not test_date:
        return None
    group = "EOC Reading" if subject == "EngRLR" else "EOC Math"
    return db.execute(
        """
        SELECT * FROM testing_windows
        WHERE active = 1 AND state = 'Virginia'
          AND start_date <= ? AND end_date >= ?
          AND assessment_group IN ('EOC', 'All', ?)
        ORDER BY CASE assessment_group WHEN ? THEN 0 WHEN 'EOC' THEN 1 ELSE 2 END, start_date
        LIMIT 1
        """,
        (test_date.isoformat(), test_date.isoformat(), group, group),
    ).fetchone()


def attempt_fingerprint(student_id, subject, normalized_date, score, test_name="", administration_id="", delivery_group=""):
    parts = [
        str(student_id or "").strip().lower(),
        str(subject or "").strip(),
        str(normalized_date or "").strip(),
        "" if score is None else str(float(score)),
        str(administration_id or "").strip().lower(),
        str(delivery_group or "").strip().lower(),
    ]
    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


def refresh_student_eoc_rules(db, student_id, previous_statuses=None):
    ensure_default_windows(db)
    previous_statuses = previous_statuses or {}
    attempts = db.execute(
        """
        SELECT * FROM test_attempts
        WHERE student_id_fk = ? AND test_area IN ('AlgI','Geom','AlgII','EngRLR')
        ORDER BY id
        """,
        (student_id,),
    ).fetchall()
    by_subject = {subject: [] for subject in PHASE_SUBJECTS}
    seen = {}
    for attempt in attempts:
        subject = attempt["test_area"]
        parsed = parse_test_date(attempt["test_date"])
        date_text = parsed.isoformat() if parsed else ""
        fingerprint = attempt_fingerprint(
            student_id, subject, date_text, attempt["score"], attempt["test_name"],
            _value(attempt, "administration_id"), _value(attempt, "delivery_group"),
        )
        duplicate = fingerprint in seen
        if not duplicate:
            seen[fingerprint] = attempt["id"]
        date_status = "Valid" if parsed else ("Missing" if not str(attempt["test_date"] or "").strip() else "Invalid")
        db.execute(
            """
            UPDATE test_attempts
            SET normalized_subject = ?, normalized_test_date = ?, date_validation_status = ?,
                attempt_fingerprint = ?, duplicate_status = ?, canonical_attempt_id = ?
            WHERE id = ?
            """,
            (
                subject, date_text or None, date_status, fingerprint,
                "Exact Duplicate" if duplicate else "Canonical",
                seen.get(fingerprint) if duplicate else attempt["id"],
                attempt["id"],
            ),
        )
        if not duplicate and attempt["score"] is not None:
            by_subject[subject].append((attempt, parsed))

    results = {}
    for subject, subject_attempts in by_subject.items():
        if not subject_attempts:
            continue
        manual = db.execute(
            "SELECT * FROM eoc_subject_rules WHERE student_id_fk=? AND normalized_subject=? AND assignment_method='Manually assigned by administrator'",
            (student_id, subject),
        ).fetchone()
        valid = [(attempt, parsed) for attempt, parsed in subject_attempts if parsed]
        earliest = sorted(valid, key=lambda item: (item[1], item[0]["id"]))[0] if valid else None
        review_reason = ""
        window = None
        rule = None
        if manual:
            rule = {
                "rule_version": manual["locked_rule_version"],
                "passing_score": manual["locked_passing_score"],
                "lavc_floor": manual["locked_lavc_floor"],
                "proficient_score": manual["proficient_score"],
                "advanced_score": manual["advanced_score"],
            }
        elif not earliest:
            review_reason = "Missing or invalid Pearson Test Date"
        else:
            window = find_testing_window(db, earliest[1], subject)
            if not window:
                review_reason = "Test Date is outside configured Virginia testing windows"
            else:
                rule = score_rule(subject, window["school_year"])
                if not rule:
                    review_reason = f"No phase-in score rule for {subject} in {window['school_year']}"

        scores = [float(attempt["score"]) for attempt, _ in subject_attempts if attempt["score"] is not None]
        highest = max(scores) if scores else None
        latest_date = max((parsed for _, parsed in valid), default=None)
        valid_count = len(valid)
        course_passed = _course_passed(db, student_id, subject)
        passed = bool(rule and highest is not None and highest >= rule["passing_score"])
        lavc = _lavc_status(rule, highest, valid_count, course_passed, passed)
        prior = previous_statuses.get(subject)
        preserved = bool(prior and prior["status"] in {"Met", "Met by LVC"})
        verified = prior["status"] if preserved else ("Met" if passed else "Not Met")
        status = "Review Required" if review_reason and not preserved else ("Passed" if passed or preserved else "Not Passed")
        initial_attempt = earliest[0] if earliest else None
        initial_date = earliest[1] if earliest else None
        assignment_method = manual["assignment_method"] if manual else ("Automatically assigned from Pearson Test Date" if rule else "Review required")
        values = {
            "student_id_fk": student_id,
            "normalized_subject": subject,
            "initial_attempt_id": manual["initial_attempt_id"] if manual else (initial_attempt["id"] if initial_attempt else None),
            "initial_attempt_date": manual["initial_attempt_date"] if manual else (initial_date.isoformat() if initial_date else None),
            "initial_attempt_window_id": manual["initial_attempt_window_id"] if manual else (window["id"] if window else None),
            "initial_attempt_school_year": manual["initial_attempt_school_year"] if manual else (window["school_year"] if window else None),
            "locked_rule_version": rule["rule_version"] if rule else None,
            "locked_passing_score": rule["passing_score"] if rule else None,
            "locked_lavc_floor": rule["lavc_floor"] if rule else None,
            "proficient_score": rule["proficient_score"] if rule else None,
            "advanced_score": rule["advanced_score"] if rule else None,
            "threshold_source": manual["threshold_source"] if manual else (window["source_reference"] if window else None),
            "assignment_method": assignment_method,
            "manual_override_reason": manual["manual_override_reason"] if manual else None,
            "valid_attempt_count": valid_count,
            "highest_valid_score": highest,
            "latest_attempt_date": latest_date.isoformat() if latest_date else None,
            "current_pass_status": status,
            "current_performance_level": performance_level(subject, window["school_year"], highest) if rule and window else _manual_performance(rule, highest),
            "lavc_eligibility_status": lavc,
            "verified_credit_status": verified,
            "review_reason": review_reason,
        }
        _save_rule(db, values)
        if review_reason:
            _ensure_flag(db, student_id, "EOC Rule Review", f"{subject}: {review_reason}. Original Test Date preserved.")
        if lavc == "Potentially LAVC eligible":
            _ensure_flag(db, student_id, "Possible LVC", f"{subject}: score is within 25 points of locked passing score; local review required.")
        results[subject] = values
    return results


def explain_rule(rule):
    if not rule:
        return "No locked EOC standard is available."
    if rule.get("review_reason"):
        return f"Review required: {rule['review_reason']}."
    subject = {
        "AlgI": "Algebra I", "Geom": "Geometry", "AlgII": "Algebra II", "EngRLR": "EOC Reading"
    }.get(rule["normalized_subject"], rule["normalized_subject"])
    return (
        f"This student first attempted {subject} during {rule['initial_attempt_school_year']}. "
        f"The passing standard remains {int(rule['locked_passing_score'])} for all {subject} retests. "
        f"The potential LAVC floor is {int(rule['locked_lavc_floor'])}."
    )


def _save_rule(db, item):
    columns = list(item)
    placeholders = ", ".join("?" for _ in columns)
    updates = ", ".join(f"{column}=excluded.{column}" for column in columns if column not in {"student_id_fk", "normalized_subject"})
    db.execute(
        f"""
        INSERT INTO eoc_subject_rules ({", ".join(columns)}, updated_at)
        VALUES ({placeholders}, CURRENT_TIMESTAMP)
        ON CONFLICT(student_id_fk, normalized_subject)
        DO UPDATE SET {updates}, updated_at=CURRENT_TIMESTAMP
        """,
        [item[column] for column in columns],
    )


def _lavc_status(rule, highest, attempts, course_passed, passed):
    if passed:
        return "SOL passed; LAVC not needed"
    if not rule:
        return "Review required"
    if attempts < 2:
        return "Needs second attempt"
    if highest is None or highest < rule["lavc_floor"]:
        return "Score below LAVC range"
    if not course_passed:
        return "Not eligible - course not passed"
    return "Potentially LAVC eligible"


def _course_passed(db, student_id, subject):
    aliases = {
        "AlgI": ("algebra i", "algebra 1"),
        "Geom": ("geometry",),
        "AlgII": ("algebra ii", "algebra 2"),
        "EngRLR": ("english 11", "english 12"),
    }[subject]
    courses = db.execute(
        "SELECT course_title, final_grade, earned_credits, status FROM transcript_courses WHERE student_id_fk=?",
        (student_id,),
    ).fetchall()
    for course in courses:
        title = (course["course_title"] or "").lower()
        grade = (course["final_grade"] or "").strip().upper()
        if any(alias in title for alias in aliases) and grade not in {"", "F"} and (course["earned_credits"] or 0) > 0:
            return True
    return False


def _manual_performance(rule, score):
    if not rule or score is None:
        return ""
    if score < rule["passing_score"]:
        return "Fail/Does Not Meet"
    if score < rule["proficient_score"]:
        return "Pass/Approaching"
    if score < rule["advanced_score"]:
        return "Pass/Proficient"
    return "Pass/Advanced"


def _ensure_flag(db, student_id, flag_type, message):
    exists = db.execute(
        "SELECT 1 FROM student_flags WHERE student_id_fk=? AND flag_type=? AND message=? AND resolved=0",
        (student_id, flag_type, message),
    ).fetchone()
    if not exists:
        db.execute(
            "INSERT INTO student_flags(student_id_fk, flag_type, message) VALUES (?, ?, ?)",
            (student_id, flag_type, message),
        )


def _value(row, key):
    try:
        return row[key]
    except (KeyError, IndexError):
        return ""
