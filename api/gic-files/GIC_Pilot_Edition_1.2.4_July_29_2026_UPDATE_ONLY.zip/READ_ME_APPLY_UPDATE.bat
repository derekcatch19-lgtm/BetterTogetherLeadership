@echo off
echo To apply this update automatically, double-click APPLY_UPDATE_NOW.bat.
echo The updater validates the installation, creates an application backup,
echo and never copies or replaces school_data.
echo.
pause
