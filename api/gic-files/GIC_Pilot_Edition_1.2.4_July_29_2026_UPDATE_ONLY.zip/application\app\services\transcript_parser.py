import os
import re
import shutil
import uuid
from datetime import date
from pathlib import Path

import pdfplumber


COURSE_AREA_PATTERNS = {
    "AlgI": ["algebra i", "algebra 1"],
    "Geom": ["geometry"],
    "AlgII": ["algebra ii", "algebra 2"],
    "AFDA": ["algebra functions and data analysis", "afda"],
    "ESCI": ["earth science"],
    "Bio": ["biology"],
    "Chem": ["chemistry"],
    "EngRLR": ["english 11", "english 12", "english 9", "english 10"],
    "EngWrit": ["english 11", "english 12"],
    "WGeo": ["world geography"],
    "WHI": ["world history i"],
    "WHII": ["world history ii"],
    "USH": ["u.s. history", "us history", "united states history", "us & va history", "va & us history", "u.s. & va history", "virginia and us history"],
    "Gov": ["u.s. government", "us government", "us & va government", "va & us government", "government"],
}


def transcript_preview(path):
    page_count, sample = _preview_sample(path)
    return {
        "columns": ["Field", "Value"],
        "suggestions": {},
        "preview": [
            {"Field": "PDF Pages", "Value": str(page_count)},
            {"Field": "Sample Student", "Value": sample.get("student_name", "")},
            {"Field": "Sample State ID", "Value": sample.get("state_id", "")},
            {"Field": "Sample Graduation Class", "Value": str(sample.get("graduation_class") or "")},
            {"Field": "Sample Completed Courses", "Value": str(len(sample["courses"]))},
            {"Field": "Sample Work In Progress Courses", "Value": str(len(sample["work_in_progress"]))},
        ],
    }


def process_transcript_upload(db, path, original_filename, stored_filename):
    results = process_transcript_batch(db, path, original_filename, stored_filename)
    matched = [result for result in results if result["student_id"]]
    if matched:
        first = matched[0]
        return first["student_id"], first["parsed"], ""
    parsed = results[0]["parsed"] if results else {}
    return None, parsed, "No matching student found by State ID or name/class."


def process_transcript_batch(db, path, original_filename, stored_filename):
    parsed_items = parse_transcripts_pdf(path)
    documents_dir = Path(path).resolve().parents[1] / "instance" / "transcripts"
    documents_dir.mkdir(parents=True, exist_ok=True)
    safe_stored = f"{uuid.uuid4().hex}_{os.path.basename(stored_filename)}"
    stored_path = documents_dir / safe_stored
    shutil.copyfile(path, stored_path)

    results = []
    processed_students = set()
    for index, parsed in enumerate(parsed_items, 1):
        student = _find_student(db, parsed)
        if not student:
            results.append({"student_id": None, "student_name": parsed.get("student_name", ""), "state_id": parsed.get("state_id", ""), "graduation_class": parsed.get("graduation_class"), "parsed": parsed, "error": "No matching student found."})
            continue

        if student["id"] not in processed_students:
            db.execute("DELETE FROM transcript_courses WHERE student_id_fk = ?", (student["id"],))
            processed_students.add(student["id"])

        doc_id = db.execute(
            """
            INSERT INTO student_documents(student_id_fk, document_type, original_filename, stored_filename)
            VALUES (?, ?, ?, ?)
            """,
            (student["id"], "Transcript", f"{original_filename} - transcript {index}", str(stored_path)),
        ).lastrowid
        for course in parsed["courses"] + parsed["work_in_progress"]:
            db.execute(
                """
                INSERT INTO transcript_courses
                (student_id_fk, school_year, grade_level, course_id, course_title, attributes,
                 final_grade, earned_credits, potential_credits, status, source_document_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    student["id"],
                    course.get("school_year"),
                    course.get("grade_level"),
                    course.get("course_id"),
                    course.get("course_title"),
                    course.get("attributes"),
                    course.get("final_grade"),
                    course.get("earned_credits") or 0,
                    course.get("potential_credits") or 0,
                    course.get("status"),
                    doc_id,
                ),
            )
        results.append({"student_id": student["id"], "student_name": f"{student['first_name']} {student['last_name']}", "state_id": parsed.get("state_id", ""), "graduation_class": student["graduation_class"], "parsed": parsed, "error": ""})
    db.commit()
    return results


def parse_transcript_pdf(path):
    items = parse_transcripts_pdf(path)
    return items[0] if items else _parse_transcript_text("")


def parse_transcripts_pdf(path):
    page_texts = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            page_texts.append(page.extract_text() or "")
    return [_parse_transcript_text(text) for text in _group_transcript_pages(page_texts) if text.strip()]


def _preview_sample(path):
    with pdfplumber.open(path) as pdf:
        page_count = len(pdf.pages)
        first_text = pdf.pages[0].extract_text() if page_count else ""
    return page_count, _parse_transcript_text(first_text or "")


def _group_transcript_pages(page_texts):
    groups = []
    current = []
    for text in page_texts:
        first_line = next((line.strip() for line in text.splitlines() if line.strip()), "")
        is_new = bool(re.search(r"\bPage\s+1\s+of\s+\d+", first_line))
        if is_new and current:
            groups.append("\n".join(current))
            current = []
        current.append(text)
    if current:
        groups.append("\n".join(current))
    return groups


def _parse_transcript_text(text):
    lines = [line.strip() for line in text.splitlines() if line.strip()]

    name = ""
    if lines:
        name = re.sub(r"\s+Page\s+\d+\s+of\s+\d+.*$", "", lines[0]).strip()
    state_id = _match_value(text, r"State ID:\s*([0-9A-Za-z-]+)")
    grade_level = _match_value(text, r"Grade Level:\s*([0-9]+)")
    courses = []
    wip = []
    current_year = ""
    current_grade = ""
    latest_year = ""
    latest_grade = grade_level
    mode = "completed"

    for line in lines:
        if line.startswith("Work in Progress"):
            mode = "wip"
            continue
        year_match = re.search(r"Year:\s*([0-9]{4}-[0-9]{4})", line)
        if year_match:
            current_year = year_match.group(1)
            grade_match = re.search(r"Grade Level:\s*([0-9]+)", line)
            if grade_match:
                current_grade = grade_match.group(1)
            elif mode == "wip" and current_grade:
                current_grade = str(int(current_grade) + 1)
            latest_year = current_year
            latest_grade = current_grade or latest_grade
            continue
        if line.startswith("Standardized Tests") or line.startswith("Credentials"):
            mode = "ignore"
            continue
        if line.startswith("Totals:"):
            mode = "completed"
            continue
        parsed = _parse_course_line(line, current_year, current_grade, mode)
        if parsed:
            if mode == "wip":
                wip.append(parsed)
            else:
                courses.append(parsed)

    return {
        "student_name": name,
        "state_id": state_id,
        "grade_level": grade_level,
        "graduation_class": _grad_class_from_grade(latest_grade, latest_year),
        "courses": courses,
        "work_in_progress": wip,
        "raw_text": text,
    }


def course_area(course_title):
    text = (course_title or "").lower()
    for key, patterns in COURSE_AREA_PATTERNS.items():
        if any(pattern in text for pattern in patterns):
            return key
    return ""


def _parse_course_line(line, school_year, grade_level, mode):
    if not re.match(r"^\d{5}\s+", line):
        return None
    parts = line.split()
    course_id = parts[0]
    if mode == "wip":
        credit_index, credit = _last_float_index(parts)
        if credit is None:
            return None
        title_tokens = parts[1:credit_index]
        attrs = _extract_attrs(title_tokens)
        return {
            "school_year": school_year,
            "grade_level": grade_level,
            "course_id": course_id,
            "course_title": " ".join(title_tokens).strip(),
            "attributes": attrs,
            "final_grade": "",
            "earned_credits": 0,
            "potential_credits": credit,
            "status": "Work In Progress",
        }
    credit_index, credit = _last_float_index(parts)
    if credit is None or credit_index < 3:
        return None
    final_grade = parts[credit_index - 1]
    title_tokens = parts[1:credit_index - 1]
    attrs = _extract_attrs(title_tokens)
    return {
        "school_year": school_year,
        "grade_level": grade_level,
        "course_id": course_id,
        "course_title": " ".join(title_tokens).strip(),
        "attributes": attrs,
        "final_grade": final_grade,
        "earned_credits": credit,
        "potential_credits": 0,
        "status": "Completed",
    }


def _extract_attrs(tokens):
    attrs = []
    while tokens and tokens[-1] in {"H", "DE", "AP", "IB", "A", "AC", "SC", "DL", "S"}:
        attrs.append(tokens.pop())
    return " ".join(reversed(attrs))


def _last_float(parts):
    _, value = _last_float_index(parts)
    return value


def _last_float_index(parts):
    for index in range(len(parts) - 1, -1, -1):
        try:
            return index, float(parts[index])
        except (ValueError, TypeError):
            continue
    return -1, None

    try:
        return float(parts[-1])
    except (ValueError, IndexError):
        return None


def _find_student(db, parsed):
    state_id = parsed.get("state_id")
    grad_class = parsed.get("graduation_class")
    if state_id and grad_class:
        row = db.execute(
            "SELECT * FROM students WHERE student_id = ? AND graduation_class = ?",
            (state_id, grad_class),
        ).fetchone()
        if row:
            return row
    if state_id:
        rows = db.execute("SELECT * FROM students WHERE student_id = ?", (state_id,)).fetchmany(2)
        if len(rows) == 1:
            return rows[0]
    last, first = _split_name(parsed.get("student_name", ""))
    if last and first and grad_class:
        row = db.execute(
            """
            SELECT * FROM students
            WHERE lower(last_name) = lower(?) AND lower(first_name) = lower(?) AND graduation_class = ?
            """,
            (last, first, grad_class),
        ).fetchone()
        if row:
            return row
    if last and first:
        rows = db.execute(
            "SELECT * FROM students WHERE lower(last_name)=lower(?) AND lower(first_name)=lower(?)",
            (last, first),
        ).fetchmany(2)
        if len(rows) == 1:
            return rows[0]
    return None


def _split_name(name):
    if "," in name:
        last, rest = name.split(",", 1)
        return last.strip(), rest.strip().split()[0] if rest.strip() else ""
    parts = name.split()
    return (parts[-1], parts[0]) if len(parts) >= 2 else ("", "")


def _match_value(text, pattern):
    match = re.search(pattern, text)
    return match.group(1).strip() if match else ""


def _grad_class_from_grade(value, school_year=""):
    try:
        grade = int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None
    start_year = None
    match = re.search(r"([0-9]{4})-[0-9]{4}", school_year or "")
    if match:
        start_year = int(match.group(1))
    if start_year is None:
        today = date.today()
        start_year = today.year if today.month >= 7 else today.year - 1
    return start_year + (12 - grade) + 1
