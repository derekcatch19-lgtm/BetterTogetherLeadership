# Backup and Restore Guide

Backups are stored in the configured data folder under `backups`.

The app creates an automatic backup before:

- Upload processing
- Startup database migrations
- Class grid deletion
- Backup restore

Admins can also create a manual backup from:

```text
Admin > Backups
```

Restore replaces the active database with a selected backup. The restore page requires typing `RESTORE`, and the app creates a safety backup before replacing the database.

Recommended practice:

- Create a manual backup before large imports.
- Copy the `backups` folder to secure school storage regularly.
- Never store backups in personal cloud accounts.

