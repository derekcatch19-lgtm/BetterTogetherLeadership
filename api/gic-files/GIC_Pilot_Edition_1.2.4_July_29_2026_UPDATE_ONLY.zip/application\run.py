if __name__ == "__main__":
    from app.local_server import main

    main()
