# Demo Package Guide

The demo package is for showing the Graduation Intelligence Center without using real student data.

## What Is Included

The demo data folder contains fake students only. It is intended for:

- Sales demonstrations
- Training sessions
- Staff orientation
- Testing reports
- Verifying install steps

Do not mix demo data with a real school installation.

## Recommended Demo Flow

1. Start the program.
2. Sign in as the demo Admin or create a first Admin if prompted.
3. Open Class Grids.
4. Open a fake student profile.
5. Show SOL or assessment attempt history.
6. Show graduation status.
7. Show the 3E or readiness card, if using the Virginia template.
8. Open Reports.
9. Export a sample Excel report.
10. Open the Troubleshooter to explain unmatched upload review.
11. Open Admin tools to show customization.

## Talking Points

The system is designed to help schools:

- Combine graduation tracking into one local dashboard.
- Keep student data on school-controlled storage.
- Upload state testing, transcripts, credentials, CPR, and local spreadsheets.
- Review unmatched records instead of losing them.
- Generate print-ready counselor reports.
- Customize rules for the school or state.

## Demo Rules

Use fake students only.

Do not upload:

- Real transcripts
- Real state testing files
- Real student identifiers
- Real parent information
- Real discipline or financial information

## Switching From Demo to Real Use

For a real school installation:

1. Stop the demo server.
2. Use a clean `school_data` folder from the blank data template.
3. Complete first-time setup for the real school.
4. Create real staff users.
5. Make a backup.
6. Upload one small real file.
7. Review the Troubleshooter.
8. Continue with full imports only after the school confirms the rules and matching behavior.

## Demo Checklist

Before giving the demo:

- The app starts from the launcher.
- Login works.
- Demo students appear.
- Student profiles open.
- Reports page opens.
- Excel export downloads.
- Rules Wizard opens.
- No real student data is present.

