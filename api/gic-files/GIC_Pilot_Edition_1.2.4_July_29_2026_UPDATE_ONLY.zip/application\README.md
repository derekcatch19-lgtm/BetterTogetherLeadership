# Graduation Intelligence Center

A secure local web application for school counselors and administrators to track graduation requirements, SOL testing, verified credits, credentials, 3E readiness, transcript progress, and student graduation reports.

The default runner uses Python's built-in local HTTP server with SQLite, OpenPyXL, and ReportLab. Student data is stored locally in the configured data folder.

## Privacy and Security

- Requires login before student data is visible.
- Supports Admin, Counselor, and Teacher Viewer roles.
- Stores passwords as salted PBKDF2 hashes.
- Keeps uploads, exports, reports, backups, logs, settings, and the database in the local data folder.
- Shows FERPA/privacy reminders on login and before exports.
- Logs uploads, exports, edits, deletions, backups, restores, report saves, logins, and user changes.
- Does not intentionally send student data to external APIs.

## First-Time Setup

On a blank install, open the app and complete the first-time setup wizard. The wizard creates the school profile and first Admin account. No default admin password is created for distributable installs.

## Quick Start

```powershell
python run.py
```

Open:

```text
http://127.0.0.1:5000
```

For internal school-network access, run with a shared data folder and network host:

```powershell
$env:GIC_DATA_DIR="D:\GraduationIntelligenceData"
$env:GIC_HOST="0.0.0.0"
$env:GIC_PORT="5000"
python run.py
```

Staff can then browse to `http://SERVER-IP:5000` while the host computer/server is on.

## Main Features

- Graduation class grids.
- Upload preview and column mapping.
- SOL score tracking with highest-score logic and attempt history.
- LVC/CA indicators.
- Transcript parsing and credit progress.
- 3E Readiness summaries and detailed reports.
- Cougar Scholars reports.
- Graduation agreements.
- Credit and SOL checklists.
- Excel and PDF exports.
- Backup and restore.
- User management and audit log.

## Update Safety

Keep application code separate from the data folder. During updates, replace only the application files and keep `GIC_DATA_DIR` pointed to the existing data folder. The app creates a backup before startup migrations.
