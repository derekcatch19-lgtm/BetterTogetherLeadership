# Install Guide for Schools

This guide is for school IT staff or the person setting up the Graduation Intelligence Center.

## Package Options

### Portable Full Install

Best for most schools.

Includes:

- Application files
- Private Python runtime
- Blank data template
- Demo data with fake students
- Documentation
- Windows launcher

The school should extract the package to a stable folder, such as:

`C:\GraduationIntelligenceCenter`

Then run:

`Start Graduation Intelligence Center.bat`

### Update Package

Use only for an existing installation.

The update package should include:

- Application updates
- Docs
- Migrations
- Launcher, if needed

It must not replace:

- `school_data`
- Student database
- Users
- School settings
- Uploads
- Reports
- Exports
- Backups

## Recommended Folder Structure

The installed folder should look like this:

```text
GraduationIntelligenceCenter
  application
  school_data
  blank_data_template
  demo_data
  docs
  Start Graduation Intelligence Center.bat
```

The `school_data` folder is the school-owned data folder. Never overwrite it during an update.

## Local Desktop Setup

Use this when one person runs the app on one computer.

1. Extract the full install package.
2. Double-click `Start Graduation Intelligence Center.bat`.
3. Complete first-time setup.
4. Sign in with the Admin account.
5. Upload data and review results.

The app runs at:

`http://127.0.0.1:5000`

## Local School Server Setup

Use this when multiple counselors or administrators need browser access.

1. Install the package on an approved school server or always-on workstation.
2. Store the folder on a local drive controlled by the school.
3. Configure backups for the `school_data` folder.
4. Allow inbound access to the selected app port only from the local school network.
5. Start the app with the host set to the local network.

Typical local network address:

`http://SERVER-IP-ADDRESS:5000`

The host computer must remain on and the server window must remain running.

## Data Safety

All student files stay local unless the school moves or copies them. The app should not send student records to external services.

Back up:

- `school_data\ahs_tracking.sqlite3`
- `school_data\uploads`
- `school_data\exports`
- `school_data\reports`
- `school_data\backups`
- `school_data\logs`

Backups should be stored on approved school storage.

## Before Giving Staff Access

Confirm:

- Login is required.
- Admin account exists.
- Counselor and viewer accounts are created.
- Teacher Viewer role cannot edit student data.
- Backup and restore have been tested.
- Demo data has been removed before using real data.
- FERPA/local data expectations have been reviewed.

