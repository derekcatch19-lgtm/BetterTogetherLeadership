# Local Server Setup Guide

1. Copy the application code folder to a school-owned Windows server or always-on workstation.
2. Choose a permanent data folder, such as `D:\GraduationIntelligenceData`.
3. Start PowerShell in the application folder.
4. Set the data folder and network host:

```powershell
$env:GIC_DATA_DIR="D:\GraduationIntelligenceData"
$env:GIC_HOST="0.0.0.0"
$env:GIC_PORT="5000"
python run.py
```

5. Find the server IP address:

```powershell
ipconfig
```

6. Staff on the school network can open `http://SERVER-IP:5000`.

The server must remain on. If Windows Firewall blocks the page, allow inbound access to the selected port only on the school/private network.

## Pilot Security Notes

- Do not expose port 5000 directly to the public internet.
- Use a fixed internal IP or school DNS name so staff have one stable address.
- Restrict the Windows Firewall rule to the school/private network and approved subnets.
- Store `GIC_DATA_DIR` on school-managed storage that is included in the division backup plan.
- The built-in server uses HTTP. If division policy requires HTTPS, IT should place it behind the division's approved internal HTTPS reverse proxy.
- The default upload limit is 512 MB. IT may lower it by setting `GIC_MAX_REQUEST_MB`.
- Inactive sessions expire after eight hours. IT may lower this with `GIC_SESSION_HOURS`.
