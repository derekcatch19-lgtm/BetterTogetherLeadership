# Import Guide

Use the Upload page for:

- Existing graduation tracking sheets
- Pearson SOL score reports
- History PBA results
- Transcript PDFs
- Workplace Readiness reports
- NCRC reports
- CPR/AED files
- ASVAB / 3E documentation

Before each upload, the app saves the file locally and shows a preview/mapping screen. Processing an upload creates an automatic database backup first.

Best practice:

- Upload one source at a time.
- Review warnings after upload.
- Spot-check a few student profiles and the class grid.
- Use the audit log to confirm who uploaded what and when.

