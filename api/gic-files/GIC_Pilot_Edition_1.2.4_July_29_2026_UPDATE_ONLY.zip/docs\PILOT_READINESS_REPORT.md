# Pilot Readiness Report

Version: 1.0.0-pilot

## Ready for a Controlled Pilot

- First-time setup requires creation of a local Admin account.
- Passwords are salted and hashed; plain-text passwords are not stored.
- Admin, Counselor, and Teacher Viewer permissions are enforced.
- Disabled accounts lose active-session access immediately.
- Repeated failed logins are temporarily throttled.
- Student data, uploads, reports, logs, settings, and backups remain in `school_data`.
- Automatic backups run before uploads, restores, and migrations.
- Blank package data contains zero users, students, and uploads.
- Demo data contains five fake students only.
- A clean Class of 2031 roster/grid import and subsequent assessment update pass automated tests.

## Required School IT Controls

- Run on a school-managed Windows server or always-on workstation.
- Restrict access to the internal school/private network.
- Do not expose the built-in HTTP server directly to the public internet.
- Include `school_data` in an approved encrypted backup process.
- Apply operating-system updates and endpoint protection.
- Use unique staff accounts and disable access promptly when roles change.

## Pilot Operating Limits

- Graduation rules must be reviewed and approved by the school; software output is decision support, not the official student record.
- The pilot should begin with fake data, followed by one small real roster and a counselor spot-check.
- SQLite is suitable for a small counseling-office pilot. Avoid very high concurrent write activity.
- The built-in server does not provide HTTPS by itself. Use an approved internal reverse proxy when HTTPS is required.
- Backups protect the database; school IT should also back up uploaded documents and generated records in the complete `school_data` folder.

## Developer Release Verification

The source release is verified before packaging with:

```powershell
python -m unittest discover -s tests -v
```

The release test suite verifies blank/demo privacy, roster-to-grid creation, assessment updating, password hashing, and automatic backup retention.
