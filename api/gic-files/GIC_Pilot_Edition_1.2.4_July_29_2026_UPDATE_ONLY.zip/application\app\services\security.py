import csv
import os
import re
import zipfile
from pathlib import Path


UPLOAD_EXTENSIONS = {".csv", ".xlsx", ".xlsm", ".xls", ".pdf"}
RULE_EXTENSIONS = UPLOAD_EXTENSIONS | {".docx", ".txt", ".html", ".htm"}
ZIP_DOCUMENT_EXTENSIONS = {".xlsx", ".xlsm", ".docx"}
OLE_DOCUMENT_EXTENSIONS = {".xls"}


class FileValidationError(ValueError):
    pass


def safe_child(root, candidate, *, must_exist=True):
    root_path = Path(root).resolve(strict=True)
    candidate_path = Path(candidate)
    if not candidate_path.is_absolute():
        candidate_path = root_path / candidate_path
    resolved = candidate_path.resolve(strict=must_exist)
    try:
        resolved.relative_to(root_path)
    except ValueError as exc:
        raise FileValidationError("The requested file is outside the approved local data folder.") from exc
    if must_exist and (resolved.is_symlink() or not resolved.is_file()):
        raise FileValidationError("The requested local file is not available.")
    return resolved


def validate_uploaded_file(path, original_name, *, category="data", max_bytes=None):
    file_path = Path(path)
    suffix = Path(original_name or "").suffix.lower()
    allowed = RULE_EXTENSIONS if category == "rules" else UPLOAD_EXTENSIONS
    if suffix not in allowed:
        raise FileValidationError("This file type is not supported.")
    if _double_extension(original_name):
        raise FileValidationError("Files with executable or ambiguous double extensions are not accepted.")
    size = file_path.stat().st_size
    if size <= 0:
        raise FileValidationError("The uploaded file is empty.")
    if max_bytes is not None and size > max_bytes:
        raise FileValidationError("The uploaded file exceeds the configured size limit.")
    header = file_path.read_bytes()[:16]
    if suffix == ".pdf":
        if not header.startswith(b"%PDF-"):
            raise FileValidationError("The file does not contain a valid PDF signature.")
    elif suffix in ZIP_DOCUMENT_EXTENSIONS:
        if not header.startswith(b"PK") or not zipfile.is_zipfile(file_path):
            raise FileValidationError("The file does not contain a valid Office document signature.")
        _validate_zip_document(file_path, suffix)
    elif suffix in OLE_DOCUMENT_EXTENSIONS:
        if not header.startswith(bytes.fromhex("D0CF11E0A1B11AE1")):
            raise FileValidationError("The file does not contain a valid legacy Excel signature.")
    elif suffix in {".csv", ".txt", ".html", ".htm"}:
        if b"\x00" in file_path.read_bytes()[:4096]:
            raise FileValidationError("The text file contains binary content.")
        if suffix == ".csv":
            _validate_csv(file_path)
    return {
        "extension": suffix,
        "size": size,
        "category": category,
        "validation": "Passed",
    }


def _double_extension(name):
    parts = [part.lower() for part in Path(name or "").name.split(".") if part]
    dangerous = {".exe", ".com", ".bat", ".cmd", ".ps1", ".js", ".vbs", ".scr", ".msi"}
    return len(parts) > 2 and any(f".{part}" in dangerous for part in parts[:-1])


def _validate_zip_document(path, suffix):
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        if len(infos) > 20000:
            raise FileValidationError("The Office document contains too many embedded entries.")
        compressed = sum(max(info.compress_size, 1) for info in infos)
        expanded = sum(info.file_size for info in infos)
        if expanded > 512 * 1024 * 1024 or expanded / max(compressed, 1) > 200:
            raise FileValidationError("The Office document expands beyond safe processing limits.")
        names = {info.filename for info in infos}
        required = "word/document.xml" if suffix == ".docx" else "xl/workbook.xml"
        if required not in names:
            raise FileValidationError("The Office document structure is incomplete.")
        if any(re.search(r"(^|/)(vbaProject|macros?)", name, re.I) for name in names):
            raise FileValidationError("Macro-enabled content is not accepted for local processing.")


def _validate_csv(path):
    with open(path, "r", encoding="utf-8-sig", errors="strict", newline="") as handle:
        sample = handle.read(65536)
    if not sample.strip():
        raise FileValidationError("The CSV file contains no readable data.")
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
        next(csv.reader([sample.splitlines()[0]], dialect))
    except (csv.Error, StopIteration) as exc:
        raise FileValidationError("The CSV file structure could not be validated.") from exc
