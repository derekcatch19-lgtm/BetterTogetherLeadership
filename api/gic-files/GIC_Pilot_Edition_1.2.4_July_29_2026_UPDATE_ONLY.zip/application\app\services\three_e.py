from datetime import datetime
import re


def three_e_readiness(db, student_id):
    statuses = {
        row["requirement_key"]: row
        for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ?", (student_id,)).fetchall()
    }
    attempts = db.execute("SELECT * FROM test_attempts WHERE student_id_fk = ?", (student_id,)).fetchall()
    courses = db.execute("SELECT * FROM transcript_courses WHERE student_id_fk = ?", (student_id,)).fetchall()

    enrollment = _enrollment_points(courses)
    employment = _employment_points(statuses, attempts, courses)
    enlistment = _enlistment_points(attempts)
    total = round(enrollment["points"] + employment["points"] + enlistment["points"], 2)
    pathways = [name for name, item in [("Enrollment", enrollment), ("Employment", employment), ("Enlistment", enlistment)] if item["points"] > 0]
    highest = max([("Enrollment", enrollment["points"]), ("Employment", employment["points"]), ("Enlistment", enlistment["points"])], key=lambda item: item[1])
    last_updated = _last_updated(statuses, attempts, courses)

    if total == 0:
        summary = "3E: None"
        status = "No 3E Evidence"
        color = "none"
    elif len(pathways) == 3:
        summary = f"3E: {_fmt(total)} - All 3 Pathways"
        status = "On Track"
        color = _color(total)
    elif len(pathways) >= 2:
        summary = f"3E: {_fmt(total)} - {' + '.join(pathways)}"
        status = "On Track" if total >= 1 else "Building"
        color = _color(total)
    else:
        summary = f"3E: {_fmt(total)} - {pathways[0]}" if pathways else "3E: Needs Review"
        status = "On Track" if total >= 1 else "Building"
        color = _color(total)

    if any(item["needs_review"] for item in [enrollment, employment, enlistment]):
        status = "Needs Review"
        if total == 0:
            summary = "3E: Needs Review"
        color = "review"

    return {
        "summary": summary,
        "status": status,
        "color": color,
        "total_points": total,
        "highest_pathway": highest[0] if highest[1] > 0 else "",
        "last_updated": last_updated,
        "data_source": _data_source(enrollment, employment, enlistment),
        "enrollment": enrollment,
        "employment": employment,
        "enlistment": enlistment,
        "recommended_action": _recommended_action(enrollment, employment, enlistment, total),
    }


def three_e_report_rows(db, grad_class=None, view_filter="all"):
    sql = """
        SELECT s.*
        FROM students s
        JOIN class_grid_members m ON m.student_id_fk = s.id
        WHERE 1=1
    """
    params = []
    if grad_class:
        sql += " AND m.graduation_class = ?"
        params.append(int(grad_class))
    sql += " ORDER BY m.graduation_class, s.last_name, s.first_name"
    rows = []
    for student in db.execute(sql, params).fetchall():
        readiness = three_e_readiness(db, student["id"])
        if view_filter == "no-evidence" and readiness["total_points"] > 0:
            continue
        if view_filter == "close" and not (0 < readiness["total_points"] < 1):
            continue
        rows.append({"student": student, "readiness": readiness})
    return rows


def three_e_hover(readiness):
    return "\n".join([
        f"Enrollment: {_fmt(readiness['enrollment']['points'])} - {readiness['enrollment']['evidence'] or 'No evidence'}",
        f"Employment: {_fmt(readiness['employment']['points'])} - {readiness['employment']['evidence'] or 'No evidence'}",
        f"Enlistment: {_fmt(readiness['enlistment']['points'])} - {readiness['enlistment']['evidence'] or 'No ASVAB score'}",
        f"Total: {_fmt(readiness['total_points'])}",
        f"Last Updated: {readiness['last_updated'] or 'No dated evidence'}",
        f"Data Source: {readiness['data_source'] or 'None'}",
    ])


def _enrollment_points(courses):
    evidence = []
    associate = False
    ap_ib = []
    dual = []
    grades = []
    early_college = False
    for course in courses:
        title = course["course_title"] or ""
        attrs = (course["attributes"] or "").upper().split()
        text = f"{title} {course['attributes'] or ''}".lower()
        grade = (course["final_grade"] or "").upper()
        if grade == "F":
            continue
        if "associate" in text:
            associate = True
        if "early college scholar" in text:
            early_college = True
        if any(attr in {"DE"} for attr in attrs) or "dual enrollment" in text or re.search(r"\bde\b", text):
            dual.append(title)
            grades.append(grade or "IP")
        if any(attr in {"AP", "IB", "CAMBRIDGE", "CLEP", "H"} for attr in attrs) or any(term in text for term in ["advanced placement", "cambridge", "clep", "honors"]):
            ap_ib.append(title)
    points = 0
    if associate:
        points = 1
    elif dual:
        points = 0.75
    elif ap_ib or early_college:
        points = 0.5
    evidence = []
    if associate:
        evidence.append("Associate degree evidence")
    if dual:
        evidence.append("Dual enrollment: " + "; ".join(dual[:4]))
    if ap_ib:
        evidence.append("AP/IB/Cambridge/CLEP/Honors: " + "; ".join(ap_ib[:4]))
    if early_college:
        evidence.append("Early College Scholar")
    return {
        "points": points,
        "evidence": "; ".join(evidence),
        "associate_degree": "Yes" if associate else "",
        "advanced_evidence": "; ".join(ap_ib),
        "dual_courses": "; ".join(dual),
        "dual_grades": "; ".join(grades),
        "early_college_scholar": "Yes" if early_college else "",
        "needs_review": False,
        "source": "Transcript" if evidence else "",
    }


def _employment_points(statuses, attempts, courses):
    credential_evidence = []
    credential_met = False
    high_demand = False
    wbl = []
    for key in ["Credential Test", "NCRC", "Workplace Readiness"]:
        row = statuses.get(key)
        if row and row["status"] == "Met":
            credential_met = True
            credential_evidence.append(row["display_value"] or key)
    for attempt in attempts:
        text = f"{attempt['credential_name'] or ''} {attempt['raw_score'] or ''} {attempt['test_name'] or ''} {attempt['test_area'] or ''}".lower()
        if "high-demand" in text or "high demand" in text:
            high_demand = True
        if "work-based" in text or "work based" in text or "internship" in text or "apprentice" in text:
            wbl.append(attempt["credential_name"] or attempt["test_name"] or attempt["raw_score"] or "Work-based learning")
    for course in courses:
        text = f"{course['course_title'] or ''} {course['attributes'] or ''}".lower()
        if "work-based" in text or "work based" in text or "internship" in text or "apprentice" in text:
            wbl.append(course["course_title"])
    cte_completer = any("cte completer" in f"{a['raw_score'] or ''} {a['credential_name'] or ''} {a['test_name'] or ''}".lower() for a in attempts)
    points = 0.75 if credential_met else 0
    if wbl:
        points = max(points, 0.5)
    evidence = []
    if credential_evidence:
        evidence.append("Credential: " + "; ".join(credential_evidence))
    if cte_completer:
        evidence.append("CTE completer")
    if wbl:
        evidence.append("Work-based learning: " + "; ".join(wbl[:3]))
    return {
        "points": points,
        "evidence": "; ".join(evidence),
        "cte_completer": "Yes" if cte_completer else "",
        "credential_earned": "Yes" if credential_met else "",
        "credential_name": "; ".join(credential_evidence),
        "high_demand_credential": "Yes" if high_demand else "",
        "work_based_learning": "Yes" if wbl else "",
        "work_based_learning_type": "; ".join(wbl),
        "needs_review": False,
        "source": "Credential/WBL Upload" if evidence else "",
    }


def _enlistment_points(attempts):
    scores = [a["score"] for a in attempts if (a["test_area"] or "").lower() == "asvab" and a["score"] is not None]
    best = max(scores) if scores else None
    if best is None:
        points = 0
        band = ""
    elif best >= 66:
        points = 1
        band = "66+"
    elif best >= 50:
        points = 0.75
        band = "50-65"
    elif best >= 31:
        points = 0.5
        band = "31-49"
    else:
        points = 0
        band = "Below 31"
    return {
        "points": points,
        "evidence": f"ASVAB/AFQT {int(best)}" if best is not None else "",
        "asvab_score": int(best) if best is not None else "",
        "asvab_band": band,
        "needs_review": False,
        "source": "ASVAB Upload" if best is not None else "",
    }


def _last_updated(statuses, attempts, courses):
    dates = []
    for row in statuses.values():
        if row["updated_at"]:
            dates.append(row["updated_at"])
    for attempt in attempts:
        if attempt["test_date"]:
            dates.append(attempt["test_date"])
        elif attempt["created_at"]:
            dates.append(attempt["created_at"])
    for course in courses:
        if course["created_at"]:
            dates.append(course["created_at"])
    if not dates:
        return ""
    value = sorted(str(d) for d in dates)[-1]
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%m/%d/%Y"):
        try:
            return datetime.strptime(value[:19], fmt).strftime("%m/%d/%Y")
        except ValueError:
            pass
    return value[:10]


def _data_source(*items):
    return "; ".join(item["source"] for item in items if item["source"])


def _recommended_action(enrollment, employment, enlistment, total):
    if total >= 1:
        return "Maintain evidence and review for higher 3E pathway totals."
    options = []
    if enrollment["points"] == 0:
        options.append("review AP/Honors/Dual Enrollment transcript evidence")
    if employment["points"] == 0:
        options.append("review credential, WPR/NCRC, CTE completer, or work-based learning evidence")
    if enlistment["points"] == 0:
        options.append("review ASVAB opportunity")
    return "Next opportunity: " + "; ".join(options) if options else "Needs counselor review."


def _color(total):
    if total >= 1:
        return "green"
    if total >= 0.75:
        return "orange"
    if total >= 0.5:
        return "yellow"
    return "none"


def _fmt(value):
    return f"{float(value):.2f}"
