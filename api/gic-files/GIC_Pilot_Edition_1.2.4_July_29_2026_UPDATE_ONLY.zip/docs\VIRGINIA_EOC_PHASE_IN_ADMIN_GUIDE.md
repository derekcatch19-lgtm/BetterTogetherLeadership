# Virginia EOC Proficiency Phase-In

## Effective Transition

- Virginia EOC tests dated through September 11, 2026 use the 2025-26 passing standard.
- New 2026-27 EOC tests begin September 12, 2026.
- A student's first valid attempt determines the passing standard for that subject.
- All later retests in that subject keep the same locked standard.
- Verified credits and locally approved LVC/credit accommodations already earned are preserved.

## 2026-27 Passing Scores

| Subject | Passing | Potential LAVC Floor | Proficient | Advanced |
|---|---:|---:|---:|---:|
| Algebra I | 413 | 388 | 453 | 518 |
| Geometry | 413 | 388 | 452 | 510 |
| Algebra II | 411 | 386 | 443 | 505 |
| EOC Reading | 400 | 375 | 500 | 500 |

The full four-year tables are maintained in
`app/services/virginia_eoc_phase_in.py`.

## What Users See

Each student profile includes a Virginia EOC Phase-In section showing:

- initial valid attempt date;
- initial testing window and school year;
- locked passing score;
- locked potential LAVC floor;
- highest valid score;
- current performance level;
- LAVC review status; and
- any date or window issue requiring review.

Exact duplicate uploads are retained for audit history but counted once.

## Admin Testing Windows

Open **Customize > Virginia Testing Windows**. Admins can add future official
testing windows after VDOE publishes them. Dates must use `YYYY-MM-DD`, and the
start date cannot be later than the end date. Changes are audit logged.

Do not change a historical window merely to make a score pass. Correct a wrong
test date in the student record or document an approved manual exception.

## Review Rules

The system flags a record for review when:

- the Pearson test date is missing or invalid;
- the date is outside configured Virginia windows; or
- no score rule exists for the subject and school year.

The system does not guess a window. Existing earned credit is preserved while
the record is under review.

LAVC remains a local approval decision. The software identifies potential
eligibility based on the locked threshold, two valid attempts, and a passed
course; it does not automatically award the credit.

## Source Notes

Implemented from the supplied VDOE phase-in implementation materials,
school-year comparison tables, point comparison table, DDOT legislative update,
and the school-confirmed September 12, 2026 transition boundary. The 100-point
reporting-scale change is tracked as a separate future display/import concern;
graduation calculations continue to preserve the source 0-600 scaled score.
