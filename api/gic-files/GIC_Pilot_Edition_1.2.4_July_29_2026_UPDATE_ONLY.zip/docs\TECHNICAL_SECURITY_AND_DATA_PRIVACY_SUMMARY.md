# Graduation Intelligence Center

## Technical Security and Data Privacy Summary

**Review date:** July 25, 2026  
**Reviewed implementation:** Pilot Version, active `app/local_server.py` server and associated services  
**Purpose:** Technical support for FERPA, Virginia student-data privacy, district security, and pilot-review documents

This document describes the application as implemented in the reviewed source code. It is not a legal opinion or a certification of FERPA, Virginia, or district-policy compliance. Compliance also depends on district configuration, contracts, procedures, staff practices, network controls, and retention requirements.

No passwords, security keys, student records, or other secrets are included in this summary.

## 1. Application Architecture

### Technology

- The active application is written in Python.
- The web server is Python's built-in `ThreadingHTTPServer` with a custom `BaseHTTPRequestHandler`; the active runner does not use Flask or another production web framework.
- SQLite is used for structured data.
- Pandas and OpenPyXL process spreadsheet imports and create Excel exports.
- PDFPlumber extracts transcript and rules-document text from PDFs.
- ReportLab generates PDF reports.
- HTML and CSS provide the browser interface.

Some Flask-oriented files remain in the source tree, but `run.py` starts `app.local_server.main`; the built-in local server is the reviewed runtime.

### Application Model

- It is a browser-based local/server application, not a native desktop application and not a hosted cloud service.
- On a single computer, the service normally binds to `127.0.0.1` and users open `http://127.0.0.1:5000`.
- For multiple users, district IT can bind the service to a local network interface and staff open the server's internal IP address or internal DNS name.
- The host computer or server must remain powered on and the application process must remain running.

### Supported Operating Systems

- The packaged launcher and tested distribution target Microsoft Windows.
- The Python source may be portable to other operating systems, but macOS and Linux installation, launcher behavior, permissions, and security have not been formally tested or documented as supported.

### Internet Requirement

- Internet access is not required for normal application use.
- The reviewed active application contains no intentional external API, analytics, telemetry, crash-reporting, cloud-storage, or AI-service integration.
- Installing Python or dependencies for the non-portable package may require internet access. The portable package includes a private Python runtime.

## 2. Data Storage

### Database and General Location

- The database is a local SQLite file named `ahs_tracking.sqlite3`.
- A packaged installation stores school data under the installation's `school_data` folder.
- A server installation can set `GIC_DATA_DIR` to an approved district folder such as a protected local or server volume.
- Without an environment override, a new source installation uses the application's `data` folder.
- A legacy installation that already contains `instance/ahs_tracking.sqlite3` continues using the `instance` folder.

The configured data area is intended to contain:

- Database
- Uploaded source files
- Generated exports
- Generated/saved reports and agreements
- Backups
- Error logs
- Local settings
- Rules documents

### Local Custody and External Transmission

- The application reads and writes files on the local computer or district server.
- No reviewed feature intentionally sends student information to the developer, an external API, an AI service, cloud storage, analytics, telemetry, or crash-reporting service.
- The rules-document analyzer is deterministic local code. It does not call an external AI model.
- Data can leave the system when an authorized user downloads, prints, copies, emails, moves, or otherwise shares an export. Those actions are outside application control after download.

### Encryption

- SQLite databases, uploaded documents, exports, reports, logs, and backups are not encrypted by the application.
- Encryption at rest depends on district controls such as BitLocker, encrypted server volumes, encrypted backups, and protected network storage.
- The built-in server uses HTTP and does not provide TLS/HTTPS.
- Encryption in transit depends on district IT placing the service behind an approved HTTPS reverse proxy or equivalent secure network control.

### Temporary and Retained Files

- Uploaded files are saved locally before preview and processing.
- Source spreadsheet and PDF uploads are retained in the upload area; there is no automatic post-processing deletion.
- Transcript PDFs are also copied into a transcript-document location and linked to student records.
- Rules-wizard documents are retained locally for review.
- Generated Excel exports and saved PDF reports are retained locally.
- These files can contain directly identifiable student information.
- The application does not provide a general temporary-file cleanup or retention scheduler.
- Error logs can contain exception text, stack traces, filenames, paths, or values involved in a failure and should be treated as potentially sensitive.

## 3. Student Data Processed

Depending on the files and fields supplied by a school, the application can import, create, store, display, calculate, export, or delete the following categories:

### Identity and Enrollment

- First, middle, and last name
- Local student number
- State student/testing identifier
- Graduation class/cohort
- Grade level
- Diploma type
- Counselor
- SPED/IEP/504 indicator
- School and division configuration associated with the record
- Notes and unmatched-record matching details

### Academic and Transcript

- School year and grade level
- Course identifiers and titles
- Honors, Advanced Placement, International Baccalaureate, dual-enrollment, and other course attributes
- Final grades
- Earned and projected credits
- Completed and work-in-progress status
- Credit totals and subject-area progress
- GPA or related values when provided in source material
- Transcript source filenames and extracted transcript text during processing

### Assessment and Graduation

- State assessment/test names, areas, dates, scores, status, and course
- All test attempts, highest-score calculations, and multiple-attempt indicators
- Pass/fail and retest indicators
- Failed-course indicators
- Verified-credit status
- LVC/LAVC/credit-accommodation status
- Performance-based assessment results
- Substitute-test evidence such as Workplace Documents and Business Letter Writing
- CPR/AED, virtual-course, service-learning, credential, and local requirement status
- Graduation progress, missing requirements, intervention flags, and counselor notes

### Readiness and Credentials

- 3E Enrollment, Employment, and Enlistment evidence and points
- Dual-enrollment evidence and grades
- Credentials, credential names, and scores
- NCRC component results
- Workplace Readiness results
- ASVAB/AFQT results
- CTE completion and work-based learning
- AP/IB/Cambridge/CLEP, associate-degree, or Early College Scholar evidence
- Custom readiness, service, project, fee, attendance, FAFSA, device-return, or school-defined tracking fields

### Administrative Metadata

- Upload filenames, source type, uploader, date, notes, processed rows, updates, and warnings
- Manual edits, old/new values, edit notes, user, and timestamp
- Saved-report metadata
- Audit events, username, role, action, detail, IP address, and timestamp
- User accounts, display names, roles, status, and password hashes

### Supported Formats

Implemented structured-data imports:

- `.xlsx`
- `.xlsm`
- `.xls` is recognized, but reliable processing depends on a compatible Pandas Excel engine that is not explicitly included in the reviewed requirements
- `.csv`

Implemented transcript parsing:

- PDF transcript files

Implemented local rules-document analysis:

- PDF
- Word `.docx`
- Excel `.xlsx`, `.xlsm`, and `.xls` subject to engine availability
- CSV
- Text
- HTML

Implemented outputs:

- Excel `.xlsx`
- PDF
- Browser-based printable HTML

The application does not provide a complete, documented machine-readable district-data export containing every table and retained document.

### Source-Document Retention

- Uploaded source documents are retained after processing.
- Student transcript documents are retained and linked to the student.
- Deleting database rows does not necessarily delete corresponding uploaded source files, generated reports, exports, logs, or backups.

## 4. Authentication and Authorization

### Password Storage

- Passwords are not stored in plaintext.
- Each password is hashed with PBKDF2-HMAC-SHA-256 using a unique random salt and 180,000 iterations.
- Password comparison uses a constant-time comparison function.
- The application requires at least 10 characters during setup, user creation, and administrative reset.
- No additional password complexity, compromised-password screening, expiration, or multi-factor authentication is implemented.

### Roles

**Admin**

- View student records, grids, reports, and printable documents
- Upload and process data
- Add and edit students and requirement data
- Export student data
- Resolve unmatched records
- Delete an entire graduation class
- Manage users
- Configure school profile, rules, fields, reports, agreements, imports, and grid columns
- View audit log
- Create and restore backups

**Counselor**

- View student records, grids, reports, and printable documents
- Upload and process data
- Add and edit students and requirement data
- Export student data
- Resolve unmatched records
- Save reports
- Cannot manage users, restore backups, change Admin configuration, or delete an entire class grid

**Teacher Viewer**

- View student records, grids, reports, checklists, agreements, and printable browser pages
- Cannot upload, edit, add students, resolve unmatched records, delete, restore, administer, or download protected Excel/PDF exports
- Restrictions are enforced by server-side route checks in addition to hidden interface controls
- Because printable HTML pages remain viewable, a Viewer can use normal browser/operating-system print or "Save as PDF" functions. The application cannot technically prevent printing, screenshots, or manual copying of information a Viewer is authorized to see.

### Account Administration

- The first-time setup flow creates the first Admin.
- Admins can create Admin, Counselor, or Viewer accounts.
- Admins can disable or enable accounts.
- Admins can replace an account's password with a new password.
- Disabling an account causes subsequent requests from its active sessions to lose access.
- There is no self-service password reset, email recovery, user deletion, or required first-login password change.
- Password reset does not explicitly invalidate all existing sessions for that user unless the account is also disabled or the service restarts.

### Sessions and Login Protection

- Sessions use a cryptographically random token stored only in server memory.
- The cookie is marked `HttpOnly`, `SameSite=Strict`, and `Path=/`.
- The cookie is not marked `Secure` because the built-in service uses HTTP.
- Inactive sessions expire after eight hours by default; the value is configurable through `GIC_SESSION_HOURS`.
- There is no separate absolute session lifetime.
- Restarting the application removes all in-memory sessions.
- Five failed login attempts from one client IP within 15 minutes trigger temporary throttling.
- Failed-login counters are memory-only and reset when the server restarts.
- Successful logins are audited; failed attempts and logouts are not recorded in the audit table.
- Shared accounts are discouraged but not technically prevented. A username is unique, but multiple people can use the same credentials concurrently.

## 5. Security Safeguards

### Implemented Application Controls

- Authentication is required before student routes are available.
- Server-side role checks protect upload, edit, export, delete, user-management, backup, restore, and configuration routes.
- Account-disabled status is checked during each authenticated request.
- Database operations generally use parameterized SQLite queries.
- User-visible dynamic text is HTML escaped by default.
- Upload and stored filenames are reduced to a safe basename and randomized.
- Export and restore filenames are reduced to a basename before local path resolution.
- Response headers include `Cache-Control: no-store`, `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, and `Referrer-Policy: same-origin` for standard page responses.
- Export downloads set content type and attachment disposition.
- A FERPA warning is displayed at login.
- A user acknowledgment screen appears before protected Excel/PDF exports.
- Cross-site POST requests identified by `Sec-Fetch-Site: cross-site` are rejected.
- Request size is limited to 512 MB by default and can be lowered through configuration.
- Standard URL-encoded forms have a 2 MB limit.
- Restore and class deletion require typed confirmation words.

### Audit Logging

The application records many high-impact actions, including:

- Successful login
- Initial setup
- Upload processing
- Excel export operations using the export helper
- Manual student and grid edits
- Student creation
- Class deletion
- Unmatched-record resolution and dismissal
- User creation, enable/disable, and password reset
- Manual backup
- Restore
- Saved graduation agreements
- School/rules/customization changes

Audit entries include username, role, action, detail, client IP, and timestamp. The Admin page displays the most recent 250 entries; older entries remain in the database unless manually removed outside the application.

Not all sensitive activity is audited. Ordinary viewing, searching, printing, logout, failed login, and some direct PDF downloads are not consistently logged.

### Upload Protections and Limitations

- Spreadsheet readers accept only supported filename extensions at the parser layer.
- Transcript parsing is limited to PDF in the active transcript workflow.
- Rules documents are parsed locally by extension.
- Filenames are sanitized and randomized.
- The application does not execute Excel macros.

Limitations:

- Files are not malware-scanned by the application.
- MIME type, file signature, archive expansion ratio, and actual content are not strongly verified before storage.
- A file is stored before parser validation; unsupported or failed files can remain in the upload folder.
- The processing form includes a local file path supplied back by the browser. The server does not currently prove that this path remains under the configured upload directory before reading it. An authenticated user with edit permission could craft a request that attempts to read another server-local file the application process can access.
- The anti-CSRF control relies on the `Sec-Fetch-Site` header and `SameSite=Strict`; the application does not use per-form CSRF tokens.
- A Content Security Policy is not currently sent.

### File and Folder Permissions

- The application does not create or enforce Windows ACLs or Unix permissions.
- Files inherit permissions from the installation and data folders.
- District IT must restrict the application folder, data folder, backups, logs, and server console to authorized personnel and service accounts.

### SQL Injection and Path Traversal

- Queries containing user values generally use SQLite parameters.
- A small number of dynamic SQL fragments are generated from internally controlled lists or validated column names.
- Filename sanitization and basename checks protect common upload/export/restore path traversal.
- The processing-path validation gap described above should be corrected before broader distribution.

## 6. Backups and Recovery

### Behavior

- A database backup is created before startup migrations.
- A database backup is created before upload processing.
- A database backup is created before class deletion.
- A database backup is created before restore.
- Admins can create a manual backup.
- Restore is Admin-only and requires typing `RESTORE`.
- Restore first creates a safety backup, then replaces the active SQLite database.

### Location and Content

- Backups are stored under the configured data folder's `backups` directory.
- Each backup is a complete copy of the SQLite database.
- Backups contain identifiable student information, user records, password hashes, settings, audit entries, and other database content.
- Database backups do not include retained upload files, transcript-document files, generated exports, reports, or error logs. District backup procedures must protect the complete data folder separately.
- Backups are currently made with a filesystem copy of the SQLite file rather than SQLite's online-backup API. The startup backup occurs before the server begins accepting users, but backups created while the threaded service is active have not been formally tested under simultaneous writes.

### Retention

- The default maximum is 40 automatic database backups.
- When a new automatic backup is created, older automatic backups beyond the limit are deleted.
- Manual backups are excluded from automatic pruning and remain until manually deleted outside the application.
- No age-based retention policy, legal-hold feature, secure erase, or Admin backup-delete button is implemented.

## 7. Data Rights, Correction, Export, and Deletion

### Individual Student

- Authorized users can search for and view a student profile.
- Admins and Counselors can correct identity fields, graduation class, diploma type, SPED/504 status, counselor, notes, requirement status, scores, and retest indicators.
- Manual edits require a note and are recorded in edit history/audit records.
- Authorized Admins and Counselors can export class/report Excel files and student/report PDFs after a FERPA acknowledgment.
- There is no implemented user-interface function to delete one individual student and all associated files.

### Class and District

- An Admin can delete an entire graduation class after typing `DELETE`.
- Database foreign keys cascade deletion to many child records.
- A pre-deletion database backup is created.
- Class deletion does not remove source uploads, transcript copies, exports, saved report files, error logs, audit entries, or prior backups.
- There is no complete "export all district data" function.
- There is no complete "permanently delete all district data" function.

To remove an installation completely, district IT must:

1. Stop the service.
2. Preserve any records required by law or policy.
3. Delete the configured data folder, including database, uploads, transcripts, exports, reports, backups, rules documents, logs, and settings.
4. Delete district-managed backup copies, snapshots, endpoint backups, and exported files according to approved retention and destruction procedures.
5. Use district-approved secure deletion or cryptographic erase where required.

SQLite row deletion alone is not guaranteed secure erasure. Deleted content may remain in free database pages until database maintenance or storage-level secure destruction. Backups and logs may continue to contain information after deletion from the active database.

### Machine-Readable Formats

- Excel `.xlsx` and CSV source formats are supported for many imports.
- Excel `.xlsx` is the principal machine-readable export format.
- A comprehensive CSV/JSON export of every student-related table and file is not implemented.

## 8. Installation and Updates

### Single Computer

1. Extract the Portable Full Install to a stable school-managed folder.
2. Run `Start Graduation Intelligence Center.bat`.
3. The launcher uses its bundled Python runtime.
4. A blank `school_data` folder is created from the blank template.
5. The school completes first-time setup and creates the first Admin.
6. The browser opens the local address.

### District Server

1. Install on an approved Windows server or always-on workstation.
2. Set `GIC_DATA_DIR` to a protected district-owned data folder.
3. Set `GIC_HOST` for internal network access and select an approved port.
4. Restrict firewall access to approved internal subnets.
5. Prefer an approved HTTPS reverse proxy.
6. Run under a restricted service account and include the full data folder in district backup/monitoring.
7. Staff connect using the internal server address or DNS name.

The built-in Python development-style server has not been independently load-tested or security-certified for broad enterprise deployment.

### Updates

- Full-install packages are for new schools and include blank and fake demo data separately.
- Update packages contain application code and documentation but intentionally exclude databases, users, school settings, uploads, reports, exports, backups, and logs.
- The application creates a database backup before startup migration work.
- Data remains in `GIC_DATA_DIR` or `school_data` while application code is replaced.
- Correctly applied updates should not overwrite district data.

Limitations:

- Update packages are not cryptographically signed.
- No built-in checksum, publisher signature, automatic updater, rollback manager, or update-origin verification is implemented.
- Update verification relies on trusted delivery, manual file replacement, startup backup, release notes, and testing.
- Mistakenly replacing or deleting the data folder remains an operational risk.

### District and Demo Separation

- Blank data contains no users, students, or uploads.
- Demo data uses fake students and is stored in a separate demo folder.
- Each installation uses its configured local data folder.
- The application has no multi-tenant mode and should not point two districts at one shared database.
- District IT must ensure demo data is not renamed into or mixed with a live school's data folder.

## 9. Support Access

- The reviewed application contains no remote-access agent, developer account, cloud control plane, telemetry channel, or developer back door.
- The developer cannot remotely access the application or database through an application feature.
- Any remote support would require the district to provide an approved remote-support session, screen share, sanitized logs, or a district-created test copy.
- Error logs contain exception class, exception message, and Python stack trace. They may reveal local paths, filenames, database details, or values associated with a failure.

Privacy-preserving support practices should include:

- Reproduce issues with the fake demo dataset when possible.
- Share screenshots with names, IDs, scores, and paths redacted.
- Provide the smallest relevant sanitized log excerpt.
- Do not send the live database, transcript files, exports, backups, or upload folder unless district authorization and an appropriate data-protection agreement are in place.
- Use district-approved encrypted transfer and access-expiration controls if real data is exceptionally required.

## 10. Known Gaps and Dependencies

### Security and Privacy Gaps

- No application-level encryption at rest.
- No built-in HTTPS/TLS.
- Session cookie lacks the `Secure` attribute in HTTP mode.
- No multi-factor authentication or district SSO/Active Directory integration.
- Shared credentials are possible.
- Viewer accounts can print, screenshot, manually copy, or use browser "Save as PDF" on records they can view even though protected application download routes are blocked.
- Password reset does not automatically revoke every existing session.
- Login throttling is per-IP, memory-only, and not a substitute for enterprise identity protection.
- Failed logins, logout, ordinary record views, printing, and some PDF downloads are not fully audited.
- Audit logs have no retention, export, tamper-evidence, or integrity-signing control.
- No per-form CSRF token.
- No Content Security Policy.
- Uploads are not malware-scanned or strongly content-signature validated.
- The hidden processing path is not restricted to the upload directory.
- No storage quota, upload retention, export retention, or automatic cleanup policy.
- Error logs can contain sensitive context and have no rotation/retention control.
- File permissions and encryption depend entirely on operating-system and district configuration.

### Data-Lifecycle Gaps

- No individual-student deletion workflow.
- No whole-district export or purge workflow.
- Class deletion leaves files, logs, audit records, and backups behind.
- No secure-deletion or SQLite `secure_delete` workflow.
- No automated handling of retention schedules, legal holds, record freezes, or backup expiration by age.
- Manual backups are never automatically deleted.
- Uploaded source documents and generated exports are retained indefinitely unless staff remove them outside the application.
- Transcript storage path behavior should be reviewed and normalized so every document remains under the configured data directory in all deployment layouts.

### Deployment and Product Gaps

- The built-in HTTP server is not a hardened production application server.
- Windows is the only documented/tested packaged platform.
- SQLite concurrency is suitable for a small pilot but has not been load-tested for district-wide concurrent write activity.
- Database backup consistency during concurrent write activity has not been stress-tested, and the implementation does not use SQLite's online-backup API.
- No independent penetration test, vulnerability scan, privacy impact assessment, SOC 2 audit, or third-party security certification has been completed.
- Dependency versions use minimum constraints rather than a fully locked, reproducible dependency set with a software bill of materials.
- No automatic security-update mechanism or signed update channel.
- No documented incident-response workflow, breach-notification workflow, RTO/RPO, disaster-recovery test record, or formal support SLA.
- Automated tests cover core pilot workflows but not the complete authorization matrix, adversarial uploads, CSRF, path traversal, backup corruption, concurrent access, or full data deletion.
- Graduation calculations are decision support and require school review; they are not a substitute for the official student information system or official state/district graduation determination.

# A. Confirmed Safeguards Currently Implemented

- Local SQLite storage with configurable school-owned data directory
- No intentional external API, AI, telemetry, analytics, cloud, or remote-support transmission
- Login required before student access
- Salted PBKDF2 password hashing
- Admin, Counselor, and Teacher Viewer server-side authorization
- Immediate access loss for disabled accounts on the next request
- Eight-hour configurable inactivity timeout
- Failed-login throttling
- Random session tokens and `HttpOnly`/`SameSite=Strict` cookie
- Parameterized queries for user-supplied database values
- Escaped HTML output by default
- Randomized, sanitized upload filenames
- Basename checks for export and restore paths
- Request-size limits
- FERPA notice and export acknowledgment
- Selected browser security headers
- Local audit log for many high-impact actions
- Automatic database backups before upload processing, startup migrations, class deletion, and restore
- Admin-only restore with typed confirmation and pre-restore safety backup
- Code/data separation in distributable and update packages
- Blank package verified without users/students/uploads and separate fake demo data

# B. Safeguards Dependent on District IT

- BitLocker or equivalent encryption at rest
- HTTPS reverse proxy and certificate management
- Firewall restrictions to private school networks and approved subnets
- Windows/server ACLs for application, database, uploads, exports, logs, and backups
- Service-account least privilege
- Endpoint protection, malware scanning, patching, and server hardening
- Secure district backup of the complete data folder
- Backup encryption, offsite protection, retention, restoration testing, and secure destruction
- Named-account policy and prevention of credential sharing
- Physical server security
- Network monitoring, incident response, and breach notification
- Approved remote-support and secure file-transfer procedures
- Retention schedules and authorization for deletion

# C. Items Recommended Before a Live Pilot

1. Run only on a school-managed Windows device or internal server.
2. Restrict access to approved internal networks; do not expose port 5000 to the public internet.
3. Enable full-disk or volume encryption.
4. Use unique named Admin, Counselor, and Viewer accounts; test every role.
5. Lower the eight-hour session timeout if district policy requires it.
6. Test backup and restore using fake data and document RTO/RPO expectations.
7. Confirm the complete data folder is included in encrypted district backups.
8. Remove demo data before real student use.
9. Begin with a small roster and verify matching, calculations, reports, and exports.
10. Obtain written school approval of graduation rules, report wording, and data ownership.
11. Establish upload/export retention and cleanup procedures.
12. Establish a privacy-preserving support process using fake data and redacted logs.
13. Correct the upload processing-path validation issue before accepting untrusted staff uploads.
14. Place the service behind district-managed HTTPS if more than localhost access is used.

# D. Items Recommended Before Commercial Distribution

1. Replace or front the built-in server with a hardened, documented production deployment.
2. Add HTTPS-first deployment guidance and secure-cookie support.
3. Implement per-form CSRF tokens and a restrictive Content Security Policy.
4. Restrict every processing path to approved data directories.
5. Add file signature/type validation, malware-scanning integration, archive limits, and quarantine/cleanup behavior.
6. Implement individual-student deletion, complete district export, complete district purge, file cleanup, and backup-aware retention controls.
7. Add audit coverage for failed logins, logout, views, prints, and every export/download; add retention and tamper-evidence.
8. Revoke active sessions after password reset and consider MFA/SSO integration.
9. Add encryption-at-rest options or require encrypted district storage with a verified deployment check.
10. Cryptographically sign releases and publish SHA-256 checksums through a trusted update channel.
11. Lock dependencies, produce an SBOM, scan dependencies, and establish a vulnerability-response process.
12. Conduct independent penetration testing, secure-code review, privacy impact assessment, and multi-user load testing.
13. Add automated adversarial security tests and full role/route authorization tests.
14. Document data-processing terms, support boundaries, incident handling, retention, deletion, accessibility, warranty, and state/district configuration responsibility.
15. Remove or clearly isolate unused legacy modules to reduce maintenance and audit ambiguity.
