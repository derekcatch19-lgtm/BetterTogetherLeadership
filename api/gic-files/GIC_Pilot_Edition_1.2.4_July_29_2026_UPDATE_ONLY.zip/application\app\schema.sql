CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('Admin','Counselor','Viewer')),
    display_name TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT,
    first_name TEXT NOT NULL,
    middle_name TEXT,
    last_name TEXT NOT NULL,
    graduation_class INTEGER NOT NULL,
    diploma_type TEXT DEFAULT 'Standard',
    sped_504_status TEXT DEFAULT 'N',
    counselor TEXT,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, graduation_class)
);

CREATE INDEX IF NOT EXISTS idx_students_name_class ON students(last_name, first_name, graduation_class);
CREATE INDEX IF NOT EXISTS idx_students_class ON students(graduation_class);

CREATE TABLE IF NOT EXISTS class_grid_members (
    student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    graduation_class INTEGER NOT NULL,
    source_upload_id INTEGER REFERENCES upload_history(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(student_id_fk, graduation_class)
);

CREATE INDEX IF NOT EXISTS idx_class_grid_members_class ON class_grid_members(graduation_class);

CREATE TABLE IF NOT EXISTS test_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    test_name TEXT,
    test_area TEXT NOT NULL,
    score REAL,
    raw_score TEXT,
    pass_fail TEXT,
    test_date TEXT,
    course TEXT,
    credential_name TEXT,
    source_upload_id INTEGER,
    failed_course_indicator INTEGER NOT NULL DEFAULT 0,
    multiple_attempt_indicator INTEGER NOT NULL DEFAULT 0,
    normalized_subject TEXT,
    normalized_test_date TEXT,
    date_validation_status TEXT,
    imported_performance_level TEXT,
    delivery_group TEXT,
    administration_id TEXT,
    attempt_fingerprint TEXT,
    duplicate_status TEXT,
    canonical_attempt_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_attempts_student_area ON test_attempts(student_id_fk, test_area);

CREATE TABLE IF NOT EXISTS testing_windows (
    id TEXT PRIMARY KEY,
    state TEXT NOT NULL,
    window_name TEXT NOT NULL,
    school_year TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    assessment_group TEXT NOT NULL DEFAULT 'EOC',
    rule_version TEXT NOT NULL,
    source_reference TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS eoc_subject_rules (
    student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    normalized_subject TEXT NOT NULL,
    initial_attempt_id INTEGER,
    initial_attempt_date TEXT,
    initial_attempt_window_id TEXT,
    initial_attempt_school_year TEXT,
    locked_rule_version TEXT,
    locked_passing_score REAL,
    locked_lavc_floor REAL,
    proficient_score REAL,
    advanced_score REAL,
    threshold_source TEXT,
    assignment_method TEXT,
    manual_override_reason TEXT,
    valid_attempt_count INTEGER NOT NULL DEFAULT 0,
    highest_valid_score REAL,
    latest_attempt_date TEXT,
    current_pass_status TEXT,
    current_performance_level TEXT,
    lavc_eligibility_status TEXT,
    verified_credit_status TEXT,
    review_reason TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(student_id_fk, normalized_subject)
);

CREATE TABLE IF NOT EXISTS eoc_rule_overrides (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    normalized_subject TEXT NOT NULL,
    old_rule_json TEXT,
    new_rule_json TEXT NOT NULL,
    reason TEXT NOT NULL,
    changed_by INTEGER REFERENCES users(id),
    changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS eoc_migration_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    migration_version TEXT NOT NULL,
    summary_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS requirement_status (
    student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    requirement_key TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Missing',
    display_value TEXT,
    score REAL,
    source TEXT,
    lvc_type TEXT,
    needs_retest INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(student_id_fk, requirement_key)
);

CREATE TABLE IF NOT EXISTS student_flags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id_fk INTEGER REFERENCES students(id) ON DELETE CASCADE,
    flag_type TEXT NOT NULL,
    message TEXT NOT NULL,
    resolved INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS upload_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_filename TEXT NOT NULL,
    stored_filename TEXT NOT NULL,
    uploaded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    uploaded_by INTEGER REFERENCES users(id),
    user_note TEXT,
    data_source_type TEXT,
    records_processed INTEGER NOT NULL DEFAULT 0,
    updates_made INTEGER NOT NULL DEFAULT 0,
    conflicts_warnings INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS manual_edits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    edited_by INTEGER REFERENCES users(id),
    field_name TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    note TEXT NOT NULL,
    edited_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS saved_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    report_type TEXT NOT NULL,
    filename TEXT NOT NULL,
    saved_by INTEGER REFERENCES users(id),
    saved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS student_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    document_type TEXT NOT NULL,
    original_filename TEXT NOT NULL,
    stored_filename TEXT NOT NULL,
    uploaded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS transcript_courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    school_year TEXT,
    grade_level TEXT,
    course_id TEXT,
    course_title TEXT NOT NULL,
    attributes TEXT,
    final_grade TEXT,
    earned_credits REAL DEFAULT 0,
    potential_credits REAL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'Completed',
    source_document_id INTEGER REFERENCES student_documents(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS unmatched_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_upload_id INTEGER REFERENCES upload_history(id) ON DELETE SET NULL,
    record_type TEXT NOT NULL DEFAULT 'Upload',
    first_name TEXT,
    middle_name TEXT,
    last_name TEXT,
    student_id TEXT,
    graduation_class TEXT,
    issue TEXT NOT NULL,
    raw_json TEXT,
    status TEXT NOT NULL DEFAULT 'Open',
    resolved_to_student_id INTEGER REFERENCES students(id) ON DELETE SET NULL,
    resolved_by INTEGER REFERENCES users(id),
    resolved_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cougar_scholar_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    last_name TEXT NOT NULL,
    first_name TEXT NOT NULL,
    middle_name TEXT,
    graduation_class INTEGER NOT NULL,
    grade_9 TEXT,
    grade_10 TEXT,
    grade_11 TEXT,
    grade_12 TEXT,
    source_note TEXT,
    UNIQUE(last_name, first_name, middle_name, graduation_class)
);
