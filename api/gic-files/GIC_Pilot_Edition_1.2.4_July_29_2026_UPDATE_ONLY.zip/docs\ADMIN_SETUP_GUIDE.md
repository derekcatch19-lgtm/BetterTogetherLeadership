# Admin Setup Guide

This guide is for the school Admin account.

## First-Time Setup

The first setup screen creates the local school profile and first Admin user.

Choose the correct template:

- Virginia Template: use when the school wants Virginia graduation tracking defaults.
- Custom / Other State Template: use when the school needs to define its own graduation requirements.

The template can be reviewed and edited from the Admin tools after setup.

## School Profile

Use School Profile to edit:

- School name
- Division or district
- Application title
- Logo or branding
- Primary and accent colors
- Principal
- Counselors
- Report footer
- Signature titles

These settings appear on reports, agreements, and printed documents.

## Users and Roles

Create one account per person.

Roles:

- Admin: full system access, including settings, users, backups, and restore.
- Counselor: full working access for student records and reports.
- Teacher Viewer: view-only access. This role should not edit, delete, upload, restore, or export protected student data unless the school changes policy.

Use strong passwords. Passwords are stored as hashes, not plain text.

## Graduation Rules

Use Graduation Rules to define what the school tracks for graduation.

Admin can configure:

- Diploma types
- Total credits required
- Subject credit requirements
- State assessment requirements
- Career, college, or military readiness indicators
- CPR or safety requirements
- Community service
- Senior project
- Local seals or recognitions
- Other local requirements

No imported document should become an official rule until an Admin reviews and approves it.

## Graduation Rules Wizard

The Rules Wizard helps a school build a starting configuration from documents.

Supported files:

- PDF
- Word
- Excel
- CSV
- Text
- HTML

Examples:

- State graduation requirements
- District graduation guide
- Course catalog
- Assessment guide
- Transcript legend
- Local checklist

The wizard proposes rules for Admin review. The Admin can accept, edit, delete, or add requirements before saving.

All document extraction and recommendation work is performed locally. The application does not send graduation documents to an external AI service.

For a Custom / Other State installation, see `CUSTOM_STATE_SETUP.md`.

## Custom Fields

Use Custom Fields for school-specific tracking.

Examples:

- Scholars Club
- Community Service Hours
- FAFSA Complete
- Capstone Complete
- Industry Credential
- Work-Based Learning
- Attendance Recovery
- Graduation Fee Paid
- Device Returned
- Parent Meeting Complete

Supported field types:

- Checkbox
- Text
- Number
- Date
- Dropdown
- Score
- Notes

## Import Templates

Use Import Templates when uploaded files do not match the built-in formats.

Templates can map school files to internal fields for:

- Transcripts
- Historical grades
- State assessments
- Credential files
- CPR files
- Dual enrollment
- AP, IB, SAT, ACT, ASVAB
- Local spreadsheets
- Existing graduation grids

Save templates when the school will upload the same report format again.

## Grid Columns

Use Grid Columns to choose what appears on the main class grid.

Keep the main grid simple for counselors. Detailed accountability fields belong in reports.

Recommended default columns:

- Student name
- Student ID
- Graduation class
- Diploma type
- Counselor
- Graduation status
- Readiness score
- Major requirement summary
- Notes

## Agreement Builder

Use Agreement Builder to customize:

- Report title
- Intro text
- Required checklist items
- Support plan options
- Signature lines
- Footer
- School-specific language

The agreement pulls from the student record and updates as data changes.

## Troubleshooter

Use the Troubleshooter after uploads.

Common reasons a record does not match:

- Nickname in one file and legal name in another
- Middle name or hyphenated name differences
- Student ID missing
- Retained student appears on a different class grid
- Graduated student is no longer on an active grid

Review unmatched records before assuming a student was not imported.

## Suggested Setup Order

1. Complete School Profile.
2. Create staff users.
3. Choose or build graduation rules.
4. Add custom fields.
5. Configure grid columns.
6. Set up agreement language.
7. Upload a small sample file.
8. Review the Troubleshooter.
9. Run reports.
10. Make a backup before full data import.
