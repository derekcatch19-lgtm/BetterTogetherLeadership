# Virginia EOC Proficiency Phase-In - Pre-Implementation Review

Date: July 25, 2026

## Controlling Sources Reviewed

- VDOE Four-Year Phase-In Proficiency Implementation Plan
- VDOE School Year 2025-2026 and 2026-2027 Comparison
- VDOE School Year 2025-2026 and 2026-2027 Point Comparison
- VDOE Summer 2026 DDOT Regional Meeting legislative update, pages 10-16

The VDOE tables agree with the supplied Algebra I, Geometry, Algebra II, and EOC Reading cut scores. The DDOT presentation confirms that a retest uses the proficiency score in effect at the initial attempt and that LAVC eligibility begins 25 points below that score after at least two attempts, a passed course, and local appeal review.

The sources provide the Summer 2026 window of June 8 through September 11, 2026 through the supplied implementation specification. They do not provide complete Fall 2026 or later window dates. The implementation must not invent those dates. Undocumented dates will remain review-required until an Admin configures an official window.

## Current Implementation

### Relevant Files

- `app/local_server.py`: HTTP routes, Admin UI, upload processing, reports, audit, backup/restore
- `app/schema.sql`: SQLite tables
- `app/services/upload_parser.py`: spreadsheet parsing, matching, test-attempt creation
- `app/services/rule_engine.py`: subject normalization, pass, LVC, verified-credit, and retest logic
- `app/services/exports.py`: Excel/PDF exports
- `app/services/transcript_parser.py`: transcript/course parsing
- `app/services/three_e.py`: 3E calculations
- `tests/test_pilot_readiness.py`: pilot regression tests
- `tools/create_dist_package.py`: blank/demo databases and distributable packages

### Relevant Tables and Fields

- `test_attempts`: original test name, normalized area, numerical/raw score, imported pass/fail, test date, course, source upload, attempt indicators
- `requirement_status`: subject status, display value, score, source, LVC type, retest flag
- `students`: identity, cohort, diploma, SPED/504, counselor
- `transcript_courses`: course, grade, credit, completion status
- `student_flags`: unresolved warning and intervention flags
- `audit_log`: user, role, action, detail, IP, timestamp
- `upload_history`: source filename/type, rows, updates, warnings
- `schema_migrations`: applied migration identifiers

### Current Business Logic

- Test names are mapped to `AlgI`, `Geom`, `AlgII`, `EngRLR`, `EngWrit`, science, and history areas.
- Most SOL numerical scores pass at 400.
- Imported performance text can contribute to some non-SOL requirements, but SOL pass logic is primarily numerical.
- Test date is stored as text and is not normalized to an official administration window.
- Multiple-attempt counting deduplicates some repeated records during calculation but imports still create duplicate database rows.
- LVC uses the fixed range 375-399 and existing SPED/504/senior constraints.
- Requirement recalculation deletes and rebuilds current status rows.
- Science, history, Writing, substitute tests, PBA, and existing credit-accommodation rules are established and must remain unchanged.

## Required Changes

1. Central data-driven cut-score service for affected Virginia EOC subjects.
2. Configurable official testing-window table separate from score tables.
3. Parsed test dates and review flags for missing, invalid, or unmatched dates.
4. Student-and-subject locked rule record based on earliest valid attempt.
5. Exact duplicate fingerprinting and potential-duplicate review.
6. Threshold-aware pass, performance level, retest, color, report, and LAVC calculations.
7. Preservation of already earned verified credits.
8. Admin-only window and threshold override with required reason and audit.
9. Repeatable migration/reconciliation report.
10. Clear student-facing/counselor-facing explanation of the locked rule.

## Conflicts and Open Source Gaps

- No score conflicts were found.
- Complete official Fall, Spring, Term Graduate, and later Summer window dates were not included. Only supported dates will be seeded.
- The DDOT deck says all SOL results will also be reported on a 100-point scale beginning in 2026-2027, while the supplied phase-in tables and requested graduation logic use the 0-600 scale. The implementation will preserve and calculate from the 0-600 scaled score. A future separate requirement would be needed to display the 100-point reporting scale.
- The documents define statewide LAVC eligibility prerequisites but do not replace local appeal approval or all existing disability/local limits. The system will identify potential eligibility, not auto-award credit.

## Migration Plan

1. Add new tables and nullable attempt metadata through idempotent schema migration.
2. Back up the database before migration.
3. Normalize affected test subjects and parse dates.
4. Mark exact duplicates without deleting historical rows.
5. Group valid attempts by student and subject.
6. Assign the earliest valid attempt to an official configured window.
7. Store locked score, LAVC floor, performance/pass status, and assignment source.
8. Preserve any previously Met or Met by LVC verified-credit status.
9. Flag missing dates, dates outside windows, ambiguous subjects, and potential duplicates.
10. Write a reconciliation summary without modifying live data during development.

## Rollback Plan

- Keep the current working distributable unchanged until validation succeeds.
- Create a database backup before migration.
- New tables/columns are additive.
- Restore the pre-migration SQLite backup if validation fails.
- Keep uploaded source files and original test names/dates unchanged.
- Build the new release into a separate output folder.

## Automated Test Plan

- Window boundary and upload-date independence tests
- Subject normalization tests
- Math and Reading threshold boundary tests
- Different locked thresholds by subject for one student
- Retest under initial standard
- LAVC floor, attempt count, course-pass, and no-auto-award tests
- Missing/invalid/out-of-window review tests
- Manual override and audit tests
- Exact duplicate and older-attempt reconciliation tests
- Previously earned verified-credit preservation
- Unchanged Writing, Biology, Earth Science, and History tests
- Virginia/custom-state separation
- Blank/demo data separation and migration rollback verification
# Implementation Status

Updated in Pilot Edition 1.2.1. School-year assignment windows run from
October 1 through September 30. Existing records through September 30, 2026
remain under the 2025-26 standard, and October 1, 2026 begins the 2026-27
phase-in window.
