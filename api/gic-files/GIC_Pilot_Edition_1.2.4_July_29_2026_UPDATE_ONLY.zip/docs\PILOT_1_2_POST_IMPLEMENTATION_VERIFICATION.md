# GIC Pilot 1.2 Hardened Post-Implementation Verification

Verification date: July 26, 2026

Scope: reviewed active source, automated tests, generated package directories,
final ZIP archives, release manifests, published checksums, live database, and
the verified pre-hardening backup.

This is a technical pilot-readiness review. It is not a legal-compliance
certification.

## Executive Result

Three former blockers are fully corrected for their stated scope. The CSRF
blocker is corrected for every authenticated POST form and both multipart
workflows, but the application still uses a GET link for logout and the
automated test does not enumerate every POST route individually. This is a
low-risk limitation for a single-computer pilot, not a student-data mutation
bypass.

## 1. Browser Paths and Upload Tokens

**Status: Fully corrected for upload preview and processing.**

Implementation:

- `app/services/security.py`
  - `safe_child`
  - `FileValidationError`
- `app/local_server.py`
  - `PENDING_UPLOAD_DIR`
  - `Handler.handle_upload`
  - `Handler.register_pending_upload`
  - `Handler.resolve_pending_upload`
  - `Handler.handle_upload_process`
  - `mapping_html`
  - `transcript_mapping_html`

Behavior:

- Initial files are written to a server-controlled pending directory.
- Validated files are moved into the configured upload directory.
- Preview forms receive an opaque random `upload_token`, not a server path.
- Token-to-path state remains in the authenticated server session.
- Processing re-resolves the stored canonical path under `UPLOAD_DIR`.
- Parent traversal, absolute escapes, and symlink escapes outside the approved
  root are rejected.
- Tokens expire after 30 minutes and are lost on service restart.

Tests:

- `test_safe_child_rejects_parent_traversal_and_absolute_escape`
- `test_safe_child_accepts_file_inside_approved_directory`
- Existing fake roster/assessment workflow test

Limitations:

- Upload tokens use in-memory session state, so an interrupted preview must be
  uploaded again after restart.
- The test suite directly tests path enforcement but does not yet drive every
  upload route through a browser-level integration test.

## 2. Per-Session CSRF Protection

**Status: Corrected for every authenticated POST form; minor GET-logout
limitation remains.**

Implementation:

- `app/local_server.py`
  - Login creates a cryptographically random `csrf_token` in each session.
  - `inject_csrf_tokens` inserts the token into rendered authenticated POST
    forms.
  - `Handler.urlencoded_form` validates tokens centrally for URL-encoded POSTs.
  - `Handler.validate_csrf_form` uses constant-time comparison and audits
    rejection.
  - `Handler.handle_upload` and `Handler.handle_rules_wizard` explicitly
    validate multipart POSTs.
  - `Handler.do_POST` returns HTTP 403 for rejected tokens.
  - `SameSite=Strict` and cross-site request rejection remain secondary checks.

Tests:

- `test_csrf_token_injection_and_validation`

Tested outcomes:

- Token insertion succeeds.
- A valid same-session token is accepted.
- An incorrect token is rejected.

Limitations:

- Login and first-time setup are intentionally pre-authentication and therefore
  do not use an authenticated session CSRF token.
- Logout is currently a GET link. It can end only the caller's session and does
  not change student data, but it should become a CSRF-protected POST before
  broader distribution.
- The current automated test exercises the centralized mechanism rather than
  separately enumerating every state-changing route.

## 3. SQLite Online Backup and Integrity Validation

**Status: Fully corrected for database backup and restore.**

Implementation:

- `app/local_server.py`
  - `create_backup` uses `sqlite3.Connection.backup`.
  - The completed backup must pass `PRAGMA integrity_check`.
  - `restore_backup` constrains the filename to `BACKUP_DIR`.
  - The selected backup is opened read-only and must pass integrity and required
    table checks before the active database is touched.
  - A safety backup is created before restore.
  - Restore uses SQLite's backup API and validates the resulting active
    database.

Tests:

- `test_online_backup_is_valid_and_corrupt_restore_is_rejected`
- `test_automatic_backups_are_retained_but_manual_backup_is_kept`

Tested outcomes:

- Online backup passes integrity checking.
- Corrupted backup is rejected.
- Failed restore leaves the active fake database intact.
- Automatic retention preserves manual backups.

Limitations:

- Database backups cover SQLite, not the entire configured data directory.
  District IT must separately back up retained uploads, documents, exports,
  reports, agreements, settings, and logs.

## 4. Server-Side File Validation

**Status: Fully corrected for the supported pilot file types, with documented
depth limitations.**

Implementation:

- `app/services/security.py`
  - `validate_uploaded_file`
  - `_double_extension`
  - `_validate_zip_document`
  - `_validate_csv`
- `app/local_server.py`
  - `Handler.handle_upload`
  - `Handler.handle_rules_wizard`

Validation includes:

- Server-side extension allowlists.
- Configurable size limits.
- PDF `%PDF-` signature.
- ZIP and internal structure validation for XLSX/XLSM/DOCX.
- OLE signature validation for legacy XLS.
- Binary-content rejection and structural sampling for CSV.
- Dangerous double-extension rejection.
- Macro-content rejection.
- Office archive entry, expanded-size, and compression-ratio limits.
- Failed-file removal and audit logging.

Tests:

- `test_renamed_executable_and_invalid_pdf_are_rejected`
- `test_valid_csv_and_office_document_are_accepted`
- Existing fake roster and state-assessment import test

Limitations:

- This is structural validation, not antivirus scanning.
- PDF validation checks the signature before the normal PDF parser performs
  deeper parsing.
- Legacy XLS validation checks the OLE signature; it does not deeply inspect
  every compound-document stream.
- District endpoint protection remains recommended.

## Automated Test Result

Command:

`python -m unittest discover -s tests -v`

Result:

- 20 tests run
- 20 passed
- 0 failures
- 0 errors

Coverage includes existing roster/import, calculations, custom-state separation,
password hashing, backup retention, Virginia phase-in rules, safe paths, upload
signatures, CSRF mechanism, backup integrity, and corrupted-restore rejection.

## External Transmission and Access Review

- The active packaged runtime imports no outbound HTTP client, analytics,
  telemetry, cloud, AI, webhook, email, FTP, or remote-support library.
- `urllib.parse` is used only for local URL parsing/encoding.
- `ThreadingHTTPServer` accepts local/browser requests; it does not transmit
  student data outward.
- No external API key, telemetry endpoint, developer account, remote shell, or
  developer back door was found.
- No student data is intentionally transmitted externally by the application.
- Authorized users can still download/print files; custody after download is a
  district operational responsibility.

## Existing Live Data Verification

The pre-hardening backup and current live database both pass
`PRAGMA integrity_check` and have identical counts:

- Students: 912
- Test attempts: 7,550
- Requirement status rows: 23,764
- Transcript courses: 14,632
- Student documents: 1,067
- Saved reports: 1
- Upload history rows: 35
- Class-grid memberships: 912

Retained generated files remain present:

- Excel exports: 20
- Saved agreements: 1

No data or report-count regression was detected.

## Package Separation and Privacy

Final packages:

- `GIC_Pilot_1_2_Hardened_Portable_Full_Install.zip`
- `GIC_Pilot_1_2_Hardened_Update.zip`

The update ZIP contains 44 entries and no database, `school_data`, upload,
export, report, log, or backup directory.

The portable/full-install package intentionally contains:

- A blank template database: 0 users, 0 students, 0 uploads.
- A fake demonstration database: 0 users, 5 fake students, 1 fake upload-history
  entry.
- Two fake demonstration CSV import files.

Therefore, the accurate confirmation is that no package contains a **real/live
student database, real users, real uploads, real exports, real logs, or real
backups**. The full installer does contain blank and fake-demo SQLite databases
by design; the update package contains no database.

The fake surnames are Anderson, Brooks, Carter, Diaz, and Evans. No real AHS
student records were found in the package databases.

## Package Integrity

Recomputed whole-package hashes exactly match the published checksum file:

- Portable Full Install:
  `2F15C95F7B2F617BAED2C320D74B830B84802DAF14F321563D20872306A6FB20`
- Data-Safe Update:
  `53EEDCC12B9BF9C3E971172909BE75EEECB96BB23BF0D3DC3C213A3CE8FEF411`

All 81 application/document files covered by the two release manifests were
rehash-verified with zero mismatches. The bundled runtime is covered by the
whole-package ZIP checksum. Key security source files in the portable and update
packages are byte-for-byte identical to the reviewed source.

## Conclusion

**Ready for a limited single-computer pilot with district safeguards.**

For an internal multiuser district-server pilot, district IT should additionally
provide HTTPS through a trusted reverse proxy, restricted firewall/network
access, protected data-folder permissions, encryption at rest, endpoint
protection, complete-data-folder backups, and a tested recovery procedure.
