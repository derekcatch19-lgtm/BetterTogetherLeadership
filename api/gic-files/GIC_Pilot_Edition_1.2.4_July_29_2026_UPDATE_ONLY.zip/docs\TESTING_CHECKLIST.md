# Testing Checklist

Run this before a new school uses the app live and after every update.

- Login works.
- Admin can create, disable, enable, and reset users.
- Teacher Viewer can view student pages.
- Teacher Viewer cannot upload, edit, delete, restore, or export.
- Upload preview works.
- Upload processing works.
- Automatic backup appears before upload.
- Graduation calculations update after upload.
- SOL pass/LVC/CA logic works.
- 3E Readiness logic works.
- Class grids load.
- Student profiles load.
- Reports generate.
- Excel exports download after export warning.
- PDF reports download after export warning.
- Manual backup works.
- Restore from backup works in a test data folder.
- Existing data remains after replacing application code.

