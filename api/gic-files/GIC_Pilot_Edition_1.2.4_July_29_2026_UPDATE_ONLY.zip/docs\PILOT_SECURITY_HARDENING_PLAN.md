# Pilot Security Hardening Review

Review date: July 25, 2026

This is a technical pilot-readiness review, not a FERPA or legal compliance
certification. Compliance also depends on district configuration, policy,
contracts, and staff practice.

## Confirmed Findings

### Live-pilot blockers

1. Upload processing forms return a local server path to the browser and accept
   that path on the processing request. Random filenames reduce risk but do not
   prove that the submitted path remains inside the upload directory.
2. `Sec-Fetch-Site` and `SameSite=Strict` are useful secondary CSRF controls,
   but authenticated state-changing forms do not have per-session CSRF tokens.
3. Active SQLite backups use filesystem copying. SQLite's online backup API is
   safer while users may be writing to the database.
4. Uploaded extensions are constrained by the browser but server-side content
   signatures are not consistently validated before parsing.

### Required before broader commercial distribution

- Complete student/district export and backup-aware purge workflows.
- Configurable retention dashboard and legal-hold workflow.
- Full audit filtering/export and record-view auditing.
- Signed installers or publisher code signing.
- Formal penetration testing and supported reverse-proxy deployment testing.
- Operational incident-response and release-management procedures.

### Recommended enhancements

- District readiness dashboard and printable report.
- Local antivirus integration hook.
- Configurable password policy and forced password change.
- Maintenance mode and incident backup workflow.

## Existing Safeguards Preserved

- Local SQLite and configurable `GIC_DATA_DIR`.
- Localhost-only default binding.
- Admin, Counselor, and Teacher Viewer authorization.
- Salted PBKDF2 password hashes and login throttling.
- `HttpOnly` and `SameSite=Strict` session cookies.
- `Cache-Control: no-store`, `nosniff`, frame denial, and referrer policy.
- Automatic pre-upload/pre-migration backups and audit events.
- Separate code, school data, blank data, and fake demo data.
- No analytics, telemetry, external AI, cloud API, or developer backdoor.

## Implementation Stages

1. Central safe-path and file-validation service; server-issued upload tokens.
2. Per-session CSRF tokens for authenticated forms and security-event logging.
3. Inactivity and absolute session lifetimes; reset/disable session invalidation.
4. SQLite online backups, integrity validation, and pre-restore validation.
5. Automated fake-data tests for traversal, file signatures, CSRF, sessions,
   authorization, backup integrity, and corrupted restore rejection.
6. Hardened pilot packages with SHA-256 release checksums.

## Data and Installation Impact

- Schema change: none is required for the first hardening stage.
- Existing database rows, uploads, reports, exports, and backups are preserved.
- New uploads receive opaque in-memory processing tokens; browser-submitted
  filesystem paths are rejected.
- Existing saved source files remain readable through approved application
  references; no retention cleanup is automatic.
- Existing active sessions are lost on application restart, as they are today.

## Rollback

1. Stop the application.
2. Restore the verified pre-update SQLite backup through the Admin restore tool
   or district-approved offline procedure.
3. Restore the previous `application` folder.
4. Leave `school_data`/`GIC_DATA_DIR` in place.
5. Restart locally and verify login, student counts, uploads, and reports.

No existing backup or student file will be deleted as part of this hardening.
