# Update Package

This folder is an update for an existing Graduation Intelligence Center install.

It is not a full install and should not be started by itself.

## Apply This Update

1. Close the Graduation Intelligence Center browser tab and black server window.
2. Make a safety copy of the existing installation folder.
3. Double-click `APPLY_UPDATE_NOW.bat`.
4. Follow the prompts and select the existing main installation folder.
5. After the updater confirms version 1.2.1, start the program with the original
   `Start Graduation Intelligence Center.bat`.

The updater validates the destination, creates an automatic backup of the old
`application` folder, and copies only application code. It does not copy,
replace, rename, or delete `school_data`.

If you see a message about Python or required packages while inside this update folder, you are trying to start the update package directly. Go back to the original full install folder and use its launcher after copying the update files.
