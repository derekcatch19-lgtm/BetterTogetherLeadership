# Graduation Intelligence Center Deployment

This app is designed to run on a school-owned local computer or internal server. Student data stays in the configured local data folder and is not sent to an external API by the application.

## Code vs. Data

- Application code lives in this project folder.
- School data lives in `data` by default, or in the folder set by `GIC_DATA_DIR`.
- Existing legacy installs with `instance/ahs_tracking.sqlite3` continue using `instance` so current data is not moved or overwritten.
- The data folder contains the database, uploads, exports, reports, backups, logs, and settings.

## Quick Run

Desktop/local only:

```powershell
python run.py
```

Internal network/server access:

```powershell
$env:GIC_HOST="0.0.0.0"
$env:GIC_PORT="5000"
$env:GIC_DATA_DIR="D:\GraduationIntelligenceData"
python run.py
```

Staff then browse to:

```text
http://SERVER-IP-ADDRESS:5000
```

The host computer or server must remain powered on and connected to the school network.

## First Login

On a clean install, the first-time setup wizard opens before login. It creates the school profile and first Admin account. No default password is created for distributable installs.
