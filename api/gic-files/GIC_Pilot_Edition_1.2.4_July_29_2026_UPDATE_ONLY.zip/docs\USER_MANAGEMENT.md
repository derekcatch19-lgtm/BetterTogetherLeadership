# User Management Guide

Admins can manage users from:

```text
Admin > Users
```

Roles:

- Admin: full access, including users, school profile, backup/restore, and deletes.
- Counselor: full working access for uploads, edits, reports, and exports.
- Teacher Viewer: view-only access. Cannot upload, edit, delete, restore, or export student files.

Teacher Viewer is appropriate for SPED teachers, classroom teachers, and other authorized staff who need to check records without changing them. The Viewer navigation is simplified and restricted controls are hidden as well as blocked by the server.

Passwords are stored as salted PBKDF2 hashes. Plain text passwords are never stored.

Before live use:

1. Complete the first-time setup wizard and create a strong named Admin account.
2. Create named accounts for each staff member.
3. Disable accounts when staff no longer need access.
4. Do not share accounts.
