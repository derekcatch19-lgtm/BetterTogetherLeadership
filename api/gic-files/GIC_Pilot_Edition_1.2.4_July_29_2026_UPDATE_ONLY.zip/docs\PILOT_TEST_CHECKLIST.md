# Pilot Test Checklist

Use this checklist before a school uses the Graduation Intelligence Center with live student data.

## Install Check

- The app starts from the launcher.
- The app opens in a browser.
- The server window stays open.
- The data folder is outside temporary storage.
- School IT knows where `school_data` is stored.
- Backups are going to approved school storage.

## Security Check

- Login is required before student data is visible.
- Admin account exists.
- Counselor accounts exist.
- Teacher Viewer account has been tested.
- Teacher Viewer cannot edit protected records.
- Passwords are not shared.
- FERPA/local data notice is visible.
- A disabled test account immediately loses access.
- Five failed test logins trigger the temporary lockout message.
- The server is limited to the school/private network by IT firewall rules.

## Setup Check

- School Profile is complete.
- Counselors are entered.
- Graduation template is selected.
- Graduation Rules are reviewed.
- Custom Fields are reviewed.
- Agreement Builder text is reviewed.
- Grid Columns are appropriate.
- Import Templates are created if needed.

## Demo Data Check

- Demo data contains fake students only.
- Demo data is not mixed with real data.
- Staff can open a class grid.
- Staff can open a student profile.
- Staff can generate a report.
- Staff can export Excel or PDF.

## First Real Upload Check

- Manual backup completed before upload.
- One small file uploaded first.
- Matched records were reviewed.
- Unmatched records were reviewed in Troubleshooter.
- A sample student profile was checked.
- A sample class grid was checked.
- A sample report was checked.

## Graduation Logic Check

- Credit totals look correct.
- Assessment requirements look correct.
- Local checklist items look correct.
- Credential or readiness logic looks correct.
- CPR or safety requirement looks correct.
- Student agreement pulls current data.
- Reports match counselor expectations.

## Backup and Restore Check

- Manual backup works.
- Automatic backup runs before upload.
- Backup timestamp is visible.
- Restore warning appears.
- Restore was tested with fake/demo data.

## Go-Live Decision

Do not go live until:

- The school signs off on rules.
- The school signs off on report language.
- Staff know how to handle unmatched records.
- Backup and restore are tested.
- The school understands updates must not overwrite `school_data`.
- IT has documented the server IP, data-folder path, backup destination, and support contact.
- The pilot has a named school rules owner who approves calculation changes.
