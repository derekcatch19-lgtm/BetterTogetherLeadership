# Quick Start for New Schools

Use this guide when a school is trying the Graduation Intelligence Center for the first time.

## 1. Choose the Right Package

For most schools, use the portable full install package. It is designed so the school can start the program without using the command line.

Recommended folder:

`C:\GraduationIntelligenceCenter`

Avoid installing inside Downloads, OneDrive, Google Drive, or a temporary folder. The program stores local school data in its own `school_data` folder, so it should live somewhere stable.

## 2. Start the Program

Open the package folder and double-click:

`Start Graduation Intelligence Center.bat`

The launcher starts the local web server and opens:

`http://127.0.0.1:5000`

The black server window must stay open while staff are using the system.

## 3. First-Time Setup

The first screen creates the school profile and the first Admin account.

Complete:

- School name
- Division or district name
- Application title
- Principal
- Counselor assignments
- School colors
- Admin username and password

Choose a graduation rules template:

- Virginia Template: includes SOL, verified credit, LVC, 3E Readiness, CPR/AED, virtual course, and Virginia-style agreement language.
- Custom / Other State Template: starts with neutral settings so the school can build its own requirements.

No student data is visible until an Admin account exists and the user signs in.

## 4. Admin Setup

After login, go to the Admin and Settings areas to finish setup.

Recommended order:

1. School Profile
2. Users
3. Graduation Rules
4. Rules Wizard, if the school wants help building rules from uploaded documents
5. Custom Fields
6. Import Templates
7. Grid Columns
8. Agreement Builder
9. Custom Reports

## 5. Try Demo Data Before Real Data

Use the `demo_data` folder only for training and demonstration. It contains fake students.

Before importing real students, confirm:

- Users can log in
- Staff understand their roles
- Backup works
- Imports are matching student names correctly
- Reports export correctly

## 6. Start Real Data

Before uploading real files:

1. Make a manual backup.
2. Confirm the school is using the correct graduation template.
3. Upload one small file first.
4. Review unmatched records in the Troubleshooter.
5. Confirm the class grid and student profiles updated correctly.

## 7. Local Network Use

For one computer only, use:

`http://127.0.0.1:5000`

For multiple users on the school network, the host computer or server must run the app and stay powered on. School IT can configure the launcher or server command to listen on the local network and give staff the server IP address.

Example:

`http://10.10.20.15:5000`

Only use this on an approved school network.

