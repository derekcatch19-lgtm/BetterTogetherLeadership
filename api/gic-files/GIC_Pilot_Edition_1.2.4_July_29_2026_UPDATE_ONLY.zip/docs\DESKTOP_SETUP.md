# Desktop / Local Setup Guide

Use this setup for one-person testing or a counselor workstation.

```powershell
python run.py
```

Open:

```text
http://127.0.0.1:5000
```

Localhost mode is only available on that computer. To share with staff, use the local server setup and run with `GIC_HOST=0.0.0.0`.

