# FERPA / Local Data Guide

This app is intended for authorized school use on a school-managed local computer or internal server.

Current safeguards:

- Login required before student records are visible.
- Role-based permissions.
- Export warning before downloading student files.
- Audit log for logins, uploads, exports, edits, deletes, reports, backups, restores, and user changes.
- Student uploads, exports, reports, backups, logs, and settings stay in the local data folder.
- No application feature intentionally sends student data to an external API.

Operational rules still matter:

- Use school-managed devices and storage.
- Do not email exports unless allowed by division policy.
- Do not place backups in personal cloud storage.
- Disable accounts when access is no longer needed.
- Keep the host computer/server physically and digitally secured.

