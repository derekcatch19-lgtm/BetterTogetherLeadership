# Update Guide

The application is update-safe when code and data remain separate.

Do not overwrite the data folder during updates.

Recommended update process:

1. Stop the running app.
2. Create a manual backup from the current version, or copy the full data folder.
3. Replace only the application code folder.
4. Keep `GIC_DATA_DIR` pointed at the existing data folder.
5. Start the app.
6. The app creates a backup before startup migrations.
7. Review Release Notes and run the testing checklist.

If something looks wrong, restore the pre-update backup from Admin > Backups.

