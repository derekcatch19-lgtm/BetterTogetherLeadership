@echo off
setlocal EnableExtensions
title AHS GIC Pilot 1.3.11 Update
echo Close the Graduation Intelligence Center server window before continuing.
set /p "CONFIRM=Type I CLOSED IT and press Enter: "
if /I not "%CONFIRM%"=="I CLOSED IT" exit /b 1
echo Paste the full path to the AHS installation folder containing application and school_data.
set /p "INSTALL_DIR=AHS installation folder: "
if not exist "%INSTALL_DIR%\application\run.py" goto invalid
if not exist "%INSTALL_DIR%\school_data\ahs_tracking.sqlite3" goto invalid
for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%I"
set "BACKUP_DIR=%INSTALL_DIR%\update_safety_backups\application_before_1_3_11_%STAMP%"
robocopy "%INSTALL_DIR%\application" "%BACKUP_DIR%" /E /R:1 /W:1 /NFL /NDL /NJH /NJS >nul
if errorlevel 8 goto failed
robocopy "%~dp0application" "%INSTALL_DIR%\application" /E /R:1 /W:1 /NFL /NDL /NJH /NJS >nul
if errorlevel 8 goto failed
findstr /C:"Employment Credential" "%INSTALL_DIR%\application\app\local_server.py" >nul
if errorlevel 1 goto failed
echo UPDATE COMPLETE. school_data was not replaced or deleted.
echo Restart the original AHS server launcher. Database migration and backup run at startup.
pause
exit /b 0
:invalid
echo ERROR: Select the main folder containing application and school_data.
pause
exit /b 1
:failed
echo ERROR: Update failed. The application backup is at %BACKUP_DIR%
pause
exit /b 1
