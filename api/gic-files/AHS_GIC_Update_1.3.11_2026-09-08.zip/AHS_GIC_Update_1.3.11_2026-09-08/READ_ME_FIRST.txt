AHS-only Pilot 1.3.11 update. This preserves AHS wording and excludes school_data.
Stop the AHS server, run APPLY_AHS_UPDATE.bat, select the main installation folder, then restart.
