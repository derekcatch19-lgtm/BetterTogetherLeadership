from io import BytesIO
from datetime import datetime
import json
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from .three_e import three_e_readiness

COLOR_MAP = {
    "Science": "D9EAD3",
    "Math": "D9EAF7",
    "English": "FFF2CC",
    "History": "EADCF8",
    "Requirement": "FCE5CD",
    "Notes": "E7E7E7",
}

GRID_COLUMNS = [
    "Last Name", "First Name", "Middle Name", "Student ID", "Graduation Class", "Original Cohort", "Early Graduate", "Diploma Type",
    "Special Education / 504 Status", "Counselor", "Notes", "8M", "8R",
    "Student Service Learning Project Complete", "3E Readiness", "Dual Enrollment", "ASVAB",
    "Employment Credential", "Credential Test", "Credential Score", "Workplace Readiness", "NCRC", "CPR/AED Complete",
    "Virtual Course Complete", "5 C's Demonstration", "ESCI", "Bio", "Chem", "AlgI", "Geom",
    "AlgII", "EngRLR", "EngWrit", "Business Letter Writing Score", "WGeo", "WHI", "WHII", "USH",
    "Algebra I Taken", "Biology Taken", "English Reading Taken",
    "SOLs Complete", "Cougar Scholars Club 24-25", "Cougar Scholars Club 25-26",
    "Cougar Scholars Club 26-27", "SOL Notes", "CTE Info", "General Notes",
    "Needs Earth Science", "Needs Biology", "Needs Chemistry", "Needs Algebra I", "Needs Geometry",
    "Needs Algebra II", "Needs English Reading", "Needs English Writing", "Needs World Geography",
    "Needs World History I", "Needs World History II", "Needs U.S. History",
]

AREA_LABELS = {
    "ESCI": "Needs Earth Science", "Bio": "Needs Biology", "Chem": "Needs Chemistry",
    "AlgI": "Needs Algebra I", "Geom": "Needs Geometry", "AlgII": "Needs Algebra II",
    "EngRLR": "Needs English Reading", "EngWrit": "Needs English Writing", "WGeo": "Needs World Geography",
    "WHI": "Needs World History I", "WHII": "Needs World History II", "USH": "Needs U.S. History",
}


def export_class_grid(db, grad_class):
    students = db.execute(
        """
        SELECT s.* FROM students s
        JOIN class_grid_members m ON m.student_id_fk = s.id
        WHERE m.graduation_class = ?
        ORDER BY s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE
        """,
        (grad_class,),
    ).fetchall()
    if _app_setting(db, "graduation_template_type", "Virginia Template") != "Virginia Template":
        return _custom_grid_workbook(db, students, f"Class of {grad_class}")
    return _grid_workbook(db, students, f"Class of {grad_class}")


def _app_setting(db, key, default=""):
    try:
        row = db.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
        return row["value"] if row and row["value"] is not None else default
    except Exception:
        return default


def _json_list_setting(db, key, default):
    try:
        parsed = json.loads(_app_setting(db, key, json.dumps(default)) or "[]")
        return parsed if isinstance(parsed, list) else default
    except Exception:
        return default


def _custom_grid_workbook(db, students, title):
    columns = [str(item).strip() for item in _json_list_setting(db, "main_grid_columns_config", ["student_name", "student_id", "graduation_class", "diploma_type", "counselor", "graduation_status", "notes"]) if str(item).strip()]
    headers = [_custom_grid_header(column) for column in columns]
    wb = Workbook()
    ws = wb.active
    ws.title = title[:31]
    ws.append(headers)
    _style_header(ws, len(headers))
    ids = [student["id"] for student in students]
    status_by_student = {}
    if ids:
        placeholders = ",".join("?" for _ in ids)
        for row in db.execute(f"SELECT * FROM requirement_status WHERE student_id_fk IN ({placeholders})", ids).fetchall():
            status_by_student.setdefault(row["student_id_fk"], {})[row["requirement_key"]] = row
    for student in students:
        statuses = status_by_student.get(student["id"], {})
        ws.append([_custom_grid_export_value(student, statuses, column) for column in columns])
    _autosize(ws)
    return _save_workbook(wb)


def _custom_grid_header(column):
    labels = {
        "student_name": "Student",
        "student_id": "Student ID",
        "graduation_class": "Class",
        "diploma_type": "Diploma",
        "counselor": "Counselor",
        "graduation_status": "Graduation Status",
        "readiness_score": "Readiness",
        "major_requirement_summary": "Major Requirements",
        "notes": "Notes",
    }
    return labels.get(column, str(column).replace("_", " ").title())


def _custom_grid_export_value(student, statuses, column):
    if column == "student_name":
        return f'{student["last_name"]}, {student["first_name"]}'
    if column == "student_id":
        return student["student_id"] or ""
    if column == "graduation_class":
        return student["graduation_class"]
    if column == "diploma_type":
        return student["diploma_type"] or ""
    if column == "counselor":
        return student["counselor"] or ""
    if column == "notes":
        return student["notes"] or ""
    if column == "graduation_status":
        missing = [key for key, row in statuses.items() if row["status"] not in {"Met", "Met by LVC", "Complete", "Pass", "Taken"}]
        return "On Track" if not missing else f"Needs Review: {len(missing)}"
    if column == "major_requirement_summary":
        missing = [key for key, row in statuses.items() if row["status"] not in {"Met", "Met by LVC", "Complete", "Pass", "Taken"}]
        return "No missing items shown" if not missing else ", ".join(missing[:4])
    row = statuses.get(column)
    return (row["display_value"] or row["status"]) if row else "Missing"


def export_report(db, report_key, rows):
    if report_key == "cougar-scholars-tracking":
        return export_cougar_scholars_tracking(db)
    if report_key in {"3e-readiness", "missing-3e-readiness", "3e-close"}:
        return export_three_e_report(rows)
    wb = Workbook()
    ws = wb.active
    ws.title = "Report"
    headers = ["Last Name", "First Name", "Student ID", "Class", "Counselor", "Diploma Type", "Detail"]
    ws.append(headers)
    _style_header(ws, len(headers))
    for row in rows:
        detail = row["detail"] if "detail" in row.keys() else ""
        ws.append([row["last_name"], row["first_name"], row["student_id"], row["graduation_class"], row["counselor"], row["diploma_type"], detail])
    _autosize(ws)
    return _save_workbook(wb)


def export_three_e_report(rows):
    wb = Workbook()
    ws = wb.active
    ws.title = "3E Readiness"
    headers = [
        "Last Name", "First Name", "Student ID", "Graduation Class", "Counselor", "Diploma Type",
        "3E Readiness Summary", "Total 3E Points", "Highest Pathway", "3E Status", "Last Updated",
        "Enrollment Points", "Enrollment Evidence", "Associate Degree", "AP/IB/Cambridge/CLEP Evidence", "Dual Enrollment Courses", "Dual Enrollment Grades", "Early College Scholar",
        "Employment Points", "Employment Evidence", "CTE Completer", "Credential Earned", "Credential Name", "High-Demand Credential", "Work-Based Learning", "Work-Based Learning Type",
        "Enlistment Points", "Enlistment Evidence", "ASVAB / AFQT Score", "ASVAB Score Band",
        "Missing 3E Opportunity", "Recommended Action", "Notes",
    ]
    ws.append(headers)
    _style_header(ws, len(headers))
    for item in rows:
        student = item["student"]
        readiness = item["readiness"]
        enrollment = readiness["enrollment"]
        employment = readiness["employment"]
        enlistment = readiness["enlistment"]
        missing = []
        if enrollment["points"] == 0:
            missing.append("Enrollment")
        if employment["points"] == 0:
            missing.append("Employment")
        if enlistment["points"] == 0:
            missing.append("Enlistment")
        ws.append([
            student["last_name"], student["first_name"], student["student_id"], student["graduation_class"], student["counselor"], student["diploma_type"],
            readiness["summary"], readiness["total_points"], readiness["highest_pathway"], readiness["status"], readiness["last_updated"],
            enrollment["points"], enrollment["evidence"], enrollment["associate_degree"], enrollment["advanced_evidence"], enrollment["dual_courses"], enrollment["dual_grades"], enrollment["early_college_scholar"],
            employment["points"], employment["evidence"], employment["cte_completer"], employment["credential_earned"], employment["credential_name"], employment["high_demand_credential"], employment["work_based_learning"], employment["work_based_learning_type"],
            enlistment["points"], enlistment["evidence"], enlistment["asvab_score"], enlistment["asvab_band"],
            ", ".join(missing), readiness["recommended_action"], "",
        ])
    _autosize(ws)
    return _save_workbook(wb)


def export_cougar_scholars_tracking(db):
    wb = Workbook()
    ws = wb.active
    ws.title = "Tracking Sheet"
    headers = ["Last Name", "First Name", "Middle Name", "Class", "9th Grade", "10th Grade", "11th Grade", "12th Grade", "Current Eligible"]
    ws.append(headers)
    _style_header(ws, len(headers))

    rows = {}
    for history in db.execute("SELECT * FROM cougar_scholar_history ORDER BY graduation_class, last_name, first_name").fetchall():
        key = _scholar_key(history["last_name"], history["first_name"], history["middle_name"], history["graduation_class"])
        rows[key] = {
            "last_name": history["last_name"],
            "first_name": history["first_name"],
            "middle_name": history["middle_name"] or "",
            "graduation_class": history["graduation_class"],
            "grade_9": history["grade_9"] or "",
            "grade_10": history["grade_10"] or "",
            "grade_11": history["grade_11"] or "",
            "grade_12": history["grade_12"] or "",
            "current": "",
        }

    for student in _current_cougar_scholars(db):
        key = _scholar_key(student["last_name"], student["first_name"], student["middle_name"], student["graduation_class"])
        row = rows.setdefault(
            key,
            {
                "last_name": student["last_name"],
                "first_name": student["first_name"],
                "middle_name": student["middle_name"] or "",
                "graduation_class": student["graduation_class"],
                "grade_9": "",
                "grade_10": "",
                "grade_11": "",
                "grade_12": "",
                "current": "",
            },
        )
        grade_key = _upcoming_grade_key(student["graduation_class"])
        if grade_key:
            row[grade_key] = "X"
        row["current"] = "X"

    for row in sorted(rows.values(), key=lambda item: (item["graduation_class"], item["last_name"].upper(), item["first_name"].upper())):
        ws.append([
            row["last_name"],
            row["first_name"],
            row["middle_name"],
            row["graduation_class"],
            row["grade_9"],
            row["grade_10"],
            row["grade_11"],
            row["grade_12"],
            row["current"],
        ])

    _autosize(ws)
    for row in ws.iter_rows(min_row=2, min_col=5, max_col=9):
        for cell in row:
            cell.alignment = Alignment(horizontal="center")

    summary = wb.create_sheet("Summary")
    summary.append(["Class", "9th Grade", "10th Grade", "11th Grade", "12th Grade", "Current Eligible"])
    _style_header(summary, 6)
    classes = sorted({row[3].value for row in ws.iter_rows(min_row=2, min_col=1, max_col=4) if row[3].value})
    for grad_class in classes:
        excel_row = summary.max_row + 1
        summary.append([
            grad_class,
            f'=COUNTIFS(\'Tracking Sheet\'!$D:$D,A{excel_row},\'Tracking Sheet\'!$E:$E,"X")',
            f'=COUNTIFS(\'Tracking Sheet\'!$D:$D,A{excel_row},\'Tracking Sheet\'!$F:$F,"X")',
            f'=COUNTIFS(\'Tracking Sheet\'!$D:$D,A{excel_row},\'Tracking Sheet\'!$G:$G,"X")',
            f'=COUNTIFS(\'Tracking Sheet\'!$D:$D,A{excel_row},\'Tracking Sheet\'!$H:$H,"X")',
            f'=COUNTIFS(\'Tracking Sheet\'!$D:$D,A{excel_row},\'Tracking Sheet\'!$I:$I,"X")',
        ])
    _autosize(summary)
    return _save_workbook(wb)


def _current_cougar_scholars(db):
    students = db.execute(
        """
        SELECT s.*
        FROM students s
        JOIN class_grid_members m ON m.student_id_fk = s.id
        ORDER BY s.graduation_class, s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE
        """
    ).fetchall()
    eligible = []
    for student in students:
        statuses = {
            row["requirement_key"]: row["status"]
            for row in db.execute("SELECT requirement_key, status FROM requirement_status WHERE student_id_fk = ?", (student["id"],)).fetchall()
        }
        if _cougar_scholar_eligible(statuses):
            eligible.append(student)
    return eligible


def _cougar_scholar_eligible(statuses):
    sol_keys = ["ESCI", "Bio", "Chem", "AlgI", "Geom", "AlgII", "EngRLR", "EngWrit", "WGeo", "WHI", "WHII", "USH"]
    passed = {key for key in sol_keys if statuses.get(key) in {"Met", "Met by LVC"}}
    if not passed:
        return False
    categories = {
        "Math": ["AlgI", "Geom", "AlgII"],
        "Science": ["ESCI", "Bio", "Chem"],
        "History": ["WGeo", "WHI", "WHII", "USH"],
    }
    category_met = {name: any(key in passed for key in keys) for name, keys in categories.items()}
    for key in sol_keys:
        if statuses.get(key) != "Not Met":
            continue
        if key in categories["Math"] and category_met["Math"]:
            continue
        if key in categories["Science"] and category_met["Science"]:
            continue
        if key in categories["History"] and category_met["History"]:
            continue
        return False
    return True


def _scholar_key(last_name, first_name, middle_name, graduation_class):
    return (
        str(last_name or "").strip().upper(),
        str(first_name or "").strip().upper(),
        int(graduation_class),
    )


def _upcoming_grade_key(graduation_class):
    today = datetime.now()
    senior_class = today.year + 1 if today.month >= 7 else today.year
    grade_level = 12 - (int(graduation_class) - senior_class)
    return f"grade_{grade_level}" if 9 <= grade_level <= 12 else None


def export_upload_history(db):
    rows = db.execute("SELECT * FROM upload_history ORDER BY uploaded_at DESC").fetchall()
    wb = Workbook()
    ws = wb.active
    ws.title = "Upload History"
    headers = ["Filename", "Uploaded At", "Source", "Records", "Updates", "Warnings", "Note"]
    ws.append(headers)
    _style_header(ws, len(headers))
    for row in rows:
        ws.append([row["original_filename"], row["uploaded_at"], row["data_source_type"], row["records_processed"], row["updates_made"], row["conflicts_warnings"], row["user_note"]])
    _autosize(ws)
    return _save_workbook(wb)


def student_pdf(db, student_id):
    student = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    statuses = db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ? ORDER BY requirement_key", (student_id,)).fetchall()
    flags = db.execute("SELECT * FROM student_flags WHERE student_id_fk = ? AND resolved = 0", (student_id,)).fetchall()
    school = _setting(db, "school_name", "School")
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()
    story = [
        Paragraph(f"{school} Graduation Status Report", styles["Title"]),
        Paragraph(f"{student['first_name']} {student['last_name']} | Class of {student['graduation_class']} | {student['diploma_type']}", styles["Normal"]),
        Paragraph(f"Counselor: {student['counselor'] or ''} | Printed: {datetime.now().strftime('%Y-%m-%d')}", styles["Normal"]),
        Spacer(1, 12),
    ]
    data = [["Requirement", "Status", "Value"]]
    for status in statuses:
        data.append([status["requirement_key"], status["status"], status["display_value"] or ""])
    table = Table(data, colWidths=[210, 110, 180])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#12365B")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(table)
    if flags:
        story.append(Spacer(1, 10))
        story.append(Paragraph("Items Still Needed / Recommended Next Steps", styles["Heading2"]))
        for flag in flags:
            story.append(Paragraph(flag["message"], styles["Normal"]))
    doc.build(story)
    buffer.seek(0)
    return buffer


def graduation_agreement_pdf(student, rows, supports, school="School"):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=30, leftMargin=30, topMargin=28, bottomMargin=28)
    styles = getSampleStyleSheet()
    story = [
        Paragraph(f"{school} - Class of {student['graduation_class']} Graduation Agreement", styles["Title"]),
        Paragraph(f"{student['first_name']} {student['last_name']} | {student['diploma_type']} | Counselor: {student['counselor'] or ''}", styles["Normal"]),
        Paragraph(f"Date Generated: {datetime.now().strftime('%Y-%m-%d')}", styles["Normal"]),
        Spacer(1, 8),
        Paragraph("Dear Senior and Parent/Guardian,", styles["Heading3"]),
        Paragraph("Graduation is one of life's great milestones, and we are proud to partner with you in reaching this important goal. To participate in graduation ceremonies, students must meet all Virginia Department of Education requirements for their diploma type, including credits, verified credits, credential and CPR requirements, attendance expectations, and any financial or discipline obligations.", styles["Normal"]),
        Spacer(1, 8),
        Paragraph("Current Graduation Status", styles["Heading2"]),
    ]
    data = [["Requirement", "Met?", "Notes"]] + [[row["requirement"], row["met"], row["notes"]] for row in rows]
    table = Table(data, colWidths=[190, 45, 290])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#12365B")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.extend([table, Spacer(1, 8), Paragraph("Cougar Success Support Plan: Check all that apply.", styles["Heading2"])])
    support_data = [[("X" if item["checked"] else ""), item["label"]] for item in supports]
    support_table = Table([["", "Support"]] + support_data, colWidths=[28, 480])
    support_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#69AEE8")),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.extend([
        support_table,
        Spacer(1, 8),
        Paragraph("Course Completion: Senior Year Impact", styles["Heading2"]),
        Paragraph("In addition to earning verified credits through SOL tests, substitute tests, performance-based assessments, or locally awarded verified credits, all students must pass required courses to graduate. For seniors, this includes English 12 and U.S. Government. Even if a student earns all verified credits, the student must still pass all state-required courses in order to graduate.", styles["Normal"]),
        Spacer(1, 14),
        Paragraph("Student Signature / Date: ____________________________________________", styles["Normal"]),
        Paragraph("Parent/Guardian Signature / Date: ____________________________________", styles["Normal"]),
        Paragraph("Counselor/Admin Signature / Date: ____________________________________", styles["Normal"]),
    ])
    doc.build(story)
    buffer.seek(0)
    return buffer


def _setting(db, key, default=""):
    try:
        row = db.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
        return row["value"] if row and row["value"] else default
    except Exception:
        return default


def _grid_workbook(db, students, title):
    wb = Workbook()
    ws = wb.active
    ws.title = title[:31]
    ws.append(GRID_COLUMNS)
    _style_header(ws, len(GRID_COLUMNS))
    for student in students:
        statuses = {row["requirement_key"]: row for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ?", (student["id"],)).fetchall()}
        row = {
            "Last Name": student["last_name"], "First Name": student["first_name"], "Middle Name": student["middle_name"],
            "Student ID": student["student_id"], "Graduation Class": student["graduation_class"],
            "Original Cohort": student["original_cohort"] or student["graduation_class"],
            "Early Graduate": "Yes" if student["early_graduate"] else "No", "Diploma Type": student["diploma_type"],
            "Special Education / 504 Status": student["sped_504_status"], "Counselor": student["counselor"],
            "Notes": student["notes"], "General Notes": student["notes"],
            "3E Readiness": three_e_readiness(db, student["id"])["summary"],
        }
        for key, status in statuses.items():
            row[key] = status["display_value"] or status["status"]
            if status["needs_retest"] and key in AREA_LABELS:
                row[AREA_LABELS[key]] = "X"
        ws.append([row.get(column, "") for column in GRID_COLUMNS])
    _color_grid(ws)
    _autosize(ws)
    return _save_workbook(wb)


def _style_header(ws, length):
    fill = PatternFill("solid", fgColor="12365B")
    for cell in ws[1][:length]:
        cell.fill = fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"


def _color_grid(ws):
    science = {"ESCI", "Bio", "Chem"}
    math = {"AlgI", "Geom", "AlgII"}
    english = {"EngRLR", "EngWrit", "Business Letter Writing Score"}
    history = {"WGeo", "WHI", "WHII", "USH"}
    req = {"3E Readiness", "Employment Credential", "Credential Test", "Credential Score", "Workplace Readiness", "NCRC", "CPR/AED Complete", "Virtual Course Complete", "5 C's Demonstration"}
    fills = {
        "Science": PatternFill("solid", fgColor=COLOR_MAP["Science"]),
        "Math": PatternFill("solid", fgColor=COLOR_MAP["Math"]),
        "English": PatternFill("solid", fgColor=COLOR_MAP["English"]),
        "History": PatternFill("solid", fgColor=COLOR_MAP["History"]),
        "Requirement": PatternFill("solid", fgColor=COLOR_MAP["Requirement"]),
        "Notes": PatternFill("solid", fgColor=COLOR_MAP["Notes"]),
    }
    headers = [cell.value for cell in ws[1]]
    for col_index, header in enumerate(headers, 1):
        family = "Notes" if "Notes" in str(header) or header == "CTE Info" else None
        if header in science:
            family = "Science"
        elif header in math:
            family = "Math"
        elif header in english:
            family = "English"
        elif header in history:
            family = "History"
        elif header in req:
            family = "Requirement"
        if family:
            for row_index in range(2, ws.max_row + 1):
                if ws.cell(row_index, col_index).value:
                    ws.cell(row_index, col_index).fill = fills[family]
        if header == "3E Readiness":
            for row_index in range(2, ws.max_row + 1):
                value = str(ws.cell(row_index, col_index).value or "")
                if "None" in value:
                    ws.cell(row_index, col_index).fill = PatternFill("solid", fgColor="F4CCCC")
                elif "Needs Review" in value:
                    ws.cell(row_index, col_index).fill = PatternFill("solid", fgColor="E7E7E7")
                elif "1." in value or "2." in value:
                    ws.cell(row_index, col_index).fill = PatternFill("solid", fgColor="D9EAD3")
                elif "0.75" in value:
                    ws.cell(row_index, col_index).fill = PatternFill("solid", fgColor="FCE5CD")
                elif "0.50" in value:
                    ws.cell(row_index, col_index).fill = PatternFill("solid", fgColor="FFF2CC")


def _autosize(ws):
    for column_cells in ws.columns:
        width = min(42, max(12, max(len(str(cell.value or "")) for cell in column_cells) + 2))
        ws.column_dimensions[column_cells[0].column_letter].width = width


def _save_workbook(wb):
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer
