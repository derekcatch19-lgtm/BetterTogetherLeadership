This data folder contains no real student data. Use the first-time setup wizard to create the local Admin account.
