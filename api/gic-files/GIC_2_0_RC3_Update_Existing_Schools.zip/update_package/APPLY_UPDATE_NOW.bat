@echo off
setlocal EnableExtensions
title Graduation Intelligence Center Update
echo Graduation Intelligence Center - Apply Current Update
echo.
echo BEFORE CONTINUING:
echo 1. Close the Graduation Intelligence Center browser tab.
echo 2. Close the black Graduation Intelligence Center server window.
echo 3. Make sure you have a backup copy of the installation folder.
echo.
set /p "CONFIRM=Type I CLOSED IT and press Enter: "
if /I not "%CONFIRM%"=="I CLOSED IT" (
  echo Update cancelled. Nothing was changed.
  pause
  exit /b 1
)
echo.
echo Open the existing main installation folder in File Explorer.
echo It is the folder containing application, school_data, and the Start launcher.
echo Click the address bar, copy the full folder path, and paste it below.
set /p "INSTALL_DIR=Existing installation folder: "
echo Selected installation: %INSTALL_DIR%
if not exist "%~dp0application\app\local_server.py" (
  echo ERROR: This update package is incomplete.
  pause
  exit /b 1
)
if not exist "%INSTALL_DIR%\application\run.py" (
  echo ERROR: The selected folder does not contain application\run.py.
  echo No files were changed.
  pause
  exit /b 1
)
if not exist "%INSTALL_DIR%\school_data" (
  echo ERROR: The selected folder does not contain school_data.
  echo Select the main installation folder, not the application folder.
  echo No files were changed.
  pause
  exit /b 1
)
set "PYTHON_EXE="
set "PYTHON_ARGS="
if exist "%INSTALL_DIR%\runtime\python\python.exe" set "PYTHON_EXE=%INSTALL_DIR%\runtime\python\python.exe"
if not defined PYTHON_EXE where py >nul 2>nul && set "PYTHON_EXE=py" && set "PYTHON_ARGS=-3"
if not defined PYTHON_EXE where python >nul 2>nul && set "PYTHON_EXE=python"
if not defined PYTHON_EXE (
  echo ERROR: Python could not be found to create a verified database backup.
  echo No files were changed.
  pause
  exit /b 1
)
if exist "%INSTALL_DIR%\school_data\ahs_tracking.sqlite3" (
  echo Creating an integrity-checked database backup...
  pushd "%~dp0application"
  "%PYTHON_EXE%" %PYTHON_ARGS% -m app.services.update_backup "%INSTALL_DIR%\school_data\ahs_tracking.sqlite3" "%INSTALL_DIR%\update_safety_backups\data"
  if errorlevel 1 (
    popd
    echo ERROR: The database backup or integrity check failed. No update was applied.
    pause
    exit /b 1
  )
  popd
)
for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%I"
set "BACKUP_DIR=%INSTALL_DIR%\update_safety_backups\application_before_current_%STAMP%"
echo.
echo Backing up the existing application to:
echo %BACKUP_DIR%
robocopy "%INSTALL_DIR%\application" "%BACKUP_DIR%" /E /R:1 /W:1 /NFL /NDL /NJH /NJS >nul
if errorlevel 8 (
  echo ERROR: The application backup failed. No update was applied.
  pause
  exit /b 1
)
echo Applying application files...
robocopy "%~dp0application" "%INSTALL_DIR%\application" /E /R:1 /W:1 /NFL /NDL /NJH /NJS >nul
if errorlevel 8 (
  echo ERROR: Windows could not copy the update files.
  echo Your original application backup is at:
  echo %BACKUP_DIR%
  pause
  exit /b 1
)
findstr /C:"GIC 2.0 Pilot Release Candidate 3 - September 24, 2026" "%INSTALL_DIR%\application\app\local_server.py" >nul
if errorlevel 1 (
  echo ERROR: Version verification failed. Do not start the program yet.
  echo Your original application backup is at:
  echo %BACKUP_DIR%
  pause
  exit /b 1
)
echo.
echo UPDATE COMPLETE - current application update is installed.
echo school_data was not copied, deleted, or replaced.
echo.
echo Now use the ORIGINAL Start Graduation Intelligence Center.bat
echo inside the existing installation folder.
pause
