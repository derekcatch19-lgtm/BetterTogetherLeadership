import cgi
import difflib
import hashlib
import hmac
import http.cookies
import json
import os
import re
import secrets
import shutil
import socket
import sqlite3
import sys
import time
import traceback
import urllib.parse
import zipfile
from datetime import datetime
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from io import BytesIO
from pathlib import Path

from .services.exports import custom_graduation_agreement_pdf, export_class_grid, export_report, export_upload_history, graduation_agreement_pdf, student_pdf
from .services.rule_engine import _valid_sol_attempt, normalize_area
from .services.rule_packs import recompute_student_for_active_pack
from .services.custom_rule_schema import new_rule_package, validate_rule_package
from .services.custom_rule_lifecycle import activate_approved, approve_validated, immutable_version_snapshot, mark_edited, supersede_active, validate_draft
from .services.custom_rule_activation import persist_active_results, preview_rule_impact
from .services.import_profiles import apply_import_profile, find_import_profile, mark_profile_used, parse_profiles, save_import_profile
from .services.custom_outputs import active_custom_package, custom_agreement_data
from .services.template_packages import apply_template_package, build_template_package, parse_and_validate_template_package, serialize_template_package, template_preview
from .services.onboarding_readiness import school_readiness
from .services.security import FileValidationError, safe_child, validate_uploaded_file
from .services.three_e import three_e_hover, three_e_readiness, three_e_report_rows
from .services.transcript_parser import course_area, process_transcript_batch, process_transcript_upload, transcript_preview
from .services.upload_parser import CANONICAL_FIELDS, _manual_field_locked, counselor_for_last_name, process_upload, read_upload_preview, save_incoming_file, secure_filename
from .services.virginia_eoc_phase_in import ensure_default_windows

BASE_DIR = Path(__file__).resolve().parent.parent
APP_VERSION = "GIC 2.0 Pilot Release Candidate 3 - September 24, 2026"
MANUAL_STUDENT_FIELD_RESTORE_MIGRATION = "restore-manual-student-fields-v2"
COUNSELOR_PROFILE_REFRESH_MIGRATION = "counselor-profile-refresh-v1"
EMPLOYMENT_STATUS_MIGRATION = "employment-manual-ncrc-correction-v7"
SUPPORT_STATUS_MIGRATION = "student-support-lvc-refresh-v1"
NAME_FORMAT_MIGRATION = "student-name-uppercase-v1"
PBA_STATUS_MIGRATION = "history-pba-failure-marker-v4"
SOL_STATUS_CODE_MIGRATION = "sol-status-codes-above-600-v5"
WRITING_SUBSTITUTE_DEDUPE_MIGRATION = "writing-blw-and-summary-dedup-v1"
LEGACY_BLW_AREA_MIGRATION = "legacy-blw-area-writing-refresh-v1"
CUSTOM_EVIDENCE_MIGRATION = "custom-field-evidence-separation-v1"
LEGACY_INSTANCE_DIR = BASE_DIR / "instance"
DEFAULT_DATA_DIR = BASE_DIR / "data"
EXPLICIT_DATA_DIR = os.environ.get("GIC_DATA_DIR")
DEMO_MODE = os.environ.get("GIC_DEMO_MODE", "").strip().lower() == "true"
DATA_DIR = Path(EXPLICIT_DATA_DIR or os.environ.get("AHS_DATA_DIR") or (LEGACY_INSTANCE_DIR if (LEGACY_INSTANCE_DIR / "ahs_tracking.sqlite3").exists() else DEFAULT_DATA_DIR))
INSTANCE_DIR = DATA_DIR
UPLOAD_DIR = DATA_DIR / "uploads"
PENDING_UPLOAD_DIR = DATA_DIR / "pending_uploads"
EXPORT_DIR = DATA_DIR / "exports"
BACKUP_DIR = DATA_DIR / "backups"
LOG_DIR = DATA_DIR / "logs"
REPORT_DIR = DATA_DIR / "reports"
SETTINGS_PATH = DATA_DIR / "settings.json"
DB_PATH = DATA_DIR / "ahs_tracking.sqlite3"
SESSIONS = {}
LOGIN_ATTEMPTS = {}
MAX_REQUEST_BYTES = int(os.environ.get("GIC_MAX_REQUEST_MB", "512")) * 1024 * 1024
MAX_FORM_BYTES = 2 * 1024 * 1024
LOGIN_WINDOW_SECONDS = 15 * 60
LOGIN_MAX_FAILURES = 5
SESSION_IDLE_SECONDS = int(os.environ.get("GIC_SESSION_IDLE_MINUTES", "30")) * 60
SESSION_ABSOLUTE_SECONDS = int(os.environ.get("GIC_SESSION_ABSOLUTE_HOURS", "8")) * 60 * 60
MAX_AUTOMATIC_BACKUPS = int(os.environ.get("GIC_MAX_AUTOMATIC_BACKUPS", "40"))

DEFAULT_SCHOOL_PROFILE = {
    "school_name": "Your School",
    "division_name": "",
    "app_title": "Graduation Intelligence Center",
    "primary_color": "#13294b",
    "accent_color": "#7cc6ee",
    "principal": "",
    "counselors": "",
    "report_footer": "Student data is confidential and intended for authorized school personnel only.",
    "signature_titles": "Student; Parent/Guardian; Counselor/Admin",
}

VIRGINIA_GRADUATION_CONFIG = {
    "template_name": "Virginia Template",
    "status": "Active",
    "diploma_types": [
        {"name": "Standard", "total_credits_required": 22},
        {"name": "Advanced", "total_credits_required": 26},
    ],
    "subject_credit_requirements": {
        "English": {"standard": 4, "advanced": 4},
        "Math": {"standard": 3, "advanced": 4},
        "Science": {"standard": 3, "advanced": 4},
        "History": {"standard": 3, "advanced": 4},
    },
    "assessment_requirements": [
        "English Reading verified credit",
        "English Writing verified credit",
        "Math verified credit",
        "Science verified credit",
        "History verified credit",
        "SOL/LVC/CA/substitute assessment rules",
    ],
    "readiness_indicators": ["3E Readiness", "Credential / CCRI evidence", "ASVAB", "WorkKeys", "Dual Enrollment"],
    "local_checklist_items": ["CPR/AED", "Virtual Course", "Student Service Learning Project"],
    "agreement_template": "Virginia graduation agreement language",
}

CUSTOM_GRADUATION_CONFIG = {
    "template_name": "Custom / Other State Template",
    "status": "Draft",
    "diploma_types": [],
    "subject_credit_requirements": {},
    "assessment_requirements": [],
    "readiness_indicators": [],
    "local_checklist_items": [],
    "agreement_template": "",
}

CONFIG_DEFAULTS = {
    "graduation_template_type": "Virginia Template",
    "graduation_rules_config": json.dumps(VIRGINIA_GRADUATION_CONFIG, indent=2),
    "custom_fields_config": "[]",
    "custom_reports_config": "[]",
    "agreement_builder_config": json.dumps({
        "title": "Graduation Agreement",
        "intro_text": "",
        "checklist_items": [],
        "support_plan_options": [],
        "signature_lines": ["Student", "Parent/Guardian", "Counselor/Admin"],
        "footer": "",
    }, indent=2),
    "import_templates_config": "[]",
    "main_grid_columns_config": json.dumps([
        "student_name",
        "student_id",
        "graduation_class",
        "diploma_type",
        "counselor",
        "graduation_status",
        "readiness_score",
        "major_requirement_summary",
        "notes",
    ], indent=2),
    "rules_wizard_draft": "",
    "custom_rule_package_draft": "",
    "custom_rule_package_versions": "[]",
    "active_custom_rule_package": "",
    "previous_custom_rule_package": "",
}

REPORTS = {
    "missing-english-reading": ("Students Missing English Reading", "EngRLR", "missing"),
    "missing-english-writing": ("Students Missing English Writing", "EngWrit", "missing"),
    "missing-math": ("Students Missing Math Verified Credit", "Math", "category"),
    "missing-science": ("Students Missing Science Verified Credit", "Science", "category"),
    "missing-history": ("Students Missing History Verified Credit", "History", "category"),
    "not-taken-biology": ("Students Who Have Not Taken Biology", "Bio", "participation_missing"),
    "not-taken-algebra-1": ("Students Who Have Not Taken Algebra I", "AlgI", "participation_missing"),
    "not-taken-reading": ("Students Who Have Not Taken EOC Reading", "EngRLR", "participation_missing"),
    "middle-school-eoc": ("Middle School EOC Test Takers", "", "middle_school_eoc"),
    "missing-cpr": ("Students Missing CPR", "CPR/AED Complete", "missing"),
    "missing-employment-credential": ("Students Needing an Employment Credential", "Employment Credential", "missing"),
    "missing-3e-readiness": ("Students With No 3E Evidence", "", "three_e_no_evidence"),
    "possible-lvc": ("Students Eligible for Possible LVC", "Possible LVC", "flag"),
    "needs-retest": ("Students Who Need Retesting", "", "retest"),
    "retake-window": ("SOL Retake Window List", "", "retake_window"),
    "missing-transcript": ("Students Missing Uploaded Transcript", "", "missing_transcript"),
    "asvab-scores": ("ASVAB Scores / 3E Enlistment Points", "", "asvab_scores"),
    "3e-readiness": ("3E Readiness Class Report", "", "three_e"),
    "3e-close": ("Students Close to Next 3E Level", "", "three_e_close"),
    "conflicts": ("Students With Conflicting Data", "Conflict", "flag"),
    "failed-course": ("Students With Failed Course Indicator *", "", "failed"),
    "multiple-attempts": ("Students With Multiple Attempts #", "", "multiple"),
    "cougar-scholars": ("Scholars Club Eligible Students", "", "cougar_scholars"),
    "cougar-scholars-tracking": ("Scholars Club Tracking Sheet", "", "cougar_tracking"),
    "credit-sol-checklist": ("Credit and SOL Checklist", "", "credit_sol_checklist"),
    "unmatched-data": ("Upload / Transcript Records Needing Match Review", "", "unmatched"),
}
CATEGORY_KEYS = {"Science": ["ESCI", "Bio", "Chem"], "Math": ["AlgI", "Geom", "AlgII"], "History": ["WGeo", "WHI", "WHII", "USH"]}


def main():
    port = int(os.environ.get("GIC_PORT") or os.environ.get("AHS_PORT", "5000"))
    host = os.environ.get("GIC_HOST") or os.environ.get("AHS_HOST") or "127.0.0.1"
    if DEMO_MODE:
        validate_demo_startup(DATA_DIR, port, host)
    init_db()
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"Graduation Intelligence Center running at http://{host}:{port}")
    print(f"Data folder: {DATA_DIR}")
    print("Open the site in a browser. First-time installs will show the setup wizard.")
    server.serve_forever()


def validate_demo_startup(data_dir, port, host="127.0.0.1", check_port=True):
    if os.environ.get("GIC_DEMO_MODE", "").strip().lower() != "true":
        raise RuntimeError("Demo mode must be explicitly enabled.")
    if not os.environ.get("GIC_DATA_DIR", "").strip():
        raise RuntimeError("Demo GIC_DATA_DIR must be explicitly configured.")
    package_value = os.environ.get("GIC_DEMO_PACKAGE_ROOT", "").strip()
    if not package_value:
        raise RuntimeError("Demo package root is not configured.")
    package_root = Path(package_value).resolve(strict=True)
    resolved = Path(data_dir).resolve(strict=True)
    expected = (package_root / "demo_data").resolve(strict=True)
    if resolved != expected:
        raise RuntimeError("Demo data must use this package's dedicated demo_data directory.")
    if resolved.name.lower() in {"instance", "school_data"}:
        raise RuntimeError("A live data directory cannot be used in demo mode.")
    marker = resolved / ".gic_demo_environment"
    if not marker.is_file() or marker.read_text(encoding="utf-8").strip() != "GIC_DEMO_DATA_V1":
        raise RuntimeError("The dedicated demo marker is missing or invalid.")
    database = resolved / "ahs_tracking.sqlite3"
    if database.exists():
        connection = sqlite3.connect(f"file:{database.as_posix()}?mode=ro", uri=True)
        try:
            row = connection.execute(
                "SELECT value FROM app_settings WHERE key='demo_mode'"
            ).fetchone()
            school = connection.execute(
                "SELECT value FROM app_settings WHERE key='school_name'"
            ).fetchone()
        except sqlite3.DatabaseError as exc:
            raise RuntimeError("The demo directory contains an unapproved database.") from exc
        finally:
            connection.close()
        if not row or row[0] != "true" or not school or school[0] != "AHS Demonstration Environment":
            raise RuntimeError("The demo directory contains a database that is not approved for demonstration use.")
    if port != 5001:
        raise RuntimeError("The demonstration environment must use port 5001.")
    if check_port:
        probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            probe.bind((host, port))
        except OSError as exc:
            raise RuntimeError("Demo port 5001 is already occupied.") from exc
        finally:
            probe.close()
    print(f"DEMONSTRATION ENVIRONMENT data folder: {resolved}")


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    for folder in [DATA_DIR, UPLOAD_DIR, PENDING_UPLOAD_DIR, EXPORT_DIR, BACKUP_DIR, LOG_DIR, REPORT_DIR]:
        folder.mkdir(parents=True, exist_ok=True)
    if DB_PATH.exists():
        create_backup("before_startup_migrations")
    db = get_db()
    schema = (BASE_DIR / "app" / "schema.sql").read_text(encoding="utf-8")
    db.executescript(schema)
    run_migrations(db)
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS saved_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
            report_type TEXT NOT NULL,
            filename TEXT NOT NULL,
            saved_by INTEGER REFERENCES users(id),
            saved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    db.close()


def run_migrations(db):
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version TEXT PRIMARY KEY,
            applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            username TEXT,
            role TEXT,
            action TEXT NOT NULL,
            detail TEXT,
            ip_address TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS app_settings (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS unmatched_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_upload_id INTEGER REFERENCES upload_history(id) ON DELETE SET NULL,
            record_type TEXT NOT NULL DEFAULT 'Upload',
            first_name TEXT,
            middle_name TEXT,
            last_name TEXT,
            student_id TEXT,
            graduation_class TEXT,
            issue TEXT NOT NULL,
            raw_json TEXT,
            status TEXT NOT NULL DEFAULT 'Open',
            resolved_to_student_id INTEGER REFERENCES students(id) ON DELETE SET NULL,
            resolved_by INTEGER REFERENCES users(id),
            resolved_at TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    ensure_column(db, "users", "disabled", "INTEGER NOT NULL DEFAULT 0")
    ensure_column(db, "users", "updated_at", "TEXT")
    ensure_column(db, "students", "original_cohort", "INTEGER")
    ensure_column(db, "students", "early_graduate", "INTEGER NOT NULL DEFAULT 0")
    ensure_column(db, "students", "middle_school_eoc_taker", "INTEGER NOT NULL DEFAULT 0")
    ensure_column(db, "students", "enrollment_status", "TEXT NOT NULL DEFAULT 'Active'")
    ensure_column(db, "students", "exit_date", "TEXT")
    ensure_column(db, "students", "exit_note", "TEXT")
    db.execute("UPDATE students SET original_cohort = graduation_class WHERE original_cohort IS NULL")
    db.execute("UPDATE students SET enrollment_status = 'Active' WHERE enrollment_status IS NULL OR trim(enrollment_status) = ''")
    if not db.execute(
        "SELECT 1 FROM schema_migrations WHERE version = ?",
        (MANUAL_STUDENT_FIELD_RESTORE_MIGRATION,),
    ).fetchone():
        field_aliases = {
            "diploma_type": ("diploma_type", "diploma type", "diploma"),
            "sped_504_status": ("sped_504_status", "sped / 504 status", "sped/504 status", "special education / 504 status"),
            "counselor": ("counselor", "school counselor"),
        }
        for field_name, aliases in field_aliases.items():
            placeholders = ",".join("?" for _ in aliases)
            latest_edits = db.execute(
                f"""
                SELECT me.student_id_fk, me.new_value
                FROM manual_edits me
                WHERE lower(trim(me.field_name)) IN ({placeholders})
                  AND me.id = (
                    SELECT max(newer.id)
                    FROM manual_edits newer
                    WHERE newer.student_id_fk = me.student_id_fk
                      AND lower(trim(newer.field_name)) IN ({placeholders})
                  )
                """,
                tuple(aliases) + tuple(aliases),
            ).fetchall()
            for edit in latest_edits:
                db.execute(
                    f"UPDATE students SET {field_name} = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                    (edit["new_value"], edit["student_id_fk"]),
                )
        db.execute(
            "INSERT INTO schema_migrations(version) VALUES (?)",
            (MANUAL_STUDENT_FIELD_RESTORE_MIGRATION,),
        )
    if not db.execute("SELECT 1 FROM schema_migrations WHERE version = ?", (NAME_FORMAT_MIGRATION,)).fetchone():
        db.execute(
            """
            UPDATE students
            SET first_name = upper(trim(first_name)),
                middle_name = upper(trim(COALESCE(middle_name, ''))),
                last_name = upper(trim(last_name)),
                updated_at = CURRENT_TIMESTAMP
            """
        )
        db.execute("INSERT INTO schema_migrations(version) VALUES (?)", (NAME_FORMAT_MIGRATION,))
    for column, declaration in {
        "normalized_subject": "TEXT",
        "normalized_test_date": "TEXT",
        "date_validation_status": "TEXT",
        "imported_performance_level": "TEXT",
        "delivery_group": "TEXT",
        "administration_id": "TEXT",
        "attempt_fingerprint": "TEXT",
        "duplicate_status": "TEXT",
        "canonical_attempt_id": "INTEGER",
    }.items():
        ensure_column(db, "test_attempts", column, declaration)
    db.executescript(
        """
        CREATE INDEX IF NOT EXISTS idx_attempts_fingerprint ON test_attempts(attempt_fingerprint);
        CREATE TABLE IF NOT EXISTS testing_windows (
            id TEXT PRIMARY KEY, state TEXT NOT NULL, window_name TEXT NOT NULL,
            school_year TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL,
            assessment_group TEXT NOT NULL DEFAULT 'EOC', rule_version TEXT NOT NULL,
            source_reference TEXT, active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS eoc_subject_rules (
            student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
            normalized_subject TEXT NOT NULL, initial_attempt_id INTEGER,
            initial_attempt_date TEXT, initial_attempt_window_id TEXT,
            initial_attempt_school_year TEXT, locked_rule_version TEXT,
            locked_passing_score REAL, locked_lavc_floor REAL,
            proficient_score REAL, advanced_score REAL, threshold_source TEXT,
            assignment_method TEXT, manual_override_reason TEXT,
            valid_attempt_count INTEGER NOT NULL DEFAULT 0, highest_valid_score REAL,
            latest_attempt_date TEXT, current_pass_status TEXT,
            current_performance_level TEXT, lavc_eligibility_status TEXT,
            verified_credit_status TEXT, review_reason TEXT,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(student_id_fk, normalized_subject)
        );
        CREATE TABLE IF NOT EXISTS eoc_rule_overrides (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
            normalized_subject TEXT NOT NULL, old_rule_json TEXT,
            new_rule_json TEXT NOT NULL, reason TEXT NOT NULL,
            changed_by INTEGER REFERENCES users(id),
            changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS eoc_migration_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            migration_version TEXT NOT NULL, summary_json TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS custom_field_values (
            student_id_fk INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
            field_key TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Missing',
            display_value TEXT,
            score REAL,
            source TEXT,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(student_id_fk, field_key)
        );
        """
    )
    if not db.execute("SELECT 1 FROM schema_migrations WHERE version = ?", (CUSTOM_EVIDENCE_MIGRATION,)).fetchone():
        db.execute(
            """
            INSERT OR IGNORE INTO custom_field_values
            (student_id_fk, field_key, status, display_value, score, source, updated_at)
            SELECT student_id_fk, requirement_key, status, display_value, score, source, updated_at
            FROM requirement_status
            WHERE source IN ('Manual Edit', 'Imported Custom Grid Field', 'Custom Rules')
            """
        )
        db.execute("INSERT INTO schema_migrations(version) VALUES (?)", (CUSTOM_EVIDENCE_MIGRATION,))
    ensure_default_windows(db)
    refresh_migrations = (
        EMPLOYMENT_STATUS_MIGRATION, SUPPORT_STATUS_MIGRATION,
        PBA_STATUS_MIGRATION, SOL_STATUS_CODE_MIGRATION,
        WRITING_SUBSTITUTE_DEDUPE_MIGRATION, LEGACY_BLW_AREA_MIGRATION,
    )
    pending_refreshes = [
        version for version in refresh_migrations
        if not db.execute("SELECT 1 FROM schema_migrations WHERE version = ?", (version,)).fetchone()
    ]
    if pending_refreshes:
        student_ids = [row["id"] for row in db.execute("SELECT id FROM students ORDER BY id").fetchall()]
        for student_id in student_ids:
            recompute_student_for_active_pack(db, student_id)
        db.executemany(
            "INSERT INTO schema_migrations(version) VALUES (?)",
            [(version,) for version in pending_refreshes],
        )
    db.execute("INSERT OR IGNORE INTO schema_migrations(version) VALUES (?)", (APP_VERSION,))
    for key, value in DEFAULT_SCHOOL_PROFILE.items():
        db.execute("INSERT OR IGNORE INTO app_settings(key, value) VALUES (?, ?)", (key, value))
    for key, value in CONFIG_DEFAULTS.items():
        db.execute("INSERT OR IGNORE INTO app_settings(key, value) VALUES (?, ?)", (key, value))
    if not db.execute(
        "SELECT 1 FROM schema_migrations WHERE version = ?",
        (COUNSELOR_PROFILE_REFRESH_MIGRATION,),
    ).fetchone():
        for student in db.execute("SELECT id, last_name FROM students ORDER BY id").fetchall():
            if _manual_field_locked(db, student["id"], "counselor"):
                continue
            assigned_counselor = counselor_for_last_name(db, student["last_name"])
            if assigned_counselor:
                db.execute(
                    "UPDATE students SET counselor = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                    (assigned_counselor, student["id"]),
                )
        db.execute(
            "INSERT INTO schema_migrations(version) VALUES (?)",
            (COUNSELOR_PROFILE_REFRESH_MIGRATION,),
        )
    db.commit()


def ensure_column(db, table_name, column_name, declaration):
    columns = [row["name"] for row in db.execute(f"PRAGMA table_info({table_name})").fetchall()]
    if column_name not in columns:
        db.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {declaration}")


def create_backup(reason="manual"):
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    if not DB_PATH.exists():
        return None
    safe_reason = re.sub(r"[^A-Za-z0-9_.-]+", "_", reason).strip("_") or "backup"
    filename = f"ahs_tracking_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{safe_reason}.sqlite3"
    target = BACKUP_DIR / filename
    source = sqlite3.connect(DB_PATH, timeout=30)
    destination = sqlite3.connect(target)
    try:
        source.backup(destination)
        result = destination.execute("PRAGMA integrity_check").fetchone()
        if not result or result[0] != "ok":
            raise RuntimeError("Backup integrity validation failed.")
    finally:
        destination.close()
        source.close()
    if reason != "manual":
        automatic = sorted(
            (path for path in BACKUP_DIR.glob("*.sqlite3") if not path.name.endswith("_manual.sqlite3")),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
        for old_backup in automatic[MAX_AUTOMATIC_BACKUPS:]:
            old_backup.unlink(missing_ok=True)
    return target


def restore_backup(filename):
    if filename != os.path.basename(filename):
        raise ValueError("Backup file not found.")
    backup_path = safe_child(BACKUP_DIR, filename)
    validation = sqlite3.connect(f"file:{backup_path.as_posix()}?mode=ro", uri=True)
    try:
        result = validation.execute("PRAGMA integrity_check").fetchone()
        required = validation.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('students','users','test_attempts')"
        ).fetchone()[0]
        if not result or result[0] != "ok" or required != 3:
            raise ValueError("Backup validation failed. The active database was not changed.")
    finally:
        validation.close()
    create_backup("before_restore")
    source = sqlite3.connect(f"file:{backup_path.as_posix()}?mode=ro", uri=True)
    destination = sqlite3.connect(DB_PATH, timeout=30)
    try:
        source.backup(destination)
        result = destination.execute("PRAGMA integrity_check").fetchone()
        if not result or result[0] != "ok":
            raise RuntimeError("Restored database failed integrity validation.")
    finally:
        destination.close()
        source.close()


def school_profile(db=None):
    profile = dict(DEFAULT_SCHOOL_PROFILE)
    close = False
    if db is None:
        db = get_db()
        close = True
    try:
        if table_exists(db, "app_settings"):
            for row in db.execute("SELECT key, value FROM app_settings").fetchall():
                profile[row["key"]] = row["value"] or ""
    finally:
        if close:
            db.close()
    return profile


def app_setting(db, key, default=""):
    row = db.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row and row["value"] is not None else default


def set_app_setting(db, key, value):
    db.execute(
        "INSERT INTO app_settings(key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP",
        (key, value),
    )


def graduation_template_type(db):
    return app_setting(db, "graduation_template_type", "Virginia Template")


def table_exists(db, table_name):
    return db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,)).fetchone() is not None


def log_audit(db, user, action, detail="", ip_address=""):
    if not table_exists(db, "audit_log"):
        return
    db.execute(
        "INSERT INTO audit_log(user_id, username, role, action, detail, ip_address) VALUES (?, ?, ?, ?, ?, ?)",
        (user_value(user, "id"), user_value(user, "username"), user_value(user, "role"), action, detail, ip_address),
    )


def user_value(user, key):
    if not user:
        return None
    try:
        return user[key]
    except (KeyError, IndexError, TypeError):
        return user.get(key) if hasattr(user, "get") else None


def invalidate_user_sessions(user_id):
    for sid, session in list(SESSIONS.items()):
        if session.get("id") == user_id:
            SESSIONS.pop(sid, None)


def inject_csrf_tokens(html, token):
    if not token:
        return html
    hidden = f'<input type="hidden" name="csrf_token" value="{esc(token)}">'
    return re.sub(
        r"(<form\b[^>]*\bmethod=[\"']?post[\"']?[^>]*>)",
        lambda match: match.group(1) + hidden,
        html,
        flags=re.IGNORECASE,
    )


def hash_password(password):
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 180000).hex()
    return f"pbkdf2_sha256${salt}${digest}"


def verify_password(stored, password):
    try:
        algorithm, salt, digest = stored.split("$", 2)
    except ValueError:
        return False
    if algorithm != "pbkdf2_sha256":
        return False
    test = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 180000).hex()
    return hmac.compare_digest(test, digest)


class Handler(BaseHTTPRequestHandler):
    server_version = "GICLocal/1.0"

    def do_GET(self):
        try:
            self.route_get()
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
            return
        except Exception as exc:
            log_exception(exc)
            self.error_page(500, f"Server error: {esc(exc)}")

    def do_POST(self):
        try:
            if self.headers.get("Sec-Fetch-Site", "").lower() == "cross-site":
                return self.error_page(403, "Cross-site form submission blocked.")
            length = int(self.headers.get("Content-Length", "0") or 0)
            if length < 0 or length > MAX_REQUEST_BYTES:
                return self.error_page(413, f"Upload is too large. The local limit is {MAX_REQUEST_BYTES // (1024 * 1024)} MB.")
            self.route_post()
        except PermissionError as exc:
            self.error_page(403, esc(str(exc)))
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
            return
        except Exception as exc:
            log_exception(exc)
            self.error_page(500, f"Server error: {esc(exc)}")

    def route_get(self):
        path, query = split_url(self.path)
        if path == "/static/styles.css":
            return self.send_static_css()
        if path == "/setup":
            db = get_db()
            try:
                if not setup_required(db):
                    return self.redirect("/login")
                return self.page("First-Time Setup", setup_html(db))
            finally:
                db.close()
        if path == "/login":
            db = get_db()
            try:
                if setup_required(db):
                    return self.redirect("/setup")
            finally:
                db.close()
            return self.page("Secure Local Login", login_html())
        if path == "/logout":
            sid = self.session_id()
            if sid:
                SESSIONS.pop(sid, None)
            return self.redirect("/login")
        user = self.current_user()
        if not user:
            db = get_db()
            try:
                if setup_required(db):
                    return self.redirect("/setup")
            finally:
                db.close()
            return self.redirect("/login")
        db = get_db()
        try:
            if path == "/":
                return self.dashboard(db, user)
            if path == "/demo-scenarios" and DEMO_MODE:
                return self.demo_scenarios(db, user)
            if path == "/upload":
                if not can_edit(user):
                    return self.error_page(403, "Teacher Viewer accounts cannot upload or change student data.")
                return self.page("Upload New Data", upload_html(), user)
            if path.startswith("/exports/"):
                if not can_export(user):
                    return self.error_page(403, "Teacher Viewer accounts cannot download student exports.")
                return self.serve_export_file(path)
            if path == "/grids":
                return self.grids(db, user)
            if path.startswith("/grids/") and path.endswith("/delete"):
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can delete a class grid.")
                return self.delete_class_confirm(db, int(path.split("/")[2]), user)
            if path.startswith("/grids/") and path.endswith("/export.xlsx"):
                if not can_export(user):
                    return self.error_page(403, "Teacher Viewer accounts cannot download student exports.")
                if not export_confirmed(query):
                    return self.export_warning(path, query, user)
                grad_class = int(path.split("/")[2])
                return self.export_ready(export_class_grid(db, grad_class), f"ahs_class_{grad_class}_grid.xlsx", f"Class of {grad_class} Excel Export", user)
            if path.startswith("/agreements/") and path.endswith("/print"):
                return self.agreements_print(db, int(path.split("/")[2]), user)
            if path.startswith("/checklists/") and path.endswith("/print"):
                return self.credit_sol_checklists_print(db, int(path.split("/")[2]), user)
            if path.startswith("/grids/"):
                return self.class_grid(db, int(path.split("/")[2]), user)
            if path == "/search":
                return self.search(db, query, user)
            if path == "/troubleshooter":
                return self.troubleshooter(db, query, user)
            if path == "/students/new":
                if not can_edit(user):
                    return self.error_page(403, "Teacher Viewer accounts cannot add students.")
                return self.page("Add Student", add_student_html(query), user)
            if path.startswith("/students/") and path.endswith("/report.pdf"):
                if not can_export(user):
                    return self.error_page(403, "Teacher Viewer accounts cannot download student reports.")
                if not export_confirmed(query):
                    return self.export_warning(path, query, user)
                student_id = int(path.split("/")[2])
                return self.download(student_pdf(db, student_id), "ahs_graduation_status_report.pdf", "application/pdf")
            if path.startswith("/students/") and path.endswith("/agreement.pdf"):
                if not can_export(user):
                    return self.error_page(403, "Teacher Viewer accounts cannot download student reports.")
                if not export_confirmed(query):
                    return self.export_warning(path, query, user)
                student_id = int(path.split("/")[2])
                profile = school_profile(db)
                custom_model = custom_agreement_data(db, student_id)
                if custom_model:
                    return self.download(custom_graduation_agreement_pdf(custom_model, profile.get("school_name") or "School"), f"graduation_agreement_{student_id}.pdf", "application/pdf")
                student, rows, supports = agreement_data(db, student_id)
                return self.download(graduation_agreement_pdf(student, rows, supports, profile.get("school_name") or "School"), f"graduation_agreement_{student_id}.pdf", "application/pdf")
            if path.startswith("/students/") and path.endswith("/agreement"):
                return self.graduation_agreement(db, int(path.split("/")[2]), user)
            if path.startswith("/students/") and path.endswith("/checklist"):
                return self.student_credit_sol_checklist(db, int(path.split("/")[2]), user)
            if path.startswith("/students/") and path.endswith("/report"):
                return self.student_report(db, int(path.split("/")[2]), user)
            if path.startswith("/students/") and path.endswith("/delete"):
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can permanently delete a student.")
                return self.student_delete_confirm(db, int(path.split("/")[2]), user)
            if path.startswith("/students/"):
                return self.student_profile(db, int(path.split("/")[2]), user)
            if path == "/reports":
                return self.reports(db, query, user)
            if path.startswith("/letters/") and path.endswith("/print"):
                return self.letters_print(db, int(path.split("/")[2]), user)
            if path.startswith("/reports/") and path.endswith(".xlsx"):
                if not can_export(user):
                    return self.error_page(403, "Teacher Viewer accounts cannot download student exports.")
                if not export_confirmed(query):
                    return self.export_warning(path, query, user)
                key = path.split("/")[2].replace(".xlsx", "")
                suffix = f"_{query.get('class', ['all'])[0]}" if query.get("class", [""])[0] else ""
                return self.export_ready(export_report(db, key, report_rows(db, key, query)), f"ahs_{key}{suffix}.xlsx", "Report Excel Export", user)
            if path == "/upload-history.xlsx":
                if not can_export(user):
                    return self.error_page(403, "Teacher Viewer accounts cannot download student exports.")
                if not export_confirmed(query):
                    return self.export_warning(path, query, user)
                return self.export_ready(export_upload_history(db), "ahs_upload_history.xlsx", "Upload History Excel Export", user)
            if path == "/settings":
                return self.page("Settings / Column Mapping", settings_html(), user)
            if path == "/admin/users":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can manage users.")
                return self.page("User Management", user_management_html(db), user)
            if path == "/admin/backups":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can manage backups.")
                return self.page("Backup and Restore", backups_html(), user)
            if path == "/admin/school-profile":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can edit the school profile.")
                return self.page("School Profile", school_profile_html(db), user)
            if path == "/admin/graduation-rules":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can edit graduation rules.")
                return self.page("Graduation Rules", graduation_rules_html(db), user)
            if path == "/admin/rules-wizard":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can use the rules wizard.")
                return self.page("Graduation Rules Wizard", rules_wizard_html(db), user)
            if path == "/admin/rules-builder":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can review structured graduation rules.")
                return self.page("Structured Rules Builder", rules_builder_html(db), user)
            if path == "/admin/templates/export.json":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can export configuration templates.")
                package = build_template_package(db, f"{school_profile(db).get('school_name') or 'School'} Template")
                log_audit(db, user, "template_export", f"Exported configuration template {package['manifest']['name']}", self.client_address[0])
                db.commit()
                return self.download(BytesIO(serialize_template_package(package)), "gic_school_template.json", "application/json")
            if path == "/admin/templates":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can manage configuration templates.")
                return self.page("School and State Templates", template_packages_html(db), user)
            if path == "/admin/readiness":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can review school setup readiness.")
                return self.page("School Setup Readiness", readiness_dashboard_html(db), user)
            if path == "/admin/testing-windows":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can manage Virginia testing windows.")
                return self.page("Virginia Testing Windows", testing_windows_html(db), user)
            if path == "/admin/custom-fields":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can edit custom fields.")
                return self.page("Custom Tracking Fields", custom_fields_html(db), user)
            if path == "/admin/custom-reports":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can edit custom reports.")
                return self.page("Custom Report Builder", custom_reports_html(db), user)
            if path == "/admin/agreement-builder":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can edit agreement templates.")
                return self.page("Graduation Agreement Builder", agreement_builder_html(db), user)
            if path == "/admin/import-templates":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can edit import templates.")
                return self.page("Import Template Manager", import_templates_html(db), user)
            if path == "/admin/grid-columns":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can edit grid columns.")
                return self.page("Main Grid Columns", grid_columns_html(db), user)
            if path == "/admin/audit-log":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can view the audit log.")
                return self.page("Audit Log", audit_log_html(db), user)
            if path == "/admin/security":
                if not is_admin(user):
                    return self.error_page(403, "Only Admin accounts can view security administration guidance.")
                return self.page("Safety, Privacy, and Security", security_admin_html(), user)
            if path == "/release-notes":
                return self.page("Release Notes", release_notes_html(), user)
        finally:
            db.close()
        self.error_page(404, "Page not found.")

    def route_post(self):
        path, _ = split_url(self.path)
        if path == "/setup":
            return self.handle_setup()
        if path == "/login":
            form = self.urlencoded_form()
            client_key = self.client_address[0]
            now = time.monotonic()
            failures = [stamp for stamp in LOGIN_ATTEMPTS.get(client_key, []) if now - stamp < LOGIN_WINDOW_SECONDS]
            if len(failures) >= LOGIN_MAX_FAILURES:
                LOGIN_ATTEMPTS[client_key] = failures
                return self.error_page(429, "Too many unsuccessful sign-in attempts. Wait 15 minutes and try again, or ask an Admin to reset the account.")
            db = get_db()
            user = db.execute("SELECT * FROM users WHERE username = ?", (form.get("username", ""),)).fetchone()
            ok = bool(user and not user["disabled"] and verify_password(user["password_hash"], form.get("password", "")))
            if ok:
                LOGIN_ATTEMPTS.pop(client_key, None)
                log_audit(db, user, "login", "Successful login", self.client_address[0])
                db.commit()
            else:
                failures.append(now)
                LOGIN_ATTEMPTS[client_key] = failures
                log_audit(db, user, "login_failed", f"Failed login for username={form.get('username', '')[:64]}", self.client_address[0])
                db.commit()
            db.close()
            if ok:
                sid = secrets.token_urlsafe(32)
                now = time.monotonic()
                SESSIONS[sid] = {
                    "id": user["id"], "username": user["username"], "role": user["role"],
                    "display_name": user["display_name"] or user["username"],
                    "created_at": now, "last_seen": now, "csrf_token": secrets.token_urlsafe(32),
                    "pending_uploads": {},
                }
                self.send_response(303)
                self.send_header("Location", "/")
                self.send_header("Set-Cookie", f"ahs_session={sid}; HttpOnly; SameSite=Strict; Path=/")
                self.end_headers()
                return
            return self.page("Secure Local Login", login_html("Invalid username, disabled account, or password."))
        user = self.current_user()
        if not user:
            return self.redirect("/login")
        if path == "/upload":
            if not can_edit(user):
                return self.error_page(403, "Teacher Viewer accounts cannot upload or change student data.")
            return self.handle_upload(user)
        if path == "/upload/process":
            if not can_edit(user):
                return self.error_page(403, "Teacher Viewer accounts cannot upload or change student data.")
            return self.handle_upload_process(user)
        if path.startswith("/students/") and path.endswith("/agreement/save"):
            if not can_edit(user):
                return self.error_page(403, "Teacher Viewer accounts cannot save reports.")
            return self.handle_save_agreement(int(path.split("/")[2]), user)
        if path.startswith("/grids/") and path.endswith("/delete"):
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can delete a class grid.")
            return self.handle_delete_class(int(path.split("/")[2]), user)
        if path.startswith("/students/") and path.endswith("/edit"):
            if not can_edit(user):
                return self.error_page(403, "Teacher Viewer accounts cannot edit student records.")
            return self.handle_student_edit(int(path.split("/")[2]), user)
        if path.startswith("/students/") and path.endswith("/status"):
            if not can_edit(user):
                return self.error_page(403, "Teacher Viewer accounts cannot change student enrollment status.")
            return self.handle_student_status(int(path.split("/")[2]), user)
        if path.startswith("/students/") and path.endswith("/delete"):
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can permanently delete a student.")
            return self.handle_student_delete(int(path.split("/")[2]), user)
        if path == "/students/new":
            if not can_edit(user):
                return self.error_page(403, "Teacher Viewer accounts cannot add students.")
            return self.handle_add_student(user)
        if path == "/troubleshooter":
            if not can_edit(user):
                return self.error_page(403, "Teacher Viewer accounts cannot resolve unmatched records.")
            return self.handle_troubleshooter(user)
        if path == "/admin/users":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can manage users.")
            return self.handle_user_management(user)
        if path == "/admin/backups/create":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can create backups.")
            return self.handle_manual_backup(user)
        if path == "/admin/backups/restore":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can restore backups.")
            return self.handle_restore_backup(user)
        if path == "/admin/school-profile":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can edit the school profile.")
            return self.handle_school_profile(user)
        if path == "/admin/graduation-rules":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can edit graduation rules.")
            return self.handle_graduation_rules(user)
        if path == "/admin/rules-wizard":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can use the rules wizard.")
            return self.handle_rules_wizard(user)
        if path == "/admin/rules-builder":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can review structured graduation rules.")
            return self.handle_rules_builder(user)
        if path == "/admin/templates/import":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can import configuration templates.")
            return self.handle_template_import(user)
        if path == "/admin/templates/apply":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can apply configuration templates.")
            return self.handle_template_apply(user)
        if path == "/admin/testing-windows":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can manage Virginia testing windows.")
            return self.handle_testing_window(user)
        if path == "/admin/custom-fields":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can edit custom fields.")
            return self.handle_custom_fields(user)
        if path == "/admin/custom-reports":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can edit custom reports.")
            return self.handle_custom_reports(user)
        if path == "/admin/agreement-builder":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can edit agreement templates.")
            return self.handle_config_text(user, "agreement_builder_config", "/admin/agreement-builder", "agreement_builder_update")
        if path == "/admin/import-templates":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can edit import templates.")
            return self.handle_import_profiles(user)
        if path == "/admin/grid-columns":
            if not is_admin(user):
                return self.error_page(403, "Only Admin accounts can edit grid columns.")
            return self.handle_grid_columns(user)
        self.error_page(404, "Page not found.")

    def handle_setup(self):
        form = self.urlencoded_form()
        db = get_db()
        try:
            if not setup_required(db):
                return self.redirect("/login")
            username = form.get("admin_username", "").strip()
            password = form.get("admin_password", "")
            confirm = form.get("admin_password_confirm", "")
            school_name = form.get("school_name", "").strip()
            if not username or not password or password != confirm or len(password) < 10 or not school_name:
                return self.page("First-Time Setup", setup_html(db, "Enter a school name and matching admin password with at least 10 characters."))
            for key in DEFAULT_SCHOOL_PROFILE:
                set_app_setting(db, key, form.get(key, DEFAULT_SCHOOL_PROFILE[key]))
            template_type = form.get("graduation_template_type", "Virginia Template")
            if template_type not in {"Virginia Template", "Custom / Other State Template"}:
                template_type = "Custom / Other State Template"
            set_app_setting(db, "graduation_template_type", template_type)
            starter_config = VIRGINIA_GRADUATION_CONFIG if template_type == "Virginia Template" else CUSTOM_GRADUATION_CONFIG
            set_app_setting(db, "graduation_rules_config", json.dumps(starter_config, indent=2))
            db.execute(
                "INSERT INTO users(username, password_hash, role, display_name, disabled) VALUES (?, ?, 'Admin', ?, 0)",
                (username, hash_password(password), form.get("admin_display_name", username).strip() or username),
            )
            log_audit(db, {"username": username, "role": "Admin"}, "first_time_setup", f"Created initial admin and school profile for {school_name}; template={template_type}", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.redirect("/login")

    def dashboard(self, db, user):
        counts = {
            "students": db.execute("SELECT COUNT(*) FROM students").fetchone()[0],
            "uploads": db.execute("SELECT COUNT(*) FROM upload_history").fetchone()[0],
            "flags": db.execute("SELECT COUNT(*) FROM student_flags WHERE resolved = 0").fetchone()[0],
            "unmatched": db.execute("SELECT COUNT(*) FROM unmatched_records WHERE status = 'Open'").fetchone()[0],
        }
        classes = db.execute("SELECT graduation_class, COUNT(*) total FROM class_grid_members GROUP BY graduation_class ORDER BY graduation_class").fetchall()
        uploads = db.execute("SELECT * FROM upload_history ORDER BY uploaded_at DESC LIMIT 8").fetchall()
        class_rows = [[link(f'Class of {r["graduation_class"]}', f'/grids/{r["graduation_class"]}'), r["total"], link("Open Grid", f'/grids/{r["graduation_class"]}')] for r in classes]
        class_content = table(["Graduation Class", "Students", ""], class_rows) if class_rows else '<div class="empty-state"><strong>No class grids yet</strong><p>Import a student roster or existing graduation grid to begin.</p><a class="button" href="/upload">Create First Grid</a></div>'
        upload_rows = [[r["original_filename"], r["uploaded_at"], r["records_processed"], r["conflicts_warnings"]] for r in uploads]
        upload_content = table(["File", "When", "Rows", "Warnings"], upload_rows) if upload_rows else '<div class="empty-state"><strong>No uploads yet</strong><p>New uploads and their warning counts will appear here.</p></div>'
        if is_admin(user):
            quick_links = '<a href="/grids">Class Grids</a><a href="/reports">Reports</a><a href="/troubleshooter">Resolve Unmatched Data</a><a href="/admin/backups">Backups</a>'
        elif can_edit(user):
            quick_links = '<a href="/grids">Class Grids</a><a href="/reports">Reports</a><a href="/troubleshooter">Resolve Unmatched Data</a><a href="/search">Find Student</a>'
        else:
            quick_links = '<a href="/grids">Class Grids</a><a href="/reports">Reports</a><a href="/search">Find Student</a><a href="/release-notes">Release Notes</a>'
        primary_action = '<a class="button" href="/upload">Upload Data</a>' if can_edit(user) else ""
        body = f"""
        <section class="page-head"><div><h1>Dashboard</h1><p>Graduation progress, current warnings, and the next work that needs attention.</p></div><div class="actions">{primary_action}<a class="button secondary" href="/search">Find Student</a></div></section>
        <section class="metrics"><article><strong>{counts['students']}</strong><span>Students</span></article><article><strong>{len(classes)}</strong><span>Active Class Grids</span></article><article><strong>{counts['flags']}</strong><span>Open Warnings</span></article><article class="{'metric-alert' if counts['unmatched'] else ''}"><strong>{counts['unmatched']}</strong><span>Unmatched Records</span></article></section>
        <section class="quick-links">{quick_links}</section>
        <section class="grid two"><div class="panel"><div class="section-head"><div><h2>Graduation Class Grids</h2><p class="muted small">Open a class to review individual progress.</p></div><a href="/grids">View All</a></div>{class_content}</div>
        <div class="panel"><div class="section-head"><div><h2>Recent Uploads</h2><p class="muted small">Newest files and processing warnings.</p></div><a href="/upload-history.xlsx">Export History</a></div>{upload_content}</div></section>
        """
        if is_admin(user):
            readiness = school_readiness_with_backups(db)
            next_step = readiness.get("next_step")
            next_action = f'<a class="button" href="{esc(next_step["link"])}">Continue: {esc(next_step["name"])}</a>' if next_step else '<a class="button secondary" href="/admin/readiness">Review Setup</a>'
            body = readiness_summary_html(readiness, next_action) + body
        self.page("Dashboard", body, user)

    def grids(self, db, user):
        rows = db.execute("SELECT graduation_class, COUNT(*) total FROM class_grid_members GROUP BY graduation_class ORDER BY graduation_class").fetchall()
        card_items = []
        for r in rows:
            delete_action = f'<a class="button secondary danger-action" href="/grids/{r["graduation_class"]}/delete">Delete</a>' if is_admin(user) else ""
            card_items.append(f"""
            <article class="class-card">
              <a class="class-main" href="/grids/{r["graduation_class"]}">
                <strong>Class of {r["graduation_class"]}</strong>
                <span>{r["total"]} students</span>
              </a>
              <div class="class-actions">
                <a class="button secondary" href="/grids/{r["graduation_class"]}/export.xlsx">Excel</a>
                <a class="button secondary" href="/letters/{r["graduation_class"]}/print">Needs Letters</a>
                <a class="button secondary" href="/agreements/{r["graduation_class"]}/print">Agreements</a>
                <a class="button secondary" href="/checklists/{r["graduation_class"]}/print">Credit/SOL</a>
                {delete_action}
              </div>
            </article>
            """)
        cards = "".join(card_items) or '<div class="empty-state"><strong>No class grids exist yet</strong><p>Start with a student roster or an existing graduation spreadsheet.</p><a class="button" href="/upload">Create First Grid</a></div>'
        management = "" if not can_edit(user) else """
        <section class="panel">
          <h2>Class Grid Management</h2>
          <div class="actions">
            <a class="button" href="/upload">Create From Student List</a>
            <a class="button secondary" href="/upload">Import Existing Grid</a>
            <a class="button secondary" href="/students/new">Add Students</a>
            <a class="button secondary" href="/upload-history.xlsx">View Import History</a>
          </div>
          <p class="muted small">Use Upload and choose Student Roster / Class List or Existing Graduation Grid to create a new active class grid. Assessment uploads update existing students only.</p>
        </section>
        """
        inactive = db.execute(
            """
            SELECT original_cohort, enrollment_status, COUNT(*) total
            FROM students
            WHERE enrollment_status IN ('Transferred Out', 'Graduated')
            GROUP BY original_cohort, enrollment_status
            ORDER BY original_cohort, enrollment_status
            """
        ).fetchall()
        inactive_html = "" if not inactive else f'<section class="panel"><h2>Retained Cohort Records</h2><p class="muted small">These students are retained for cohort history but are not shown on active class grids.</p>{table(["Original Cohort","Status","Students"], [[r["original_cohort"], r["enrollment_status"], r["total"]] for r in inactive])}</section>'
        self.page("Graduation Class Grids", f'<section class="page-head"><div><h1>Graduation Class Grids</h1><p>Each grid persists and updates as new uploads are processed.</p></div></section>{management}<section class="panel card-list">{cards}</section>{inactive_html}', user)

    def class_grid(self, db, grad_class, user):
        students = db.execute(
            """
            SELECT s.* FROM students s
            JOIN class_grid_members m ON m.student_id_fk = s.id
            WHERE m.graduation_class = ?
            ORDER BY s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE
            """,
            (grad_class,),
        ).fetchall()
        if graduation_template_type(db) != "Virginia Template":
            return self.custom_class_grid(db, grad_class, students, user)
        ids = [r["id"] for r in students]
        statuses = status_map(db, ids)
        attempts = attempts_map(db, ids)
        local_columns = visible_custom_grid_columns(db)
        rows = []
        for s in students:
            st = statuses.get(s["id"], {})
            student_attempts = attempts.get(s["id"], [])
            readiness = three_e_readiness(db, s["id"])
            rows.append([student_grid_name(s), s["diploma_type"], s["sped_504_status"], s["counselor"] or "", status_pick_cell(st, ["ESCI", "Bio", "Chem"], student_attempts), status_pick_cell(st, ["AlgI", "Geom", "AlgII"], student_attempts), status_pick_cell(st, ["EngRLR"], student_attempts), substitute_cell(student_attempts, "reading"), status_pick_cell(st, ["EngWrit"], student_attempts), substitute_cell(student_attempts, "writing"), status_pick_cell(st, ["WGeo", "WHI", "WHII", "USH"], student_attempts), status_pick(st, ["CPR/AED Complete"], "status"), employment_credential_cell(st.get("Employment Credential"), student_attempts), three_e_cell(readiness), completion_status_cell(st.get("SOLs Complete"))] + [custom_field_grid_cell(st.get(column)) for column in local_columns])
        grid_table_class = "grid-table senior-grid" if int(grad_class) == _senior_class_for_reports() else "grid-table"
        delete_action = f'<a class="button secondary" href="/grids/{grad_class}/delete">Delete Class</a>' if is_admin(user) else ""
        headers = ["Student","Diploma","SPED/504","Counselor","Science","Math","English R","WD","English W","BLW","History","CPR","Employment","3E Readiness","SOLs Complete"] + [custom_grid_header(column) for column in local_columns]
        body = f'<section class="page-head"><div><h1>Class of {grad_class}</h1><p>Current tracking grid with color-coded requirement families.</p></div><div class="actions"><a class="button" href="/grids/{grad_class}/export.xlsx">Export Excel</a><a class="button secondary" href="/admin/grid-columns">Customize Columns</a><a class="button secondary" href="/reports?report=missing-employment-credential&class={grad_class}">Employment Needs</a><a class="button secondary" href="/reports?report=3e-readiness&class={grad_class}">View 3E Class Report</a><a class="button secondary" href="/letters/{grad_class}/print">Print Needs Letters</a><a class="button secondary" href="/agreements/{grad_class}/print">Print Agreements</a><a class="button secondary" href="/checklists/{grad_class}/print">Print Credit/SOL Checklists</a>{delete_action}</div></section><div class="table-scroll panel class-grid-scroll">{table(headers, rows, grid_table_class)}</div>'
        self.page(f"Class of {grad_class}", body, user)

    def custom_class_grid(self, db, grad_class, students, user):
        ids = [r["id"] for r in students]
        statuses = status_map(db, ids)
        columns = custom_grid_columns(db)
        headers = [custom_grid_header(column) for column in columns]
        rows = []
        for student in students:
            student_statuses = statuses.get(student["id"], {})
            rows.append([custom_grid_cell(student, student_statuses, column) for column in columns])
        delete_action = f'<a class="button secondary" href="/grids/{grad_class}/delete">Delete Class</a>' if is_admin(user) else ""
        body = f"""
        <section class="page-head">
          <div><h1>Class of {grad_class}</h1><p>Custom graduation grid using this school's selected columns and tracking fields.</p></div>
          <div class="actions">
            <a class="button" href="/grids/{grad_class}/export.xlsx">Export Excel</a>
            <a class="button secondary" href="/admin/grid-columns">Customize Grid Columns</a>
            <a class="button secondary" href="/admin/custom-fields">Custom Fields</a>
            <a class="button secondary" href="/reports">Reports</a>
            {delete_action}
          </div>
        </section>
        <section class="panel warning"><strong>Custom grid:</strong> use each student profile's Manual Grid / Requirement Edit section to update school-specific fields that do not come through an upload yet. Detailed fields can also be kept in reports instead of the main grid.</section>
        <div class="table-scroll panel">{table(headers, rows, "grid-table")}</div>
        """
        self.page(f"Class of {grad_class}", body, user)

    def delete_class_confirm(self, db, grad_class, user):
        total = db.execute("SELECT COUNT(*) FROM class_grid_members WHERE graduation_class = ?", (grad_class,)).fetchone()[0]
        body = f'<section class="page-head"><div><h1>Delete Class of {grad_class}</h1><p>This removes {total} students and their local test history from this app. Export the class grid first if you need an archive.</p></div></section><form method="post" class="panel" action="/grids/{grad_class}/delete"><label>Type DELETE to confirm<input name="confirm" required></label><button type="submit">Delete Class of {grad_class}</button></form>'
        self.page(f"Delete Class of {grad_class}", body, user)

    def search(self, db, query, user):
        filters = {k: query.get(k, [""])[0].strip() for k in ["first_name", "last_name", "student_id", "graduation_class", "counselor", "diploma_type", "missing", "needs_retake"]}
        rows = search_students(db, filters) if any(filters.values()) else []
        fields = "".join(f'<label>{label(k)}<input name="{k}" value="{esc(v)}"></label>' for k, v in filters.items())
        body = f'<section class="page-head"><div><h1>Search Student</h1><p>Find active, transferred, or graduated students by demographics, class, counselor, missing requirement, or retake area.</p></div></section><form class="panel form-grid" method="get">{fields}<button type="submit">Search</button></form><section class="panel">{table(["Name","ID","Class","Status","Counselor","Diploma"], [[link(f"{esc(r["last_name"])}, {esc(r["first_name"])}", f"/students/{r["id"]}"), r["student_id"] or "", r["graduation_class"], r["enrollment_status"] or "Active", r["counselor"] or "", r["diploma_type"]] for r in rows])}</section>'
        self.page("Search Student", body, user)

    def troubleshooter(self, db, query, user):
        open_rows = db.execute("SELECT * FROM unmatched_records WHERE status = 'Open' ORDER BY created_at DESC LIMIT 100").fetchall()
        warning_uploads = db.execute("SELECT * FROM upload_history WHERE conflicts_warnings > 0 ORDER BY uploaded_at DESC LIMIT 20").fetchall()
        body = f"""
        <section class="page-head"><div><h1>Student Match Troubleshooter</h1><p>Review unmatched uploads, name spelling differences, transcript match issues, and warning rows.</p></div><div class="actions"><a class="button" href="/students/new">Add Student Manually</a><a class="button secondary" href="/reports?report=unmatched-data">View Unmatched Report</a></div></section>
        <section class="panel"><h2>Open Match Queue</h2>{unmatched_records_table(db, open_rows)}</section>
        <section class="panel"><h2>Recent Uploads With Warnings</h2>{table(["File","When","Rows","Warnings","Source"], [[r["original_filename"], r["uploaded_at"], r["records_processed"], r["conflicts_warnings"], r["data_source_type"] or ""] for r in warning_uploads])}</section>
        """
        self.page("Student Match Troubleshooter", body, user)

    def demo_scenarios(self, db, user):
        students = db.execute(
            """
            SELECT id, first_name, last_name, graduation_class, notes
            FROM students
            WHERE notes LIKE 'DEMO SCENARIO:%'
            ORDER BY graduation_class, last_name
            """
        ).fetchall()
        rows = [
            [
                link(f'{esc(row["last_name"])}, {esc(row["first_name"])}', f'/students/{row["id"]}'),
                row["graduation_class"],
                (row["notes"] or "").replace("DEMO SCENARIO:", "").strip(),
            ]
            for row in students
        ]
        body = f"""
        <section class="page-head"><div><h1>Demonstration Scenarios</h1><p>Quick links for presenting fictional workflows.</p></div></section>
        <section class="panel">{table(["Fictional Student","Class","Scenario"], rows)}</section>
        """
        self.page("Demonstration Scenarios", body, user)

    def student_profile(self, db, student_id, user):
        s = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
        statuses = db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ? ORDER BY requirement_key", (student_id,)).fetchall()
        attempts = db.execute("SELECT * FROM test_attempts WHERE student_id_fk = ? ORDER BY created_at DESC", (student_id,)).fetchall()
        flags = db.execute("SELECT * FROM student_flags WHERE student_id_fk = ? AND resolved = 0", (student_id,)).fetchall()
        edits = db.execute("SELECT * FROM manual_edits WHERE student_id_fk = ? ORDER BY edited_at DESC", (student_id,)).fetchall()
        saved = db.execute("SELECT * FROM saved_reports WHERE student_id_fk = ? ORDER BY saved_at DESC", (student_id,)).fetchall()
        documents = db.execute("SELECT * FROM student_documents WHERE student_id_fk = ? ORDER BY uploaded_at DESC", (student_id,)).fetchall()
        transcript_courses = db.execute("SELECT * FROM transcript_courses WHERE student_id_fk = ? ORDER BY status, school_year, course_title", (student_id,)).fetchall()
        transcript_html = transcript_section(transcript_courses, documents)
        readiness = three_e_readiness(db, student_id)
        readiness_html = three_e_card(readiness)
        eoc_rules = db.execute(
            "SELECT * FROM eoc_subject_rules WHERE student_id_fk=? ORDER BY normalized_subject",
            (student_id,),
        ).fetchall()
        eoc_rules_html = eoc_phase_in_card(eoc_rules)
        flag_html = f'<section class="panel warning-list"><h2>Open Flags</h2>{"".join(f"<p>{esc(f["message"])}</p>" for f in flags)}</section>' if flags else ""
        edit_form = f"""
        <form method="post" action="/students/{student_id}/edit" class="stack">
        <input type="hidden" name="edit_action" value="profile">
        <label>Student ID <input name="student_id" value="{esc(s['student_id'] or '')}"></label>
        <label>First Name <input name="first_name" value="{esc(s['first_name'] or '')}" required></label>
        <label>Middle Name <input name="middle_name" value="{esc(s['middle_name'] or '')}"></label>
        <label>Last Name <input name="last_name" value="{esc(s['last_name'] or '')}" required></label>
        <label>Planned Graduation Class <input name="graduation_class" value="{esc(s['graduation_class'] or '')}" required></label>
        <label>Original Cohort <input name="original_cohort" value="{esc(s['original_cohort'] or s['graduation_class'] or '')}" required></label>
        <label class="choice"><input type="checkbox" name="early_graduate" value="1" {"checked" if s['early_graduate'] else ""}><span><strong>Early Graduate</strong><small>Place in the earlier graduating class while retaining the original cohort.</small></span></label>
        <label class="choice"><input type="checkbox" name="middle_school_eoc_taker" value="1" {"checked" if s['middle_school_eoc_taker'] else ""}><span><strong>MS EOC Test Taker</strong><small>Student took Algebra or another mathematics EOC in middle school and needs high-school EOC scheduling review.</small></span></label>
        <label>Diploma Type <input name="diploma_type" value="{esc(s['diploma_type'] or '')}"></label>
        <label>SPED / 504 Status <input name="sped_504_status" value="{esc(s['sped_504_status'] or '')}"></label>
        <label>Counselor <input name="counselor" value="{esc(s['counselor'] or '')}"></label>
        <label>Notes <textarea name="notes">{esc(s['notes'] or '')}</textarea></label>
        <label>Required Edit Note <input name="edit_note" required></label><button type="submit">Save Manual Edit</button></form>
        """
        grid_edit_form = manual_grid_edit_form(db, student_id)
        enrollment_status = s["enrollment_status"] or "Active"
        status_note = f' | Exit date: {esc(s["exit_date"] or "Not recorded")}' if enrollment_status != "Active" else ""
        status_actions = ""
        if can_edit(user):
            if enrollment_status == "Active":
                status_actions = f'''<div class="actions">
                <form method="post" action="/students/{student_id}/status" class="inline-form"><input type="hidden" name="status" value="Transferred Out"><input name="note" placeholder="Transfer destination or note" required><button class="secondary" type="submit">Transferred Out</button></form>
                <form method="post" action="/students/{student_id}/status" class="inline-form"><input type="hidden" name="status" value="Graduated"><input name="note" placeholder="Graduation note" required><button class="secondary" type="submit">Graduated</button></form>
                </div>'''
            else:
                status_actions = f'''<form method="post" action="/students/{student_id}/status" class="inline-form"><input type="hidden" name="status" value="Active"><input name="note" placeholder="Reason for restoring" required><button type="submit">Restore to Active Grid</button></form>'''
        status_panel = f'<section class="panel"><h2>Enrollment / Cohort Status</h2><p><strong>{esc(enrollment_status)}</strong>{status_note}</p><p>{esc(s["exit_note"] or "")}</p>{status_actions}</section>'
        delete_student_action = f'<a class="button secondary danger-action" href="/students/{student_id}/delete">Permanently Delete Incorrect Student</a>' if is_admin(user) else ""
        body = f"""
        <section class="page-head"><div><h1>{esc(s['first_name'])} {esc(s['last_name'])}</h1><p>Class of {s['graduation_class']} | {student_cohort_label(s)} | {esc(s['diploma_type'] or '')} | Counselor: {esc(s['counselor'] or '')}</p></div><div class="actions"><a class="button" href="/students/{student_id}/agreement">Generate Graduation Agreement</a><a class="button secondary" href="/students/{student_id}/checklist">Credit/SOL Checklist</a><a class="button secondary" href="/students/{student_id}/report">Print Report</a><a class="button secondary" href="/students/{student_id}/report.pdf">Download PDF</a>{delete_student_action}</div></section>
        {flag_html}
        {status_panel}
        {readiness_html}
        {eoc_rules_html}
        <section class="grid two"><div class="panel"><h2>Requirement Status</h2>{table(['Requirement','Status','Value','Retest'], [[r['requirement_key'], r['status'], status_value_cell(r, attempts), 'Yes' if r['needs_retest'] else ''] for r in statuses])}</div><div class="panel"><h2>Manual Student Edit</h2>{edit_form}</div></section>
        <section class="panel"><h2>Manual Grid / Requirement Edit</h2>{grid_edit_form}</section>
        {transcript_html}
        <section class="panel"><h2>Test / Upload History</h2>{table(['Date','Area','Name','Score','Status','Course'], [[a['test_date'] or a['created_at'], a['test_area'], a['test_name'] or '', a['raw_score'] or '', a['pass_fail'] or '', a['course'] or ''] for a in attempts])}</section>
        <section class="panel"><h2>Edit History</h2>{table(['When','Field','Old','New','Note'], [[e['edited_at'], e['field_name'], e['old_value'], e['new_value'], e['note']] for e in edits])}</section>
        <section class="panel"><h2>Saved Reports</h2>{table(['When','Type','File'], [[r['saved_at'], r['report_type'], r['filename']] for r in saved])}</section>
        """
        self.page("Student Profile", body, user)

    def handle_student_status(self, student_id, user):
        form = self.urlencoded_form()
        new_status = form.get("status", "").strip()
        note = form.get("note", "").strip()
        if new_status not in {"Active", "Transferred Out", "Graduated"} or not note:
            return self.error_page(400, "Choose a valid student status and enter a note.")
        db = get_db()
        student = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
        if not student:
            db.close()
            return self.error_page(404, "Student not found.")
        old_status = student["enrollment_status"] or "Active"
        if new_status == "Active":
            db.execute(
                "UPDATE students SET enrollment_status='Active', exit_date=NULL, exit_note=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (student_id,),
            )
            db.execute(
                "INSERT OR IGNORE INTO class_grid_members(student_id_fk, graduation_class) VALUES (?, ?)",
                (student_id, student["graduation_class"]),
            )
        else:
            db.execute(
                "UPDATE students SET enrollment_status=?, exit_date=date('now'), exit_note=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (new_status, note, student_id),
            )
            db.execute("DELETE FROM class_grid_members WHERE student_id_fk = ?", (student_id,))
        db.execute(
            "INSERT INTO manual_edits(student_id_fk, edited_by, field_name, old_value, new_value, note) VALUES (?, ?, 'Enrollment Status', ?, ?, ?)",
            (student_id, user["id"], old_status, new_status, note),
        )
        log_audit(db, user, "student_status_change", f"student_id={student_id}; {old_status} -> {new_status}; note={note}", self.client_address[0])
        db.commit()
        db.close()
        return self.redirect(f"/students/{student_id}")

    def student_delete_confirm(self, db, student_id, user):
        student = db.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
        if not student:
            return self.error_page(404, "Student not found.")
        name = f'{student["first_name"]} {student["last_name"]}'
        body = f"""
        <section class="page-head"><div><h1>Permanently Delete Student</h1><p>{esc(name)} | Class of {student['graduation_class']}</p></div></section>
        <section class="panel warning"><h2>This is different from Graduated or Transferred Out</h2><p>Use this only to correct an accidental merge, duplicate, or incorrect student. The student record, attempts, statuses, transcript rows, and class membership will be removed from the active database. A safety backup is created first. Existing backup archives and original multi-student upload files follow the school's retention policy and are not rewritten.</p></section>
        <form method="post" action="/students/{student_id}/delete" class="panel stack"><label>Type DELETE STUDENT to confirm<input name="confirm" required></label><label>Reason<input name="reason" required placeholder="Example: Incorrect same-name merge; recreate correct student"></label><button class="danger-action" type="submit">Permanently Delete This Student</button></form>
        """
        self.page("Permanently Delete Student", body, user)

    def handle_student_delete(self, student_id, user):
        form = self.urlencoded_form()
        if form.get("confirm", "").strip().upper() != "DELETE STUDENT":
            return self.error_page(400, "Type DELETE STUDENT exactly to confirm permanent deletion.")
        reason = form.get("reason", "").strip()
        if not reason:
            return self.error_page(400, "Enter a reason for the permanent deletion.")
        db = get_db()
        student = db.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
        if not student:
            db.close()
            return self.error_page(404, "Student not found.")
        backup = create_backup("before_delete_student")
        identity = f'{student["last_name"]}, {student["first_name"]}; class={student["graduation_class"]}; local_id={student_id}'
        db.execute("DELETE FROM students WHERE id=?", (student_id,))
        log_audit(db, user, "student_permanent_delete", f"{identity}; reason={reason}; backup={backup.name if backup else 'none'}", self.client_address[0])
        db.commit()
        db.close()
        return self.redirect("/grids")

    def graduation_agreement(self, db, student_id, user):
        custom_model = custom_agreement_data(db, student_id)
        if custom_model:
            profile = school_profile(db)
            return self.page("Graduation Agreement", custom_agreement_section(custom_model, profile.get("school_name") or "School", True), user)
        student, rows, supports = agreement_data(db, student_id)
        profile = school_profile(db)
        school = profile.get("school_name") or "School"
        body = f"""
        <section class="agreement-page">
          <div class="report-toolbar actions">
            <button onclick="window.print()">Print</button>
            <a class="button secondary" href="/students/{student_id}/agreement.pdf">Export as PDF</a>
            <form method="post" action="/students/{student_id}/agreement/save"><button type="submit">Save copy to student record</button></form>
          </div>
          <h1>{esc(school)} - Class of {student['graduation_class']} Graduation Agreement</h1>
          <div class="agreement-meta">
            <p><strong>Student Name:</strong> {esc(student['first_name'])} {esc(student['last_name'])}</p>
            <p><strong>Graduation Class:</strong> {student['graduation_class']}</p>
            <p><strong>Diploma Type:</strong> {esc(student['diploma_type'] or '')}</p>
            <p><strong>Counselor:</strong> {esc(student['counselor'] or '')}</p>
            <p><strong>Date Generated:</strong> {datetime.now().strftime('%Y-%m-%d')}</p>
          </div>
          <h2>Dear Senior and Parent/Guardian,</h2>
          <p>Graduation is one of life's great milestones, and we are proud to partner with you in reaching this important goal. At {esc(school)}, we believe in holding high expectations for every student and providing the support needed to meet them.</p>
          <p>To participate in graduation ceremonies, students must meet all Virginia Department of Education requirements for their diploma type. This includes earning all required standard credits, completing verified credits, meeting credential and CPR requirements, meeting attendance expectations, and clearing any financial or discipline obligations.</p>
          <h2>Current Graduation Status</h2>
          {table(['Requirement','Met?','Notes'], [[r['requirement'], r['met'], r['notes']] for r in rows])}
          <h2>Student Success Support Plan: Check all that apply.</h2>
          <div class="support-grid">{''.join(f'<label><span class="box">{"X" if item["checked"] else ""}</span>{esc(item["label"])}</label>' for item in supports)}</div>
          <h2>Course Completion: Senior Year Impact</h2>
          <p>In addition to earning verified credits through SOL tests, substitute tests, performance-based assessments, or locally awarded verified credits, all students must pass required courses to graduate. For seniors, this includes English 12 and U.S. Government, both of which are core credit-bearing classes tied directly to diploma completion.</p>
          <p>These courses can become a graduation barrier late in the year, particularly when students do not turn in final projects or assignments, miss final exams or perform poorly, or have borderline grades and stop engaging in the final weeks.</p>
          <p>To address this, {esc(school)} may provide targeted support options for students who are at risk of not completing required courses. This support may include finishing incomplete assignments, completing additional recovery work, attending targeted support sessions, or participating in May Term when appropriate.</p>
          <p>This approach maintains academic integrity while providing a structured safety net for students at risk of missing graduation due to incomplete coursework, not just SOL performance.</p>
          <p><strong>Even if a student earns all verified credits, the student must still pass all state-required courses in order to graduate.</strong></p>
          <h2>Acknowledgment</h2>
          <div class="signature-grid"><p>Student Signature / Date</p><p>Parent/Guardian Signature / Date</p><p>Counselor/Admin Signature / Date</p></div>
        </section>
        """
        self.page("Graduation Agreement", body, user)

    def student_report(self, db, student_id, user):
        s = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
        statuses = db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ? ORDER BY requirement_key", (student_id,)).fetchall()
        flags = db.execute("SELECT * FROM student_flags WHERE student_id_fk = ? AND resolved = 0", (student_id,)).fetchall()
        profile = school_profile(db)
        school = profile.get("school_name") or "School"
        body = f"""
        <section class="report-page"><div class="report-toolbar"><button onclick="window.print()">Print Report</button><a class="button secondary" href="/students/{student_id}/report.pdf">Download PDF</a></div>
        <h1>{esc(school)} Graduation Status Report</h1><p><strong>{esc(s['first_name'])} {esc(s['last_name'])}</strong> | Class of {s['graduation_class']} | {esc(s['diploma_type'] or '')} | Counselor: {esc(s['counselor'] or '')}</p>
        <p>Date printed: <span id="printed-date"></span></p><h2>Graduation Requirement Checklist</h2>{table(['Requirement','Status','Score / Value'], [[r['requirement_key'], r['status'], r['display_value'] or ''] for r in statuses])}
        <h2>Items Still Needed / Recommended Next Steps</h2>{''.join(f'<p>{esc(f["message"])}</p>' for f in flags) or '<p>No open flags. Review any missing checklist items above.</p>'}</section>
        <script>document.getElementById('printed-date').textContent = new Date().toLocaleDateString();</script>
        """
        self.page("Graduation Status Report", body, user)

    def student_credit_sol_checklist(self, db, student_id, user):
        student = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
        statuses = {row["requirement_key"]: row for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ?", (student_id,)).fetchall()}
        courses = db.execute("SELECT * FROM transcript_courses WHERE student_id_fk = ? ORDER BY school_year, course_title", (student_id,)).fetchall()
        attempts = db.execute("SELECT * FROM test_attempts WHERE student_id_fk = ? ORDER BY test_date DESC, created_at DESC", (student_id,)).fetchall()
        body = f'<div class="report-toolbar"><button onclick="window.print()">Print / Save PDF</button><a class="button secondary" href="/students/{student_id}">Back to Student</a></div>{credit_sol_checklist_section(student, statuses, courses, attempts)}'
        self.page(f"{student['first_name']} {student['last_name']} Credit/SOL Checklist", body, user)

    def reports(self, db, query, user):
        selected = query.get("report", ["needs-retest"])[0]
        title = custom_report_title(db, selected) or REPORTS.get(selected, REPORTS["needs-retest"])[0]
        rows = report_rows(db, selected, query)
        options = "".join(f'<option value="{k}" {"selected" if k == selected else ""}>{esc(v[0])}</option>' for k, v in REPORTS.items())
        custom_options = "".join(f'<option value="{esc(item["key"])}" {"selected" if item["key"] == selected else ""}>{esc(item["name"])}</option>' for item in custom_report_definitions(db))
        if custom_options:
            options += f'<optgroup label="Custom Reports">{custom_options}</optgroup>'
        classes = db.execute("SELECT graduation_class FROM class_grid_members GROUP BY graduation_class ORDER BY graduation_class").fetchall()
        selected_class = query.get("class", [""])[0]
        class_options = '<option value="">All Classes</option>' + "".join(f'<option value="{r["graduation_class"]}" {"selected" if selected_class == str(r["graduation_class"]) else ""}>Class of {r["graduation_class"]}</option>' for r in classes)
        class_query = f'&class={esc(selected_class)}' if selected_class else ""
        if REPORTS.get(selected, ("", "", ""))[2].startswith("three_e"):
            report_html = three_e_report_table(rows)
            actions = f'<a class="button" href="/reports?report=3e-readiness{class_query}">View 3E Class Report</a><a class="button secondary" href="/reports/{selected}.xlsx?class={esc(selected_class)}">Export 3E Report to Excel</a><button onclick="window.print()">Print 3E Summary</button><a class="button secondary" href="/reports?report=missing-3e-readiness{class_query}">Show Students With No 3E Evidence</a><a class="button secondary" href="/reports?report=3e-close{class_query}">Show Students Close to Next 3E Level</a>'
        elif REPORTS.get(selected, ("", "", ""))[2] == "credit_sol_checklist":
            report_html = table(["Name","ID","Class","Counselor","Detail"], [[link(f"{esc(r["last_name"])}, {esc(r["first_name"])}", f"/students/{r["id"]}"), r["student_id"] or "", r["graduation_class"], r["counselor"] or "", r["detail"] if "detail" in r.keys() else ""] for r in rows])
            print_link = f'/checklists/{esc(selected_class)}/print' if selected_class else '/reports?report=credit-sol-checklist'
            actions = f'<a class="button" href="{print_link}">Print Class Checklists</a><a class="button secondary" href="/reports/{selected}.xlsx?class={esc(selected_class)}">Export Checklist Roster</a>'
        elif REPORTS.get(selected, ("", "", ""))[2] == "unmatched":
            report_html = table(["Name","ID","Class","Counselor","Detail"], [[link(f"{esc(r['last_name'])}, {esc(r['first_name'])}", "/troubleshooter"), r["student_id"] or "", r["graduation_class"], r["counselor"] or "", r["detail"]] for r in rows])
            actions = f'<a class="button" href="/troubleshooter">Open Troubleshooter</a><a class="button secondary" href="/reports/{selected}.xlsx">Export Excel</a>'
        else:
            report_html = table(["Name","ID","Class","Counselor","Detail"], [[link(f"{esc(r["last_name"])}, {esc(r["first_name"])}", f"/students/{r["id"]}"), r["student_id"] or "", r["graduation_class"], r["counselor"] or "", r["detail"] if "detail" in r.keys() else ""] for r in rows])
            actions = f'<a class="button" href="/reports/{selected}.xlsx">Export Excel</a>'
        body = f'<section class="page-head"><div><h1>Reports / Students Needing Action</h1><p>Use these lists for follow-up, retesting plans, and end-of-year checks.</p></div><div class="actions">{actions}</div></section><form class="panel form-grid" method="get"><label>Report<select name="report" onchange="this.form.submit()">{options}</select></label><label>Graduation Class<select name="class" onchange="this.form.submit()">{class_options}</select></label></form><section class="panel"><h2>{esc(title)}</h2>{report_html}</section>'
        self.page("Reports", body, user)

    def letters_print(self, db, grad_class, user):
        profile = school_profile(db)
        school = profile.get("school_name") or "School"
        students = db.execute(
            """
            SELECT s.* FROM students s
            JOIN class_grid_members m ON m.student_id_fk = s.id
            WHERE m.graduation_class = ?
            ORDER BY s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE
            """,
            (grad_class,),
        ).fetchall()
        sections = []
        for student in students:
            statuses = {row["requirement_key"]: row for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ?", (student["id"],)).fetchall()}
            needs = graduation_needs(statuses)
            sections.append(f'<section class="letter"><h1>{esc(school)} Graduation Needs Letter</h1><p>Date: <span class="printed-date"></span></p><p>Student: <strong>{esc(student["first_name"])} {esc(student["last_name"])}</strong><br>Class of {student["graduation_class"]}<br>Counselor: {esc(student["counselor"] or "")}</p><p>This snapshot shows graduation testing and requirement items still needing attention at this time.</p>{table(["Area","Current Status"], needs or [["Graduation Testing", "No open testing needs shown."]])}<p>Please contact the school counseling department with questions about the next step for any item listed above.</p></section>')
        body = f'<div class="report-toolbar"><button onclick="window.print()">Print All Letters</button></div>{"".join(sections)}<script>document.querySelectorAll(".printed-date").forEach(e => e.textContent = new Date().toLocaleDateString());</script>'
        self.page(f"Class of {grad_class} Needs Letters", body, user)

    def agreements_print(self, db, grad_class, user):
        students = db.execute(
            """
            SELECT s.* FROM students s
            JOIN class_grid_members m ON m.student_id_fk = s.id
            WHERE m.graduation_class = ?
            ORDER BY s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE
            """,
            (grad_class,),
        ).fetchall()
        sections = []
        profile = school_profile(db)
        school = profile.get("school_name") or "School"
        for student in students:
            custom_model = custom_agreement_data(db, student["id"])
            if custom_model:
                sections.append(custom_agreement_section(custom_model, school, False))
                continue
            _, rows, supports = agreement_data(db, student["id"])
            sections.append(agreement_print_section(student, rows, supports, school))
        body = f'<div class="report-toolbar"><button onclick="window.print()">Print All Graduation Agreements</button><a class="button secondary" href="/grids/{grad_class}">Back to Class Grid</a></div>{"".join(sections)}'
        self.page(f"Class of {grad_class} Graduation Agreements", body, user)

    def credit_sol_checklists_print(self, db, grad_class, user):
        students = db.execute(
            """
            SELECT s.* FROM students s
            JOIN class_grid_members m ON m.student_id_fk = s.id
            WHERE m.graduation_class = ?
            ORDER BY s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE
            """,
            (grad_class,),
        ).fetchall()
        sections = []
        for student in students:
            statuses = {row["requirement_key"]: row for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ?", (student["id"],)).fetchall()}
            courses = db.execute("SELECT * FROM transcript_courses WHERE student_id_fk = ? ORDER BY school_year, course_title", (student["id"],)).fetchall()
            attempts = db.execute("SELECT * FROM test_attempts WHERE student_id_fk = ? ORDER BY test_date DESC, created_at DESC", (student["id"],)).fetchall()
            sections.append(credit_sol_checklist_section(student, statuses, courses, attempts))
        body = f'<div class="report-toolbar"><button onclick="window.print()">Print Credit/SOL Checklists</button><a class="button secondary" href="/grids/{grad_class}">Back to Class Grid</a></div>{"".join(sections)}'
        self.page(f"Class of {grad_class} Credit and SOL Checklists", body, user)

    def handle_upload(self, user):
        form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ={"REQUEST_METHOD": "POST", "CONTENT_TYPE": self.headers.get("Content-Type")})
        self.validate_csrf_form(form)
        file_item = form["data_file"] if "data_file" in form else None
        if isinstance(file_item, list):
            file_item = next((item for item in file_item if getattr(item, "filename", "")), None)
        if file_item is None or not file_item.filename:
            return self.page("Upload New Data", upload_html("Choose an Excel, CSV, state assessment, roster, grid, or transcript/course-history file first."), user)
        original = secure_filename(file_item.filename)
        stored = f"{secrets.token_hex(16)}_{original}"
        pending_path = PENDING_UPLOAD_DIR / stored
        with open(pending_path, "wb") as out:
            shutil.copyfileobj(file_item.file, out, length=1024 * 1024)
        try:
            validate_uploaded_file(pending_path, original, category="data", max_bytes=MAX_REQUEST_BYTES)
            path = UPLOAD_DIR / stored
            pending_path.replace(path)
            path = safe_child(UPLOAD_DIR, path)
        except FileValidationError as exc:
            pending_path.unlink(missing_ok=True)
            db = get_db()
            try:
                log_audit(db, user, "upload_rejected", f"Rejected upload {original}: {exc}", self.client_address[0])
                db.commit()
            finally:
                db.close()
            return self.page("Upload New Data", upload_html(str(exc)), user)
        source_type = form.getfirst("source_type", "")
        note = form.getfirst("note", "")
        upload_token = self.register_pending_upload(path, original, stored, source_type, note)
        if original.lower().endswith(".pdf") and "transcript" in source_type.lower():
            preview = transcript_preview(str(path))
            return self.page("Confirm Transcript Upload", transcript_mapping_html(original, upload_token, source_type, note, preview), user)
        preview = read_upload_preview(str(path))
        db = get_db()
        try:
            existing_classes = active_grid_classes(db)
            profiles = parse_profiles(app_setting(db, "import_templates_config", "[]"))
            matched_profile, profile_score, profile_reason = find_import_profile(profiles, source_type, preview["columns"])
            if matched_profile:
                preview["suggestions"] = apply_import_profile(matched_profile, preview["columns"], preview["suggestions"])
        finally:
            db.close()
        self.page("Confirm Column Mapping", mapping_html(original, upload_token, source_type, note, preview, existing_classes, matched_profile, profile_score, profile_reason, is_admin(user)), user)

    def handle_upload_process(self, user):
        form = self.urlencoded_form()
        upload = self.resolve_pending_upload(form.get("upload_token", ""))
        form.update(upload)
        if form.get("upload_kind") == "transcript" or (form.get("path", "").lower().endswith(".pdf") and "transcript" in form.get("source_type", "").lower()):
            db = get_db()
            backup = create_backup("before_upload")
            results = process_transcript_batch(db, form["path"], form["original"], form["stored"])
            matched_ids = sorted({result["student_id"] for result in results if result["student_id"]})
            for student_id in matched_ids:
                recompute_student_for_active_pack(db, student_id)
            for result in results:
                if not result["student_id"]:
                    parsed = result["parsed"]
                    name_parts = (parsed.get("student_name") or result.get("student_name") or "").replace(",", " ").split()
                    db.execute(
                        """
                        INSERT INTO unmatched_records(record_type, first_name, middle_name, last_name, student_id, graduation_class, issue, raw_json)
                        VALUES ('Transcript', ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            name_parts[1] if len(name_parts) > 1 else (name_parts[0] if name_parts else ""),
                            " ".join(name_parts[2:-1]) if len(name_parts) > 3 else "",
                            name_parts[0] if len(name_parts) > 1 else "",
                            result.get("state_id") or parsed.get("state_id") or "",
                            str(result.get("graduation_class") or parsed.get("graduation_class") or ""),
                            result.get("error") or "Transcript could not be matched to an existing student.",
                            json.dumps(parsed, ensure_ascii=True),
                        ),
                    )
            log_audit(db, user, "upload", f"Processed transcript upload {form.get('original', '')}; backup={backup.name if backup else ''}", self.client_address[0])
            db.commit()
            db.close()
            return self.page("Transcript Batch Results", transcript_batch_results_html(results), user)
        source_type = form.get("source_type", "")
        mapping = {field: form.get(field, "") for field in CANONICAL_FIELDS}
        db = get_db()
        backup = create_backup("before_upload")
        if not grid_creating_source(source_type) and db.execute("SELECT COUNT(*) FROM class_grid_members").fetchone()[0] == 0:
            db.close()
            return self.page(
                "Upload New Data",
                upload_html("No class grid exists yet. Import a Student Roster / Class List or Existing Graduation Grid first, then upload assessment/test score files."),
                user,
            )
        try:
            upload_id, processed, updates, warnings = process_upload(
                db,
                form["path"],
                form["original"],
                form["stored"],
                user["id"],
                source_type,
                form.get("note", ""),
                mapping,
                form.get("grid_action", ""),
                form.get("grid_class_override", ""),
            )
        except ValueError as exc:
            db.close()
            return self.page("Upload New Data", upload_html(str(exc)), user)
        profiles = parse_profiles(app_setting(db, "import_templates_config", "[]"))
        profile_id = form.get("import_profile_id", "").strip()
        if profile_id:
            profiles = mark_profile_used(profiles, profile_id)
        if form.get("save_import_profile") == "1" and is_admin(user):
            columns = read_upload_preview(form["path"])["columns"]
            profiles, saved_profile = save_import_profile(profiles, form.get("import_profile_name", ""), source_type, columns, mapping)
            profile_id = saved_profile["id"]
            log_audit(db, user, "import_profile_save", f"Saved import profile {saved_profile['name']} for {source_type}", self.client_address[0])
        if profile_id or form.get("save_import_profile") == "1":
            set_app_setting(db, "import_templates_config", json.dumps(profiles, indent=2))
        log_audit(db, user, "upload", f"Processed {form.get('original', '')}; rows={processed}; updates={updates}; warnings={warnings}; backup={backup.name if backup else ''}", self.client_address[0])
        created_classes = [
            row["graduation_class"]
            for row in db.execute("SELECT DISTINCT graduation_class FROM class_grid_members WHERE source_upload_id = ? ORDER BY graduation_class", (upload_id,)).fetchall()
        ]
        db.commit()
        db.close()
        if created_classes:
            return self.redirect(f"/grids/{created_classes[0]}")
        if warnings and not updates:
            return self.redirect("/troubleshooter")
        return self.redirect(f"/?message=Upload+{upload_id}+processed:+{processed}+rows,+{updates}+updates,+{warnings}+warnings")

    def register_pending_upload(self, path, original, stored, source_type, note):
        session = SESSIONS.get(self.session_id())
        if not session:
            raise PermissionError("Your session expired. Sign in and upload the file again.")
        token = secrets.token_urlsafe(32)
        session.setdefault("pending_uploads", {})[token] = {
            "path": str(safe_child(UPLOAD_DIR, path)),
            "original": original,
            "stored": stored,
            "source_type": source_type,
            "note": note,
            "created_at": time.monotonic(),
        }
        return token

    def resolve_pending_upload(self, token):
        session = SESSIONS.get(self.session_id())
        item = session.get("pending_uploads", {}).get(token) if session else None
        if not item or time.monotonic() - item.get("created_at", 0) > 30 * 60:
            raise PermissionError("This upload preview expired. Return to Upload and choose the file again.")
        item = dict(item)
        item["path"] = str(safe_child(UPLOAD_DIR, item["path"]))
        return item

    def handle_delete_class(self, grad_class, user):
        form = self.urlencoded_form()
        if form.get("confirm", "").strip().upper() != "DELETE":
            return self.redirect(f"/grids/{grad_class}")
        db = get_db()
        backup = create_backup("before_delete_class")
        db.execute("DELETE FROM students WHERE graduation_class = ?", (grad_class,))
        log_audit(db, user, "delete_class", f"Deleted class of {grad_class}; backup={backup.name if backup else ''}", self.client_address[0])
        db.commit()
        db.close()
        return self.redirect("/grids")

    def handle_save_agreement(self, student_id, user):
        db = get_db()
        custom_model = custom_agreement_data(db, student_id)
        agreements_dir = INSTANCE_DIR / "agreements"
        agreements_dir.mkdir(exist_ok=True)
        filename = f"graduation_agreement_{student_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        path = agreements_dir / filename
        with open(path, "wb") as handle:
            profile = school_profile(db)
            if custom_model:
                handle.write(custom_graduation_agreement_pdf(custom_model, profile.get("school_name") or "School").getvalue())
            else:
                student, rows, supports = agreement_data(db, student_id)
                handle.write(graduation_agreement_pdf(student, rows, supports, profile.get("school_name") or "School").getvalue())
        db.execute(
            "INSERT INTO saved_reports(student_id_fk, report_type, filename, saved_by) VALUES (?, ?, ?, ?)",
            (student_id, "Graduation Agreement", str(path), user["id"]),
        )
        log_audit(db, user, "report_saved", f"Saved graduation agreement for student_id={student_id}: {filename}", self.client_address[0])
        db.commit()
        db.close()
        return self.redirect(f"/students/{student_id}/agreement")

    def handle_student_edit(self, student_id, user):
        form = self.urlencoded_form()
        note = form.get("edit_note", "").strip()
        db = get_db()
        s = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
        if not note:
            db.close()
            return self.page(
                "Manual Edit Not Saved",
                f'<section class="panel warning"><h1>Manual Edit Not Saved</h1><p>Enter an edit note explaining the change, then save again. No student information was changed.</p><p><a class="button" href="/students/{student_id}">Back to Student</a></p></section>',
                user,
            )
        try:
            if form.get("edit_action") == "grid":
                self._save_manual_grid_edit(db, user, student_id, form, note)
                if form.get("requirement_key", "").startswith(("Employment:", "PBA:")):
                    recompute_student_for_active_pack(db, student_id)
            else:
                self._save_manual_student_edit(db, user, student_id, s, form, note)
                recompute_student_for_active_pack(db, student_id)
            db.commit()
        except (sqlite3.IntegrityError, ValueError) as exc:
            db.rollback()
            db.close()
            return self.page("Manual Edit Error", f'<section class="panel warning"><h1>Manual Edit Not Saved</h1><p>{esc(str(exc) or "The edit could not be saved. Check required fields and duplicate student IDs.")}</p><p><a class="button" href="/students/{student_id}">Back to Student</a></p></section>', user)
        db.close()
        return self.redirect(f"/students/{student_id}")

    def _save_manual_grid_edit(self, db, user, student_id, form, note):
            selected_key = form.get("requirement_key", "").strip()
            employment_fields = {
                "Employment:WPR": ("Workplace Readiness", "Workplace Readiness"),
                "Employment:WISE": ("Credential Test", "W!SE"),
                "Employment:NCRC:Overall": ("NCRC", "NCRC Overall Result"),
                "Employment:NCRC:Workplace": ("NCRC", "Workplace Documents"),
                "Employment:NCRC:Graphic": ("NCRC", "Graphic Literacy"),
                "Employment:NCRC:Applied": ("NCRC", "Applied Math"),
            }
            pba_fields = {
                "PBA:WGeo": ("WGeo", "World Geography PBA"),
                "PBA:WHI": ("WHI", "World History I PBA"),
                "PBA:WHII": ("WHII", "World History II PBA"),
                "PBA:USH": ("USH", "US History PBA"),
            }
            special_fields = {**employment_fields, **pba_fields}
            requirement_key, default_test_name = special_fields.get(selected_key, (selected_key, "Manual Grid Edit"))
            display_value = form.get("display_value", "").strip()
            status = form.get("status", "Met").strip() or "Met"
            needs_retest = 1 if form.get("needs_retest") == "1" else 0
            score_text = form.get("score", "").strip()
            score = None
            if score_text:
                try:
                    score = float(score_text)
                except ValueError:
                    score = None
            if score is None and selected_key in special_fields and display_value:
                numeric_match = re.search(r"\d+(?:\.\d+)?", display_value)
                if numeric_match:
                    score = float(numeric_match.group(0))
                    score_text = numeric_match.group(0)
            old = db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ? AND requirement_key = ?", (student_id, requirement_key)).fetchone()
            old_value = old["display_value"] if old else ""
            if not requirement_key:
                raise ValueError("Choose a grid area or requirement.")
            if selected_key == "Employment:WPR" and score is None:
                raise ValueError("Enter the numeric Workplace Readiness score. A score of 75 or higher passes.")
            if selected_key.startswith("Employment:NCRC:") and selected_key != "Employment:NCRC:Overall" and score is None:
                raise ValueError("Enter the numeric NCRC component score. Each component requires 3 or higher.")
            if selected_key.startswith("PBA:") and score is None:
                raise ValueError("Enter the numeric PBA average score. A score of 2 or higher earns the History verified credit.")
            raw_value = display_value or score_text
            if selected_key == "Employment:WPR" and score is not None:
                raw_value = f"WPR-{int(score) if score.is_integer() else score}"
            elif selected_key == "Employment:WISE":
                raw_value = display_value or "W!SE"
            elif selected_key == "Employment:NCRC:Overall":
                raw_value = "NCRC-F" if status.lower() in {"fail", "failed", "missing", "not met"} else "NCRC"
            elif selected_key.startswith("PBA:") and score is not None:
                raw_value = f"PBA - {int(score) if score.is_integer() else score}"
            if display_value or score_text or form.get("test_name", "").strip() or selected_key in special_fields:
                db.execute(
                    """
                    INSERT INTO test_attempts(student_id_fk, test_name, test_area, score, raw_score, pass_fail, test_date, course, source_upload_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)
                    """,
                    (
                        student_id,
                        form.get("test_name", "").strip() or default_test_name,
                        requirement_key,
                        score,
                        raw_value,
                        status,
                        form.get("test_date", "").strip(),
                        form.get("course", "").strip(),
                    ),
                )
            db.execute(
                """
                INSERT INTO requirement_status(student_id_fk, requirement_key, status, display_value, score, source, needs_retest, updated_at)
                VALUES (?, ?, ?, ?, ?, 'Manual Edit', ?, CURRENT_TIMESTAMP)
                ON CONFLICT(student_id_fk, requirement_key) DO UPDATE SET
                  status = excluded.status,
                  display_value = excluded.display_value,
                  score = excluded.score,
                  source = excluded.source,
                  needs_retest = excluded.needs_retest,
                  updated_at = CURRENT_TIMESTAMP
                """,
                (student_id, requirement_key, status, raw_value, score, needs_retest),
            )
            if requirement_key in custom_field_names(db):
                db.execute(
                    """
                    INSERT INTO custom_field_values(student_id_fk, field_key, status, display_value, score, source, updated_at)
                    VALUES (?, ?, ?, ?, ?, 'Manual Edit', CURRENT_TIMESTAMP)
                    ON CONFLICT(student_id_fk, field_key) DO UPDATE SET
                      status=excluded.status, display_value=excluded.display_value,
                      score=excluded.score, source=excluded.source, updated_at=CURRENT_TIMESTAMP
                    """,
                    (student_id, requirement_key, status, raw_value, score),
                )
            db.execute("INSERT INTO manual_edits(student_id_fk, edited_by, field_name, old_value, new_value, note) VALUES (?, ?, ?, ?, ?, ?)", (student_id, user["id"], f"Grid: {requirement_key}", old_value or "", raw_value or status, note))
            log_audit(db, user, "grid_manual_edit", f"student_id={student_id}; requirement={requirement_key}; note={note}", self.client_address[0])

    def _save_manual_student_edit(self, db, user, student_id, s, form, note):
            try:
                new_grad_class = int(float(form.get("graduation_class", s["graduation_class"]) or s["graduation_class"]))
            except ValueError:
                new_grad_class = s["graduation_class"]
            try:
                original_cohort = int(float(form.get("original_cohort", s["original_cohort"] or s["graduation_class"])))
            except (TypeError, ValueError):
                original_cohort = int(s["original_cohort"] or s["graduation_class"])
            early_graduate = 1 if form.get("early_graduate") == "1" else 0
            middle_school_eoc_taker = 1 if form.get("middle_school_eoc_taker") == "1" else 0
            if early_graduate and new_grad_class >= original_cohort:
                raise ValueError("An early graduate must have a planned graduation class earlier than the original cohort.")
            fields = ["student_id", "first_name", "middle_name", "last_name", "graduation_class", "original_cohort", "early_graduate", "middle_school_eoc_taker", "diploma_type", "sped_504_status", "counselor", "notes"]
            values = {
                "student_id": form.get("student_id", "").strip() or None,
                "first_name": form.get("first_name", "").strip().upper(),
                "middle_name": form.get("middle_name", "").strip().upper(),
                "last_name": form.get("last_name", "").strip().upper(),
                "graduation_class": new_grad_class,
                "original_cohort": original_cohort,
                "early_graduate": early_graduate,
                "middle_school_eoc_taker": middle_school_eoc_taker,
                "diploma_type": form.get("diploma_type", ""),
                "sped_504_status": form.get("sped_504_status", ""),
                "counselor": form.get("counselor", ""),
                "notes": form.get("notes", ""),
            }
            if not values["first_name"] or not values["last_name"]:
                raise ValueError("First name and last name are required.")
            for field in fields:
                new_value = values[field]
                old_value = s[field] if field in s.keys() else ""
                if ("" if new_value is None else str(new_value)) != ("" if old_value is None else str(old_value)):
                    db.execute(f"UPDATE students SET {field} = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (new_value, student_id))
                    db.execute("INSERT INTO manual_edits(student_id_fk, edited_by, field_name, old_value, new_value, note) VALUES (?, ?, ?, ?, ?, ?)", (student_id, user["id"], field, "" if old_value is None else str(old_value), "" if new_value is None else str(new_value), note))
                    log_audit(db, user, "student_edit", f"student_id={student_id}; field={field}; note={note}", self.client_address[0])
            if int(s["graduation_class"]) != int(new_grad_class):
                db.execute("DELETE FROM class_grid_members WHERE student_id_fk = ?", (student_id,))
                db.execute("INSERT OR IGNORE INTO class_grid_members(student_id_fk, graduation_class) VALUES (?, ?)", (student_id, new_grad_class))

    def handle_add_student(self, user):
        form = self.urlencoded_form()
        db = get_db()
        new_id = None
        try:
            student_id = form.get("student_id", "").strip() or None
            grad_class = int(float(form.get("graduation_class", "0") or 0))
            original_cohort = int(float(form.get("original_cohort", grad_class) or grad_class))
            early_graduate = 1 if form.get("early_graduate") == "1" else 0
            middle_school_eoc_taker = 1 if form.get("middle_school_eoc_taker") == "1" else 0
            if early_graduate and grad_class >= original_cohort:
                raise ValueError("An early graduate must have a planned graduation class earlier than the original cohort.")
            first_name = form.get("first_name", "").strip().upper()
            last_name = form.get("last_name", "").strip().upper()
            if not first_name or not last_name or not grad_class:
                return self.page("Add Student", add_student_html(form, "First name, last name, and graduation class are required."), user)
            existing = db.execute("SELECT * FROM students WHERE student_id = ? AND graduation_class = ?", (student_id, grad_class)).fetchone() if student_id else None
            if existing:
                if (existing["enrollment_status"] or "Active") != "Active":
                    raise ValueError("That Student ID and graduation class belong to an archived student. Restore that student or permanently delete the incorrect archived record before recreating it.")
                new_id = existing["id"]
            else:
                db.execute(
                    "INSERT INTO students(student_id, first_name, middle_name, last_name, graduation_class, original_cohort, early_graduate, middle_school_eoc_taker, diploma_type, sped_504_status, counselor, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (student_id, first_name, form.get("middle_name", "").strip().upper(), last_name, grad_class, original_cohort, early_graduate, middle_school_eoc_taker, form.get("diploma_type", "Standard"), form.get("sped_504_status", "N"), form.get("counselor", ""), form.get("notes", "")),
                )
                new_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
            db.execute("INSERT OR IGNORE INTO class_grid_members(student_id_fk, graduation_class) VALUES (?, ?)", (new_id, grad_class))
            if form.get("unmatched_id"):
                db.execute("UPDATE unmatched_records SET status = 'Resolved', resolved_to_student_id = ?, resolved_by = ?, resolved_at = CURRENT_TIMESTAMP WHERE id = ?", (new_id, user["id"], form.get("unmatched_id")))
            log_audit(db, user, "student_create", f"Created/added student_id={new_id} class={grad_class}", self.client_address[0])
            db.commit()
        except (sqlite3.IntegrityError, ValueError) as exc:
            db.rollback()
            message = str(exc) or "That student appears to already exist in this class. Search the class grid or enter a Student ID to link the correct record."
            return self.page("Add Student", add_student_html(form, message), user)
        finally:
            db.close()
        return self.redirect(f"/students/{new_id}")

    def handle_troubleshooter(self, user):
        form = self.urlencoded_form()
        db = get_db()
        try:
            action = form.get("action", "")
            unmatched_id = int(form.get("unmatched_id", "0") or 0)
            if action == "link":
                target_id = int(form.get("student_pk", "0") or 0)
                db.execute("UPDATE unmatched_records SET status = 'Resolved', resolved_to_student_id = ?, resolved_by = ?, resolved_at = CURRENT_TIMESTAMP WHERE id = ?", (target_id, user["id"], unmatched_id))
                log_audit(db, user, "unmatched_link", f"unmatched_id={unmatched_id}; student_id={target_id}", self.client_address[0])
            elif action == "place_class":
                grad_class = int(form.get("graduation_class", "0") or 0)
                record = db.execute("SELECT * FROM unmatched_records WHERE id = ? AND status = 'Open'", (unmatched_id,)).fetchone()
                if record and grad_class:
                    try:
                        target_id = place_unmatched_record(db, record, grad_class)
                    except ValueError as exc:
                        log_audit(db, user, "unmatched_place_failed", f"unmatched_id={unmatched_id}; class={grad_class}; {exc}", self.client_address[0])
                    else:
                        db.execute("UPDATE unmatched_records SET status = 'Resolved', resolved_to_student_id = ?, resolved_by = ?, resolved_at = CURRENT_TIMESTAMP WHERE id = ?", (target_id, user["id"], unmatched_id))
                        log_audit(db, user, "unmatched_place_class", f"unmatched_id={unmatched_id}; student_id={target_id}; class={grad_class}", self.client_address[0])
            elif action == "graduated":
                db.execute("UPDATE unmatched_records SET status = 'Graduated', resolved_by = ?, resolved_at = CURRENT_TIMESTAMP WHERE id = ?", (user["id"], unmatched_id))
                log_audit(db, user, "unmatched_graduated", f"unmatched_id={unmatched_id}", self.client_address[0])
            elif action == "dismiss":
                db.execute("UPDATE unmatched_records SET status = 'Dismissed', resolved_by = ?, resolved_at = CURRENT_TIMESTAMP WHERE id = ?", (user["id"], unmatched_id))
                log_audit(db, user, "unmatched_dismiss", f"unmatched_id={unmatched_id}", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.redirect("/troubleshooter")

    def handle_user_management(self, user):
        form = self.urlencoded_form()
        action = form.get("action", "")
        db = get_db()
        try:
            if action == "create":
                username = form.get("username", "").strip()
                password = form.get("password", "")
                role = normalize_role(form.get("role", "Viewer"))
                display_name = form.get("display_name", "").strip()
                if not username or len(password) < 10:
                    return self.error_page(400, "Enter a username and a password with at least 10 characters.")
                db.execute(
                    "INSERT INTO users(username, password_hash, role, display_name, disabled) VALUES (?, ?, ?, ?, 0)",
                    (username, hash_password(password), role, display_name or username),
                )
                log_audit(db, user, "user_create", f"Created user {username} with role {role}", self.client_address[0])
            elif action == "reset":
                target_id = int(form.get("user_id", "0"))
                password = form.get("password", "")
                if len(password) < 10:
                    return self.error_page(400, "New passwords must contain at least 10 characters.")
                db.execute("UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (hash_password(password), target_id))
                invalidate_user_sessions(target_id)
                log_audit(db, user, "user_reset_password", f"Reset password for user_id={target_id}", self.client_address[0])
            elif action in {"disable", "enable"}:
                target_id = int(form.get("user_id", "0"))
                disabled = 1 if action == "disable" else 0
                db.execute("UPDATE users SET disabled = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (disabled, target_id))
                if disabled:
                    invalidate_user_sessions(target_id)
                log_audit(db, user, f"user_{action}", f"user_id={target_id}", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.redirect("/admin/users")

    def handle_manual_backup(self, user):
        backup = create_backup("manual")
        db = get_db()
        log_audit(db, user, "backup_create", f"Created manual backup {backup.name if backup else 'none'}", self.client_address[0])
        db.commit()
        db.close()
        return self.redirect("/admin/backups")

    def handle_restore_backup(self, user):
        form = self.urlencoded_form()
        if form.get("confirm", "").strip().upper() != "RESTORE":
            return self.error_page(400, "Restore cancelled. Type RESTORE to confirm.")
        filename = form.get("filename", "")
        restore_backup(filename)
        db = get_db()
        log_audit(db, user, "backup_restore", f"Restored backup {filename}", self.client_address[0])
        db.commit()
        db.close()
        return self.redirect("/admin/backups")

    def handle_school_profile(self, user):
        form = self.urlencoded_form()
        db = get_db()
        for key in DEFAULT_SCHOOL_PROFILE:
            set_app_setting(db, key, form.get(key, ""))
        log_audit(db, user, "school_profile_update", "Updated school profile/settings", self.client_address[0])
        db.commit()
        db.close()
        return self.redirect("/admin/school-profile")

    def handle_graduation_rules(self, user):
        form = self.urlencoded_form()
        db = get_db()
        try:
            template_type = form.get("graduation_template_type", "Custom / Other State Template")
            if template_type not in {"Virginia Template", "Custom / Other State Template"}:
                template_type = "Custom / Other State Template"
            config_text = form.get("graduation_rules_config", "").strip()
            if not config_text:
                config_text = json.dumps(VIRGINIA_GRADUATION_CONFIG if template_type == "Virginia Template" else CUSTOM_GRADUATION_CONFIG, indent=2)
            set_app_setting(db, "graduation_template_type", template_type)
            set_app_setting(db, "graduation_rules_config", config_text)
            log_audit(db, user, "graduation_rules_update", f"Updated graduation rules template={template_type}", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.redirect("/admin/graduation-rules")

    def handle_testing_window(self, user):
        form = self.urlencoded_form()
        window_id = form.get("id", "").strip()
        start_date = form.get("start_date", "").strip()
        end_date = form.get("end_date", "").strip()
        school_year = form.get("school_year", "").strip()
        if not window_id or not school_year:
            return self.error_page(400, "Window ID and school year are required.")
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d").date()
            end = datetime.strptime(end_date, "%Y-%m-%d").date()
        except ValueError:
            return self.error_page(400, "Testing-window dates must use YYYY-MM-DD.")
        if start > end:
            return self.error_page(400, "The testing-window start date must be before its end date.")
        db = get_db()
        try:
            db.execute(
                """
                INSERT INTO testing_windows
                (id, state, window_name, school_year, start_date, end_date,
                 assessment_group, rule_version, source_reference, active, updated_at)
                VALUES (?, 'Virginia', ?, ?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP)
                ON CONFLICT(id) DO UPDATE SET
                    window_name=excluded.window_name, school_year=excluded.school_year,
                    start_date=excluded.start_date, end_date=excluded.end_date,
                    assessment_group=excluded.assessment_group,
                    rule_version=excluded.rule_version,
                    source_reference=excluded.source_reference,
                    active=1, updated_at=CURRENT_TIMESTAMP
                """,
                (
                    window_id, form.get("window_name", "").strip() or window_id,
                    school_year, start.isoformat(), end.isoformat(),
                    form.get("assessment_group", "EOC").strip() or "EOC",
                    form.get("rule_version", school_year).strip() or school_year,
                    form.get("source_reference", "").strip(),
                ),
            )
            log_audit(db, user, "testing_window_update", f"Virginia testing window {window_id}: {start} through {end}", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.redirect("/admin/testing-windows")

    def handle_rules_wizard(self, user):
        form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ={"REQUEST_METHOD": "POST", "CONTENT_TYPE": self.headers.get("Content-Type")})
        self.validate_csrf_form(form)
        if form.getfirst("wizard_action", "") == "approve":
            return self.error_page(409, "Legacy line-based activation is disabled. Review and validate the typed draft in Structured Rules Builder; activation will be added only with preview, backup, and rollback safeguards.")
        docs_dir = DATA_DIR / "rules_docs"
        docs_dir.mkdir(parents=True, exist_ok=True)
        file_items = form["rule_docs"] if "rule_docs" in form else []
        if not isinstance(file_items, list):
            file_items = [file_items]
        summaries = []
        for item in file_items:
            if not getattr(item, "filename", ""):
                continue
            original = secure_filename(item.filename)
            stored = f"{secrets.token_hex(8)}_{original}"
            path = docs_dir / stored
            with open(path, "wb") as out:
                shutil.copyfileobj(item.file, out, length=1024 * 1024)
            try:
                validate_uploaded_file(path, original, category="rules", max_bytes=min(MAX_REQUEST_BYTES, 50 * 1024 * 1024))
                path = safe_child(docs_dir, path)
            except FileValidationError as exc:
                path.unlink(missing_ok=True)
                log_db = get_db()
                try:
                    log_audit(log_db, user, "rules_document_rejected", f"Rejected rules document {original}: {exc}", self.client_address[0])
                    log_db.commit()
                finally:
                    log_db.close()
                continue
            text = extract_rules_document_text(path)
            summaries.append({"filename": original, "stored": str(path), "proposal": propose_rules_from_text(original, text)})
        draft = json.dumps({"status": "Draft - Admin Review Required", "documents": summaries}, indent=2)
        db = get_db()
        try:
            set_app_setting(db, "rules_wizard_draft", draft)
            log_audit(db, user, "rules_wizard_upload", f"Uploaded {len(summaries)} rules document(s) for local analysis", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.redirect("/admin/rules-wizard")

    def handle_rules_builder(self, user):
        form = self.urlencoded_form()
        db = get_db()
        try:
            draft = typed_rule_draft(db)
            action = form.get("builder_action", "").strip()
            if action == "reset_from_analysis":
                draft = typed_rule_draft_from_analysis(app_setting(db, "rules_wizard_draft", ""))
            elif action == "validate_draft":
                draft = validate_draft(draft, user.get("username") or user.get("display_name") or "Admin")
            elif action == "approve_version":
                draft = approve_validated(draft, user.get("username") or user.get("display_name") or "Admin")
                versions = _json_setting_list(db, "custom_rule_package_versions")
                identity = (draft["package"].get("key"), draft["package"].get("version"))
                if any((item.get("package", {}).get("key"), item.get("package", {}).get("version")) == identity for item in versions):
                    raise ValueError("That package key and version already has an approved immutable snapshot. Change the version before approving again.")
                versions.append(immutable_version_snapshot(draft))
                set_app_setting(db, "custom_rule_package_versions", json.dumps(versions, indent=2))
            elif action == "activate_version":
                if form.get("confirm", "").strip() != "ACTIVATE":
                    raise ValueError("Type ACTIVATE to confirm rule activation.")
                preview = preview_rule_impact(db, draft)
                backup = create_backup("before_custom_rule_activation")
                previous_raw = app_setting(db, "active_custom_rule_package", "")
                if previous_raw:
                    set_app_setting(db, "previous_custom_rule_package", previous_raw)
                active = activate_approved(draft, user_value(user, "username") or user_value(user, "display_name") or "Admin")
                summary = persist_active_results(db, active, preview)
                set_app_setting(db, "active_custom_rule_package", json.dumps(active, indent=2))
                set_app_setting(db, "graduation_template_type", "Custom / Other State Template")
                draft = active
                log_audit(db, user, "custom_rules_activate", f"Activated {active['package']['key']} {active['package']['version']}; students={summary['students']}; changed={summary['changed']}; backup={backup.name if backup else 'none'}", self.client_address[0])
            elif action == "rollback_version":
                if form.get("confirm", "").strip() != "ROLLBACK":
                    raise ValueError("Type ROLLBACK to restore the previous rule version.")
                previous_raw = app_setting(db, "previous_custom_rule_package", "")
                if not previous_raw:
                    raise ValueError("No previous active custom rule version is available.")
                previous = json.loads(previous_raw)
                previous["package"]["status"] = "approved"
                backup = create_backup("before_custom_rule_rollback")
                current_raw = app_setting(db, "active_custom_rule_package", "")
                restored = activate_approved(previous, user_value(user, "username") or user_value(user, "display_name") or "Admin")
                summary = persist_active_results(db, restored)
                set_app_setting(db, "active_custom_rule_package", json.dumps(restored, indent=2))
                set_app_setting(db, "previous_custom_rule_package", json.dumps(supersede_active(json.loads(current_raw), user_value(user, "username") or "Admin"), indent=2) if current_raw else "")
                draft = restored
                log_audit(db, user, "custom_rules_rollback", f"Rolled back to {restored['package']['key']} {restored['package']['version']}; students={summary['students']}; backup={backup.name if backup else 'none'}", self.client_address[0])
            elif action == "save_package":
                draft["package"].update({
                    "key": form.get("key", "").strip(),
                    "name": form.get("name", "").strip(),
                    "jurisdiction": form.get("jurisdiction", "").strip(),
                    "version": form.get("version", "").strip(),
                    "status": "draft",
                    "effective_from": form.get("effective_from", "").strip() or None,
                    "effective_to": form.get("effective_to", "").strip() or None,
                    "cohort_start": _optional_int(form.get("cohort_start", "")),
                    "cohort_end": _optional_int(form.get("cohort_end", "")),
                })
            elif action == "save_plan":
                _upsert_builder_item(draft["diploma_plans"], form, {"key": "text", "name": "text", "total_credits": "number", "requirement_keys": "csv"})
            elif action == "save_requirement":
                _upsert_builder_item(draft["requirements"], form, {"key": "text", "label": "text", "type": "text", "operator": "text", "threshold": "number", "unit": "text", "diploma_scope": "csv", "evidence_keys": "csv", "required": "bool"})
            elif action == "save_evidence":
                _upsert_builder_item(draft["evidence_definitions"], form, {"key": "text", "label": "text", "type": "text", "aliases": "csv", "subject_family": "text", "date_required": "bool"})
            elif action == "save_relationship":
                _upsert_builder_item(draft["relationships"], form, {"type": "text", "parent_requirement": "text", "child_requirements": "csv", "minimum": "integer"})
            elif action.startswith("delete_"):
                collection = {"delete_plan": "diploma_plans", "delete_requirement": "requirements", "delete_evidence": "evidence_definitions", "delete_relationship": "relationships"}.get(action)
                index = int(form.get("item_index", "-1"))
                if collection and 0 <= index < len(draft[collection]):
                    draft[collection].pop(index)
            if action not in {"validate_draft", "approve_version", "activate_version", "rollback_version"}:
                draft = mark_edited(draft)
            set_app_setting(db, "custom_rule_package_draft", json.dumps(draft, indent=2))
            log_audit(db, user, "structured_rules_draft", f"Updated structured rules draft action={action}", self.client_address[0])
            db.commit()
        except (ValueError, TypeError) as exc:
            db.rollback()
            return self.error_page(400, f"The structured rule change was not saved: {exc}")
        finally:
            db.close()
        return self.redirect("/admin/rules-builder")

    def handle_template_import(self, user):
        form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ={"REQUEST_METHOD": "POST", "CONTENT_TYPE": self.headers.get("Content-Type")})
        self.validate_csrf_form(form)
        item = form["template_file"] if "template_file" in form else None
        if item is None or not getattr(item, "filename", ""):
            return self.error_page(400, "Choose a GIC template JSON file.")
        original = secure_filename(item.filename)
        stored = f"{secrets.token_hex(8)}_{original}"
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        path = safe_child(UPLOAD_DIR, UPLOAD_DIR / stored, must_exist=False)
        try:
            with open(path, "wb") as out:
                shutil.copyfileobj(item.file, out, length=1024 * 1024)
            validate_uploaded_file(path, original, category="template", max_bytes=5 * 1024 * 1024)
            package = parse_and_validate_template_package(path.read_bytes())
            preview = template_preview(package)
            token = self.register_pending_upload(path, original, stored, "GIC Configuration Template", "")
        except (FileValidationError, ValueError, UnicodeDecodeError) as exc:
            path.unlink(missing_ok=True)
            return self.error_page(400, f"The template could not be previewed: {exc}")
        db = get_db()
        try:
            log_audit(db, user, "template_preview", f"Previewed template {preview['name']} checksum={preview['sha256']}", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.page("Review Template Import", template_import_preview_html(preview, token), user)

    def handle_template_apply(self, user):
        form = self.urlencoded_form()
        if form.get("confirm", "").strip() != "IMPORT TEMPLATE":
            return self.error_page(400, "Type IMPORT TEMPLATE to confirm this configuration import.")
        try:
            upload = self.resolve_pending_upload(form.get("upload_token", ""))
            package = parse_and_validate_template_package(Path(upload["path"]).read_bytes())
        except (PermissionError, ValueError, OSError) as exc:
            return self.error_page(400, f"The template could not be applied: {exc}")
        db = get_db()
        try:
            backup = create_backup("before_template_import")
            preview = apply_template_package(db, package)
            log_audit(db, user, "template_import", f"Imported template {preview['name']} as Draft; backup={backup.name if backup else 'none'}", self.client_address[0])
            db.commit()
        except (ValueError, sqlite3.DatabaseError) as exc:
            db.rollback()
            return self.error_page(400, f"The template was not imported: {exc}")
        finally:
            db.close()
        Path(upload["path"]).unlink(missing_ok=True)
        return self.redirect("/admin/rules-builder")

    def handle_config_text(self, user, setting_key, redirect_path, audit_action):
        form = self.urlencoded_form()
        db = get_db()
        try:
            set_app_setting(db, setting_key, form.get("config_text", ""))
            log_audit(db, user, audit_action, f"Updated {setting_key}", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.redirect(redirect_path)

    def handle_custom_fields(self, user):
        form = self.urlencoded_form()
        action = form.get("field_action", "add")
        db = get_db()
        try:
            fields = _json_setting_list(db, "custom_fields_config")
            if action == "delete":
                index = int(form.get("field_index", "-1"))
                if 0 <= index < len(fields):
                    removed = fields.pop(index)
                    log_audit(db, user, "custom_field_delete", f"Deleted custom field {removed.get('name', '')}", self.client_address[0])
            else:
                name = form.get("name", "").strip()
                field_type = form.get("type", "checkbox").strip().lower()
                if not name:
                    return self.error_page(400, "Enter a field name.")
                if field_type not in {"checkbox", "text", "number", "date", "dropdown", "score", "notes"}:
                    field_type = "text"
                item = {
                    "name": name,
                    "type": field_type,
                    "description": form.get("description", "").strip(),
                    "options": form.get("options", "").strip(),
                    "completion_rule": form.get("completion_rule", "nonblank").strip() or "nonblank",
                    "import_aliases": form.get("import_aliases", "").strip(),
                    "required": form.get("required") == "1",
                    "grid_visible": form.get("grid_visible") == "1",
                    "profile_visible": form.get("profile_visible") == "1",
                    "report_enabled": form.get("report_enabled") == "1",
                }
                existing = next((i for i, field in enumerate(fields) if str(field.get("name", "")).strip().lower() == name.lower()), None)
                if existing is None:
                    fields.append(item)
                else:
                    fields[existing] = item
                if item["grid_visible"]:
                    columns = custom_grid_columns(db)
                    if name not in columns:
                        columns.append(name)
                        set_app_setting(db, "main_grid_columns_config", json.dumps(columns, indent=2))
                log_audit(db, user, "custom_field_save", f"Saved custom field {name}", self.client_address[0])
            set_app_setting(db, "custom_fields_config", json.dumps(fields, indent=2))
            if action != "delete" and item.get("required"):
                db.execute(
                    """
                    INSERT OR IGNORE INTO requirement_status
                    (student_id_fk, requirement_key, status, display_value, source, needs_retest, updated_at)
                    SELECT id, ?, 'Missing', '', 'Custom Rules', 0, CURRENT_TIMESTAMP FROM students
                    """,
                    (item["name"],),
                )
            db.commit()
        finally:
            db.close()
        return self.redirect("/admin/custom-fields")

    def handle_grid_columns(self, user):
        form = self.urlencoded_form()
        db = get_db()
        try:
            if form.get("column_action") == "add_field":
                name = form.get("name", "").strip()
                field_type = form.get("type", "checkbox").strip().lower()
                if not name:
                    return self.error_page(400, "Enter a name for the new tracking column.")
                if field_type not in {"checkbox", "text", "number", "date", "dropdown", "score", "notes"}:
                    field_type = "text"
                fields = _json_setting_list(db, "custom_fields_config")
                if any(str(item.get("name", "")).strip().lower() == name.lower() for item in fields if isinstance(item, dict)):
                    return self.error_page(400, "A tracking field with that name already exists.")
                fields.append({
                    "name": name,
                    "type": field_type,
                    "description": form.get("description", "").strip(),
                    "options": form.get("options", "").strip(),
                    "completion_rule": form.get("completion_rule", "checked" if field_type == "checkbox" else "nonblank").strip(),
                    "import_aliases": form.get("import_aliases", "").strip(),
                    "required": form.get("required") == "1",
                    "grid_visible": True,
                    "profile_visible": True,
                    "report_enabled": True,
                })
                set_app_setting(db, "custom_fields_config", json.dumps(fields, indent=2))
                columns = custom_grid_columns(db)
                if name not in columns:
                    columns.append(name)
                set_app_setting(db, "main_grid_columns_config", json.dumps(columns, indent=2))
                if form.get("required") == "1":
                    db.execute(
                        """INSERT OR IGNORE INTO requirement_status
                           (student_id_fk,requirement_key,status,display_value,source,needs_retest,updated_at)
                           SELECT id,?,'Missing','','Custom Rules',0,CURRENT_TIMESTAMP FROM students""",
                        (name,),
                    )
                log_audit(db, user, "grid_column_create", f"Created and displayed tracking field {name}", self.client_address[0])
                db.commit()
                return self.redirect("/admin/grid-columns")
            available = custom_grid_available_columns(db)
            columns = [column for column in available if form.get(f"show_{field_key(column)}") == "1"]
            for required in ["student_name", "graduation_class"]:
                if required not in columns:
                    columns.insert(0, required)
            set_app_setting(db, "main_grid_columns_config", json.dumps(columns, indent=2))
            log_audit(db, user, "grid_columns_update", f"Selected {len(columns)} custom grid columns", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.redirect("/admin/grid-columns")

    def handle_import_profiles(self, user):
        form = self.urlencoded_form()
        db = get_db()
        try:
            profiles = parse_profiles(app_setting(db, "import_templates_config", "[]"))
            action = form.get("profile_action", "").strip()
            profile_id = form.get("profile_id", "").strip()
            if action == "delete":
                profiles = [item for item in profiles if item.get("id") != profile_id]
                log_audit(db, user, "import_profile_delete", f"Deleted saved import profile {profile_id}", self.client_address[0])
            elif action == "toggle":
                for item in profiles:
                    if item.get("id") == profile_id:
                        item["active"] = not item.get("active", True)
                        log_audit(db, user, "import_profile_toggle", f"Set import profile {item.get('name','')} active={item['active']}", self.client_address[0])
                        break
            else:
                return self.error_page(400, "Choose a valid import-profile action.")
            set_app_setting(db, "import_templates_config", json.dumps(profiles, indent=2))
            db.commit()
        finally:
            db.close()
        return self.redirect("/admin/import-templates")

    def handle_custom_reports(self, user):
        form = self.urlencoded_form()
        db = get_db()
        try:
            reports = _json_setting_list(db, "custom_reports_config")
            if form.get("report_action") == "delete":
                index = int(form.get("report_index", "-1"))
                if 0 <= index < len(reports):
                    reports.pop(index)
            else:
                name = form.get("name", "").strip()
                field = form.get("field", "").strip()
                if not name or not field:
                    return self.error_page(400, "Enter a report name and choose a tracking field.")
                filters = [{"field": field, "operator": form.get("operator", "is"), "value": form.get("value", "Missing").strip()}]
                second_field = form.get("field_2", "").strip()
                if second_field:
                    filters.append({"field": second_field, "operator": form.get("operator_2", "is"), "value": form.get("value_2", "Missing").strip()})
                reports.append({
                    "name": name,
                    "filters": filters,
                    "combine": form.get("combine", "all") if len(filters) > 1 else "all",
                    "columns": ["student_name", "student_id", "graduation_class", "counselor", "detail"],
                    "sort": "graduation_class,last_name,first_name",
                    "export": ["excel", "pdf"],
                })
            set_app_setting(db, "custom_reports_config", json.dumps(reports, indent=2))
            log_audit(db, user, "custom_reports_update", f"Custom reports count={len(reports)}", self.client_address[0])
            db.commit()
        finally:
            db.close()
        return self.redirect("/admin/custom-reports")

    def page(self, title, body, user=None):
        nav = ""
        body_class = ""
        if user:
            body_class = f'role-{field_key(user_value(user, "role") or "user")}'
            setup_links = '<a href="/settings">Column Mapping</a><a href="/release-notes">Release Notes</a>'
            admin_links = ""
            if is_admin(user):
                admin_links = """
                <details class="nav-menu"><summary>Admin</summary><div>
                  <a href="/admin/school-profile">School Profile</a>
                  <a href="/admin/users">Users</a>
                  <a href="/admin/backups">Backups</a>
                  <a href="/admin/audit-log">Audit Log</a>
                  <a href="/admin/security">Security</a>
                  <a href="/admin/readiness">Setup Readiness</a>
                </div></details>
                <details class="nav-menu"><summary>Customize</summary><div>
                  <a href="/admin/graduation-rules">Graduation Rules</a>
                  <a href="/admin/rules-wizard">Rules Wizard</a>
                  <a href="/admin/rules-builder">Structured Rules Builder</a>
                  <a href="/admin/templates">School / State Templates</a>
                  <a href="/admin/testing-windows">Virginia Testing Windows</a>
                  <a href="/admin/custom-fields">Custom Fields</a>
                  <a href="/admin/custom-reports">Custom Reports</a>
                  <a href="/admin/agreement-builder">Agreement Builder</a>
                  <a href="/admin/import-templates">Import Templates</a>
                  <a href="/admin/grid-columns">Grid Columns</a>
                </div></details>
                """
            user_chip = f'<span class="user-chip">{esc(user_value(user, "display_name") or user_value(user, "username") or "User")}<small>{esc("Teacher Viewer" if user_value(user, "role") == "Viewer" else user_value(user, "role") or "")}</small></span>'
            if can_edit(user):
                demo_link = '<a href="/demo-scenarios">Scenarios</a>' if DEMO_MODE else ""
                nav = f'<nav>{demo_link}<a href="/upload">Upload</a><a href="/grids">Class Grids</a><a href="/search">Search</a><a href="/troubleshooter">Troubleshooter</a><a href="/reports">Reports</a><details class="nav-menu"><summary>Settings</summary><div>{setup_links}</div></details>{admin_links}{user_chip}<a href="/logout">Logout</a></nav>'
            else:
                demo_link = '<a href="/demo-scenarios">Scenarios</a>' if DEMO_MODE else ""
                nav = f'<nav>{demo_link}<a href="/grids">Class Grids</a><a href="/search">Search</a><a href="/reports">Reports</a><a href="/release-notes">Release Notes</a>{user_chip}<a href="/logout">Logout</a></nav>'
                body = '<div class="flash viewer-notice"><strong>View-only account:</strong> You may review student records and reports, but cannot upload, edit, delete, manage users, or download protected exports.</div>' + body
        profile = school_profile()
        brand = f'{profile.get("school_name") or "School"} {profile.get("app_title") or "Graduation Intelligence Center"}'
        if user:
            session = SESSIONS.get(self.session_id(), {})
            body = inject_csrf_tokens(body, session.get("csrf_token", ""))
        demo_banner = '<div class="demo-banner"><strong>DEMO</strong> DEMONSTRATION ENVIRONMENT - ALL STUDENTS AND RECORDS ARE FICTIONAL</div>' if DEMO_MODE else ""
        demo_badge = ' <span class="demo-badge">DEMO</span>' if DEMO_MODE else ""
        html = f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(title)}</title><link rel="stylesheet" href="/static/styles.css"></head><body class="{body_class}">{demo_banner}<header class="topbar"><a class="brand" href="/">{esc(brand)}{demo_badge}</a>{nav}</header><main class="shell">{body}</main></body></html>'
        self.send_bytes(html.encode("utf-8"), "text/html; charset=utf-8")

    def send_static_css(self):
        self.send_bytes((BASE_DIR / "app" / "static" / "styles.css").read_bytes(), "text/css")

    def export_ready(self, buffer, filename, title, user):
        EXPORT_DIR.mkdir(exist_ok=True)
        stem, ext = os.path.splitext(filename)
        saved_name = f"{stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{ext}"
        saved_path = EXPORT_DIR / saved_name
        with open(saved_path, "wb") as handle:
            handle.write(buffer.getvalue())
        db = get_db()
        log_audit(db, user, "export", f"{title}: {saved_name}", self.client_address[0])
        db.commit()
        db.close()
        return self.download(buffer, saved_name, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

    def export_warning(self, path, query, user):
        params = {k: v[-1] for k, v in query.items() if v}
        params["confirm_export"] = "1"
        target = path + "?" + urllib.parse.urlencode(params)
        body = f"""
        <section class="page-head"><div><h1>Export Student Data?</h1><p>This download may contain protected student information. Save it only to approved local or school-managed storage.</p></div></section>
        <section class="panel">
          <p><strong>FERPA reminder:</strong> exports are for authorized school use only. Do not email, upload, or share student files outside approved school systems.</p>
          <div class="actions"><a class="button" href="{esc(target)}">I Understand - Download</a><a class="button secondary" href="javascript:history.back()">Cancel</a></div>
        </section>
        """
        return self.page("Export Warning", body, user)

    def serve_export_file(self, path):
        filename = os.path.basename(urllib.parse.unquote(path.split("/exports/", 1)[1]))
        file_path = EXPORT_DIR / filename
        if not file_path.exists() or file_path.parent != EXPORT_DIR:
            return self.error_page(404, "Export file not found.")
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def download(self, buffer, filename, content_type):
        data = buffer.getvalue()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_bytes(self, data, content_type):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, location):
        self.send_response(303)
        self.send_header("Location", location)
        self.end_headers()

    def error_page(self, code, message):
        self.send_response(code)
        data = f"<h1>{code}</h1><p>{message}</p>".encode("utf-8")
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def urlencoded_form(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length < 0 or length > MAX_FORM_BYTES:
            raise ValueError("Form submission is too large.")
        raw = self.rfile.read(length).decode("utf-8")
        form = {key: values[-1] for key, values in urllib.parse.parse_qs(raw, keep_blank_values=True).items()}
        self.validate_csrf_form(form)
        return form

    def validate_csrf_form(self, form):
        sid = self.session_id()
        session = SESSIONS.get(sid) if sid else None
        if not session:
            return
        supplied = form.getfirst("csrf_token", "") if hasattr(form, "getfirst") else form.get("csrf_token", "")
        if not supplied or not hmac.compare_digest(str(supplied), session.get("csrf_token", "")):
            db = get_db()
            try:
                log_audit(db, session, "security_csrf_rejected", "Rejected state-changing request with missing or invalid CSRF token", self.client_address[0])
                db.commit()
            finally:
                db.close()
            raise PermissionError("The form security token is missing or expired. Reload the page and try again.")

    def session_id(self):
        cookie = http.cookies.SimpleCookie(self.headers.get("Cookie"))
        morsel = cookie.get("ahs_session")
        return morsel.value if morsel else None

    def current_user(self):
        sid = self.session_id()
        session_user = SESSIONS.get(sid) if sid else None
        if not session_user:
            return None
        now = time.monotonic()
        if (
            now - session_user.get("last_seen", now) > SESSION_IDLE_SECONDS
            or now - session_user.get("created_at", now) > SESSION_ABSOLUTE_SECONDS
        ):
            SESSIONS.pop(sid, None)
            return None
        db = get_db()
        try:
            row = db.execute("SELECT id, username, role, display_name, disabled FROM users WHERE id = ?", (session_user["id"],)).fetchone()
        finally:
            db.close()
        if not row or row["disabled"]:
            SESSIONS.pop(sid, None)
            return None
        session_user.update({"username": row["username"], "role": row["role"], "display_name": row["display_name"] or row["username"], "last_seen": now})
        return session_user


def login_html(error=""):
    err = f'<div class="flash danger">{esc(error)}</div>' if error else ""
    return f'<section class="login-panel">{err}<h1>Secure Local Login</h1><p class="muted">Authorized school use only. Student records are protected by FERPA and must remain on approved local or school-managed systems.</p><form method="post" class="stack"><label>Username <input name="username" autocomplete="username" required></label><label>Password <input name="password" type="password" autocomplete="current-password" required></label><button type="submit">Sign In</button></form></section>'


def extract_rules_document_text(path):
    suffix = path.suffix.lower()
    try:
        if suffix == ".pdf":
            import pdfplumber
            text = []
            with pdfplumber.open(str(path)) as pdf:
                for page in pdf.pages[:30]:
                    text.append(page.extract_text() or "")
            return "\n".join(text)
        if suffix == ".docx":
            return extract_docx_text(path)
        if suffix in {".xlsx", ".xlsm", ".xls"}:
            import pandas as pd
            frames = pd.read_excel(path, sheet_name=None, nrows=80)
            return "\n".join(frame.astype(str).to_csv(index=False) for frame in frames.values())
        if suffix == ".csv":
            return path.read_text(encoding="utf-8", errors="ignore")
        if suffix in {".txt", ".html", ".htm"}:
            return path.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:
        return f"Could not extract text from {path.name}: {exc}"
    return f"Unsupported file type: {path.name}"


def extract_docx_text(path):
    with zipfile.ZipFile(path) as archive:
        xml = archive.read("word/document.xml").decode("utf-8", errors="ignore")
    xml = re.sub(r"</w:p>", "\n", xml)
    xml = re.sub(r"<[^>]+>", " ", xml)
    lines = [re.sub(r"\s+", " ", line).strip() for line in xml.splitlines()]
    return "\n".join(line for line in lines if line)


def propose_rules_from_text(filename, text):
    lower = text.lower()
    proposal = {
        "source_document": filename,
        "status": "Draft - Admin Review Required",
        "detected_topics": [],
        "diploma_types": [],
        "credit_requirements": [],
        "assessment_requirements": [],
        "readiness_requirements": [],
        "local_checklist_items": [],
        "evidence": [],
        "recommended_next_step": "Admin should review, edit, and save approved rules in Graduation Rules.",
    }
    topic_map = {
        "diploma": "Diploma types",
        "credit": "Credit requirements",
        "assessment": "Assessment requirements",
        "test": "Assessment requirements",
        "cpr": "CPR / safety",
        "community service": "Community service",
        "service learning": "Community service",
        "senior project": "Senior project",
        "credential": "Career readiness / credential",
        "dual enrollment": "College readiness",
        "ap": "AP / advanced coursework",
        "work-based": "Work-based learning",
        "work based": "Work-based learning",
        "fafsa": "FAFSA / local checklist",
    }
    for needle, topic in topic_map.items():
        if needle in lower and topic not in proposal["detected_topics"]:
            proposal["detected_topics"].append(topic)
    sentences = [re.sub(r"\s+", " ", item).strip(" -•\t") for item in re.split(r"[\r\n]+|(?<=[.;])\s+", text) if len(item.strip()) >= 8]
    category_terms = {
        "diploma_types": ["diploma", "graduation pathway"],
        "credit_requirements": ["credit", "english", "mathematics", "math", "science", "social studies", "history"],
        "assessment_requirements": ["assessment", "exam", "test", "proficiency", "competency", "score"],
        "readiness_requirements": ["credential", "work-based", "work based", "dual enrollment", "advanced placement", "ap course", "ib course", "military", "career readiness", "college readiness"],
        "local_checklist_items": ["cpr", "community service", "service learning", "senior project", "fafsa", "attendance", "graduation fee", "capstone"],
    }
    limits = {"diploma_types": 8, "credit_requirements": 16, "assessment_requirements": 12, "readiness_requirements": 12, "local_checklist_items": 12}
    for sentence in sentences:
        sentence_lower = sentence.lower()
        for key, terms in category_terms.items():
            matched = [term for term in terms if term in sentence_lower]
            if not matched or len(proposal[key]) >= limits[key]:
                continue
            confidence = "High" if re.search(r"\b(?:shall|must|required?|minimum|at least|earn|complete)\b", sentence_lower) and (re.search(r"\d", sentence_lower) or key != "credit_requirements") else "Needs Review"
            clean = sentence[:320]
            if clean not in proposal[key]:
                proposal[key].append(clean)
                proposal["evidence"].append({"category": key, "recommendation": clean, "confidence": confidence, "source": filename})
    diploma_candidates = re.findall(r"\b(?:standard|advanced|honors|academic|career|technical|general)\s+(?:studies\s+)?diploma\b", lower)
    for candidate in diploma_candidates:
        title = candidate.title()
        if title not in proposal["diploma_types"]:
            proposal["diploma_types"].insert(0, title)
    return proposal


def setup_required(db):
    if not table_exists(db, "users"):
        return True
    return db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0


def setup_html(db, error=""):
    profile = school_profile(db)
    selected_template = graduation_template_type(db)
    va_checked = "checked" if selected_template == "Virginia Template" else ""
    custom_checked = "checked" if selected_template != "Virginia Template" else ""
    err = f'<div class="flash danger">{esc(error)}</div>' if error else ""
    return f"""
    <section class="page-head"><div><h1>First-Time Setup</h1><p>Create the school profile, choose a graduation rules template, and create the first Admin account for this local installation.</p></div></section>
    <form method="post" action="/setup" class="panel form-grid">
      {err}
      <fieldset class="wide choice-panel">
        <legend>Graduation Rules Template</legend>
        <label class="choice"><input type="radio" name="graduation_template_type" value="Virginia Template" {va_checked}> <span><strong>Virginia Template</strong><small>SOL tracking, verified credits, LVC/CA logic, 3E Readiness, CPR/AED, virtual course, and Virginia agreement defaults.</small></span></label>
        <label class="choice"><input type="radio" name="graduation_template_type" value="Custom / Other State Template" {custom_checked}> <span><strong>Custom / Other State Template</strong><small>Starts without Virginia-specific rules. Admins build local diploma, credit, assessment, readiness, checklist, report, and agreement rules after setup.</small></span></label>
      </fieldset>
      <label>School Name<input name="school_name" value="{esc(profile.get("school_name", ""))}" required></label>
      <label>Division Name<input name="division_name" value="{esc(profile.get("division_name", ""))}"></label>
      <label>Application Title<input name="app_title" value="{esc(profile.get("app_title", ""))}" required></label>
      <label>Principal<input name="principal" value="{esc(profile.get("principal", ""))}"></label>
      <label class="wide">Counselor Assignments<input name="counselors" value="{esc(profile.get("counselors", ""))}" placeholder="Example: Smith A-G; Jones H-P; Lee Q-Z"></label>
      <label>Primary Color<input name="primary_color" value="{esc(profile.get("primary_color", ""))}"></label>
      <label>Accent Color<input name="accent_color" value="{esc(profile.get("accent_color", ""))}"></label>
      <label class="wide">Report Footer<input name="report_footer" value="{esc(profile.get("report_footer", ""))}"></label>
      <label class="wide">Signature Titles<input name="signature_titles" value="{esc(profile.get("signature_titles", ""))}"></label>
      <label>Admin Username<input name="admin_username" autocomplete="username" required></label>
      <label>Admin Display Name<input name="admin_display_name"></label>
      <label>Admin Password<input name="admin_password" type="password" autocomplete="new-password" required></label>
      <label>Confirm Password<input name="admin_password_confirm" type="password" autocomplete="new-password" required></label>
      <button type="submit">Create School Installation</button>
    </form>
    <section class="panel"><strong>Privacy note:</strong> setup creates a local database only. Student data should remain on approved school-owned storage.</section>
    """


def template_packages_html(db):
    draft = app_setting(db, "custom_rule_package_draft", "")
    active = app_setting(db, "active_custom_rule_package", "")
    current = "Active custom rules are available to export." if active else "A draft configuration is available to export." if draft else "No custom rule package is configured yet; local fields, reports, agreements, imports, and grid choices can still be exported."
    return f"""
    <section class="page-head"><div><h1>School and State Templates</h1><p>Move reusable configuration between installations without student records, users, source uploads, exports, logs, or backups.</p></div></section>
    <section class="panel"><h2>Export Configuration</h2><p>{esc(current)}</p><p class="muted">The exported JSON includes supported custom fields, reports, agreement settings, import profiles, grid columns, and sanitized rule drafts. It never includes school data.</p><a class="button" href="/admin/templates/export.json">Download Configuration Template</a></section>
    <section class="panel"><h2>Import Configuration</h2><form method="post" action="/admin/templates/import" enctype="multipart/form-data" class="form-grid">
      <label class="wide">GIC Template JSON<input type="file" name="template_file" accept=".json,application/json" required></label>
      <button type="submit">Validate and Preview</button>
    </form><p class="muted">Importing requires a second confirmation. Rules are saved as Draft and cannot affect graduation calculations until an Admin validates, approves, previews, and activates them.</p></section>
    <section class="panel"><h2>Safety Boundary</h2><ul><li>Configuration only; no students or staff accounts.</li><li>Checksum verification detects changed or incomplete files.</li><li>An integrity-checked database backup is created before import.</li><li>Existing students remain in place and are not recalculated during template import.</li></ul></section>
    """


def school_readiness_with_backups(db):
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    return school_readiness(db, len(list(BACKUP_DIR.glob("*.sqlite3"))))


def readiness_summary_html(readiness, action_html=""):
    ready = readiness["overall"] == "ready"
    state = "Required setup complete" if ready else "Setup needs attention"
    tone = "readiness-ready" if ready else "readiness-attention"
    return f"""
    <section class="panel readiness-summary {tone}">
      <div><span class="eyebrow">New School Readiness</span><h2>{esc(state)}</h2><p>{readiness['required_complete']} of {readiness['required_total']} required setup areas complete. Template: {esc(readiness['template'])}.</p></div>
      <div class="readiness-meter" aria-label="{readiness['percent']} percent complete"><span style="width:{readiness['percent']}%"></span></div>
      <div class="actions">{action_html}<a class="button secondary" href="/admin/readiness">View Full Checklist</a></div>
    </section>
    """


def readiness_dashboard_html(db):
    readiness = school_readiness_with_backups(db)
    labels = {"complete": "Complete", "needed": "Required", "attention": "Review", "recommended": "Recommended"}
    items = []
    for step in readiness["steps"]:
        items.append(f"""
        <article class="readiness-step status-{esc(step['status'])}">
          <div class="readiness-step-mark" aria-hidden="true">{'&#10003;' if step['status'] == 'complete' else '!' if step['status'] in {'needed', 'attention'} else '+'}</div>
          <div><div class="section-head"><h2>{esc(step['name'])}</h2><span class="status-label">{esc(labels.get(step['status'], step['status'].title()))}</span></div><p>{esc(step['detail'])}</p><a href="{esc(step['link'])}">{'Review' if step['status'] == 'complete' else 'Complete this step'}</a></div>
        </article>
        """)
    next_step = readiness.get("next_step")
    next_html = f'<section class="panel callout"><strong>Recommended next action:</strong> {esc(next_step["name"])}. <a href="{esc(next_step["link"])}">Open this setup area</a>.</section>' if next_step else '<section class="panel callout"><strong>Required setup is complete.</strong> Review recommended items, test with fake data, and create a verified backup before live use.</section>'
    return f"""
    <section class="page-head"><div><h1>School Setup Readiness</h1><p>A live view of the configuration needed for a dependable local installation. This page only reads setup status; it does not activate rules or change student records.</p></div><div class="actions"><a class="button secondary" href="/admin/templates">School / State Templates</a></div></section>
    {readiness_summary_html(readiness)}
    {next_html}
    <section class="readiness-list">{''.join(items)}</section>
    <section class="panel"><h2>Before Live Student Data</h2><p>District IT should confirm the approved server location, access permissions, firewall scope, HTTPS or an equivalent protected internal connection, backup retention, and authorized user list.</p></section>
    """


def template_import_preview_html(preview, token):
    counts = preview.get("counts", {})
    section_rows = [[section] for section in preview.get("sections", [])]
    warnings = "".join(f"<li>{esc(item)}</li>" for item in preview.get("warnings", []))
    return f"""
    <section class="page-head"><div><h1>Review Template Import</h1><p>Review the configuration package before applying it. Nothing has been changed yet.</p></div><div class="actions"><a class="button secondary" href="/admin/templates">Cancel</a></div></section>
    <section class="panel summary-grid"><div><strong>Template</strong><span>{esc(preview.get("name", ""))}</span></div><div><strong>Jurisdiction</strong><span>{esc(preview.get("jurisdiction", ""))}</span></div><div><strong>Rule Version</strong><span>{esc(preview.get("rule_version", "") or "Not specified")}</span></div><div><strong>Checksum</strong><span><code>{esc(preview.get("sha256", ""))}</code></span></div></section>
    <section class="panel"><h2>Contents</h2><p>{counts.get("custom_fields", 0)} custom fields; {counts.get("custom_reports", 0)} reports; {counts.get("import_profiles", 0)} import profiles; {counts.get("approved_rule_versions", 0)} sanitized rule versions.</p>{table(["Configuration Section"], section_rows)}</section>
    <section class="panel warning"><h2>Required Review</h2><ul>{warnings}</ul><p>This import replaces supported configuration sections but does not delete students, users, uploads, reports, exports, logs, or backups.</p></section>
    <form method="post" action="/admin/templates/apply" class="panel form-grid">
      <input type="hidden" name="upload_token" value="{esc(token)}">
      <label>Confirmation<input name="confirm" placeholder="Type IMPORT TEMPLATE" required></label>
      <button type="submit">Import as Draft Configuration</button>
    </form>
    """


def is_admin(user):
    return user_value(user, "role") == "Admin"


def can_edit(user):
    return user_value(user, "role") in {"Admin", "Counselor"}


def can_export(user):
    return user_value(user, "role") in {"Admin", "Counselor"}


def normalize_role(role):
    role = (role or "").strip()
    if role == "Teacher Viewer":
        return "Viewer"
    return role if role in {"Admin", "Counselor", "Viewer"} else "Viewer"


def export_confirmed(query):
    return query.get("confirm_export", [""])[0] == "1"


def user_management_html(db):
    rows = []
    for user in db.execute("SELECT id, username, role, display_name, disabled, created_at FROM users ORDER BY username").fetchall():
        label_role = "Teacher Viewer" if user["role"] == "Viewer" else user["role"]
        toggle = "enable" if user["disabled"] else "disable"
        toggle_text = "Enable" if user["disabled"] else "Disable"
        rows.append([
            user["username"],
            user["display_name"] or "",
            label_role,
            "Disabled" if user["disabled"] else "Active",
            Markup(f'<form method="post" action="/admin/users" class="inline-form"><input type="hidden" name="action" value="{toggle}"><input type="hidden" name="user_id" value="{user["id"]}"><button type="submit">{toggle_text}</button></form>'),
            Markup(f'<form method="post" action="/admin/users" class="inline-form"><input type="hidden" name="action" value="reset"><input type="hidden" name="user_id" value="{user["id"]}"><input name="password" type="password" placeholder="New password" required><button type="submit">Reset</button></form>'),
        ])
    return f"""
    <section class="page-head"><div><h1>User Management</h1><p>Create staff accounts, disable access, and reset passwords. Passwords are stored as salted PBKDF2 hashes.</p></div></section>
    <section class="panel"><h2>Create User</h2><form method="post" action="/admin/users" class="form-grid">
      <input type="hidden" name="action" value="create">
      <label>Username<input name="username" required></label>
      <label>Display Name<input name="display_name"></label>
      <label>Role<select name="role"><option value="Admin">Admin - Full Access</option><option value="Counselor">Counselor - Working Access</option><option value="Viewer">Teacher Viewer - View Only</option></select></label>
      <label>Password<input name="password" type="password" required></label>
      <button type="submit">Create User</button>
    </form><p class="muted small"><strong>Teacher Viewer</strong> is intended for SPED teachers, classroom teachers, and other staff who may review records but must not change or export student information.</p></section>
    <section class="panel"><h2>Existing Users</h2>{table(["Username","Display Name","Role","Status","Access","Password"], rows)}</section>
    """


def backups_html():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    backups = sorted(BACKUP_DIR.glob("*.sqlite3"), reverse=True)
    rows = []
    for backup in backups:
        rows.append([
            backup.name,
            datetime.fromtimestamp(backup.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
            f"{backup.stat().st_size / 1024 / 1024:.1f} MB",
            Markup(f'<form method="post" action="/admin/backups/restore" class="inline-form"><input type="hidden" name="filename" value="{esc(backup.name)}"><input name="confirm" placeholder="Type RESTORE" required><button type="submit">Restore</button></form>'),
        ])
    return f"""
    <section class="page-head"><div><h1>Backup and Restore</h1><p>Backups are stored in <code>{esc(BACKUP_DIR)}</code>. The system also backs up automatically before uploads, migrations, class deletes, and restores.</p></div>
      <form method="post" action="/admin/backups/create"><button type="submit">Create Manual Backup</button></form>
    </section>
    <section class="panel warning"><strong>Restore warning:</strong> restoring replaces the active database. A safety backup is created first, but confirm carefully.</section>
    <section class="panel"><h2>Available Backups</h2>{table(["Backup","Timestamp","Size","Restore"], rows)}</section>
    """


def school_profile_html(db):
    profile = school_profile(db)
    fields = ""
    for key in DEFAULT_SCHOOL_PROFILE:
        value = profile.get(key, "")
        label_text = label(key)
        fields += f'<label>{esc(label_text)}<input name="{esc(key)}" value="{esc(value)}"></label>'
    return f"""
    <section class="page-head"><div><h1>School Profile</h1><p>Configure the school name, branding, report language, and counselor assignments for this installation.</p></div></section>
    <form method="post" action="/admin/school-profile" class="panel form-grid">{fields}<button type="submit">Save School Profile</button></form>
    """


def graduation_rules_html(db):
    template_type = graduation_template_type(db)
    config = app_setting(db, "graduation_rules_config", CONFIG_DEFAULTS["graduation_rules_config"])
    va_selected = "selected" if template_type == "Virginia Template" else ""
    custom_selected = "selected" if template_type != "Virginia Template" else ""
    return f"""
    <section class="page-head"><div><h1>Graduation Rules</h1><p>Choose the state/template foundation and edit the local graduation requirements. Changes stay local until an Admin saves them.</p></div>
      <div class="actions"><a class="button secondary" href="/admin/rules-wizard">Rules Wizard</a><a class="button secondary" href="/admin/custom-fields">Custom Fields</a><a class="button secondary" href="/admin/custom-reports">Reports</a><a class="button secondary" href="/admin/agreement-builder">Agreement</a><a class="button secondary" href="/admin/import-templates">Imports</a><a class="button secondary" href="/admin/grid-columns">Grid Columns</a></div>
    </section>
    <section class="panel">
      <h2>Template Selection</h2>
      <form method="post" action="/admin/graduation-rules" class="form-grid">
        <label>Template<select name="graduation_template_type"><option {va_selected}>Virginia Template</option><option {custom_selected}>Custom / Other State Template</option></select></label>
        <label class="wide">Graduation Rules Configuration<textarea name="graduation_rules_config" rows="22">{esc(config)}</textarea></label>
        <button type="submit">Save Graduation Rules</button>
      </form>
    </section>
    {custom_setup_next_steps_html() if template_type != "Virginia Template" else ""}
    <section class="panel">
      <h2>What This Controls</h2>
      <div class="card-list">
        <article class="class-card"><strong>Diplomas and Credits</strong><span>Diploma names, total credits, and subject credit requirements.</span></article>
        <article class="class-card"><strong>Assessments</strong><span>State tests, verified credits, substitute tests, local awards, PBAs, and retake rules.</span></article>
        <article class="class-card"><strong>Readiness</strong><span>Career, college, military, credential, work-based learning, and local readiness indicators.</span></article>
        <article class="class-card"><strong>Local Graduation Items</strong><span>CPR, community service, senior project, FAFSA, fees, devices, meetings, and other local checks.</span></article>
      </div>
    </section>
    """


def _lines(text):
    return [line.strip(" -\t") for line in str(text or "").splitlines() if line.strip(" -\t")]


def rules_config_from_review_form(form):
    return {
        "template_name": form.getfirst("template_name", "Custom School Template").strip() or "Custom School Template",
        "status": "Active - Admin Approved",
        "diploma_types": [{"name": item, "total_credits_required": None} for item in _lines(form.getfirst("diploma_types", ""))],
        "subject_credit_requirements": {item: {} for item in _lines(form.getfirst("credit_requirements", ""))},
        "assessment_requirements": _lines(form.getfirst("assessment_requirements", "")),
        "readiness_indicators": _lines(form.getfirst("readiness_requirements", "")),
        "local_checklist_items": _lines(form.getfirst("local_checklist_items", "")),
        "agreement_template": form.getfirst("agreement_template", ""),
        "approved_at": datetime.now().isoformat(timespec="seconds"),
        "recommended_next_steps": [
            "Import Student Roster",
            "Import Existing Graduation Grid",
            "Create Graduation Classes",
            "Preview Checklist",
        ],
    }


def _json_setting_list(db, key):
    try:
        value = app_setting(db, key, CONFIG_DEFAULTS.get(key, "[]"))
        parsed = json.loads(value or "[]")
        return parsed if isinstance(parsed, list) else []
    except Exception:
        return []


def _json_setting_dict(db, key):
    try:
        value = app_setting(db, key, CONFIG_DEFAULTS.get(key, "{}"))
        parsed = json.loads(value or "{}")
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def _field_type_for_requirement(name):
    text = str(name or "").lower()
    if any(token in text for token in ["hour", "score", "points", "credit total", "credits"]):
        return "number"
    if any(token in text for token in ["date", "deadline"]):
        return "date"
    if any(token in text for token in ["note", "comment"]):
        return "notes"
    return "checkbox"


def seed_custom_setup_from_rules(db, config):
    requirements = []
    subject_reqs = config.get("subject_credit_requirements", {})
    if isinstance(subject_reqs, dict):
        requirements.extend(f"{name} Credits" for name in subject_reqs.keys())
    for key in ["assessment_requirements", "readiness_indicators", "local_checklist_items"]:
        values = config.get(key, [])
        if isinstance(values, list):
            requirements.extend(str(item).strip() for item in values if str(item).strip())

    custom_fields = _json_setting_list(db, "custom_fields_config")
    seen_fields = {str(item.get("name", "")).strip().lower() for item in custom_fields if isinstance(item, dict)}
    for requirement in requirements:
        if requirement.lower() in seen_fields:
            continue
        custom_fields.append({
            "name": requirement,
            "type": _field_type_for_requirement(requirement),
            "options": "",
            "description": "Created from approved custom graduation rules",
            "completion_rule": "nonblank",
            "import_aliases": "",
            "required": True,
            "grid_visible": requirement in requirements[:8],
            "profile_visible": True,
            "report_enabled": True,
        })
        seen_fields.add(requirement.lower())
    set_app_setting(db, "custom_fields_config", json.dumps(custom_fields, indent=2))

    for student in db.execute("SELECT id FROM students").fetchall():
        for field in custom_fields:
            if not isinstance(field, dict) or not field.get("required"):
                continue
            name = str(field.get("name", "")).strip()
            if name:
                db.execute(
                    """
                    INSERT OR IGNORE INTO requirement_status
                    (student_id_fk, requirement_key, status, display_value, source, needs_retest, updated_at)
                    VALUES (?, ?, 'Missing', '', 'Approved Custom Rules', 0, CURRENT_TIMESTAMP)
                    """,
                    (student["id"], name),
                )

    base_columns = ["student_name", "student_id", "graduation_class", "diploma_type", "counselor", "graduation_status"]
    summary_columns = [req for req in requirements[:8]]
    columns = []
    for column in base_columns + summary_columns + ["notes"]:
        if column not in columns:
            columns.append(column)
    set_app_setting(db, "main_grid_columns_config", json.dumps(columns, indent=2))

    reports = _json_setting_list(db, "custom_reports_config")
    seen_reports = {str(item.get("name", "")).strip().lower() for item in reports if isinstance(item, dict)}
    for requirement in requirements[:20]:
        report_name = f"Students Missing {requirement}"
        if report_name.lower() in seen_reports:
            continue
        reports.append({
            "name": report_name,
            "filters": [{"field": requirement, "operator": "is", "value": "Missing"}],
            "export": ["excel", "pdf"],
        })
        seen_reports.add(report_name.lower())
    set_app_setting(db, "custom_reports_config", json.dumps(reports, indent=2))

    agreement = _json_setting_dict(db, "agreement_builder_config")
    agreement.setdefault("title", f"{config.get('template_name', 'Custom')} Graduation Agreement")
    agreement.setdefault("intro_text", "")
    agreement["checklist_items"] = requirements
    agreement.setdefault("support_plan_options", ["Counselor meeting", "Intervention plan", "Retake or completion opportunity"])
    agreement.setdefault("signature_lines", ["Student", "Parent/Guardian", "Counselor/Admin"])
    agreement.setdefault("footer", "Confidential student planning document")
    set_app_setting(db, "agreement_builder_config", json.dumps(agreement, indent=2))


def custom_setup_next_steps_html():
    return """
    <section class="panel success">
      <h2>Custom / Out-of-State Setup Path</h2>
      <ol class="steps-list">
        <li><strong>Approve rules.</strong> Use the Rules Wizard or Graduation Rules page to activate the school/state requirements.</li>
        <li><strong>Review generated tracking fields.</strong> Open Custom Fields and adjust wording, field type, or local items.</li>
        <li><strong>Review grid columns.</strong> Open Grid Columns and choose the few fields counselors need on the main grid.</li>
        <li><strong>Import a student roster or existing grid.</strong> This creates the class grid. Rules alone do not create students.</li>
        <li><strong>Upload evidence files.</strong> Add transcripts, state assessments, credentials, readiness items, CPR/safety, or local spreadsheets.</li>
        <li><strong>Use Troubleshooter.</strong> Match names, add missing students, and fix anything that did not map cleanly.</li>
      </ol>
      <div class="actions">
        <a class="button secondary" href="/admin/custom-fields">Custom Fields</a>
        <a class="button secondary" href="/admin/grid-columns">Grid Columns</a>
        <a class="button secondary" href="/admin/custom-reports">Custom Reports</a>
        <a class="button" href="/upload">Import Roster / Grid</a>
      </div>
      <p class="muted small">For a new out-of-state school, start simple: Name, Student ID, Class, Diploma, Counselor, Graduation Status, major missing items, and Notes. Keep detailed accountability items in reports.</p>
    </section>
    """


def rules_wizard_review_html(draft):
    if not draft:
        return '<section class="panel"><h2>Review</h2><p class="muted">No draft yet. Upload graduation requirement documents to begin.</p></section>'
    try:
        parsed = json.loads(draft)
    except json.JSONDecodeError:
        return f'<section class="panel"><h2>Review</h2><p class="flash warning">The draft could not be parsed. Use the advanced JSON section below.</p><textarea rows="18">{esc(draft)}</textarea></section>'
    proposals = [doc.get("proposal", {}) for doc in parsed.get("documents", [])]

    def gather(key):
        values = []
        for proposal in proposals:
            item = proposal.get(key, [])
            if isinstance(item, dict):
                values.extend(item.keys())
            elif isinstance(item, list):
                values.extend(str(v) for v in item)
        cleaned = []
        for value in values:
            text = str(value).strip()
            if text and text not in cleaned:
                cleaned.append(text)
        return "\n".join(cleaned)

    detected_topics = gather("detected_topics")
    diploma_types = gather("diploma_types")
    credit_requirements = gather("credit_requirements")
    assessment_requirements = gather("assessment_requirements")
    readiness_requirements = gather("readiness_requirements")
    local_items = gather("local_checklist_items")
    evidence_rows = []
    for proposal in proposals:
        for item in proposal.get("evidence", []):
            if isinstance(item, dict):
                evidence_rows.append([label(item.get("category", "")), item.get("recommendation", ""), item.get("confidence", "Needs Review"), item.get("source", "")])
    validation = []
    if not (diploma_types or credit_requirements or assessment_requirements or readiness_requirements or local_items):
        validation.append("No structured requirements were detected. Add items before approval.")
    else:
        validation.append("Draft has structured items. Review and edit before approval.")
    validation_html = "".join(f"<li>{esc(item)}</li>" for item in validation)
    return f"""
    <section class="panel">
      <h2>Rules Wizard Steps</h2>
      <div class="wizard-steps"><span>1 Upload</span><span>2 Analyze</span><span>3 Review</span><span>4 Structure</span><span>5 Validate</span><span>6 Activation Pending</span></div>
    </section>
    <section class="panel">
      <h2>Review Recommendations</h2>
      <p>Detected topics: {esc(detected_topics or "None")}</p>
      <div class="grid two"><div><strong>Diploma Types</strong><pre>{esc(diploma_types or "None")}</pre></div><div><strong>Credit Requirements</strong><pre>{esc(credit_requirements or "None")}</pre></div><div><strong>Assessment Requirements</strong><pre>{esc(assessment_requirements or "None")}</pre></div><div><strong>Readiness and Local Items</strong><pre>{esc((readiness_requirements + chr(10) + local_items).strip() or "None")}</pre></div></div>
      <div class="flash warning"><strong>Validation</strong><ul>{validation_html}</ul>Recommendations remain a draft. Activation is disabled until structured validation, preview, backup, and rollback are implemented.</div>
      <form method="post" action="/admin/rules-builder"><input type="hidden" name="builder_action" value="reset_from_analysis"><button type="submit">Create Structured Draft From This Analysis</button></form>
    </section>
    <section class="panel"><h2>Source Evidence</h2><p class="muted">These are local recommendations, not finalized rules. High confidence means the wording included a requirement term such as must, shall, required, minimum, earn, or complete.</p>{table(["Category","Recommended Wording","Confidence","Source Document"], evidence_rows)}</section>
    {custom_setup_next_steps_html()}
    <details class="panel"><summary><strong>Advanced Raw JSON</strong></summary><textarea rows="18" readonly>{esc(draft)}</textarea></details>
    """


def rules_wizard_html(db):
    draft = app_setting(db, "rules_wizard_draft", "")
    return f"""
    <section class="page-head"><div><h1>Graduation Rules Wizard</h1><p>Upload state or local graduation documents. The system drafts a proposal for Admin review; no rule becomes active until saved by an Admin.</p></div></section>
    <form method="post" action="/admin/rules-wizard" enctype="multipart/form-data" class="panel form-grid">
      <label class="wide">Graduation Requirement Documents<input name="rule_docs" type="file" accept=".pdf,.docx,.xlsx,.csv,.txt,.html,.htm" multiple required></label>
      <button type="submit">Analyze Documents Locally</button>
    </form>
    {rules_wizard_review_html(draft)}
    {custom_setup_next_steps_html() if graduation_template_type(db) != "Virginia Template" else ""}
    <section class="panel warning"><strong>Important:</strong> this helper reads documents locally and proposes configuration text. It does not finalize graduation requirements without Admin review and save.</section>
    """


def typed_rule_draft(db):
    raw = app_setting(db, "custom_rule_package_draft", "")
    if raw:
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass
    return typed_rule_draft_from_analysis(app_setting(db, "rules_wizard_draft", ""))


def typed_rule_draft_from_analysis(raw):
    draft = new_rule_package("Custom School Graduation Rules", "Custom / Other State")
    try:
        parsed = json.loads(raw or "{}")
    except json.JSONDecodeError:
        return draft
    proposals = [item.get("proposal", {}) for item in parsed.get("documents", []) if isinstance(item, dict)]
    seen = set()
    for proposal in proposals:
        for name in proposal.get("diploma_types", []):
            key = field_key(name)
            if key and key not in {item["key"] for item in draft["diploma_plans"]}:
                draft["diploma_plans"].append({"key": key, "name": str(name), "total_credits": None, "requirement_keys": []})
        for source_key, kind in [
            ("credit_requirements", "subject_credits"),
            ("assessment_requirements", "assessment"),
            ("readiness_requirements", "calculated"),
            ("local_checklist_items", "checklist"),
        ]:
            for text in proposal.get(source_key, []):
                label_text = str(text).strip()
                base_key = field_key(label_text)[:48] or "requirement"
                key = base_key
                suffix = 2
                while key in seen:
                    key = f"{base_key}_{suffix}"
                    suffix += 1
                seen.add(key)
                number = re.search(r"\b(\d+(?:\.\d+)?)\b", label_text)
                item = {"key": key, "label": label_text, "type": kind, "required": True, "diploma_scope": [], "evidence_keys": []}
                if kind == "subject_credits":
                    item.update({"operator": ">=", "threshold": float(number.group(1)) if number else None, "unit": "credits"})
                draft["requirements"].append(item)
    return draft


def rules_builder_html(db):
    draft = typed_rule_draft(db)
    validation = validate_rule_package(draft)
    package = draft.get("package", {})
    lifecycle = package.get("lifecycle", {})
    versions = _json_setting_list(db, "custom_rule_package_versions")
    active_raw = app_setting(db, "active_custom_rule_package", "")
    previous_raw = app_setting(db, "previous_custom_rule_package", "")
    status = str(package.get("status") or "draft").title()
    errors = "".join(f"<li>{esc(item)}</li>" for item in validation.errors) or "<li>No blocking errors.</li>"
    warnings = "".join(f"<li>{esc(item)}</li>" for item in validation.warnings) or "<li>No warnings.</li>"
    plan_rows = [[item.get("key", ""), item.get("name", ""), item.get("total_credits", ""), ", ".join(item.get("requirement_keys", [])), _builder_delete("plan", index)] for index, item in enumerate(draft.get("diploma_plans", []))]
    requirement_rows = [[item.get("key", ""), item.get("label", ""), item.get("type", ""), item.get("operator", ""), item.get("threshold", ""), ", ".join(item.get("diploma_scope", [])), _builder_delete("requirement", index)] for index, item in enumerate(draft.get("requirements", []))]
    evidence_rows = [[item.get("key", ""), item.get("label", ""), item.get("type", ""), ", ".join(item.get("aliases", [])), _builder_delete("evidence", index)] for index, item in enumerate(draft.get("evidence_definitions", []))]
    relationship_rows = [[item.get("type", ""), item.get("parent_requirement", ""), ", ".join(item.get("child_requirements", [])), item.get("minimum", ""), _builder_delete("relationship", index)] for index, item in enumerate(draft.get("relationships", []))]
    version_rows = [[item.get("package", {}).get("name", ""), item.get("package", {}).get("version", ""), item.get("package", {}).get("status", "").title(), item.get("package", {}).get("lifecycle", {}).get("approved_at", ""), item.get("package", {}).get("lifecycle", {}).get("approved_by", "")] for item in versions]
    preview_html = ""
    if package.get("status") == "validated":
        lifecycle_action = '<form method="post" action="/admin/rules-builder"><input type="hidden" name="builder_action" value="approve_version"><button type="submit">Approve Immutable Version</button></form>'
    elif package.get("status") == "approved":
        preview = preview_rule_impact(db, draft)
        summary = preview["summary"]
        impact_rows = [[item["student_name"], item["graduation_class"], item["current_status"], item["proposed_status"], "Yes" if item["changed"] else "No"] for item in preview["rows"][:50]]
        preview_html = f'''<section class="panel"><h2>Activation Impact Preview</h2><div class="stats"><div><strong>{summary['students']}</strong><span>Students evaluated</span></div><div><strong>{summary['changed']}</strong><span>Status changes</span></div><div><strong>{summary['on_track']}</strong><span>On Track</span></div><div><strong>{summary['needs_review']}</strong><span>Needs Review</span></div><div><strong>{summary['not_applicable']}</strong><span>Not Applicable</span></div></div>{table(['Student','Class','Current','Proposed','Changes'], impact_rows)}<p>Showing the first 50 students. Activation recalculates all active students and stores explanation traces.</p><form method="post" action="/admin/rules-builder" class="inline-form"><input type="hidden" name="builder_action" value="activate_version"><label>Type ACTIVATE<input name="confirm" required></label><button type="submit">Activate Approved Version</button></form></section>'''
        lifecycle_action = '<p class="flash success"><strong>Approved:</strong> this immutable version is ready for impact review below.</p>'
    elif package.get("status") == "active":
        lifecycle_action = '<p class="flash success"><strong>Active:</strong> this custom rule version is currently calculating student statuses.</p>'
    else:
        lifecycle_action = '<form method="post" action="/admin/rules-builder"><input type="hidden" name="builder_action" value="validate_draft"><button type="submit">Validate Draft</button></form>' if validation.valid else '<p>Resolve all blocking errors before validation.</p>'
    return f"""
    <section class="page-head"><div><h1>Structured Graduation Rules Builder</h1><p>Review a typed draft. Nothing on this page can activate rules or recalculate students.</p></div><div class="actions"><a class="button secondary" href="/admin/rules-wizard">Source Analysis</a></div></section>
    <section class="panel"><h2>Lifecycle</h2><p><strong>Current state:</strong> {esc(status)}</p><div class="grid two"><div class="flash {'success' if validation.valid else 'danger'}"><strong>Blocking checks</strong><ul>{errors}</ul></div><div class="flash warning"><strong>Warnings</strong><ul>{warnings}</ul></div></div>{lifecycle_action}<p><strong>Validated:</strong> {esc(lifecycle.get('validated_at') or 'Not yet')} &nbsp; <strong>Approved:</strong> {esc(lifecycle.get('approved_at') or 'Not yet')}</p><p><strong>Activation safeguard:</strong> activation requires an approved fingerprint, impact preview, typed confirmation, an integrity-checked backup, calculation result storage, and an audit record.</p></section>
    {preview_html}
    {f'''<section class="panel warning"><h2>Rollback</h2><p>A previous active version is available. Rollback creates another verified backup before recalculating students.</p><form method="post" action="/admin/rules-builder" class="inline-form"><input type="hidden" name="builder_action" value="rollback_version"><label>Type ROLLBACK<input name="confirm" required></label><button type="submit">Restore Previous Version</button></form></section>''' if active_raw and previous_raw else ''}
    <section class="panel"><h2>Package</h2><form method="post" action="/admin/rules-builder" class="form-grid"><input type="hidden" name="builder_action" value="save_package"><label>Key<input name="key" value="{esc(package.get('key',''))}"></label><label>Name<input name="name" value="{esc(package.get('name',''))}"></label><label>Jurisdiction<input name="jurisdiction" value="{esc(package.get('jurisdiction',''))}"></label><label>Version<input name="version" value="{esc(package.get('version',''))}"></label><label>Effective From<input type="date" name="effective_from" value="{esc(package.get('effective_from') or '')}"></label><label>Effective To<input type="date" name="effective_to" value="{esc(package.get('effective_to') or '')}"></label><label>Cohort Start<input name="cohort_start" value="{esc(package.get('cohort_start') or '')}"></label><label>Cohort End<input name="cohort_end" value="{esc(package.get('cohort_end') or '')}"></label><button type="submit">Save Draft Details</button></form></section>
    <section class="panel"><h2>Diploma Plans</h2>{table(['Key','Name','Credits','Requirements',''], plan_rows)}{_builder_form('plan')}</section>
    <section class="panel"><h2>Requirements</h2>{table(['Key','Label','Type','Operator','Threshold','Diploma Scope',''], requirement_rows)}{_builder_form('requirement')}</section>
    <section class="panel"><h2>Evidence Definitions</h2>{table(['Key','Label','Type','Aliases',''], evidence_rows)}{_builder_form('evidence')}</section>
    <section class="panel"><h2>Requirement Relationships</h2>{table(['Type','Parent','Children','Minimum',''], relationship_rows)}{_builder_form('relationship')}</section>
    <section class="panel"><h2>Approved Version History</h2><p>Approved snapshots are retained separately from the editable draft.</p>{table(['Package','Version','State','Approved','Approved By'], version_rows)}</section>
    <details class="panel"><summary><strong>Advanced Draft JSON</strong></summary><textarea rows="24" readonly>{esc(json.dumps(draft, indent=2))}</textarea></details>
    """


def _builder_delete(kind, index):
    return Markup(f'<form method="post" action="/admin/rules-builder" class="inline-form"><input type="hidden" name="builder_action" value="delete_{kind}"><input type="hidden" name="item_index" value="{index}"><button type="submit">Delete</button></form>')


def _builder_form(kind):
    if kind == "plan":
        fields = '<label>Key<input name="key" required></label><label>Name<input name="name" required></label><label>Total Credits<input type="number" step="0.5" name="total_credits"></label><label>Requirement Keys<input name="requirement_keys" placeholder="english_credits, math_credits"></label>'
    elif kind == "requirement":
        type_options = ''.join(f'<option>{item}</option>' for item in ['credit_total','subject_credits','assessment','credential','checklist','number','date','text','calculated'])
        fields = f'<label>Key<input name="key" required></label><label>Label<input name="label" required></label><label>Type<select name="type">{type_options}</select></label><label>Operator<input name="operator" placeholder=">="></label><label>Threshold<input type="number" step="0.01" name="threshold"></label><label>Unit<input name="unit" placeholder="credits, hours, points"></label><label>Diploma Scope<input name="diploma_scope" placeholder="standard, advanced"></label><label>Evidence Keys<input name="evidence_keys"></label><label><input type="checkbox" name="required" value="1" checked> Required</label>'
    elif kind == "evidence":
        type_options = ''.join(f'<option>{item}</option>' for item in ['transcript_course','assessment_attempt','credential_attempt','completion_record','custom_field','manual_confirmation'])
        fields = f'<label>Key<input name="key" required></label><label>Label<input name="label" required></label><label>Type<select name="type">{type_options}</select></label><label>Import Aliases<input name="aliases"></label><label>Subject Family<input name="subject_family"></label><label><input type="checkbox" name="date_required" value="1"> Date required</label>'
    else:
        type_options = ''.join(f'<option>{item}</option>' for item in ['all_of','any_of','count_of','alternative'])
        fields = f'<label>Type<select name="type">{type_options}</select></label><label>Parent Requirement<input name="parent_requirement" required></label><label>Child Requirements<input name="child_requirements" required></label><label>Minimum<input type="number" name="minimum"></label>'
    return f'<form method="post" action="/admin/rules-builder" class="form-grid"><input type="hidden" name="builder_action" value="save_{kind}">{fields}<button type="submit">Add {label(kind)}</button></form>'


def _upsert_builder_item(items, form, field_types):
    item = {}
    for field, field_type in field_types.items():
        value = form.get(field, "").strip()
        if field_type == "csv":
            item[field] = [part.strip() for part in value.split(",") if part.strip()]
        elif field_type == "bool":
            item[field] = form.get(field) == "1"
        elif field_type == "number":
            item[field] = float(value) if value else None
        elif field_type == "integer":
            item[field] = int(value) if value else None
        else:
            item[field] = value
    key = item.get("key")
    if key:
        existing = next((index for index, current in enumerate(items) if current.get("key") == key), None)
        if existing is not None:
            items[existing] = item
            return
    items.append(item)


def _optional_int(value):
    text = str(value or "").strip()
    return int(text) if text else None


def custom_fields_html(db):
    fields = _json_setting_list(db, "custom_fields_config")
    rows = []
    for index, field in enumerate(fields):
        if not isinstance(field, dict):
            continue
        visibility = ", ".join(label for enabled, label in [(field.get("grid_visible"), "Grid"), (field.get("profile_visible", True), "Profile"), (field.get("report_enabled", True), "Reports")] if enabled) or "Profile"
        rows.append([field.get("name", ""), field.get("type", "text"), field.get("completion_rule", "nonblank"), field.get("import_aliases", ""), visibility, Markup(f'<form method="post" action="/admin/custom-fields" class="inline-form"><input type="hidden" name="field_action" value="delete"><input type="hidden" name="field_index" value="{index}"><button type="submit">Delete</button></form>')])
    return f"""
    <section class="page-head"><div><h1>Custom Tracking Fields</h1><p>Create requirements and local items that can appear on profiles, class grids, imports, and reports.</p></div><div class="actions"><a class="button secondary" href="/admin/rules-wizard">Rules Wizard</a><a class="button secondary" href="/admin/grid-columns">Grid Columns</a><a class="button secondary" href="/admin/custom-reports">Reports</a></div></section>
    <section class="panel"><h2>Add or Update a Field</h2><form method="post" action="/admin/custom-fields" class="form-grid">
      <input type="hidden" name="field_action" value="add">
      <label>Field Name<input name="name" required placeholder="Example: Community Service Hours"></label>
      <label>Field Type<select name="type"><option>checkbox</option><option>text</option><option>number</option><option>date</option><option>dropdown</option><option>score</option><option>notes</option></select></label>
      <label class="wide">Description<input name="description" placeholder="What counselors should record"></label>
      <label>Dropdown Options<input name="options" placeholder="College, Employment, Military"></label>
      <label>Completion Rule<input name="completion_rule" value="nonblank" placeholder="nonblank, checked, >=20, equals Complete"></label>
      <label class="wide">Import Aliases<input name="import_aliases" placeholder="Community Hours, Service Hrs, Volunteer Hours"></label>
      <fieldset class="wide choice-panel"><legend>Use This Field</legend>
        <label><input type="checkbox" name="required" value="1"> Required for graduation status</label>
        <label><input type="checkbox" name="grid_visible" value="1"> Show on main class grid</label>
        <label><input type="checkbox" name="profile_visible" value="1" checked> Show on student profile</label>
        <label><input type="checkbox" name="report_enabled" value="1" checked> Allow in custom reports</label>
      </fieldset>
      <button type="submit">Save Tracking Field</button>
    </form></section>
    <section class="panel"><h2>Configured Fields</h2>{table(["Field","Type","Completion Rule","Import Aliases","Used In",""], rows)}</section>
    <details class="panel"><summary><strong>Advanced Configuration JSON</strong></summary><textarea rows="14" readonly>{esc(json.dumps(fields, indent=2))}</textarea></details>
    """


def custom_reports_html(db):
    reports = _json_setting_list(db, "custom_reports_config")
    names = custom_report_field_names(db)
    field_options = "".join(f'<option value="{esc(name)}">{esc(name)}</option>' for name in names)
    optional_field_options = '<option value="">No second condition</option>' + field_options
    rows = []
    for index, report in enumerate(reports):
        filters = report.get("filters", []) if isinstance(report, dict) else []
        rule_text = f" {str(report.get('combine','all')).upper()} ".join(f"{rule.get('field','')} {rule.get('operator','')} {rule.get('value','')}" for rule in filters)
        rows.append([report.get("name", ""), rule_text, Markup(f'<form method="post" action="/admin/custom-reports" class="inline-form"><input type="hidden" name="report_action" value="delete"><input type="hidden" name="report_index" value="{index}"><button type="submit">Delete</button></form>')])
    return f"""
    <section class="page-head"><div><h1>Custom Report Builder</h1><p>Create reusable student lists from any school-defined tracking field.</p></div></section>
    <section class="panel"><h2>Create Report</h2><form method="post" action="/admin/custom-reports" class="form-grid">
      <label>Report Name<input name="name" required placeholder="Students Missing Community Service"></label>
      <label>Tracking Field<select name="field" required>{field_options}</select></label>
      <label>Comparison<select name="operator"><option value="is">Is</option><option value="is_not">Is Not</option><option value="less_than">Less Than</option><option value="greater_than">Greater Than</option></select></label>
      <label>Value<input name="value" value="Missing"></label>
      <label>Combine Conditions<select name="combine"><option value="all">AND - all conditions</option><option value="any">OR - any condition</option></select></label>
      <label>Second Tracking Field<select name="field_2">{optional_field_options}</select></label>
      <label>Second Comparison<select name="operator_2"><option value="is">Is</option><option value="is_not">Is Not</option><option value="less_than">Less Than</option><option value="greater_than">Greater Than</option></select></label>
      <label>Second Value<input name="value_2" value="Missing"></label>
      <button type="submit">Save Report</button>
    </form></section>
    <section class="panel"><h2>Saved Reports</h2>{table(["Report","Conditions",""], rows)}</section>
    """


def agreement_builder_html(db):
    text = app_setting(db, "agreement_builder_config", CONFIG_DEFAULTS["agreement_builder_config"])
    examples = """{
  "title": "Graduation Agreement",
  "intro_text": "School-specific opening language",
  "checklist_items": ["Credit total", "State assessment", "CPR", "Local fees"],
  "support_plan_options": ["Intervention class", "Retake opportunity", "Counselor meeting"],
  "signature_lines": ["Student", "Parent/Guardian", "Counselor/Admin"],
  "footer": "Confidential student planning document"
}"""
    return config_editor_html("Graduation Agreement Builder", "Edit report title, intro text, checklist items, support plan options, signature lines, footer, and school-specific language.", "/admin/agreement-builder", text, examples)


def import_templates_html(db):
    profiles = parse_profiles(app_setting(db, "import_templates_config", "[]"))
    rows = []
    for item in profiles:
        mappings = ", ".join(f"{label(field)} <- {column}" for field, column in item.get("mappings", {}).items())
        actions = Markup(f'''<div class="actions"><form method="post" action="/admin/import-templates" class="inline-form"><input type="hidden" name="profile_action" value="toggle"><input type="hidden" name="profile_id" value="{esc(item.get('id',''))}"><button type="submit">{'Disable' if item.get('active', True) else 'Enable'}</button></form><form method="post" action="/admin/import-templates" class="inline-form"><input type="hidden" name="profile_action" value="delete"><input type="hidden" name="profile_id" value="{esc(item.get('id',''))}"><button type="submit">Delete</button></form></div>''')
        rows.append([item.get("name", ""), item.get("source_type", ""), "Active" if item.get("active", True) else "Disabled", mappings, item.get("last_used_at", "Never"), actions])
    return f'''<section class="page-head"><div><h1>Import Profile Manager</h1><p>Mappings saved after a confirmed upload are recognized by source type and file headers.</p></div><div class="actions"><a class="button" href="/upload">Upload and Create Profile</a></div></section><section class="panel"><h2>Saved Profiles</h2>{table(["Name","Source Type","Status","Mappings","Last Used",""], rows)}<p class="muted">To create or replace a profile, upload a representative file, confirm its mapping, and select Save this confirmed mapping.</p></section><details class="panel"><summary><strong>Advanced Profile JSON</strong></summary><textarea rows="18" readonly>{esc(json.dumps(profiles, indent=2))}</textarea></details>'''


def grid_columns_html(db):
    selected = set(custom_grid_columns(db))
    choices = "".join(f'<label class="choice"><input type="checkbox" name="show_{field_key(column)}" value="1" {"checked" if column in selected else ""}><span><strong>{esc(custom_grid_header(column))}</strong><small>{"Required column" if column in {"student_name", "graduation_class"} else "Can be shown or hidden"}</small></span></label>' for column in custom_grid_available_columns(db))
    return f"""
    <section class="page-head"><div><h1>Main Grid Columns</h1><p>Select the columns counselors need for a quick class-level view.</p></div></section>
    <form method="post" action="/admin/grid-columns" class="panel"><div class="grid two">{choices}</div><button type="submit">Save Grid Columns</button></form>
    <section class="panel"><h2>Add a New Tracking Column</h2><p class="muted">Create a school-specific field here and it will immediately appear as a selected grid column, on student profiles, and in the report builder.</p>
      <form method="post" action="/admin/grid-columns" class="form-grid">
        <input type="hidden" name="column_action" value="add_field">
        <label>Column Name<input name="name" required placeholder="Example: Community Service"></label>
        <label>Field Type<select name="type"><option>checkbox</option><option>text</option><option>number</option><option>date</option><option>dropdown</option><option>score</option><option>notes</option></select></label>
        <label>Completion Rule<input name="completion_rule" value="checked" placeholder="checked, nonblank, >=20"></label>
        <label>Import Aliases<input name="import_aliases" placeholder="Community Service, Service Complete"></label>
        <label class="choice"><input type="checkbox" name="required" value="1"><span>Include in graduation-status review</span></label>
        <button type="submit">Add and Show Column</button>
      </form>
    </section>
    """


def custom_field_names(db):
    names = []
    for item in _json_setting_list(db, "custom_fields_config"):
        if isinstance(item, dict):
            name = str(item.get("name", "")).strip()
        else:
            name = str(item).strip()
        if name and name not in names:
            names.append(name)
    return names


def custom_report_field_names(db):
    names = custom_field_names(db)
    package = active_custom_package(db)
    if package:
        for requirement in package.get("requirements", []):
            key = str(requirement.get("key", "")).strip()
            if key and key not in names:
                names.append(key)
        if "Custom Graduation Status" not in names:
            names.append("Custom Graduation Status")
    return names


def field_key(value):
    return re.sub(r"[^a-z0-9]+", "_", str(value or "").lower()).strip("_")


def custom_grid_available_columns(db):
    built_in = ["student_name", "student_id", "graduation_class", "diploma_type", "counselor", "graduation_status", "major_requirement_summary", "notes"]
    return built_in + [name for name in custom_field_names(db) if name not in built_in]


def visible_custom_grid_columns(db):
    selected = set(custom_grid_columns(db))
    columns = []
    for item in _json_setting_list(db, "custom_fields_config"):
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "")).strip()
        if name and (item.get("grid_visible") or name in selected):
            columns.append(name)
    return columns


def custom_grid_columns(db):
    columns = _json_setting_list(db, "main_grid_columns_config")
    columns = [str(column).strip() for column in columns if str(column).strip()]
    if not columns:
        columns = ["student_name", "student_id", "graduation_class", "diploma_type", "counselor", "graduation_status", "notes"]
    for required in ["student_name", "graduation_class"]:
        if required not in columns:
            columns.insert(0, required)
    return columns


def custom_grid_header(column):
    labels = {
        "student_name": "Student",
        "student_id": "Student ID",
        "graduation_class": "Class",
        "diploma_type": "Diploma",
        "counselor": "Counselor",
        "graduation_status": "Graduation Status",
        "readiness_score": "Readiness",
        "major_requirement_summary": "Major Requirements",
        "notes": "Notes",
    }
    return labels.get(column, label(column))


def custom_grid_cell(student, statuses, column):
    if column == "student_name":
        return student_grid_name(student)
    if column == "student_id":
        return esc(student["student_id"] or "")
    if column == "graduation_class":
        return student["graduation_class"]
    if column == "diploma_type":
        return esc(student["diploma_type"] or "")
    if column == "counselor":
        return esc(student["counselor"] or "")
    if column == "notes":
        return esc(student["notes"] or "")
    if column == "graduation_status":
        missing = [key for key, row in statuses.items() if row["status"] not in {"Met", "Met by LVC", "Complete", "Pass", "Taken"}]
        return "On Track" if not missing else f"Needs Review: {len(missing)}"
    if column == "major_requirement_summary":
        missing = [key for key, row in statuses.items() if row["status"] not in {"Met", "Met by LVC", "Complete", "Pass", "Taken"}]
        return "No missing items shown" if not missing else esc(", ".join(missing[:4]) + ("..." if len(missing) > 4 else ""))
    row = statuses.get(column)
    return custom_field_grid_cell(row)


def custom_field_grid_cell(row):
    if not row:
        return Markup('<span class="status missing">Missing</span>')
    value = row["display_value"] or row["status"] or ""
    css = "met" if row["status"] in {"Met", "Met by LVC", "Complete", "Pass", "Taken"} else "missing" if row["status"] == "Missing" else "warn"
    return Markup(f'<span class="status {css}">{esc(value)}</span>')


def custom_report_definitions(db):
    reports = []
    for index, item in enumerate(_json_setting_list(db, "custom_reports_config")):
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "")).strip()
        filters = item.get("filters", [])
        if not name or not isinstance(filters, list) or not filters:
            continue
        reports.append({"key": f"custom-{index}", "name": name, "filters": filters, "combine": item.get("combine", "all"), "columns": item.get("columns", []), "sort": item.get("sort", "")})
    return reports


def custom_report_definition(db, report_key):
    for item in custom_report_definitions(db):
        if item["key"] == report_key:
            return item
    return None


def custom_report_title(db, report_key):
    item = custom_report_definition(db, report_key)
    return item["name"] if item else ""


def config_editor_html(title, description, action, current_text, example_text):
    return f"""
    <section class="page-head"><div><h1>{esc(title)}</h1><p>{esc(description)}</p></div><div class="actions"><a class="button secondary" href="/admin/graduation-rules">Graduation Rules</a><a class="button secondary" href="/admin/rules-wizard">Rules Wizard</a></div></section>
    <form method="post" action="{esc(action)}" class="panel">
      <label>Configuration<textarea name="config_text" rows="24">{esc(current_text)}</textarea></label>
      <button type="submit">Save {esc(title)}</button>
    </form>
    <section class="panel"><h2>Example Format</h2><textarea rows="12" readonly>{esc(example_text)}</textarea></section>
    """


def audit_log_html(db):
    rows = db.execute("SELECT created_at, username, role, action, detail, ip_address FROM audit_log ORDER BY created_at DESC LIMIT 250").fetchall()
    return '<section class="page-head"><div><h1>Audit Log</h1><p>Recent uploads, exports, edits, backups, restores, reports, logins, and user changes.</p></div></section><section class="panel">' + table(["When","User","Role","Action","Detail","IP"], rows) + "</section>"


def release_notes_html():
    return f"""
    <section class="page-head"><div><h1>Release Notes</h1><p>Version {esc(APP_VERSION)}</p></div></section>
    <section class="panel"><h2>Pilot Release</h2>
      <ul>
        <li>Credit/SOL checklists now mark current transcript courses as IP instead of X; X is reserved for completed courses. Economics and Personal Finance is listed separately under Other Requirements instead of English.</li>
        <li>Admins can create a school-specific tracking field directly on the Grid Columns page and immediately show it on Virginia or custom-state grids, profiles, reports, and Excel exports.</li>
        <li>Science, Math, and History score cells now group every stored attempt by tested course when hovered or opened.</li>
        <li>Added separate Virginia reports for students with no recorded Biology, Algebra I, or EOC Reading attempt.</li>
        <li>Added an MS EOC Test Taker marker and monitoring report for students who tested in middle school and need high-school scheduling review.</li>
        <li>Added Admin-only permanent deletion for incorrect merges and duplicate students, with typed confirmation, audit logging, and a pre-delete backup.</li>
        <li>Archived same-name students are no longer silently selected for a new active roster import.</li>
        <li>School-entered custom evidence is stored separately from calculated rule results so activation and rollback do not erase source values.</li>
        <li>Configuration-template imports remain drafts and no longer deactivate the currently approved rule package.</li>
        <li>Added a color-coded Employment credential column using the strongest W!SE, Workplace Readiness, or NCRC evidence.</li>
        <li>NCRC now requires an earned NCRC result or all three component tests at level 3 or above.</li>
        <li>Added a class-filterable report for students still needing an Employment credential.</li>
        <li>Restored the clearly labeled, color-coded SOLs Complete column on every Virginia class grid.</li>
        <li>Removed inactive legacy Flask prototype modules and the unused shared fallback secret.</li>
        <li>Added a complete Admin, Counselor, and Teacher Viewer authorization matrix across protected GET and POST routes.</li>
        <li>Added release-time dependency vulnerability, secret, and package-content verification records.</li>
        <li>Mixed SOL and History PBA workbooks now preserve each row's Scaled Score instead of treating the entire file as a two-score PBA worksheet.</li>
        <li>Assessment files covering multiple graduation classes now match by student ID or unique student name instead of forcing every row into the first class year in the filename.</li>
        <li>The multiple-attempt # marker now uses each student's locked Math or Reading passing standard, including new standards above 400.</li>
        <li>Published Pearson reports with separate Student Test Month, Day, and Year columns now combine automatically into a validated full test date.</li>
        <li>Virginia EOC school-year windows now run October 1 through September 30 and include future phase-in years.</li>
        <li>Assessment imports recover Scaled Score and other standard columns when an older mapping screen omits them.</li>
        <li>Guided local Custom/Other State setup with document evidence and confidence labels.</li>
        <li>Form-based custom tracking fields, grid-column selection, and custom report creation.</li>
        <li>Custom spreadsheet aliases and completion rules feed student grids and reports.</li>
        <li>Virginia and Custom/Other State calculations remain separate.</li>
        <li>Teacher Viewer accounts have a dedicated view-only interface and server-enforced restrictions.</li>
        <li>Configurable data directory for school-server installs.</li>
        <li>Admin, Counselor, and Teacher Viewer roles.</li>
        <li>User management with salted password hashing.</li>
        <li>Automatic database backups before uploads and migrations.</li>
        <li>Manual backup and restore tools.</li>
        <li>FERPA login/export warnings and audit logging.</li>
        <li>Configurable school profile so the app can be reused across schools.</li>
        <li>Login throttling after repeated failed attempts and eight-hour inactive-session expiration.</li>
        <li>Disabled accounts lose access immediately, including existing browser sessions.</li>
        <li>Request-size safeguards, streamed file storage, and automatic backup retention.</li>
        <li>Repeatable clean roster, assessment, privacy, password, and backup tests.</li>
      </ul>
    </section>
    """


def grid_creating_source(source_type):
    text = str(source_type or "").lower()
    return any(token in text for token in ["student roster", "class list", "existing graduation grid", "graduation tracking sheet"])


def upload_html(error=""):
    err = f'<div class="flash warning">{esc(error)}</div>' if error else ""
    return f'{err}<section class="page-head"><div><h1>Upload New Data</h1><p>Accepted formats include Excel, CSV, assessment files, roster/grid files, and transcript/course-history PDFs. Files are stored locally and never sent to an external service.</p></div></section><form method="post" enctype="multipart/form-data" class="panel form-grid"><label>Data Source Type<select name="source_type"><option>Student Roster / Class List</option><option>Existing Graduation Grid</option><option>Custom Tracking Spreadsheet</option><option>State Assessment Upload (Ex. Pearson)</option><option>Business Letter Writing Results</option><option>Workplace Documents Results</option><option>History PBA results</option><option>Transcript / Course History</option><option>Workplace Readiness report</option><option>NCRC report</option><option>CTE credentialing results</option><option>CPR/AED completion file</option><option>ASVAB / 3E documentation</option><option>Other</option></select></label><label>User Note<input name="note" placeholder="Example: Class of 2031 roster or Spring state assessment scores"></label><label class="wide">File<input name="data_file" type="file" accept=".xlsx,.xls,.xlsm,.csv,.pdf" required></label><button type="submit">Review Upload</button></form>'


def mapping_html(original, upload_token, source_type, note, preview, existing_classes=None, matched_profile=None, profile_score=0.0, profile_reason="", can_save_profile=False):
    fields = ""
    for field in CANONICAL_FIELDS:
        options = '<option value="">Not included</option>'
        for col in preview["columns"]:
            selected = "selected" if preview["suggestions"].get(field) == col else ""
            options += f'<option value="{esc(col)}" {selected}>{esc(col)}</option>'
        fields += f'<label>{label(field)}<select name="{field}">{options}</select></label>'
    hidden = f'<input type="hidden" name="upload_token" value="{esc(upload_token)}"><input type="hidden" name="import_profile_id" value="{esc((matched_profile or {}).get("id", ""))}">' 
    preview_rows = [[row.get(col, "") for col in preview["columns"]] for row in preview["preview"]]
    grid_controls = '<div class="flash warning">Assessment/test score uploads update existing students. If no class grid exists yet, import a Student Roster / Class List or Existing Graduation Grid first.</div>'
    if grid_creating_source(source_type):
        class_options = "".join(f'<option value="{cls}">Class of {cls}</option>' for cls in (existing_classes or []))
        detected_class = preview["suggestions"].get("graduation_class", "")
        grid_controls = f"""
        <fieldset class="wide choice-panel">
          <legend>Class Grid Import Plan</legend>
          <label class="choice"><input type="radio" name="grid_action" value="use_file_year" checked><span>Use graduation year from file<small>Best when the file includes Graduation Year, Grad Year, Graduation Class, or Cohort.</small></span></label>
          <label class="choice"><input type="radio" name="grid_action" value="create_or_use_class"><span>Create or use one class grid<small>Use this when the file is one class list or only includes grade level.</small></span></label>
          <label>Class year to create/use<input name="grid_class_override" placeholder="Example: 2031"></label>
          <label>Existing grid<select name="existing_grid"><option value="">Choose only if merging</option>{class_options}</select></label>
          <p class="muted small">Preview rows shown: {len(preview["preview"])}. Confirm required fields before processing.</p>
          <p class="muted small">Detected graduation class column: {esc(detected_class or "None")}</p>
        </fieldset>
        """
    normalized_columns = {" ".join(str(column).lower().split()) for column in preview["columns"]}
    split_date_notice = ""
    has_split_test_date = {"student test month", "student test day", "student test year"}.issubset(normalized_columns)
    has_mapped_test_date = bool(preview["suggestions"].get("test_date"))
    if has_split_test_date:
        split_date_notice = '<p class="flash success"><strong>Published report date detected:</strong> Student Test Month, Day, and Year will be combined automatically into one complete Test Date. You do not need to select one date-part column.</p>'
    historical_date_notice = ""
    if "existing graduation grid" in str(source_type or "").lower():
        if has_mapped_test_date or has_split_test_date:
            historical_date_notice = '<p class="flash success"><strong>Test-date evidence detected:</strong> The imported dates will be retained for Virginia EOC phase-in and passing-standard review.</p>'
        else:
            historical_date_notice = '<p class="flash warning"><strong>No actual test date was detected in this historical grid.</strong> Scores and notes will still be preserved, but date-sensitive Virginia EOC results may display <strong>Review Required</strong>. The system will not guess a test date. Upload the dated assessment report later to confirm the applicable passing standard.</p>'
    profile_notice = f'<div class="flash success"><strong>Saved mapping applied:</strong> {esc(matched_profile.get("name", ""))} ({profile_score:.0%} match). {esc(profile_reason)}</div>' if matched_profile else '<div class="flash warning"><strong>No saved mapping matched.</strong> Confirm the suggested columns below.</div>'
    save_controls = '<fieldset class="wide choice-panel"><legend>Reuse This Mapping</legend><label class="choice"><input type="checkbox" name="save_import_profile" value="1"><span>Save this confirmed mapping<small>Future files with matching headers will use it automatically.</small></span></label><label>Profile name<input name="import_profile_name" placeholder="Example: PowerSchool State Assessment Export"></label></fieldset>' if can_save_profile else ''
    return f'<section class="page-head"><div><h1>Confirm Column Mapping</h1><p>Suggested matches are preselected. Confirm them before processing {esc(original)}.</p></div></section>{profile_notice}{split_date_notice}{historical_date_notice}<form method="post" action="/upload/process" class="panel">{hidden}{grid_controls}<div class="mapping-grid">{fields}</div>{save_controls}<button type="submit">Process Upload</button></form><section class="panel"><h2>Preview</h2><div class="table-scroll">{table(preview["columns"], preview_rows)}</div></section>'


def transcript_mapping_html(original, upload_token, source_type, note, preview):
    hidden = "".join(
        f'<input type="hidden" name="{k}" value="{esc(v)}">'
        for k, v in {
            "upload_token": upload_token,
            "upload_kind": "transcript",
        }.items()
    )
    preview_rows = [[row.get(col, "") for col in preview["columns"]] for row in preview["preview"]]
    return f'<section class="page-head"><div><h1>Confirm Transcript / Course History Upload</h1><p>The system will match this file to the student by State ID first, then by name and class.</p></div></section><form method="post" action="/upload/process" class="panel">{hidden}<button type="submit">Process Transcript / Course History</button></form><section class="panel"><h2>Transcript Preview</h2><div class="table-scroll">{table(preview["columns"], preview_rows)}</div></section>'


def transcript_error_html(parsed, error):
    rows = [
        ["Student", parsed.get("student_name", "")],
        ["State ID", parsed.get("state_id", "")],
        ["Grade Level", parsed.get("grade_level", "")],
        ["Graduation Class", parsed.get("graduation_class", "")],
        ["Issue", error],
    ]
    return f'<section class="page-head"><div><h1>Transcript Upload Needs Review</h1><p>The transcript/course-history file was readable, but it could not be matched to an existing student.</p></div></section><section class="panel">{table(["Field","Value"], rows)}<p>Check that the student is already in the correct class grid and that the student ID or name matches the transcript.</p></section>'


def transcript_batch_results_html(results):
    matched = [result for result in results if result["student_id"]]
    unmatched = [result for result in results if not result["student_id"]]
    rows = []
    for result in results:
        parsed = result["parsed"]
        courses = len(parsed.get("courses", []))
        wip = len(parsed.get("work_in_progress", []))
        student = link(esc(result["student_name"]), f'/students/{result["student_id"]}') if result["student_id"] else esc(result["student_name"] or parsed.get("student_name", ""))
        rows.append([
            "Matched" if result["student_id"] else "Needs Review",
            student,
            result["state_id"],
            result["graduation_class"] or "",
            f"{courses} completed / {wip} in progress",
            result["error"],
        ])
    body = f"""
    <section class="page-head">
      <div><h1>Transcript Batch Results</h1><p>{len(matched)} transcript(s) matched and saved. {len(unmatched)} need review.</p></div>
      <div class="actions"><a class="button" href="/grids">Class Grids</a><a class="button secondary" href="/upload">Upload Another File</a></div>
    </section>
    <section class="panel">{table(["Status","Student","State ID","Class","Courses","Note"], rows)}</section>
    """
    return body


def manual_grid_edit_form(db, student_id):
    options = [
        ("Science", "Science"),
        ("Math", "Math"),
        ("EngRLR", "English Reading"),
        ("EngWrit", "English Writing"),
        ("History", "History"),
        ("ESCI", "Earth Science"),
        ("Bio", "Biology"),
        ("Chem", "Chemistry"),
        ("AlgI", "Algebra I"),
        ("Geom", "Geometry"),
        ("AlgII", "Algebra II"),
        ("WGeo", "World Geography"),
        ("WHI", "World History I"),
        ("WHII", "World History II"),
        ("USH", "US History"),
        ("PBA:WGeo", "PBA - World Geography"),
        ("PBA:WHI", "PBA - World History I"),
        ("PBA:WHII", "PBA - World History II"),
        ("PBA:USH", "PBA - US History"),
        ("WD", "Workplace Docs"),
        ("BLW", "Business Letter Writing"),
        ("Credential Test", "Credential Test"),
        ("Employment:WPR", "Employment - Workplace Readiness (WPR)"),
        ("Employment:WISE", "Employment - W!SE Credential"),
        ("Employment:NCRC:Overall", "NCRC - Overall Earned / Failed Result"),
        ("Employment:NCRC:Workplace", "NCRC - Workplace Documents"),
        ("Employment:NCRC:Graphic", "NCRC - Graphic Literacy"),
        ("Employment:NCRC:Applied", "NCRC - Applied Math"),
        ("CPR/AED Complete", "CPR/AED"),
        ("3E Readiness", "3E Readiness"),
        ("SOLs Complete", "SOLs Complete"),
        ("Manual Note", "Manual Note"),
    ]
    existing_values = {value for value, _label in options}
    for field in custom_field_names(db):
        if field not in existing_values:
            options.append((field, field))
            existing_values.add(field)
    requirement_options = "".join(f'<option value="{esc(value)}">{esc(label)}</option>' for value, label in options)
    status_options = "".join(f"<option>{esc(value)}</option>" for value in ["Met", "Missing", "Met by LVC", "CA/LVC", "Needs Review", "Complete", "Taken", "Pass", "Fail"])
    return f"""
    <form method="post" action="/students/{student_id}/edit" class="form-grid">
      <input type="hidden" name="edit_action" value="grid">
      <label>Grid Area / Requirement<select name="requirement_key">{requirement_options}</select></label>
      <label>Status<select name="status">{status_options}</select></label>
      <label>Display Value<input name="display_value" placeholder="Example: 405, WD-4, BLW-3, PBA - LAVC"></label>
      <label>Numeric Score (PBA / WPR / NCRC)<input name="score" placeholder="Example: 2 for PBA, 87 for WPR, or 4 for NCRC"></label>
      <label>Test Name<input name="test_name" placeholder="Example: EOC Reading, Manual Edit"></label>
      <label>Test Date<input name="test_date" placeholder="YYYY-MM-DD or note"></label>
      <label>Course<input name="course" placeholder="Optional course"></label>
      <label>Needs Retest?<select name="needs_retest"><option value="0">No</option><option value="1">Yes</option></select></label>
      <label class="wide">Required Edit Note<input name="edit_note" required placeholder="Explain why this manual grid edit is being made"></label>
      <button type="submit">Save Manual Grid Edit</button>
    </form>
    """


def transcript_section(courses, documents):
    docs = table(["Uploaded", "Type", "File"], [[d["uploaded_at"], d["document_type"], d["original_filename"]] for d in documents])
    summary = transcript_summary_from_courses(courses)
    summary_rows = [
        ["English", core_progress_text(summary, "English"), summary["English"]["detail"]],
        ["Math Core", core_progress_text(summary, "Math"), summary["Math"]["detail"]],
        ["Science", core_progress_text(summary, "Science"), summary["Science"]["detail"]],
        ["History / Social Science", core_progress_text(summary, "History"), summary["History"]["detail"]],
        ["Standard Core Check", diploma_core_text(summary, "standard"), "Standard: 4 English, 3 Math, 3 Science, 3 History/Social Science."],
        ["Advanced Core Check", diploma_core_text(summary, "advanced"), "Advanced: 4 English, 4 Math, 4 Science, 4 History/Social Science."],
        ["Credits", f'{summary["credits_completed"]:.1f} earned', f'{summary["credits_projected"]:.1f} projected with current courses'],
    ]
    course_rows = [
        [
            c["school_year"] or "",
            c["grade_level"] or "",
            c["course_title"],
            c["attributes"] or "",
            c["final_grade"] or "",
            c["earned_credits"] or c["potential_credits"] or "",
            c["status"],
        ]
        for c in courses
    ]
    return f'<section class="grid two"><div class="panel"><h2>Transcript Documents</h2>{docs}<h2>Transcript Progress</h2>{table(["Area","Progress","Courses"], summary_rows)}</div><div class="panel"><h2>Transcript Courses</h2>{table(["Year","Grade","Course","Type","Final","Credits","Status"], course_rows)}</div></section>'


def add_student_html(values=None, error=""):
    values = values or {}
    get = values.get if hasattr(values, "get") else lambda key, default="": default
    err = f'<div class="flash danger">{esc(error)}</div>' if error else ""
    return f"""
    <section class="page-head"><div><h1>Add Student Manually</h1><p>Add a student to the correct class grid before testing, transcript upload, or score upload.</p></div></section>
    <form method="post" action="/students/new" class="panel form-grid">
      {err}
      <input type="hidden" name="unmatched_id" value="{esc(get("unmatched_id", ""))}">
      <label>Student ID<input name="student_id" value="{esc(get("student_id", ""))}"></label>
      <label>First Name<input name="first_name" value="{esc(get("first_name", ""))}" required></label>
      <label>Middle Name<input name="middle_name" value="{esc(get("middle_name", ""))}"></label>
      <label>Last Name<input name="last_name" value="{esc(get("last_name", ""))}" required></label>
      <label>Planned Graduation Class<input name="graduation_class" value="{esc(get("graduation_class", ""))}" required></label>
      <label>Original Cohort<input name="original_cohort" value="{esc(get("original_cohort", get("graduation_class", "")))}" required></label>
      <label class="choice"><input type="checkbox" name="early_graduate" value="1" {"checked" if str(get("early_graduate", "")) in {"1", "true", "True"} else ""}><span><strong>Early Graduate</strong><small>Keep the original cohort while placing the student in an earlier class.</small></span></label>
      <label class="choice"><input type="checkbox" name="middle_school_eoc_taker" value="1" {"checked" if str(get("middle_school_eoc_taker", "")) in {"1", "true", "True"} else ""}><span><strong>MS EOC Test Taker</strong><small>Flag middle-school EOC participation for high-school mathematics scheduling review.</small></span></label>
      <label>Diploma Type<input name="diploma_type" value="{esc(get("diploma_type", "Standard"))}"></label>
      <label>SPED / 504<input name="sped_504_status" value="{esc(get("sped_504_status", "N"))}"></label>
      <label>Counselor<input name="counselor" value="{esc(get("counselor", ""))}"></label>
      <label class="wide">Notes<input name="notes" value="{esc(get("notes", ""))}"></label>
      <button type="submit">Add Student to Class Grid</button>
    </form>
    """


def active_grid_classes(db):
    rows = db.execute("SELECT graduation_class FROM class_grid_members GROUP BY graduation_class ORDER BY graduation_class").fetchall()
    return [int(row["graduation_class"]) for row in rows if row["graduation_class"]]


def grade_level_class_map(classes):
    labels = ["Senior", "Junior", "Sophomore", "Freshman"]
    return [(label, classes[index]) for index, label in enumerate(labels) if index < len(classes)]


def place_unmatched_record(db, record, grad_class):
    first_name = (record["first_name"] or "").strip().upper()
    middle_name = (record["middle_name"] or "").strip().upper()
    last_name = (record["last_name"] or "").strip().upper()
    student_id = (record["student_id"] or "").strip() or None
    if not first_name or not last_name:
        raise ValueError("Cannot place an unmatched row without first and last name.")

    existing = None
    if student_id:
        existing = db.execute(
            "SELECT * FROM students WHERE student_id = ? AND graduation_class = ?",
            (student_id, grad_class),
        ).fetchone()
    if existing is None:
        existing = db.execute(
            "SELECT * FROM students WHERE lower(first_name) = lower(?) AND lower(last_name) = lower(?) AND graduation_class = ?",
            (first_name, last_name, grad_class),
        ).fetchone()

    if existing:
        student_pk = existing["id"]
    else:
        db.execute(
            "INSERT INTO students(student_id, first_name, middle_name, last_name, graduation_class, diploma_type, sped_504_status, counselor, notes) VALUES (?, ?, ?, ?, ?, 'Standard', 'N', '', ?)",
            (student_id, first_name, middle_name, last_name, grad_class, "Created from Student Match Troubleshooter"),
        )
        student_pk = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    db.execute("INSERT OR IGNORE INTO class_grid_members(student_id_fk, graduation_class) VALUES (?, ?)", (student_pk, grad_class))
    return student_pk


def unmatched_records_table(db, records):
    rows = []
    classes = active_grid_classes(db)
    grade_classes = grade_level_class_map(classes)
    for record in records:
        name = " ".join(part for part in [record["first_name"], record["middle_name"], record["last_name"]] if part)
        suggestions = match_suggestions(db, record)
        suggestion_forms = []
        for student, score in suggestions:
            suggestion_forms.append(f'<form method="post" action="/troubleshooter" class="inline-form"><input type="hidden" name="action" value="link"><input type="hidden" name="unmatched_id" value="{record["id"]}"><input type="hidden" name="student_pk" value="{student["id"]}"><button type="submit">Link</button> {esc(student["last_name"])}, {esc(student["first_name"])} - Class {student["graduation_class"]} ({score:.0%})</form>')
        create_href = "/students/new?" + urllib.parse.urlencode({"unmatched_id": record["id"], "student_id": record["student_id"] or "", "first_name": record["first_name"] or "", "middle_name": record["middle_name"] or "", "last_name": record["last_name"] or "", "graduation_class": record["graduation_class"] or ""})
        grade_buttons = "".join(
            f'<form method="post" action="/troubleshooter" class="inline-form"><input type="hidden" name="action" value="place_class"><input type="hidden" name="unmatched_id" value="{record["id"]}"><input type="hidden" name="graduation_class" value="{grad_class}"><button class="secondary" type="submit">{esc(label)}</button><span class="muted small">Class of {grad_class}</span></form>'
            for label, grad_class in grade_classes
        )
        quick_actions = f"""
        <div class="troubleshooter-actions">
          <strong>Quick place</strong>
          <div class="quick-action-row">{grade_buttons or '<span class="muted small">No class grids yet.</span>'}</div>
          <form method="post" action="/troubleshooter" class="inline-form"><input type="hidden" name="action" value="graduated"><input type="hidden" name="unmatched_id" value="{record["id"]}"><button type="submit">Graduated / Remove</button></form>
        </div>
        """
        actions = "".join(suggestion_forms) + quick_actions + f'<p><a class="button secondary" href="{esc(create_href)}">Create New Student From This Row</a></p><form method="post" action="/troubleshooter" class="inline-form"><input type="hidden" name="action" value="dismiss"><input type="hidden" name="unmatched_id" value="{record["id"]}"><button type="submit">Dismiss</button></form>'
        rows.append([record["created_at"], record["record_type"], name or "(No name)", record["student_id"] or "", record["graduation_class"] or "", record["issue"], Markup(actions)])
    return table(["When","Type","Name","ID","Class","Issue","Suggested Fix"], rows)


def match_suggestions(db, record):
    candidates = db.execute("SELECT * FROM students WHERE (? = '' OR graduation_class = ?) ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE LIMIT 500", (record["graduation_class"] or "", record["graduation_class"] or "")).fetchall()
    target = normalize_match_name(record["first_name"], record["last_name"], record["student_id"])
    scored = []
    for student in candidates:
        if record["student_id"] and student["student_id"] and record["student_id"] == student["student_id"]:
            scored.append((student, 1.0))
            continue
        score = difflib.SequenceMatcher(None, target, normalize_match_name(student["first_name"], student["last_name"], student["student_id"])).ratio()
        if score >= 0.55:
            scored.append((student, score))
    return sorted(scored, key=lambda item: item[1], reverse=True)[:5]


def normalize_match_name(first, last, student_id=""):
    return re.sub(r"[^a-z0-9]+", "", f"{first or ''}{last or ''}{student_id or ''}".lower())


def transcript_summary_from_courses(courses):
    summary = {
        "English": {"standard_target": 4, "advanced_target": 4, "completed": 0, "projected": 0, "detail": ""},
        "Math": {"standard_target": 3, "advanced_target": 4, "completed": 0, "projected": 0, "detail": ""},
        "Science": {"standard_target": 3, "advanced_target": 4, "completed": 0, "projected": 0, "detail": ""},
        "History": {"standard_target": 3, "advanced_target": 4, "completed": 0, "projected": 0, "detail": ""},
        "credits_completed": 0.0,
        "credits_projected": 0.0,
    }
    details = {"English": [], "Math": [], "Science": [], "History": []}
    for course in courses:
        title = course["course_title"]
        area_key = course_area(title)
        family = {"EngRLR": "English", "EngWrit": "English", "AlgI": "Math", "Geom": "Math", "AlgII": "Math", "AFDA": "Math", "ESCI": "Science", "Bio": "Science", "Chem": "Science", "WGeo": "History", "WHI": "History", "WHII": "History", "USH": "History", "Gov": "History"}.get(area_key)
        family = family or transcript_family_from_checklist_code(checklist_course_code(title, course["attributes"], "transcript"))
        earned = float(course["earned_credits"] or 0)
        potential = float(course["potential_credits"] or 0)
        summary["credits_completed"] += earned
        summary["credits_projected"] += earned + potential
        if family:
            grade = course["final_grade"] or ("IP" if course["status"] == "Work In Progress" else "")
            label_text = f"{title} ({grade})" if grade else title
            details[family].append(label_text)
            if earned > 0 and str(course["final_grade"] or "").upper() != "F":
                summary[family]["completed"] += 1
                summary[family]["projected"] += 1
            elif potential > 0 and course["status"] == "Work In Progress":
                summary[family]["projected"] += 1
    for family, values in details.items():
        summary[family]["detail"] = "; ".join(values) if values else "No transcript courses loaded."
    return summary


def testing_windows_html(db):
    windows = db.execute(
        "SELECT * FROM testing_windows WHERE state='Virginia' ORDER BY start_date"
    ).fetchall()
    rows = [
        [
            row["window_name"], row["school_year"], row["start_date"], row["end_date"],
            row["assessment_group"], row["rule_version"], row["source_reference"] or "",
        ]
        for row in windows
    ]
    return f"""
    <section class="page-head"><div><h1>Virginia Testing Windows</h1><p>These dates assign the permanent EOC standard from a student's first valid attempt. Retests keep that locked standard.</p></div></section>
    <section class="panel warning"><strong>Current transition:</strong> tests through September 30, 2026 use the 2025-26 standard. The 2026-27 assignment window begins October 1, 2026. Each later school-year window also runs October 1 through September 30. Editing a window affects future recalculation and is recorded in the audit log.</section>
    <section class="panel">{table(["Window","School Year","Start","End","Group","Rule","Source"], rows)}</section>
    <form method="post" action="/admin/testing-windows" class="panel form-grid">
      <h2>Add or Update a Testing Window</h2>
      <label>Window ID<input name="id" placeholder="va-eoc-sy-2027-2028" required></label>
      <label>Window Name<input name="window_name" required></label>
      <label>School Year<input name="school_year" placeholder="2027-2028" required></label>
      <label>Start Date<input type="date" name="start_date" required></label>
      <label>End Date<input type="date" name="end_date" required></label>
      <label>Assessment Group<select name="assessment_group"><option>EOC</option><option>EOC Math</option><option>EOC Reading</option></select></label>
      <label>Rule Version<input name="rule_version" placeholder="2027-2028" required></label>
      <label>Official Source / Note<textarea name="source_reference" required></textarea></label>
      <button type="submit">Save Testing Window</button>
    </form>
    """


def eoc_phase_in_card(rules):
    if not rules:
        return ""
    names = {"AlgI": "Algebra I", "Geom": "Geometry", "AlgII": "Algebra II", "EngRLR": "EOC Reading"}
    rows = []
    for rule in rules:
        threshold = int(rule["locked_passing_score"]) if rule["locked_passing_score"] is not None else "Review"
        floor = int(rule["locked_lavc_floor"]) if rule["locked_lavc_floor"] is not None else "Review"
        detail = rule["review_reason"] or (
            f'First valid attempt {rule["initial_attempt_date"]}; standard locked from '
            f'{rule["initial_attempt_school_year"]}; {rule["assignment_method"]}.'
        )
        rows.append([
            names.get(rule["normalized_subject"], rule["normalized_subject"]),
            rule["initial_attempt_date"] or "Review required",
            threshold,
            floor,
            rule["highest_valid_score"] if rule["highest_valid_score"] is not None else "",
            rule["current_performance_level"] or rule["current_pass_status"] or "",
            rule["lavc_eligibility_status"] or "",
            detail,
        ])
    return f'<section class="panel"><h2>Virginia EOC Phase-In</h2><p class="muted">The passing standard is based on the first valid attempt and remains locked for retests.</p>{table(["Subject","Initial Attempt","Pass Score","LAVC Floor","Highest","Level","LAVC Review","Rule Detail"], rows)}</section>'


def three_e_cell(readiness):
    detail_rows = [
        ["Enrollment", f'{readiness["enrollment"]["points"]:.2f}', readiness["enrollment"]["evidence"] or "No evidence"],
        ["Employment", f'{readiness["employment"]["points"]:.2f}', readiness["employment"]["evidence"] or "No evidence"],
        ["Enlistment", f'{readiness["enlistment"]["points"]:.2f}', readiness["enlistment"]["evidence"] or "No ASVAB score"],
        ["Total", f'{readiness["total_points"]:.2f}', readiness["status"]],
        ["Updated", "", readiness["last_updated"] or "No dated evidence"],
    ]
    return Markup(f'<details class="three-e-detail"><summary class="three-e-cell three-e-{esc(readiness["color"])}" title="{esc(three_e_hover(readiness))}">{esc(readiness["summary"])}</summary>{table(["Pathway", "Points", "Evidence"], detail_rows, "mini-table")}</details>')


def employment_credential_cell(status_row, attempts):
    if not status_row:
        return Markup('<span class="sol-score-badge sol-not">Missing</span>')
    value = status_row["display_value"] or ("Passed" if status_row["status"] == "Met" else "Missing")
    if "NCRC" in value.upper():
        value = "NCRC"
    style = "sol-pass" if status_row["status"] == "Met" else "sol-not"
    evidence = []
    for attempt in attempts:
        text = f'{attempt["test_area"] or ""} {attempt["test_name"] or ""} {attempt["credential_name"] or ""} {attempt["raw_score"] or ""}'.lower()
        if any(token in text for token in ("credential", "w!se", "wise", "wpr", "workplace readiness", "ncrc", "graphic literacy", "applied math")):
            evidence.append([attempt["test_date"] or "", attempt["credential_name"] or attempt["test_name"] or attempt["test_area"], attempt["raw_score"] or attempt["score"] or "", attempt["pass_fail"] or ""])
    if not evidence:
        return Markup(f'<span class="sol-score-badge {style}">{esc(value)}</span>')
    return Markup(f'<details class="sol-score-detail {style}" title="Click to view stored credential evidence"><summary>{esc(value)}</summary><div>{table(["Date", "Credential", "Score", "Status"], evidence, "mini-table")}</div></details>')


def completion_status_cell(status_row):
    met = bool(status_row and status_row["status"] == "Met")
    return Markup(f'<span class="sol-score-badge {"sol-pass" if met else "sol-not"}">{"Yes" if met else "No"}</span>')


def three_e_card(readiness):
    rows = [
        ["Enrollment", f'{readiness["enrollment"]["points"]:.2f}', readiness["enrollment"]["evidence"] or "No evidence"],
        ["Employment", f'{readiness["employment"]["points"]:.2f}', readiness["employment"]["evidence"] or "No evidence"],
        ["Enlistment", f'{readiness["enlistment"]["points"]:.2f}', readiness["enlistment"]["evidence"] or "No ASVAB score"],
        ["Total 3E Points", f'{readiness["total_points"]:.2f}', readiness["summary"]],
        ["Highest Pathway", readiness["highest_pathway"] or "None", readiness["status"]],
        ["Recommended Next Opportunity", "", readiness["recommended_action"]],
    ]
    return f'<section class="panel three-e-card"><h2>3E Readiness</h2>{table(["Pathway","Score","Evidence / Next Step"], rows)}</section>'


def three_e_report_table(rows):
    headers = ["Last Name", "First Name", "Student ID", "Class", "Counselor", "Diploma", "3E Summary", "Total", "Highest", "Status", "Enrollment", "Employment", "Enlistment", "Recommended Action"]
    body = []
    for item in rows:
        student = item["student"]
        readiness = item["readiness"]
        body.append([
            link(esc(student["last_name"]), f'/students/{student["id"]}'),
            student["first_name"],
            student["student_id"] or "",
            student["graduation_class"],
            student["counselor"] or "",
            student["diploma_type"] or "",
            readiness["summary"],
            f'{readiness["total_points"]:.2f}',
            readiness["highest_pathway"] or "",
            readiness["status"],
            readiness["enrollment"]["evidence"] or "",
            readiness["employment"]["evidence"] or "",
            readiness["enlistment"]["evidence"] or "",
            readiness["recommended_action"],
        ])
    return table(headers, body, "grid-table")


def core_progress_text(summary, family):
    item = summary[family]
    return f'{item["completed"]} completed / {item["projected"]} projected; Standard needs {item["standard_target"]}, Advanced needs {item["advanced_target"]}'


def diploma_core_text(summary, diploma):
    key = "advanced_target" if diploma == "advanced" else "standard_target"
    missing = []
    projected_missing = []
    for family in ["English", "Math", "Science", "History"]:
        target = summary[family][key]
        completed = summary[family]["completed"]
        projected = summary[family]["projected"]
        if completed < target:
            missing.append(f"{family} {completed}/{target}")
        if projected < target:
            projected_missing.append(f"{family} projected {projected}/{target}")
    if not missing:
        return "Met with completed transcript credits."
    if not projected_missing:
        return "On track with current courses; completed so far: " + ", ".join(missing)
    return "Needs review: " + ", ".join(projected_missing)


def settings_html():
    return '<section class="page-head"><div><h1>Settings / Column Mapping</h1><p>During upload, each field can be matched to any source column.</p></div></section><section class="panel">' + table(["System Field", "Recognized Examples"], [[label(k), ", ".join(v)] for k, v in CANONICAL_FIELDS.items()]) + "</section>"


def security_admin_html():
    return """
    <section class="page-head"><div><h1>Safety, Privacy, and Security</h1><p>Deployment reminders for the local Graduation Intelligence Center installation.</p></div></section>
    <section class="panel"><h2>Current application safeguards</h2><p>Authentication, role-based access, session expiration, CSRF protection, validated local uploads, audit logging, and integrity-checked SQLite backups are built into the active local server.</p></section>
    <section class="panel"><h2>School and division responsibilities</h2><p>District IT must secure the host, data folders, network, backups, operating system, endpoint protection, user approvals, retention, and incident response. Configure HTTPS before transmitting student records over a network that is not otherwise adequately protected.</p></section>
    <section class="panel"><h2>Documentation</h2><p>See <code>docs/security_and_privacy</code> in the installation package for the security overview, deployment checklist, data handling guide, incident response guide, architecture, vendor questionnaire, SBOM, and test results.</p></section>
    <section class="panel warning"><strong>Important:</strong> the application is not represented as FERPA certified, and no installation can be guaranteed completely secure. Approval for real student data remains with the school or division.</section>
    """


def split_url(url):
    parsed = urllib.parse.urlparse(url)
    return parsed.path, urllib.parse.parse_qs(parsed.query)


def log_exception(exc):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    with open(LOG_DIR / "error.log", "a", encoding="utf-8") as handle:
        handle.write(f"\n--- {type(exc).__name__}: {exc} ---\n")
        handle.write(traceback.format_exc())


def table(headers, rows, cls=""):
    rows = rows or []
    head = "".join(f"<th>{esc(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{cell if isinstance(cell, Markup) else esc(cell)}</td>" for cell in row) + "</tr>" for row in rows)
    if not body:
        body = f'<tr><td colspan="{len(headers)}">No records found.</td></tr>'
    return f'<table class="{cls}"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>'


class Markup(str):
    pass


def link(text, href):
    return Markup(f'<a href="{esc(href)}">{text}</a>')


def label(value):
    return str(value).replace("_", " ").title()


def esc(value):
    return (str(value) if value is not None else "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def student_cohort_label(student):
    cohort = student["original_cohort"] if "original_cohort" in student.keys() else student["graduation_class"]
    tags = []
    if "early_graduate" in student.keys() and student["early_graduate"]:
        tags.append('<span class="tag">Early Graduate</span>')
    if "middle_school_eoc_taker" in student.keys() and student["middle_school_eoc_taker"]:
        tags.append('<span class="tag">MS EOC Test Taker</span>')
    return Markup(f'{" ".join(tags)} Original Cohort {esc(cohort)}')


def student_grid_name(student):
    name = link(f'{esc(student["last_name"])}, {esc(student["first_name"])}', f'/students/{student["id"]}')
    tags = []
    if "early_graduate" in student.keys() and student["early_graduate"]:
        tags.append('<span class="tag">Early Graduate</span>')
    if "middle_school_eoc_taker" in student.keys() and student["middle_school_eoc_taker"]:
        tags.append('<span class="tag">MS EOC Test Taker</span>')
    if tags:
        cohort = student["original_cohort"] or student["graduation_class"]
        return Markup(f'{name}<br>{" ".join(tags)}<small class="muted"> Original Cohort {esc(cohort)}</small>')
    return name


def status_map(db, student_ids):
    if not student_ids:
        return {}
    placeholders = ",".join("?" for _ in student_ids)
    rows = db.execute(f"SELECT * FROM requirement_status WHERE student_id_fk IN ({placeholders})", student_ids).fetchall()
    data = {}
    for row in rows:
        data.setdefault(row["student_id_fk"], {})[row["requirement_key"]] = row
    return data


def attempts_map(db, student_ids):
    if not student_ids:
        return {}
    placeholders = ",".join("?" for _ in student_ids)
    rows = db.execute(f"SELECT * FROM test_attempts WHERE student_id_fk IN ({placeholders}) ORDER BY test_date DESC, created_at DESC", student_ids).fetchall()
    data = {}
    for row in rows:
        data.setdefault(row["student_id_fk"], []).append(row)
    return data


def status_pick(statuses, keys, field="display_value"):
    for key in keys:
        row = statuses.get(key)
        if row and row[field]:
            return row[field]
    return ""


SOL_STATUS_KEYS = {"ESCI", "Bio", "Chem", "AlgI", "Geom", "AlgII", "EngRLR", "EngWrit", "WGeo", "WHI", "WHII", "USH"}
SOL_AREA_LABELS = {
    "ESCI": "Earth Science", "Bio": "Biology", "Chem": "Chemistry",
    "AlgI": "Algebra I", "Geom": "Geometry", "AlgII": "Algebra II",
    "EngRLR": "EOC Reading", "EngWrit": "EOC Writing",
    "WGeo": "World Geography", "WHI": "World History I",
    "WHII": "World History II", "USH": "US History",
}


def status_pick_cell(statuses, keys, attempts):
    choices = [statuses.get(key) for key in keys if statuses.get(key)]
    choices = [row for row in choices if row["display_value"] or row["status"]]
    if not choices:
        return ""
    row = sorted(choices, key=status_display_rank, reverse=True)[0]
    value = row["display_value"] or row["status"] or ""
    if len(keys) > 1:
        return subject_family_detail_cell(keys, value, attempts, row)
    return score_detail_cell(row["requirement_key"], value, attempts, row)


def subject_family_detail_cell(area_keys, value, attempts, status_row=None):
    groups = grouped_sol_attempts(area_keys, attempts)
    style = sol_score_class(value, status_row)
    if not groups:
        return Markup(f'<span class="sol-score-badge {style}">{esc(value)}</span>') if value else ""
    sections = []
    hover_lines = []
    for area_key in area_keys:
        rows = groups.get(area_key, [])
        if not rows:
            continue
        area_name = SOL_AREA_LABELS.get(area_key, area_key)
        sections.append(f'<section class="attempt-group"><h4>{esc(area_name)}</h4>{table(["Date", "Test", "Score", "Status", "Course"], rows, "mini-table")}</section>')
        hover_lines.append(area_name + ": " + "; ".join(f"{row[0]} {row[2]} {row[3]}".strip() for row in rows))
    return Markup(f'<details class="sol-score-detail {style}" title="{esc(chr(10).join(hover_lines))}"><summary>{esc(value)}</summary><div>{"".join(sections)}</div></details>')


def status_value_cell(row, attempts):
    value = row["display_value"] or ""
    if row["requirement_key"] in SOL_STATUS_KEYS and value:
        return score_detail_cell(row["requirement_key"], value, attempts, row)
    return value


def status_display_rank(row):
    status = row["status"] or ""
    value = row["display_value"] or ""
    has_score = bool(re.search(r"\d", value)) or "PBA" in value.upper()
    score = row["score"] if "score" in row.keys() and row["score"] is not None else -1
    if status in {"Met", "Met by LVC"} and has_score:
        return (50, score)
    if status in {"Met", "Met by LVC"}:
        return (45, score)
    if status == "Not Met" and has_score:
        return (30, score)
    if status == "Missing" and value:
        return (20, score)
    if status == "Not Needed":
        return (5, score)
    return (1, score)


def score_detail_cell(area_key, value, attempts, status_row=None):
    if area_key not in SOL_STATUS_KEYS:
        return value
    history = sol_attempt_history(area_key, attempts, require_multiple=False)
    style = sol_score_class(value, status_row)
    if not history or not value or "Verified credit met in subject area" in value:
        return Markup(f'<span class="sol-score-badge {style}">{esc(value)}</span>') if value else ""
    hover = sol_attempt_hover(area_key, attempts)
    return Markup(f'<details class="sol-score-detail {style}" title="{esc(hover)}"><summary>{esc(value)}</summary><div>{history}</div></details>')


def sol_score_class(value, status_row=None):
    text = str(value or "")
    status = status_row["status"] if status_row else ""
    if status == "Not Met":
        return "sol-not"
    if "PBA" in text.upper() or status in {"Met", "Met by LVC"}:
        return "sol-pass"
    if "WD" in text.upper() or "WPD" in text.upper() or "BLW" in text.upper() or "BUSINESS" in text.upper():
        return "sol-sub"
    if "Verified credit met in subject area" in text:
        return "sol-info"
    return "sol-info"


def graduation_needs(statuses):
    checks = [
        ("Math verified credit", ["AlgI", "Geom", "AlgII"], "One math verified credit is needed."),
        ("Algebra I participation", ["Algebra I Taken"], "Student must have taken Algebra I."),
        ("Science verified credit", ["ESCI", "Bio", "Chem"], "One science verified credit is needed."),
        ("Biology participation", ["Biology Taken"], "Student must have taken Biology."),
        ("History verified credit", ["WGeo", "WHI", "WHII", "USH"], "One history verified credit or passing PBA result is needed."),
        ("English Reading", ["EngRLR"], "Reading SOL or approved substitute is needed."),
        ("English Reading participation", ["English Reading Taken"], "Student must have taken English Reading."),
        ("English Writing", ["EngWrit"], "Writing SOL or Business Letter Writing score of 3+ is needed."),
        ("CPR/AED", ["CPR/AED Complete"], "CPR/AED completion is needed."),
        ("Pathway / Credential Evidence", ["CCRI"], "AP, Honors, IB, Dual Enrollment, work-based learning, or approved credential pathway evidence is needed."),
        ("Credential", ["Credential Test", "NCRC", "Workplace Readiness"], "Credential test, NCRC, or Workplace Readiness credential is needed if using credential as pathway."),
    ]
    needs = []
    for label_text, keys, message in checks:
        if not any(statuses.get(key) and statuses[key]["status"] in {"Met", "Met by LVC"} for key in keys):
            needs.append([label_text, message])
    retakes = [f'{key}: {row["display_value"] or row["status"]}' for key, row in statuses.items() if row["needs_retest"]]
    if retakes:
        needs.append(["Retake window", "; ".join(retakes)])
    return needs


def agreement_data(db, student_id):
    student = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    statuses = {row["requirement_key"]: row for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ?", (student_id,)).fetchall()}
    courses = db.execute("SELECT * FROM transcript_courses WHERE student_id_fk = ?", (student_id,)).fetchall()
    rows = agreement_rows(student, statuses, courses)
    supports = agreement_supports(statuses, rows)
    return student, rows, supports


def status_met(statuses, keys):
    return any(statuses.get(key) and statuses[key]["status"] in {"Met", "Met by LVC", "Not Needed"} for key in keys)


def status_note(statuses, keys, missing_note):
    used = [f'{key}: {statuses[key]["display_value"] or statuses[key]["status"]}' for key in keys if statuses.get(key) and statuses[key]["status"] in {"Met", "Met by LVC"}]
    missing = [key for key in keys if not statuses.get(key) or statuses[key]["status"] not in {"Met", "Met by LVC", "Not Needed"}]
    if used and missing:
        return f'{"; ".join(used)}. Still needed: {missing_note}'
    if used:
        return "; ".join(used)
    return missing_note if missing else "Requirement satisfied."


def status_any_note(statuses, keys, missing_note):
    used = [
        f'{key}: {statuses[key]["display_value"] or statuses[key]["status"]}'
        for key in keys
        if statuses.get(key) and statuses[key]["status"] in {"Met", "Met by LVC", "Not Needed"}
    ]
    return "; ".join(used) if used else missing_note


def agreement_rows(student, statuses, courses=None):
    english_met = status_met(statuses, ["EngRLR"]) and status_met(statuses, ["EngWrit"])
    credential_keys = ["Credential Test", "NCRC", "Workplace Readiness"]
    diploma = (student["diploma_type"] or "Standard").lower()
    required_credits = 26 if "advanced" in diploma else 22
    credit_met = "No"
    advanced_note = "Verify AP, Honors, IB, Dual Enrollment, work-based learning, or CTE credential pathway."
    if courses:
        summary = transcript_summary_from_courses(courses)
        credit_met = "Yes" if summary["credits_completed"] >= required_credits else "No"
        advanced_note = advanced_studies_note(courses, statuses)
        credit_note = f'{summary["credits_completed"]:.1f} earned; {summary["credits_projected"]:.1f} projected with current courses; {required_credits} required. Standard core: {diploma_core_text(summary, "standard")} Advanced core: {diploma_core_text(summary, "advanced")} {advanced_note}'
    else:
        credit_note = f"Transcript not uploaded yet. Verify {required_credits} standard credits for this diploma. {advanced_note}"
    return [
        {"requirement": "English Verified Credit (2)", "met": "Yes" if english_met else "No", "notes": status_note(statuses, ["EngRLR", "EngWrit"], "Needs Reading and/or Writing verified credit. Reading substitute: Workplace Docs 4+. Writing substitute: Business Letter Writing 3+ or eligible LVC.")},
        {"requirement": "Math Verified Credit (1)", "met": "Yes" if status_met(statuses, ["AlgI", "Geom", "AlgII"]) else "No", "notes": status_any_note(statuses, ["AlgI", "Geom", "AlgII"], "Needs one math verified credit; Algebra I participation is separately tracked.")},
        {"requirement": "Science Verified Credit (1)", "met": "Yes" if status_met(statuses, ["ESCI", "Bio", "Chem"]) else "No", "notes": status_any_note(statuses, ["ESCI", "Bio", "Chem"], "Needs one science verified credit; Biology participation is separately tracked. If no science verified credit, review Science Workaround / two credential-test option.")},
        {"requirement": "History Verified Credit (1)", "met": "Yes" if status_met(statuses, ["WGeo", "WHI", "WHII", "USH"]) else "No", "notes": status_any_note(statuses, ["WGeo", "WHI", "WHII", "USH"], "Needs one history verified credit or passing History PBA result.")},
        {"requirement": "CTE Credential / Pathway Requirement", "met": "Yes" if status_met(statuses, ["CCRI"]) or status_met(statuses, credential_keys) else "No", "notes": status_any_note(statuses, ["CCRI"] + credential_keys, "Needs AP, Honors, IB, Dual Enrollment, work-based learning, or approved credential pathway evidence.")},
        {"requirement": "CPR/AED", "met": "Yes" if status_met(statuses, ["CPR/AED Complete"]) else "No", "notes": status_note(statuses, ["CPR/AED Complete"], "CPR/AED completion needed.")},
        {"requirement": "Virtual Course", "met": "Yes" if status_met(statuses, ["Virtual Course Complete"]) else "No", "notes": status_note(statuses, ["Virtual Course Complete"], "Virtual course completion needs verification.")},
        {"requirement": "Student Service Learning Project", "met": "Yes" if status_met(statuses, ["Student Service Learning Project Complete"]) else "No", "notes": status_note(statuses, ["Student Service Learning Project Complete"], "Service learning project needs verification.")},
        {"requirement": "Credit Total: Standard 22 / Advanced 26", "met": credit_met, "notes": credit_note},
        {"requirement": "Attendance Requirement", "met": "No", "notes": "Verify attendance expectations manually."},
        {"requirement": "Financial / Discipline Obligations", "met": "No", "notes": "Verify financial and discipline obligations manually."},
    ]


def agreement_supports(statuses, rows):
    missing = {row["requirement"] for row in rows if row["met"] == "No"}
    missing_reading = not status_met(statuses, ["EngRLR"])
    missing_writing = not status_met(statuses, ["EngWrit"])
    missing_math = not status_met(statuses, ["AlgI", "Geom", "AlgII"])
    missing_science = not status_met(statuses, ["ESCI", "Bio", "Chem"])
    missing_history = not status_met(statuses, ["WGeo", "WHI", "WHII", "USH"])
    risk_count = sum([missing_reading, missing_writing, missing_math, missing_science, missing_history, len(missing) >= 4])
    options = [
        ("Reading Success", missing_reading),
        ("Writing Success", missing_writing),
        ("Math Success", missing_math),
        ("Science Success", missing_science),
        ("Substitute Test Opportunity: Workplace Docs", missing_reading),
        ("Substitute Test Opportunity: Business Letter Writing", missing_writing),
        ("Substitute Test Opportunity: History PBA", missing_history),
        ("Science Workaround Review", missing_science),
        ("Passed 2 Credential Tests", missing_science or "CTE Credential / Pathway Requirement" in missing),
        ("Graduation Team Monitoring: Yes", risk_count >= 2),
        ("Graduation Team Monitoring: No", risk_count < 2),
    ]
    return [{"label": label_text, "checked": checked} for label_text, checked in options]


def advanced_studies_note(courses, statuses):
    advanced_courses = []
    for course in courses:
        attrs = (course["attributes"] or "").upper().split()
        title = course["course_title"] or ""
        title_lower = title.lower()
        if any(attr in {"H", "DE", "AP", "IB"} for attr in attrs) or any(term in title_lower for term in ["honors", "dual enrollment", "advanced placement", " ap ", " ib "]):
            grade = course["final_grade"] or ("IP" if course["status"] == "Work In Progress" else "")
            advanced_courses.append(f"{title} ({grade})" if grade else title)
    credential_met = status_met(statuses, ["Credential Test", "Workplace Readiness", "CCRI", "NCRC", "ASVAB"])
    if advanced_courses:
        sample = "; ".join(advanced_courses[:4])
        more = "..." if len(advanced_courses) > 4 else ""
        return f"Advanced pathway evidence found: {sample}{more}"
    if credential_met:
        return "Advanced pathway may be met through credential or pathway evidence."
    return "No AP/Honors/IB/Dual Enrollment or credential pathway evidence loaded yet."


def agreement_print_section(student, rows, supports, school="School"):
    return f"""
    <section class="agreement-page print-break">
      <h1>{esc(school)} - Class of {student['graduation_class']} Graduation Agreement</h1>
      <div class="agreement-meta">
        <p><strong>Student Name:</strong> {esc(student['first_name'])} {esc(student['last_name'])}</p>
        <p><strong>Graduation Class:</strong> {student['graduation_class']}</p>
        <p><strong>Diploma Type:</strong> {esc(student['diploma_type'] or '')}</p>
        <p><strong>Counselor:</strong> {esc(student['counselor'] or '')}</p>
        <p><strong>Date Generated:</strong> {datetime.now().strftime('%Y-%m-%d')}</p>
      </div>
      <h2>Dear Senior and Parent/Guardian,</h2>
      <p>Graduation is one of life's great milestones, and we are proud to partner with you in reaching this important goal. To participate in graduation ceremonies, students must meet all Virginia Department of Education requirements for their diploma type.</p>
      <h2>Current Graduation Status</h2>
      {table(['Requirement','Met?','Notes'], [[r['requirement'], r['met'], r['notes']] for r in rows])}
      <h2>Student Success Support Plan: Check all that apply.</h2>
      <div class="support-grid">{''.join(f'<label><span class="box">{"X" if item["checked"] else ""}</span>{esc(item["label"])}</label>' for item in supports)}</div>
      <h2>Course Completion: Senior Year Impact</h2>
      <p>Even if a student earns all verified credits, the student must still pass all state-required courses in order to graduate, including English 12 and U.S. Government for seniors.</p>
      <h2>Acknowledgment</h2>
      <div class="signature-grid"><p>Student Signature / Date</p><p>Parent/Guardian Signature / Date</p><p>Counselor/Admin Signature / Date</p></div>
    </section>
    """


def custom_agreement_section(model, school="School", toolbar=False):
    student = model["student"]
    actions = f'''<div class="report-toolbar actions"><button onclick="window.print()">Print</button><a class="button secondary" href="/students/{student['id']}/agreement.pdf">Export as PDF</a><form method="post" action="/students/{student['id']}/agreement/save"><button type="submit">Save copy to student record</button></form></div>''' if toolbar else ""
    signatures = "".join(f"<p>{esc(line)} / Date</p>" for line in model["signature_lines"])
    return f'''<section class="agreement-page print-break">{actions}<h1>{esc(school)} - {esc(model['title'])}</h1><div class="agreement-meta"><p><strong>Student Name:</strong> {esc(student['first_name'])} {esc(student['last_name'])}</p><p><strong>Graduation Class:</strong> {student['graduation_class']}</p><p><strong>Diploma Type:</strong> {esc(student['diploma_type'] or '')}</p><p><strong>Counselor:</strong> {esc(student['counselor'] or '')}</p><p><strong>Date Generated:</strong> {datetime.now().strftime('%Y-%m-%d')}</p></div><p>{esc(model['intro_text'])}</p><p class="muted">Active rules: {esc(model['package_name'])} {esc(model['package_version'])}</p><h2>Current Graduation Status</h2>{table(['Requirement','Met?','Notes'], [[row['requirement'], row['met'], row['notes']] for row in model['rows']])}<h2>Support Plan</h2><div class="support-grid">{''.join(f'<label><span class="box">{"X" if item["checked"] else ""}</span>{esc(item["label"])}</label>' for item in model['supports']) or '<p>No support options configured.</p>'}</div><h2>Course Completion</h2><p>{esc(model['course_completion_text'])}</p><h2>Acknowledgment</h2><div class="signature-grid">{signatures}</div><p class="muted">{esc(model['footer'])}</p></section>'''


CHECKLIST_COURSES = {
    "English": [
        "English 9", "English 9 Honors", "English 10", "English 10 Honors", "English 11", "English 11 Honors",
        "English 12", "English 12 Honors", "DE English 111/112", "DE English 245/246", "Applied English 9",
        "Applied English 10", "Applied English 11", "Applied English 12",
    ],
    "Social Studies": [
        "World Geography", "World History I", "World History I Honors", "World History II", "World History II Honors",
        "US History", "US History Honors", "DE HIS 121/122", "US Government", "US Government Honors",
        "DE Pol. Science 135/136", "Applied Social Studies 9", "Applied Social Studies 10",
        "Applied Social Studies 11", "Applied Social Studies 12",
    ],
    "Mathematics": [
        "Algebra I", "Algebra I Honors", "AFDA", "Geometry", "Geometry Honors", "Algebra II",
        "Algebra II Honors", "Adv. Algebra/Trig", "Pre-Calculus", "Calculus", "Probability & Stats.",
        "DE Pre-Calculus", "DE Calculus", "DE Statistics", "Data Science", "Applied Math 9",
        "Applied Math 10", "Applied Math 11", "Applied Math 12",
    ],
    "Science": [
        "Earth Science", "Earth Science Honors", "Environmental Science", "Biology", "Biology Honors",
        "Chemistry", "Earth Science II: Astronomy", "Physics", "Biology II: Ecology",
        "Biology II: Anatomy & Phys.", "Applied Science 9", "Applied Science 10", "Applied Science 11",
        "Applied Science 12", "DE Bio 101/102", "DE CHEM 111/112", "DE PHY 201/202",
    ],
    "Health and PE": ["HPE 9", "HPE 10", "Personal Fitness", "Adv. PE", "Adv. PE Weightlifting"],
    "Foreign Language": ["Spanish I", "Spanish II", "Spanish III", "Spanish IV", "Other"],
    "Other Requirements": ["Economics & Pers. Finance"],
}


CHECKLIST_SOL_KEYS = [
    ("English Reading", "EngRLR"),
    ("English Writing", "EngWrit"),
    ("Algebra I", "AlgI"),
    ("Geometry", "Geom"),
    ("Algebra II", "AlgII"),
    ("Earth Sci.", "ESCI"),
    ("Biology", "Bio"),
    ("Chemistry", "Chem"),
    ("World Geog.", "WGeo"),
    ("World Hist. I", "WHI"),
    ("World Hist. II", "WHII"),
    ("US History", "USH"),
]


def credit_sol_checklist_section(student, statuses, courses, attempts):
    summary = transcript_summary_from_courses(courses)
    standard = ""
    advanced = ""
    entered_9th = int(student["graduation_class"]) - 4 if student["graduation_class"] else ""
    credential = status_pick(statuses, ["Credential Test", "NCRC", "Workplace Readiness"]) or ""
    virtual = status_pick(statuses, ["Virtual Course Complete"], "status")
    if (not virtual or virtual == "Missing") and course_mark("Economics & Pers. Finance", courses):
        virtual = "Met - Econ & Personal Finance"
    course_credit = f'{summary["credits_completed"]:.1f} earned / {summary["credits_projected"]:.1f} projected'
    sol_needed = graduation_needs(statuses)
    sol_needed_text = "; ".join(item[0] for item in sol_needed if "verified" in item[0].lower() or "English" in item[0] or "Retake" in item[0]) or "None shown from current records."
    body = f"""
    <section class="credit-sol-checklist print-break">
      <h1>Credit and SOL Checklist</h1>
      <div class="checklist-meta">
        <p><strong>Student Name:</strong> {esc(student['last_name'])}, {esc(student['first_name'])} {esc(student['middle_name'] or '')}</p>
        <p><strong>Year Entered 9th Grade:</strong> {entered_9th}</p>
        <p><strong>Counselor:</strong> {esc(student['counselor'] or '')}</p>
        <p><strong>Graduation Class:</strong> {student['graduation_class']}</p>
      </div>
      <div class="checklist-line"><span>{standard}</span> Standard Diploma (22 course credits, 5 verified credits, credential/pathway evidence)</div>
      <div class="checklist-line"><span>{advanced}</span> Advanced Diploma (26 course credits, 5 verified credits, credential/pathway evidence)</div>
      <div class="checklist-line"><span></span> Other Diploma, Case Manager ________________________________________</div>
      <div class="checklist-meta">
        <p><strong>Course Credits Completed:</strong> {esc(course_credit)}</p>
        <p><strong>GPA:</strong> __________</p>
        <p><strong>Virtual Class:</strong> {esc(virtual or '')}</p>
        <p><strong>CTE Credentialing Test:</strong> {esc(credential)}</p>
      </div>
      <div class="checklist-course-grid">
        {''.join(checklist_course_column(title, names, courses) for title, names in CHECKLIST_COURSES.items())}
      </div>
      <h2>Verified Credits and Score</h2>
      <div class="checklist-sol-grid">
        {''.join(checklist_sol_item(label_text, key, statuses) for label_text, key in CHECKLIST_SOL_KEYS)}
      </div>
      <p><strong>SOLs Needed:</strong> {esc(sol_needed_text)}</p>
    </section>
    """
    return body


def checklist_course_column(title, names, courses):
    items = "".join(f'<div class="checklist-line"><span>{course_mark(name, courses)}</span>{esc(name)}</div>' for name in names)
    return f'<div><h2>{esc(title)}</h2>{items}</div>'


def checklist_sol_item(label_text, key, statuses):
    row = statuses.get(key)
    met = row and row["status"] in {"Met", "Met by LVC", "Not Needed"}
    value = row["display_value"] if row else ""
    score = f'<em>{esc(value or "")}</em>'
    return f'<div class="checklist-line sol-checkline"><span>{"X" if met else ""}</span>{esc(label_text)} {score}</div>'


def sol_attempt_history(area_key, attempts, require_multiple=True):
    seen = set()
    rows = []
    for attempt in attempts:
        if normalize_area(attempt["test_area"], attempt["test_name"]) != area_key:
            continue
        if not _valid_sol_attempt(area_key, attempt):
            continue
        score_text = attempt_score_text(attempt)
        identity = (score_text, attempt["test_date"] or "", attempt["test_name"] or "", attempt["test_area"] or "")
        if identity in seen:
            continue
        seen.add(identity)
        rows.append([
            attempt["test_date"] or attempt["created_at"] or "",
            attempt["test_name"] or attempt["test_area"] or "",
            score_text,
            attempt["pass_fail"] or "",
            attempt["course"] or "",
        ])
    if require_multiple and len(rows) <= 1:
        return ""
    if not rows:
        return ""
    return table(["Date", "Test", "Score", "Status", "Course"], rows, "mini-table")


def grouped_sol_attempts(area_keys, attempts):
    allowed = set(area_keys)
    grouped = {key: [] for key in area_keys}
    seen = set()
    for attempt in attempts:
        area_key = normalize_area(attempt["test_area"], attempt["test_name"])
        if area_key not in allowed:
            continue
        if not _valid_sol_attempt(area_key, attempt):
            continue
        score_text = attempt_score_text(attempt)
        identity = (area_key, score_text, attempt["test_date"] or "", attempt["test_name"] or "")
        if identity in seen:
            continue
        seen.add(identity)
        grouped[area_key].append([
            attempt["test_date"] or attempt["created_at"] or "",
            attempt["test_name"] or attempt["test_area"] or "",
            score_text,
            attempt["pass_fail"] or "",
            attempt["course"] or "",
        ])
    return {key: rows for key, rows in grouped.items() if rows}


def sol_attempt_hover(area_key, attempts):
    lines = []
    for attempt in attempts:
        if normalize_area(attempt["test_area"], attempt["test_name"]) != area_key:
            continue
        if not _valid_sol_attempt(area_key, attempt):
            continue
        lines.append(" | ".join([
            str(attempt["test_date"] or attempt["created_at"] or ""),
            str(attempt["test_name"] or attempt["test_area"] or ""),
            str(attempt_score_text(attempt)),
            str(attempt["pass_fail"] or ""),
        ]))
    return "\n".join(lines)


def attempt_score_text(attempt):
    raw = (attempt["raw_score"] or "").strip()
    if raw and any(char.isalpha() for char in raw):
        text = raw
    elif attempt["score"] is None:
        text = raw
    elif float(attempt["score"]).is_integer():
        text = str(int(attempt["score"]))
    else:
        text = str(attempt["score"])
    if attempt["failed_course_indicator"] and "*" not in text:
        text += "*"
    return text


def substitute_cell(attempts, kind):
    evidence = []
    for attempt in attempts:
        raw = f"{attempt['raw_score'] or ''} {attempt['pass_fail'] or ''} {attempt['credential_name'] or ''} {attempt['test_name'] or ''} {attempt['test_area'] or ''}"
        level = substitute_level(kind, raw)
        if level is None:
            continue
        evidence.append((level, attempt))
    if not evidence:
        return ""
    level, best = sorted(evidence, key=lambda item: item[0], reverse=True)[0]
    threshold = 4 if kind == "reading" else 3
    label_text = f"WD-{int(level) if float(level).is_integer() else level}" if kind == "reading" else f"BLW-{int(level) if float(level).is_integer() else level}"
    cls = "sol-sub" if level >= threshold else "sol-not"
    rows = []
    seen = set()
    for level_value, attempt in sorted(evidence, key=lambda item: (item[1]["test_date"] or item[1]["created_at"] or ""), reverse=True):
        score_text = attempt_score_text(attempt)
        identity = (score_text, attempt["test_date"] or "", attempt["test_name"] or "", attempt["test_area"] or "")
        if identity in seen:
            continue
        seen.add(identity)
        rows.append([
            attempt["test_date"] or attempt["created_at"] or "",
            attempt["test_name"] or attempt["test_area"] or "",
            score_text,
            attempt["pass_fail"] or "",
            attempt["course"] or "",
        ])
    history = table(["Date", "Test", "Score", "Status", "Course"], rows, "mini-table")
    hover = "\n".join(" | ".join(map(str, row[:4])) for row in rows)
    return Markup(f'<details class="sol-score-detail {cls}" title="{esc(hover)}"><summary>{esc(label_text)}</summary><div>{history}</div></details>')


def substitute_level(kind, raw):
    text = str(raw or "").lower()
    if kind == "reading":
        patterns = [
            r"\b(?:wpd|wd)\s*[-:]?\s*(\d+(?:\.\d+)?)\b",
            r"\bworkplace\s+(?:docs|documents)\s*[-:]?\s*(\d+(?:\.\d+)?)\b",
            r"\b(\d+(?:\.\d+)?)\s*(?:wpd|wd|workplace\s+(?:docs|documents))\b",
        ]
    else:
        patterns = [
            r"\b(?:blw|business\s+letter(?:\s+writing)?)\s*[-:]?\s*(\d+(?:\.\d+)?)\b",
            r"\b(\d+(?:\.\d+)?)\s*(?:blw|business\s+letter(?:\s+writing)?)\b",
        ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                return None
    return None


def course_mark(name, courses):
    matched_in_progress = False
    for course in courses:
        if not course_counts_for_checklist(course):
            continue
        if checklist_course_matches(name, course):
            status = (course["status"] or "").strip().lower()
            if status in {"work in progress", "in progress", "current", "enrolled"}:
                matched_in_progress = True
                continue
            return "X"
    return "IP" if matched_in_progress else ""


def course_counts_for_checklist(course):
    grade = (course["final_grade"] or "").upper()
    if grade == "F":
        return False
    return bool(course["earned_credits"] or course["potential_credits"])


def checklist_advanced_on_track(summary, courses):
    core_ok = all(summary[family]["projected"] >= summary[family]["advanced_target"] for family in ["English", "Math", "Science", "History"])
    core_close = (
        summary["English"]["projected"] >= 4
        and summary["Math"]["projected"] >= 3
        and summary["Science"]["projected"] >= 3
        and summary["History"]["projected"] >= 3
        and sum(1 for family in ["Math", "Science", "History"] if summary[family]["projected"] >= 4) >= 1
    )
    credits_ok = summary["credits_projected"] >= 26
    language_count = sum(1 for course in courses if course_counts_for_checklist(course) and course_family_code(course) == "foreign_language")
    advanced_coursework = any(course_counts_for_checklist(course) and course_is_advanced_track(course) for course in courses)
    return credits_ok and language_count >= 2 and advanced_coursework and (core_ok or core_close)


def course_is_advanced_track(course):
    attrs = (course["attributes"] or "").upper().split()
    title = normalize_course_name(course["course_title"])
    return (
        any(attr in {"H", "DE", "AP", "IB"} for attr in attrs)
        or "honors" in title
        or title.startswith("de ")
        or "advanced placement" in title
        or "dual enrollment" in title
    )


def checklist_course_matches(label_text, course):
    target = checklist_course_code(label_text, source="checklist")
    actual = checklist_course_code(course["course_title"], attrs=course["attributes"], source="transcript")
    if target == actual:
        return True
    if target == "de_eng_111_112":
        return actual in {"de_eng_111", "de_eng_112"}
    if target == "de_eng_245_246":
        return actual in {"de_eng_245", "de_eng_246"}
    if target == "de_his_121_122":
        return actual in {"de_his_121", "de_his_122"}
    if target == "de_pol_135_136":
        return actual in {"de_pol_135", "de_pol_136"}
    if target == "de_pre_calculus":
        return actual in {"de_mth_161", "de_mth_162", "de_pre_calculus"}
    if target == "de_bio_101_102":
        return actual in {"de_bio_101", "de_bio_102"}
    if target == "de_chem_111_112":
        return actual in {"de_chem_111", "de_chem_112"}
    if target == "de_phy_201_202":
        return actual in {"de_phy_201", "de_phy_202"}
    return False


def checklist_course_code(value, attrs="", source="transcript"):
    text = str(value or "").lower()
    norm = normalize_course_name(text)
    attrs_text = str(attrs or "").upper().split()
    honors = "H" in attrs_text or "honor" in norm
    de = "DE" in attrs_text or norm.startswith("de ") or "dual enrollment" in norm
    if de:
        match = re.search(r"\beng\s*(111|112|245|246)\b", norm)
        if match:
            return f"de_eng_{match.group(1)}"
        match = re.search(r"\bhis\s*(121|122)\b", norm)
        if match:
            return f"de_his_{match.group(1)}"
        match = re.search(r"\bpol(?:itical)?(?: science)?\s*(135|136)\b", norm)
        if match:
            return f"de_pol_{match.group(1)}"
        match = re.search(r"\bbio\s*(101|102)\b", norm)
        if match:
            return f"de_bio_{match.group(1)}"
        match = re.search(r"\b(?:chem|chm)\s*(111|112)\b", norm)
        if match:
            return f"de_chem_{match.group(1)}"
        match = re.search(r"\bphy\s*(201|202)\b", norm)
        if match:
            return f"de_phy_{match.group(1)}"
        match = re.search(r"\bmth\s*(161|162)\b", norm)
        if match:
            return f"de_mth_{match.group(1)}"
        match = re.search(r"\bmth\s*245\b", norm)
        if match:
            return "de_statistics"
    explicit = {
        "english 9 honors": "english_9_honors",
        "english 9": "english_9",
        "english 10 honors": "english_10_honors",
        "english 10": "english_10",
        "english 11 honors": "english_11_honors",
        "english 11": "english_11",
        "english 12 honors": "english_12_honors",
        "english 12": "english_12",
        "applied english 9": "applied_english_9",
        "applied english 10": "applied_english_10",
        "applied english 11": "applied_english_11",
        "applied english 12": "applied_english_12",
        "de english 111 112": "de_eng_111_112",
        "de english 245 246": "de_eng_245_246",
        "economics and pers finance": "economics_personal_finance",
        "economics and personal finance": "economics_personal_finance",
        "world geography": "world_geography",
        "world history i honors": "world_history_i_honors",
        "world history i": "world_history_i",
        "world history ii honors": "world_history_ii_honors",
        "world history ii": "world_history_ii",
        "us history honors": "us_history_honors",
        "us and va history honors": "us_history_honors",
        "us history": "us_history",
        "us and va history": "us_history",
        "us government honors": "us_government_honors",
        "us government": "us_government",
        "de his 121 122": "de_his_121_122",
        "de pol science 135 136": "de_pol_135_136",
        "applied social studies 9": "applied_social_studies_9",
        "applied social studies 10": "applied_social_studies_10",
        "applied social studies 11": "applied_social_studies_11",
        "applied social studies 12": "applied_social_studies_12",
        "algebra i honors": "algebra_i_honors",
        "algebra i": "algebra_i",
        "afda": "afda",
        "geometry honors": "geometry_honors",
        "geometry": "geometry",
        "algebra ii honors": "algebra_ii_honors",
        "algebra ii": "algebra_ii",
        "adv algebra trig": "advanced_algebra_trig",
        "mathematical analysis pre calculus": "pre_calculus",
        "pre calculus": "pre_calculus",
        "calculus": "calculus",
        "probability and stats": "probability_stats",
        "de pre calculus": "de_pre_calculus",
        "de calculus": "de_calculus",
        "de statistics": "de_statistics",
        "data science": "data_science",
        "applied math 9": "applied_math_9",
        "applied math 10": "applied_math_10",
        "applied math 11": "applied_math_11",
        "applied math 12": "applied_math_12",
        "earth science honors": "earth_science_honors",
        "earth science": "earth_science",
        "environmental science": "environmental_science",
        "biology honors": "biology_honors",
        "biology": "biology",
        "chemistry": "chemistry",
        "earth science ii astronomy": "earth_science_ii_astronomy",
        "physics": "physics",
        "biology ii ecology": "biology_ii_ecology",
        "biology ii anatomy and phys": "biology_ii_anatomy",
        "applied science 9": "applied_science_9",
        "applied science 10": "applied_science_10",
        "applied science 11": "applied_science_11",
        "applied science 12": "applied_science_12",
        "de bio 101 102": "de_bio_101_102",
        "de chem 111 112": "de_chem_111_112",
        "de phy 201 202": "de_phy_201_202",
        "hpe 9": "hpe_9",
        "health and pe 9": "hpe_9",
        "hpe 10": "hpe_10",
        "health and pe 10": "hpe_10",
        "personal fitness": "personal_fitness",
        "adv pe": "advanced_pe",
        "adv pe weightlifting": "advanced_pe_weightlifting",
        "spanish i": "spanish_i",
        "spanish ii": "spanish_ii",
        "spanish iii": "spanish_iii",
        "spanish iv": "spanish_iv",
    }
    if norm in explicit:
        code = explicit[norm]
        if source == "transcript" and honors:
            if code == "english_9": return "english_9_honors"
            if code == "english_10": return "english_10_honors"
            if code == "english_11": return "english_11_honors"
            if code == "english_12": return "english_12_honors"
            if code == "world_history_i": return "world_history_i_honors"
            if code == "world_history_ii": return "world_history_ii_honors"
            if code == "us_history": return "us_history_honors"
            if code == "us_government": return "us_government_honors"
            if code == "algebra_i": return "algebra_i_honors"
            if code == "geometry": return "geometry_honors"
            if code == "algebra_ii": return "algebra_ii_honors"
            if code == "earth_science": return "earth_science_honors"
            if code == "biology": return "biology_honors"
        return code
    return norm.replace(" ", "_")


def normalize_course_name(value):
    text = str(value or "").lower()
    text = text.replace("&", " and ").replace("/", " ")
    text = text.replace(".", "").replace(":", " ")
    text = re.sub(r"\bde\b", "de", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def course_family_code(course):
    code = checklist_course_code(course["course_title"], attrs=course["attributes"], source="transcript")
    if code.startswith("spanish_"):
        return "foreign_language"
    return ""


def transcript_family_from_checklist_code(code):
    if code.startswith(("english_", "applied_english_", "de_eng_")):
        return "English"
    if code in {"algebra_i", "algebra_i_honors", "afda", "geometry", "geometry_honors", "algebra_ii", "algebra_ii_honors", "advanced_algebra_trig", "pre_calculus", "calculus", "probability_stats", "de_pre_calculus", "de_calculus", "de_statistics", "de_mth_161", "de_mth_162", "data_science"} or code.startswith("applied_math_"):
        return "Math"
    if code in {"earth_science", "earth_science_honors", "environmental_science", "biology", "biology_honors", "chemistry", "earth_science_ii_astronomy", "physics", "biology_ii_ecology", "biology_ii_anatomy", "de_bio_101", "de_bio_102", "de_chem_111", "de_chem_112", "de_phy_201", "de_phy_202"} or code.startswith("applied_science_"):
        return "Science"
    if code in {"world_geography", "world_history_i", "world_history_i_honors", "world_history_ii", "world_history_ii_honors", "us_history", "us_history_honors", "us_government", "us_government_honors", "de_his_121", "de_his_122", "de_pol_135", "de_pol_136"} or code.startswith("applied_social_studies_"):
        return "History"
    return None


def search_students(db, filters):
    sql = "SELECT DISTINCT s.* FROM students s LEFT JOIN requirement_status r ON r.student_id_fk = s.id WHERE 1=1"
    params = []
    for field in ["first_name", "last_name", "student_id", "counselor", "diploma_type"]:
        if filters.get(field):
            sql += f" AND s.{field} LIKE ?"
            params.append(f"%{filters[field]}%")
    if filters.get("graduation_class"):
        sql += " AND s.graduation_class = ?"
        params.append(filters["graduation_class"])
    if filters.get("missing"):
        sql += " AND r.requirement_key = ? AND r.status NOT IN ('Met','Met by LVC')"
        params.append(filters["missing"])
    if filters.get("needs_retake"):
        sql += " AND r.requirement_key = ? AND r.needs_retest = 1"
        params.append(filters["needs_retake"])
    sql += " ORDER BY s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE LIMIT 200"
    return db.execute(sql, params).fetchall()


def unmatched_report_rows(db):
    rows = db.execute("SELECT * FROM unmatched_records WHERE status = 'Open' ORDER BY created_at DESC").fetchall()
    return [
        {
            "id": 0,
            "last_name": row["last_name"] or "(Unmatched)",
            "first_name": row["first_name"] or "",
            "student_id": row["student_id"] or "",
            "graduation_class": row["graduation_class"] or "",
            "counselor": "",
            "diploma_type": "",
            "detail": f'{row["record_type"]}: {row["issue"]}',
        }
        for row in rows
    ]


def report_rows(db, report_key, query=None):
    query = query or {}
    if str(report_key).startswith("custom-"):
        return custom_report_rows(db, report_key, query)
    _, target, mode = REPORTS.get(report_key, REPORTS["needs-retest"])
    if mode in {"three_e", "three_e_no_evidence", "three_e_close"}:
        grad_class = query.get("class", [""])[0] if hasattr(query, "get") else ""
        view_filter = "all"
        if mode == "three_e_no_evidence":
            view_filter = "no-evidence"
        elif mode == "three_e_close":
            view_filter = "close"
        return three_e_report_rows(db, grad_class or None, view_filter)
    if mode == "credit_sol_checklist":
        grad_class = query.get("class", [""])[0] if hasattr(query, "get") else ""
        sql = """
            SELECT s.*, 'Printable checklist available from class print action' AS detail
            FROM students s
            JOIN class_grid_members m ON m.student_id_fk = s.id
            WHERE 1=1
        """
        params = []
        if grad_class:
            sql += " AND m.graduation_class = ?"
            params.append(int(grad_class))
        sql += " ORDER BY m.graduation_class, s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE"
        return db.execute(sql, params).fetchall()
    if mode == "unmatched":
        return unmatched_report_rows(db)
    if mode == "participation_missing":
        grad_class = query.get("class", [""])[0] if hasattr(query, "get") else ""
        participation_key = {"Bio": "Biology Taken", "AlgI": "Algebra I Taken", "EngRLR": "English Reading Taken"}[target]
        test_name = {"Bio": "Biology", "AlgI": "Algebra I", "EngRLR": "EOC Reading"}[target]
        sql = """
            SELECT s.*, ? AS detail
            FROM students s
            WHERE COALESCE(s.enrollment_status, 'Active') = 'Active'
              AND NOT EXISTS (
                SELECT 1 FROM requirement_status r
                WHERE r.student_id_fk=s.id AND r.requirement_key=?
                  AND r.status IN ('Met','Taken','Complete','Pass')
              )
        """
        params = [f"No valid {test_name} attempt is recorded.", participation_key]
        if grad_class:
            sql += " AND s.graduation_class=?"
            params.append(int(grad_class))
        sql += " ORDER BY s.graduation_class, s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE"
        return db.execute(sql, params).fetchall()
    if mode == "middle_school_eoc":
        return db.execute(
            """SELECT s.*, 'Schedule and monitor a high-school EOC mathematics test' AS detail
               FROM students s
               WHERE COALESCE(s.enrollment_status,'Active')='Active'
                 AND COALESCE(s.middle_school_eoc_taker,0)=1
               ORDER BY s.graduation_class, s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE"""
        ).fetchall()
    if mode == "missing":
        grad_class = query.get("class", [""])[0] if hasattr(query, "get") else ""
        sql = "SELECT s.*, r.requirement_key || ': ' || COALESCE(r.display_value, r.status) AS detail FROM students s JOIN requirement_status r ON r.student_id_fk = s.id WHERE COALESCE(s.enrollment_status, 'Active') = 'Active' AND r.requirement_key = ? AND r.status NOT IN ('Met','Met by LVC')"
        params = [target]
        if grad_class:
            sql += " AND s.graduation_class = ?"
            params.append(int(grad_class))
        sql += " ORDER BY s.graduation_class, s.last_name"
        return db.execute(sql, params).fetchall()
    if mode == "met":
        return db.execute("SELECT s.*, r.requirement_key AS detail FROM students s JOIN requirement_status r ON r.student_id_fk = s.id WHERE COALESCE(s.enrollment_status, 'Active') = 'Active' AND r.requirement_key = ? AND r.status = 'Met' ORDER BY s.graduation_class, s.last_name", (target,)).fetchall()
    if mode in {"cougar_scholars", "cougar_tracking"}:
        detail = "Subject-area SOL requirements met for all attempted areas" if mode == "cougar_scholars" else "Current eligible; tracking export marks upcoming grade"
        return cougar_scholar_rows(db, detail)
    if mode == "flag":
        return db.execute("SELECT s.*, f.message AS detail FROM students s JOIN student_flags f ON f.student_id_fk = s.id WHERE COALESCE(s.enrollment_status, 'Active') = 'Active' AND f.flag_type = ? AND f.resolved = 0 ORDER BY s.graduation_class, s.last_name", (target,)).fetchall()
    if mode == "retest":
        return db.execute("SELECT s.*, r.requirement_key AS detail FROM students s JOIN requirement_status r ON r.student_id_fk = s.id WHERE COALESCE(s.enrollment_status, 'Active') = 'Active' AND r.needs_retest = 1 ORDER BY s.graduation_class, s.last_name").fetchall()
    if mode == "retake_window":
        return db.execute(
            """
            SELECT s.*, r.requirement_key || ': ' || COALESCE(r.display_value, r.status) AS detail
            FROM students s
            JOIN requirement_status r ON r.student_id_fk = s.id
            WHERE r.needs_retest = 1
              AND COALESCE(s.enrollment_status, 'Active') = 'Active'
              AND r.status = 'Not Met'
              AND r.lvc_type IS NULL
            ORDER BY s.graduation_class, s.last_name
            """
        ).fetchall()
    if mode == "missing_transcript":
        return db.execute(
            """
            SELECT s.*, 'No matched transcript uploaded' AS detail
            FROM students s
            WHERE s.graduation_class = ?
              AND COALESCE(s.enrollment_status, 'Active') = 'Active'
              AND NOT EXISTS (
                SELECT 1 FROM transcript_courses tc WHERE tc.student_id_fk = s.id
              )
            ORDER BY s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE
            """,
            (_senior_class_for_reports(),),
        ).fetchall()
    if mode == "asvab_scores":
        return db.execute(
            """
            SELECT s.*,
                   'Best ASVAB: ' || CAST(CAST(MAX(a.score) AS INTEGER) AS TEXT) ||
                   '; 3E enlistment points: ' ||
                   CASE
                     WHEN MAX(a.score) >= 66 THEN '1'
                     WHEN MAX(a.score) >= 50 THEN '0.75'
                     WHEN MAX(a.score) >= 31 THEN '0.5'
                     ELSE '0'
                   END AS detail
            FROM students s
            JOIN test_attempts a ON a.student_id_fk = s.id
            WHERE COALESCE(s.enrollment_status, 'Active') = 'Active' AND a.test_area = 'ASVAB' AND a.score IS NOT NULL
            GROUP BY s.id
            ORDER BY s.graduation_class, s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE
            """
        ).fetchall()
    if mode in {"failed", "multiple"}:
        column = "failed_course_indicator" if mode == "failed" else "multiple_attempt_indicator"
        return db.execute(f"SELECT DISTINCT s.*, a.test_area AS detail FROM students s JOIN test_attempts a ON a.student_id_fk = s.id WHERE COALESCE(s.enrollment_status, 'Active') = 'Active' AND a.{column} = 1 ORDER BY s.graduation_class, s.last_name").fetchall()
    if mode == "category":
        keys = CATEGORY_KEYS[target]
        placeholders = ",".join("?" for _ in keys)
        return db.execute(f"SELECT DISTINCT s.*, ? AS detail FROM students s WHERE COALESCE(s.enrollment_status, 'Active') = 'Active' AND NOT EXISTS (SELECT 1 FROM requirement_status r WHERE r.student_id_fk = s.id AND r.requirement_key IN ({placeholders}) AND r.status IN ('Met','Met by LVC')) ORDER BY s.graduation_class, s.last_name", [target] + keys).fetchall()
    return []


def custom_report_rows(db, report_key, query=None):
    definition = custom_report_definition(db, report_key)
    if not definition:
        return []
    query = query or {}
    grad_class = query.get("class", [""])[0] if hasattr(query, "get") else ""
    sql = """SELECT DISTINCT s.* FROM students s JOIN class_grid_members m ON m.student_id_fk=s.id WHERE COALESCE(s.enrollment_status,'Active')='Active'"""
    params = []
    if grad_class:
        sql += " AND m.graduation_class = ?"
        params.append(int(grad_class))
    sql += " ORDER BY m.graduation_class, s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE"
    rows = []
    filters = [item for item in definition.get("filters", []) if str(item.get("field", "")).strip()]
    combine_any = definition.get("combine") == "any"
    for student in db.execute(sql, params).fetchall():
        statuses = {row["requirement_key"]: row for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk=?", (student["id"],)).fetchall()}
        checks = [_custom_filter_matches(statuses.get(item["field"]), item) for item in filters]
        if not checks or not (any(checks) if combine_any else all(checks)):
            continue
        details = []
        for item in filters:
            row = statuses.get(item["field"])
            details.append(f"{item['field']}: {(row['display_value'] or row['status']) if row else 'Missing'}")
        output = dict(student)
        output["detail"] = "; ".join(details)
        rows.append(output)
    return rows


def _custom_filter_matches(row, filter_item):
    operator = str(filter_item.get("operator", "is")).strip().lower()
    target = str(filter_item.get("value", "Missing")).strip()
    status = str(row["status"] if row else "Missing")
    display = str((row["display_value"] or "") if row else "")
    if target.lower() == "missing" and operator in {"is", "equals", "="}:
        return row is None or status in {"Missing", "Needs Review", "Not Met"} or not display
    if operator in {"is", "equals", "="}:
        return target.lower() in {status.lower(), display.lower()}
    if operator in {"is_not", "not"}:
        return target.lower() not in {status.lower(), display.lower()}
    try:
        observed = float(row["score"] if row and row["score"] is not None else display or 0)
        expected = float(target or 0)
    except ValueError:
        return False
    if operator in {"less_than", "<"}:
        return observed < expected
    if operator in {"greater_than", ">"}:
        return observed > expected
    return status not in {"Met", "Met by LVC", "Complete", "Pass", "Taken"}


def cougar_scholar_rows(db, detail):
    students = db.execute(
        """
        SELECT s.*
        FROM students s
        JOIN class_grid_members m ON m.student_id_fk = s.id
        ORDER BY s.graduation_class, s.last_name COLLATE NOCASE, s.first_name COLLATE NOCASE
        """
    ).fetchall()
    eligible = []
    for student in students:
        statuses = {
            row["requirement_key"]: row["status"]
            for row in db.execute("SELECT requirement_key, status FROM requirement_status WHERE student_id_fk = ?", (student["id"],)).fetchall()
        }
        if cougar_scholar_eligible(statuses):
            row = dict(student)
            row["detail"] = detail
            eligible.append(row)
    return eligible


def cougar_scholar_eligible(statuses):
    sol_keys = ["ESCI", "Bio", "Chem", "AlgI", "Geom", "AlgII", "EngRLR", "EngWrit", "WGeo", "WHI", "WHII", "USH"]
    passed = {key for key in sol_keys if statuses.get(key) in {"Met", "Met by LVC"}}
    if not passed:
        return False
    categories = {
        "Math": ["AlgI", "Geom", "AlgII"],
        "Science": ["ESCI", "Bio", "Chem"],
        "History": ["WGeo", "WHI", "WHII", "USH"],
    }
    category_met = {name: any(key in passed for key in keys) for name, keys in categories.items()}
    for key in sol_keys:
        if statuses.get(key) != "Not Met":
            continue
        if key in categories["Math"] and category_met["Math"]:
            continue
        if key in categories["Science"] and category_met["Science"]:
            continue
        if key in categories["History"] and category_met["History"]:
            continue
        return False
    return True


def _senior_class_for_reports():
    today = datetime.now()
    return today.year + 1 if today.month >= 7 else today.year
