import copy
import hashlib
import json
from datetime import datetime, timezone

from .custom_rule_schema import validate_rule_package


def definition_hash(config):
    """Return a stable fingerprint of rule content, excluding lifecycle metadata."""
    normalized = copy.deepcopy(config)
    package = normalized.setdefault("package", {})
    package["status"] = "draft"
    package.pop("lifecycle", None)
    payload = json.dumps(normalized, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def mark_edited(config):
    edited = copy.deepcopy(config)
    package = edited.setdefault("package", {})
    package["status"] = "draft"
    package.pop("lifecycle", None)
    return edited


def validate_draft(config, actor, now=None):
    candidate = mark_edited(config)
    validation = validate_rule_package(candidate)
    if not validation.valid:
        raise ValueError("Rule package cannot be validated: " + "; ".join(validation.errors))
    timestamp = now or datetime.now(timezone.utc).isoformat()
    fingerprint = definition_hash(candidate)
    candidate["package"]["status"] = "validated"
    candidate["package"]["lifecycle"] = {
        "validated_at": timestamp,
        "validated_by": str(actor or "Admin"),
        "validated_hash": fingerprint,
    }
    return candidate


def approve_validated(config, actor, now=None):
    package = config.get("package", {})
    lifecycle = package.get("lifecycle", {})
    if package.get("status") != "validated":
        raise ValueError("Only a validated rule package can be approved.")
    expected = lifecycle.get("validated_hash")
    actual = definition_hash(config)
    if not expected or expected != actual:
        raise ValueError("The rule package changed after validation. Validate it again before approval.")
    validation = validate_rule_package(config)
    if not validation.valid:
        raise ValueError("Rule package cannot be approved: " + "; ".join(validation.errors))
    approved = copy.deepcopy(config)
    timestamp = now or datetime.now(timezone.utc).isoformat()
    approved["package"]["status"] = "approved"
    approved["package"]["lifecycle"].update({
        "approved_at": timestamp,
        "approved_by": str(actor or "Admin"),
        "approved_hash": actual,
    })
    return approved


def immutable_version_snapshot(config):
    if config.get("package", {}).get("status") != "approved":
        raise ValueError("Only an approved package can be saved as a version snapshot.")
    return copy.deepcopy(config)


def activate_approved(config, actor, now=None):
    if config.get("package", {}).get("status") != "approved":
        raise ValueError("Only an approved immutable version can be activated.")
    active = copy.deepcopy(config)
    timestamp = now or datetime.now(timezone.utc).isoformat()
    active["package"]["status"] = "active"
    active["package"].setdefault("lifecycle", {}).update({
        "activated_at": timestamp,
        "activated_by": str(actor or "Admin"),
    })
    validation = validate_rule_package(active, allow_active=True)
    if not validation.valid:
        raise ValueError("Rule package cannot be activated: " + "; ".join(validation.errors))
    return active


def supersede_active(config, actor, now=None):
    if not config:
        return None
    superseded = copy.deepcopy(config)
    timestamp = now or datetime.now(timezone.utc).isoformat()
    superseded["package"]["status"] = "superseded"
    superseded["package"].setdefault("lifecycle", {}).update({
        "superseded_at": timestamp,
        "superseded_by": str(actor or "Admin"),
    })
    return superseded
