import json
from dataclasses import dataclass

from .rule_engine import recompute_student_status
from .custom_rule_activation import evaluate_and_persist_student


VIRGINIA_TEMPLATE = "Virginia Template"
CUSTOM_TEMPLATE = "Custom / Other State Template"


@dataclass(frozen=True)
class RulePackMetadata:
    key: str
    name: str
    jurisdiction: str
    version: str


class VirginiaRulePack:
    metadata = RulePackMetadata(
        key="virginia",
        name=VIRGINIA_TEMPLATE,
        jurisdiction="Virginia",
        version="legacy-compatible-v1",
    )

    def recompute_student(self, db, student_id):
        recompute_student_status(db, student_id)


class CustomRulePack:
    metadata = RulePackMetadata(
        key="custom",
        name=CUSTOM_TEMPLATE,
        jurisdiction="School configured",
        version="tracking-fields-v1",
    )

    def recompute_student(self, db, student_id):
        active = _active_custom_package(db)
        if active:
            evaluate_and_persist_student(db, active, student_id)
            return
        for field in _custom_field_definitions(db):
            if not field.get("required"):
                continue
            name = str(field.get("name", "")).strip()
            if not name:
                continue
            db.execute(
                """
                INSERT OR IGNORE INTO requirement_status
                (student_id_fk, requirement_key, status, display_value, source,
                 needs_retest, updated_at)
                VALUES (?, ?, 'Missing', '', 'Custom Rules', 0, CURRENT_TIMESTAMP)
                """,
                (student_id, name),
            )


RULE_PACKS = {
    VIRGINIA_TEMPLATE: VirginiaRulePack(),
    CUSTOM_TEMPLATE: CustomRulePack(),
}


def active_rule_pack(db):
    row = db.execute(
        "SELECT value FROM app_settings WHERE key = 'graduation_template_type'"
    ).fetchone()
    template = str(row["value"] if row else VIRGINIA_TEMPLATE).strip()
    return RULE_PACKS.get(template, RULE_PACKS[CUSTOM_TEMPLATE])


def recompute_student_for_active_pack(db, student_id):
    pack = active_rule_pack(db)
    pack.recompute_student(db, student_id)
    return pack.metadata


def _custom_field_definitions(db):
    row = db.execute(
        "SELECT value FROM app_settings WHERE key = 'custom_fields_config'"
    ).fetchone()
    try:
        parsed = json.loads(row["value"] or "[]") if row else []
    except (json.JSONDecodeError, TypeError):
        return []
    return [item for item in parsed if isinstance(item, dict)]


def _active_custom_package(db):
    row = db.execute("SELECT value FROM app_settings WHERE key='active_custom_rule_package'").fetchone()
    if not row or not row["value"]:
        return None
    try:
        parsed = json.loads(row["value"])
    except (json.JSONDecodeError, TypeError):
        return None
    return parsed if isinstance(parsed, dict) and parsed.get("package", {}).get("status") == "active" else None
