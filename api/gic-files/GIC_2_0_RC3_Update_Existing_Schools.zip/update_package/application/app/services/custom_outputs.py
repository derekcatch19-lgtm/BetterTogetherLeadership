import json


def active_custom_package(db):
    raw = _setting(db, "active_custom_rule_package", "")
    try:
        parsed = json.loads(raw) if raw else None
    except (json.JSONDecodeError, TypeError):
        return None
    return parsed if isinstance(parsed, dict) and parsed.get("package", {}).get("status") == "active" else None


def custom_agreement_data(db, student_id):
    package = active_custom_package(db)
    if not package:
        return None
    student = db.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
    if not student:
        return None
    try:
        template = json.loads(_setting(db, "agreement_builder_config", "{}"))
    except (json.JSONDecodeError, TypeError):
        template = {}
    statuses = {row["requirement_key"]: row for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk=?", (student_id,)).fetchall()}
    results = {row["requirement_key"]: row for row in db.execute("SELECT * FROM custom_calculation_results WHERE student_id_fk=? AND rule_pack_key=? AND rule_version=?", (student_id, package["package"]["key"], package["package"]["version"])).fetchall()}
    definitions = {item["key"]: item for item in package.get("requirements", [])}
    plan = _plan_for_student(package, student["diploma_type"])
    configured = template.get("checklist_items", [])
    keys = []
    if configured:
        for item in configured:
            key = item.get("requirement_key") if isinstance(item, dict) else _key_by_label(definitions, item)
            if key:
                keys.append(key)
    elif plan:
        keys = list(plan.get("requirement_keys", []))
    rows = []
    missing = []
    for key in keys:
        definition = definitions.get(key, {"label": key})
        status = statuses.get(key)
        result = results.get(key)
        value = (status["display_value"] or status["status"]) if status else (result["value"] if result else "Missing")
        state = status["status"] if status else (result["status"] if result else "Missing")
        met = state in {"Met", "Complete", "Pass", "Taken"}
        if not met:
            missing.append(key)
        explanation = ""
        if result:
            try:
                explanation = json.loads(result["explanation_json"]).get("explanation", "")
            except (json.JSONDecodeError, TypeError):
                pass
        rows.append({"key": key, "requirement": definition.get("label", key), "met": "Yes" if met else "No", "notes": explanation or str(value or state)})
    supports = []
    for option in template.get("support_plan_options", []):
        if isinstance(option, dict):
            label = option.get("label", "")
            requirement_keys = option.get("requirement_keys", [])
            checked = any(key in missing for key in requirement_keys)
        else:
            label, checked = str(option), False
        if label:
            supports.append({"label": label, "checked": checked})
    return {
        "student": student,
        "rows": rows,
        "supports": supports,
        "title": template.get("title") or "Graduation Agreement",
        "intro_text": template.get("intro_text") or "This agreement summarizes the student's current graduation progress under the active school-approved requirements.",
        "course_completion_text": template.get("course_completion_text") or "Students must complete all required coursework and locally defined graduation requirements.",
        "signature_lines": template.get("signature_lines") or ["Student", "Parent/Guardian", "Counselor/Admin"],
        "footer": template.get("footer") or "Confidential student planning document",
        "package_name": package["package"].get("name", "Custom Graduation Rules"),
        "package_version": package["package"].get("version", ""),
    }


def _plan_for_student(package, diploma_type):
    wanted = _norm(diploma_type)
    plans = package.get("diploma_plans", [])
    for plan in plans:
        if wanted in {_norm(plan.get("key")), _norm(plan.get("name"))}:
            return plan
    return plans[0] if len(plans) == 1 else None


def _key_by_label(definitions, label):
    wanted = _norm(label)
    for key, item in definitions.items():
        if wanted in {_norm(key), _norm(item.get("label"))}:
            return key
    return ""


def _setting(db, key, default=""):
    row = db.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row and row["value"] is not None else default


def _norm(value):
    return "".join(character for character in str(value or "").lower() if character.isalnum())
