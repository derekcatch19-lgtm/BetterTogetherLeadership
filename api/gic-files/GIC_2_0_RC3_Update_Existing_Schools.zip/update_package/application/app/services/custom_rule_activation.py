import json

from .custom_rule_evaluator import evaluate_custom_rules
from .transcript_parser import course_area


def student_snapshot(db, student):
    courses = []
    for row in db.execute("SELECT * FROM transcript_courses WHERE student_id_fk=? ORDER BY id", (student["id"],)).fetchall():
        item = dict(row)
        item["subject_family"] = course_area(item.get("course_title"))
        courses.append(item)
    attempts = [dict(row) for row in db.execute("SELECT * FROM test_attempts WHERE student_id_fk=? ORDER BY id", (student["id"],)).fetchall()]
    custom_values = {}
    evidence_rows = db.execute(
        "SELECT field_key,status,display_value,score FROM custom_field_values WHERE student_id_fk=?",
        (student["id"],),
    ).fetchall()
    for row in evidence_rows:
        custom_values[row["field_key"]] = row["score"] if row["score"] is not None else (row["display_value"] or row["status"])
    return {
        "student": {
            "student_id": student["student_id"],
            "graduation_class": student["graduation_class"],
            "diploma_type": student["diploma_type"],
        },
        "courses": courses,
        "attempts": attempts,
        "custom_values": custom_values,
    }


def preview_rule_impact(db, config):
    rows = []
    summary = {"students": 0, "on_track": 0, "needs_review": 0, "not_applicable": 0, "changed": 0}
    students = db.execute("SELECT * FROM students WHERE COALESCE(enrollment_status,'Active')='Active' ORDER BY graduation_class,last_name,first_name").fetchall()
    for student in students:
        evaluation = evaluate_custom_rules(config, student_snapshot(db, student))
        current = _current_custom_status(db, student["id"])
        proposed = evaluation["overall_status"]
        changed = current != proposed
        summary["students"] += 1
        summary[_summary_key(proposed)] += 1
        summary["changed"] += int(changed)
        rows.append({
            "student_id_fk": student["id"],
            "student_name": f"{student['last_name']}, {student['first_name']}",
            "graduation_class": student["graduation_class"],
            "current_status": current,
            "proposed_status": proposed,
            "changed": changed,
            "evaluation": evaluation,
        })
    return {"summary": summary, "rows": rows}


def persist_active_results(db, config, preview=None):
    preview = preview or preview_rule_impact(db, config)
    package = config["package"]
    db.execute("DELETE FROM custom_calculation_results WHERE rule_pack_key=? AND rule_version=?", (package["key"], package["version"]))
    db.execute("DELETE FROM requirement_status WHERE source LIKE 'Custom Rule Pack:%'")
    for row in preview["rows"]:
        _persist_student_evaluation(db, config, row["student_id_fk"], row["evaluation"])
    return preview["summary"]


def evaluate_and_persist_student(db, config, student_id):
    student = db.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
    if not student:
        raise ValueError("Student not found for custom rule calculation.")
    evaluation = evaluate_custom_rules(config, student_snapshot(db, student))
    source = f"Custom Rule Pack:{config['package']['key']}:{config['package']['version']}"
    db.execute("DELETE FROM custom_calculation_results WHERE student_id_fk=? AND rule_pack_key=? AND rule_version=?", (student_id, config["package"]["key"], config["package"]["version"]))
    db.execute("DELETE FROM requirement_status WHERE student_id_fk=? AND source LIKE 'Custom Rule Pack:%' AND source<>?", (student_id, source))
    _persist_student_evaluation(db, config, student_id, evaluation)
    return evaluation


def _persist_student_evaluation(db, config, student_id, evaluation):
    package = config["package"]
    source = f"Custom Rule Pack:{package['key']}:{package['version']}"
    for result in evaluation["results"]:
        db.execute(
            """INSERT INTO custom_calculation_results
               (student_id_fk,rule_pack_key,rule_version,requirement_key,status,value,explanation_json)
               VALUES (?,?,?,?,?,?,?)""",
            (student_id, package["key"], package["version"], result["key"], result["status"], str(result.get("value") if result.get("value") is not None else ""), json.dumps({"explanation": result.get("explanation", ""), "evidence": result.get("evidence", [])})),
        )
        db.execute(
            """INSERT OR REPLACE INTO requirement_status
               (student_id_fk,requirement_key,status,display_value,source,needs_retest,updated_at)
               VALUES (?,?,?,?,?,0,CURRENT_TIMESTAMP)""",
            (student_id, result["key"], result["status"], str(result.get("value") if result.get("value") is not None else ""), source),
        )
    db.execute(
        """INSERT OR REPLACE INTO requirement_status
           (student_id_fk,requirement_key,status,display_value,source,needs_retest,updated_at)
           VALUES (?,'Custom Graduation Status',?,?,?,0,CURRENT_TIMESTAMP)""",
        (student_id, "Met" if evaluation["overall_status"] == "On Track" else evaluation["overall_status"], evaluation["overall_status"], source),
    )


def _current_custom_status(db, student_id):
    row = db.execute("SELECT display_value,status FROM requirement_status WHERE student_id_fk=? AND requirement_key='Custom Graduation Status'", (student_id,)).fetchone()
    return (row["display_value"] or row["status"]) if row else "Not Calculated"


def _summary_key(status):
    return {"On Track": "on_track", "Not Applicable": "not_applicable"}.get(status, "needs_review")
