import re
from collections import defaultdict
from datetime import date

from .transcript_parser import course_area
from .virginia_eoc_phase_in import PHASE_SUBJECTS, refresh_student_eoc_rules

SOL_AREAS = {
    "ESCI": ("Science", ["earth science", "earth sci", "esci"]),
    "Bio": ("Science", ["biology", "bio"]),
    "Chem": ("Science", ["chemistry", "chem"]),
    "AlgI": ("Math", ["algebra i", "algebra 1", "algebra i (", "algi"]),
    "Geom": ("Math", ["geometry", "geom"]),
    "AlgII": ("Math", ["algebra ii", "algebra 2", "algii"]),
    "EngRLR": ("English", ["english reading", "reading", "engrlr", "workplace documents", "workplace docs"]),
    "EngWrit": ("English", ["english writing", "writing", "engwrit", "business letter", "blw"]),
    "WGeo": ("History", ["world geography", "w geography", "wgeo"]),
    "WHI": ("History", ["world history i", "w hist i", "whi"]),
    "WHII": ("History", ["world history ii", "whii"]),
    "USH": ("History", ["u.s. history", "us history", "ush"]),
}

REQUIRED_PARTICIPATION = {
    "AlgI": "Algebra I Taken",
    "Bio": "Biology Taken",
    "EngRLR": "English Reading Taken",
}

OTHER_REQUIREMENTS = {
    "CCRI": ["ccri"],
    "Credential Test": ["credential", "cte"],
    "Workplace Readiness": ["workplace readiness"],
    "NCRC": ["ncrc", "graphic literacy", "applied math"],
    "CPR/AED Complete": ["cpr", "aed"],
    "Virtual Course Complete": ["virtual"],
    "Student Service Learning Project Complete": ["service learning"],
    "Dual Enrollment": ["dual enrollment"],
    "ASVAB": ["asvab"],
    "5 C's Demonstration": ["5 c", "5c"],
}

CATEGORY_REQUIREMENTS = {"English": 2, "Math": 1, "Science": 1, "History": 1}
CATEGORY_AREA_KEYS = {
    "Math": ["AlgI", "Geom", "AlgII"],
    "Science": ["ESCI", "Bio", "Chem"],
    "History": ["WGeo", "WHI", "WHII", "USH"],
}


def normalize_area(test_area, test_name=""):
    text = f"{test_area or ''} {test_name or ''}".lower()
    # NCRC component labels such as Workplace Documents would otherwise be
    # mistaken for an English Reading substitute test.
    if "ncrc" in (test_area or "").lower():
        return "NCRC"
    if "pba" in text or "performance based" in text or "performance assessment" in text:
        if "world geography" in text or "wgeo" in text:
            return "WGeo"
        if "world history ii" in text or "whii" in text:
            return "WHII"
        if "world history i" in text or "whi" in text:
            return "WHI"
        if "u.s. history" in text or "us history" in text or "ush" in text or "history" in text:
            return "USH"
    # Check the longer Roman-numeral subjects first so "II" is not consumed by an "I" alias.
    for key in ("AlgII", "WHII"):
        if any(alias in text for alias in SOL_AREAS[key][1]):
            return key
    for key, (_, aliases) in SOL_AREAS.items():
        if any(alias in text for alias in aliases):
            return key
    for key, aliases in OTHER_REQUIREMENTS.items():
        if any(alias in text for alias in aliases):
            return key
    return (test_area or test_name or "Other").strip()


def parse_score(raw):
    if raw is None:
        return None, False, False
    text = str(raw).strip()
    multiple = "#" in text
    failed_course = "*" in text
    cleaned = text.replace("#", "").replace("*", "")
    try:
        return float(cleaned), multiple, failed_course
    except ValueError:
        match = re.search(r"\d+(?:\.\d+)?", cleaned)
        if match:
            return float(match.group(0)), multiple, failed_course
        return None, multiple, failed_course


def attempt_passes(area_key, score, pass_fail, raw_score="", passing_score=400):
    pf = (pass_fail or "").strip().lower()
    raw = (raw_score or "").strip().lower()
    if area_key in CATEGORY_AREA_KEYS["History"] and (
        "pba" in raw or "performance based assessment" in raw or "performance-based assessment" in raw
    ):
        raw_pba_failure = bool(re.search(r"(?:\bf\s*[-/]?\s*pba\b|\bpba\s*[-/]?\s*f\b)", raw))
        explicit_failure = pf in {"fail", "failed", "f", "false", "0", "no", "n", "not met", "not awarded", "unchecked"}
        if explicit_failure or raw_pba_failure:
            return False
        if pf in {"pass", "passed", "p", "true", "1", "yes", "y", "complete", "completed", "awarded"}:
            return True
        # Historical grids use a bare PBA marker to mean earned credit. A
        # numeric PBA result uses the established passing average of 2.
        # Only a value written as a PBA result is a PBA average. Older grids
        # sometimes store an SOL score followed by F-PBA; that SOL score must
        # never be compared with the PBA 2-point passing threshold.
        match = re.search(r"\bpba\s*[-:]?\s*(\d+(?:\.\d+)?)\b", raw)
        numeric = float(match.group(1)) if match else None
        return numeric >= 2 if numeric is not None else True
    if area_key not in PHASE_SUBJECTS and pf in {"pass", "passed", "p", "yes", "y", "complete", "completed"}:
        return True
    if area_key == "EngRLR":
        substitute_level = _substitute_level("reading", raw)
        if substitute_level is not None:
            return substitute_level >= 4
    if area_key == "EngWrit":
        substitute_level = _substitute_level("writing", raw)
        if substitute_level is not None:
            return substitute_level >= 3
    if score is None:
        return False
    if area_key == "EngRLR" and 4 <= score < 400 and any(label in raw or label in pf for label in ["wd", "wpd", "workplace"]):
        return True
    if area_key == "EngWrit" and 3 <= score < 400 and any(label in raw or label in pf for label in ["blw", "business letter"]):
        return True
    if area_key == "Workplace Readiness":
        return score >= 75
    if area_key == "Credential Test":
        return score >= 75 or pf in {"pass", "passed", "p", "yes", "y", "complete", "completed"}
    return score >= passing_score


def recompute_student_status(db, student_id):
    student = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    attempts = db.execute("SELECT * FROM test_attempts WHERE student_id_fk = ?", (student_id,)).fetchall()
    previous_statuses = {
        row["requirement_key"]: row
        for row in db.execute("SELECT * FROM requirement_status WHERE student_id_fk = ?", (student_id,)).fetchall()
    }
    db.execute("DELETE FROM requirement_status WHERE student_id_fk = ?", (student_id,))
    db.execute("DELETE FROM student_flags WHERE student_id_fk = ? AND resolved = 0", (student_id,))
    eoc_rules = refresh_student_eoc_rules(db, student_id, previous_statuses)

    grouped = defaultdict(list)
    for attempt in attempts:
        area_key = normalize_area(attempt["test_area"], attempt["test_name"])
        if area_key in SOL_AREAS and not _valid_sol_attempt(area_key, attempt):
            continue
        grouped[area_key].append(attempt)
    for area_attempts in grouped.values():
        db.execute(
            f"UPDATE test_attempts SET multiple_attempt_indicator = ? WHERE id IN ({','.join('?' for _ in area_attempts)})",
            [1 if _distinct_attempt_count(area_attempts) > 1 else 0] + [attempt["id"] for attempt in area_attempts],
        )

    natural_met_by_category = _natural_met_by_category(grouped, eoc_rules)
    met_by_category = defaultdict(int)
    missing_best = {}
    failed_course_areas = _failed_course_areas(db, student_id)
    lvc_awarded = 0
    sped = _is_sped_or_504(student["sped_504_status"])

    for key, (category, _) in SOL_AREAS.items():
        phase_rule = eoc_rules.get(key)
        passing_score = phase_rule.get("locked_passing_score") if phase_rule else 400
        passing_score = passing_score if passing_score is not None else 400
        best = _best_attempt(grouped.get(key, []), key, passing_score)
        status = "Missing"
        display = ""
        score = None
        lvc_type = None
        needs_retest = 0
        if best:
            score = best["score"]
            best_text = f"{best['test_name'] or ''} {best['test_area'] or ''} {best['raw_score'] or ''}".lower()
            if score is None and "pba" in best_text:
                numeric_match = re.search(r"\d+(?:\.\d+)?", best["raw_score"] or "")
                if numeric_match:
                    score = float(numeric_match.group(0))
            attempts_count = _distinct_attempt_count(grouped.get(key, []))
            display = _display_score(best, attempts_count, passing_score)
            passed = attempt_passes(key, score, best["pass_fail"], _attempt_evidence_text(best), passing_score)
            failed_pba_attempt = None
            if category == "History":
                for candidate in grouped.get(key, []):
                    candidate_text = f"{candidate['test_name'] or ''} {candidate['test_area'] or ''} {candidate['raw_score'] or ''}".lower()
                    candidate_pf = (candidate["pass_fail"] or "").strip().lower()
                    raw_failure = bool(re.search(r"(?:\bf\s*[-/]?\s*pba\b|\bpba\s*[-/]?\s*f\b)", candidate_text))
                    explicit_failure = candidate_pf in {"fail", "failed", "f", "false", "0", "no", "n", "not met", "not awarded", "unchecked"}
                    if "pba" in candidate_text and (raw_failure or explicit_failure):
                        failed_pba_attempt = candidate
                        break
            prior = previous_statuses.get(key)
            preserved = bool(
                key in PHASE_SUBJECTS and prior
                and prior["status"] in {"Met", "Met by LVC"}
                and (
                    prior["status"] == "Met by LVC"
                    or (phase_rule and phase_rule.get("review_reason"))
                )
            )
            if passed:
                status = "Met"
                if key == "EngWrit":
                    substitute_level = _writing_substitute_level(best)
                    if substitute_level is not None:
                        sol_attempt = _best_writing_sol_attempt(grouped.get(key, []))
                        substitute_display = _substitute_display("writing", substitute_level)
                        if sol_attempt and sol_attempt["score"] is not None:
                            sol_score = sol_attempt["score"]
                            sol_display = str(int(sol_score)) if float(sol_score).is_integer() else str(sol_score)
                            display = f"{sol_display} / {substitute_display}"
                        else:
                            display = substitute_display
                if category == "History" and "pba" in f"{best['test_name'] or ''} {best['test_area'] or ''} {best['raw_score'] or ''}".lower():
                    display = "PBA - LAVC"
                met_by_category[category] += 1
            elif category == "History" and failed_pba_attempt:
                status = "Not Met"
                failed_text = f"{failed_pba_attempt['test_name'] or ''} {failed_pba_attempt['raw_score'] or ''}".lower()
                raw_pba_failure = bool(re.search(r"(?:\bf\s*[-/]?\s*pba\b|\bpba\s*[-/]?\s*f\b)", failed_text))
                failed_score = failed_pba_attempt["score"]
                if failed_score is None and not raw_pba_failure:
                    numeric_pba = re.search(r"\bpba\s*[-:]?\s*(\d+(?:\.\d+)?)\b", failed_text)
                    failed_score = float(numeric_pba.group(1)) if numeric_pba else None
                if raw_pba_failure or failed_score is None:
                    display = "PBA - F"
                else:
                    display = f"PBA - {int(failed_score) if float(failed_score).is_integer() else failed_score}"
                missing_best[key] = failed_score if failed_score is not None else -1
            elif category == "History" and "pba" in best_text:
                status = "Not Met"
                raw_pba_failure = bool(re.search(r"(?:\bf\s*[-/]?\s*pba\b|\bpba\s*[-/]?\s*f\b)", best_text))
                display = "PBA - F" if raw_pba_failure or score is None else display
                missing_best[key] = score if score is not None else -1
            elif preserved:
                status = prior["status"]
                display = prior["display_value"] or display
                lvc_type = prior["lvc_type"]
                met_by_category[category] += 1
            elif score is not None and 375 <= score <= 399 and (
                attempts_count >= 2 or _attempt_has_lvc_marker(best)
            ) and key not in PHASE_SUBJECTS and _lvc_allowed(student, key, natural_met_by_category, lvc_awarded):
                status = "Met by LVC"
                lvc_type = "SPED/504 CA" if sped else "Senior LVC"
                display = f"{display} LVC".strip()
                met_by_category[category] += 1
                lvc_awarded += 1
            elif score is not None:
                status = "Not Met"
                if key in failed_course_areas:
                    display = f"{display}*".replace("**", "*")
                else:
                    missing_best[key] = score
        else:
            if key in failed_course_areas:
                display = "Course failed *"
            else:
                missing_best[key] = -1

        _upsert_status(db, student_id, key, status, display, score, "SOL", lvc_type, needs_retest)

    _mark_not_needed_when_category_met(db, student_id, met_by_category, grouped, missing_best)
    _apply_required_participation(db, student_id, grouped)
    _mark_best_retests(db, student_id, student, grouped, missing_best)
    _apply_possible_lvc_flag(db, student_id, student, grouped, met_by_category, lvc_awarded)
    _apply_other_requirements(db, student_id, grouped)
    _apply_completion_summary(db, student_id, met_by_category)


def _best_attempt(attempts, area_key=None, passing_score=400):
    if not attempts:
        return None
    def rank(attempt):
        passes = attempt_passes(
            area_key, attempt["score"], attempt["pass_fail"],
            _attempt_evidence_text(attempt), passing_score,
        ) if area_key else False
        return (1 if passes else 0, attempt["score"] is not None, attempt["score"] or -1, attempt["test_date"] or "")
    return sorted(attempts, key=rank, reverse=True)[0]


def _natural_met_by_category(grouped, eoc_rules=None):
    eoc_rules = eoc_rules or {}
    met = defaultdict(int)
    for key, (category, _) in SOL_AREAS.items():
        passing_score = (eoc_rules.get(key) or {}).get("locked_passing_score") or 400
        best = _best_attempt(grouped.get(key, []), key, passing_score)
        if best and attempt_passes(key, best["score"], best["pass_fail"], best["raw_score"], passing_score):
            met[category] += 1
    return met


def _distinct_attempt_count(attempts):
    attempts_by_result = defaultdict(set)
    for attempt in attempts:
        area, score, _ = _attempt_identity(attempt, include_date=False)
        attempts_by_result[(area, score)].add(_precise_attempt_date(attempt["test_date"]))
    count = 0
    for dates in attempts_by_result.values():
        precise_dates = {date_value for date_value in dates if date_value}
        # A grid or longitudinal school-year row is summary evidence. It does
        # not create another attempt when the same score is also present in a
        # dated Pearson record. Different full dates remain distinct attempts.
        count += len(precise_dates) if precise_dates else 1
    return count


def _precise_attempt_date(value):
    text = str(value or "").strip()
    patterns = [
        (r"^(\d{4})-(\d{1,2})-(\d{1,2})$", (1, 2, 3)),
        (r"^(\d{1,2})/(\d{1,2})/(\d{4})$", (3, 1, 2)),
        (r"^(\d{1,2})-(\d{1,2})-(\d{4})$", (3, 1, 2)),
    ]
    for pattern, order in patterns:
        match = re.match(pattern, text)
        if not match:
            continue
        year, month, day = (int(match.group(index)) for index in order)
        if 1 <= month <= 12 and 1 <= day <= 31:
            return f"{year:04d}-{month:02d}-{day:02d}"
    return ""


def _attempt_identity(attempt, include_date=True):
    score = attempt["score"]
    if score is not None:
        score_key = str(int(score)) if float(score).is_integer() else str(score)
    else:
        score_key = (attempt["raw_score"] or "").strip().lower()
    date_key = (attempt["test_date"] or "").strip() if include_date else ""
    area_key = normalize_area(attempt["test_area"], attempt["test_name"])
    return _attempt_identity_from_parts(area_key, score_key, date_key)


def _attempt_identity_from_parts(area_key, score_key, date_key):
    return (area_key, score_key, date_key)


def _valid_sol_attempt(area_key, attempt):
    raw = (attempt["raw_score"] or "").strip().lower()
    if "name:" in raw and "dtype:" in raw:
        return False
    score = attempt["score"]
    if score is None:
        return bool(raw and any(label in raw for label in ["pba", "lavc", "pass", "passed"]))
    evidence_text = _attempt_evidence_text(attempt)
    if area_key == "EngRLR" and _substitute_level("reading", evidence_text) is not None:
        return True
    if area_key == "EngWrit" and _substitute_level("writing", evidence_text) is not None:
        return True
    if "pba" in f"{attempt['test_name'] or ''} {attempt['test_area'] or ''}".lower():
        return True
    # Virginia SOL scaled scores top out at 600. Values above 600 are
    # administrative status codes (for example, not tested or parent refusal),
    # not passing test results.
    if score > 600:
        return False
    return score >= 200


def _attempt_has_lvc_marker(attempt):
    text = f"{attempt['raw_score'] or ''} {attempt['pass_fail'] or ''} {attempt['credential_name'] or ''}".lower()
    return bool(re.search(r"(^|[^a-z])(ca|lavc|lvc)([^a-z]|$)", text))


def _substitute_level(kind, raw):
    text = str(raw or "").strip().lower()
    if kind == "reading":
        patterns = [
            r"\b(?:wpd|wd)\s*[-:]?\s*(\d+(?:\.\d+)?)\b",
            r"\bworkplace\s+(?:docs|documents)\s*[-:]?\s*(\d+(?:\.\d+)?)\b",
            r"\b(\d+(?:\.\d+)?)\s*(?:wpd|wd|workplace\s+(?:docs|documents))\b",
        ]
    else:
        patterns = [
            r"\b(?:blw|business\s+letter(?:\s+writing)?)\s*[-:]?\s*(\d+(?:\.\d+)?)\b",
            r"\b(\d+(?:\.\d+)?)\s*(?:blw|business\s+letter(?:\s+writing)?)\b",
        ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                return None
    return None


def _writing_substitute_level(attempt):
    return _substitute_level("writing", _attempt_evidence_text(attempt))


def _attempt_evidence_text(attempt):
    return " ".join(str(value or "") for value in (
        attempt["raw_score"], attempt["test_name"], attempt["test_area"],
        attempt["credential_name"], attempt["pass_fail"],
    ))


def _best_writing_sol_attempt(attempts):
    candidates = [
        attempt for attempt in attempts
        if attempt["score"] is not None and _writing_substitute_level(attempt) is None
    ]
    if not candidates:
        return None
    return sorted(
        candidates,
        key=lambda attempt: (attempt["score"], _precise_attempt_date(attempt["test_date"])),
        reverse=True,
    )[0]


def _substitute_display(kind, level):
    rendered = int(level) if float(level).is_integer() else level
    return f"WD-{rendered}" if kind == "reading" else f"BLW-{rendered}"


def _failed_course_areas(db, student_id):
    try:
        courses = db.execute(
            """
            SELECT course_title, final_grade FROM transcript_courses
            WHERE student_id_fk = ? AND upper(trim(final_grade)) = 'F'
            """,
            (student_id,),
        ).fetchall()
    except Exception:
        return set()
    return {area for area in (course_area(course["course_title"]) for course in courses) if area}


def _display_score(attempt, attempts_count, passing_score=400):
    score = attempt["score"]
    raw = (attempt["raw_score"] or "").strip()
    is_pba = "pba" in f"{attempt['test_name'] or ''} {attempt['test_area'] or ''} {raw}".lower()
    if is_pba and score is not None:
        rendered = int(score) if float(score).is_integer() else score
        display = f"PBA - {rendered}"
    elif raw and any(char.isalpha() for char in raw):
        display = raw
    elif score is None:
        display = raw
    elif float(score).is_integer():
        display = str(int(score))
    else:
        display = str(score)
    if attempt["failed_course_indicator"] and "*" not in display:
        display += "*"
    if score is not None and score < passing_score and attempts_count > 1 and "#" not in display:
        display += "#"
    return display


def _upsert_status(db, student_id, key, status, display, score, source, lvc_type=None, needs_retest=0):
    db.execute(
        """
        INSERT INTO requirement_status
        (student_id_fk, requirement_key, status, display_value, score, source, lvc_type, needs_retest, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        """,
        (student_id, key, status, display, score, source, lvc_type, needs_retest),
    )


def _apply_required_participation(db, student_id, grouped):
    for area_key, requirement_key in REQUIRED_PARTICIPATION.items():
        taken = bool(grouped.get(area_key))
        _upsert_status(db, student_id, requirement_key, "Met" if taken else "Missing", "Yes" if taken else "No", None, "Participation")


def _mark_not_needed_when_category_met(db, student_id, met_by_category, grouped, missing_best):
    for category, area_keys in CATEGORY_AREA_KEYS.items():
        if met_by_category[category] < CATEGORY_REQUIREMENTS[category]:
            continue
        for area_key in area_keys:
            if grouped.get(area_key):
                continue
            db.execute(
                """
                UPDATE requirement_status
                SET status = ?, display_value = ?, needs_retest = 0
                WHERE student_id_fk = ? AND requirement_key = ? AND status = 'Missing'
                """,
                ("Not Needed", "Verified credit met in subject area", student_id, area_key),
            )
            missing_best.pop(area_key, None)


def _mark_best_retests(db, student_id, student, grouped, missing_best):
    by_category = defaultdict(list)
    for key, score in missing_best.items():
        category = SOL_AREAS.get(key, ("Other", []))[0]
        if category == "History" and student["graduation_class"] > _senior_class():
            continue
        if category == "Science" and key != "Bio" and not grouped.get("Bio"):
            continue
        by_category[category].append((key, score))
    for entries in by_category.values():
        key, _ = max(entries, key=lambda item: item[1])
        db.execute("UPDATE requirement_status SET needs_retest = 1 WHERE student_id_fk = ? AND requirement_key = ?", (student_id, key))


def _senior_class():
    today = date.today()
    return today.year + 1 if today.month >= 7 else today.year


def _is_sped_or_504(value):
    text = (value or "").strip().upper()
    return text in {"Y", "YES", "504", "SPED", "IEP", "SPECIAL EDUCATION", "SPED/504"}


def _lvc_allowed(student, area_key, met_by_category, lvc_awarded):
    if _is_sped_or_504(student["sped_504_status"]):
        return True
    if student["graduation_class"] != _senior_class() or lvc_awarded:
        return False
    category = SOL_AREAS.get(area_key, ("Other", []))[0]
    projected = defaultdict(int, met_by_category)
    projected[category] += 1
    missing_categories = sum(max(0, need - projected[cat]) for cat, need in CATEGORY_REQUIREMENTS.items())
    return missing_categories == 0


def _apply_possible_lvc_flag(db, student_id, student, grouped, met_by_category, lvc_awarded):
    sped = _is_sped_or_504(student["sped_504_status"])
    if sped or lvc_awarded:
        return
    missing_categories = sum(max(0, need - met_by_category[cat]) for cat, need in CATEGORY_REQUIREMENTS.items())
    if missing_categories != 1:
        return
    for key, attempts in grouped.items():
        if key not in SOL_AREAS or key in PHASE_SUBJECTS or len(attempts) < 2:
            continue
        best = _best_attempt(attempts)
        if best and best["score"] is not None and 375 <= best["score"] <= 399:
            db.execute(
                "INSERT INTO student_flags(student_id_fk, flag_type, message) VALUES (?, ?, ?)",
                (student_id, "Possible LVC", f"Eligible for possible LVC in {key}; user confirmation required."),
            )


def _apply_other_requirements(db, student_id, grouped):
    met_displays = {}
    credential_attempts = grouped.get("Credential Test", [])
    ncrc_attempts = grouped.get("NCRC", []) + [attempt for attempt in credential_attempts if "ncrc" in _attempt_text(attempt)]
    wpr_attempts = grouped.get("Workplace Readiness", []) + [attempt for attempt in credential_attempts if "wpr" in _attempt_text(attempt) or "workplace readiness" in _attempt_text(attempt)]
    ncrc_met, ncrc_display = _ncrc_status(ncrc_attempts)
    wpr_met, wpr_display = _simple_requirement_status(wpr_attempts, "Workplace Readiness")
    employment_met, employment_display, employment_score = _employment_credential_status(
        credential_attempts, ncrc_attempts, wpr_attempts
    )
    asvab_met, asvab_display = _simple_requirement_status(grouped.get("ASVAB", []), "ASVAB")
    credential_met = employment_met
    credential_display = employment_display

    for key in OTHER_REQUIREMENTS:
        if key == "NCRC":
            status = "Met" if ncrc_met else ("Entered" if grouped.get("NCRC") else "Missing")
            display = ncrc_display
        elif key == "Workplace Readiness":
            status = "Met" if wpr_met else ("Entered" if grouped.get("Workplace Readiness") else "Missing")
            display = wpr_display
        elif key == "Credential Test":
            status = "Met" if credential_met else ("Entered" if grouped.get("Credential Test") or grouped.get("NCRC") or grouped.get("Workplace Readiness") else "Missing")
            display = credential_display
        elif key == "CCRI":
            explicit_met, explicit_display = _simple_requirement_status(grouped.get("CCRI", []), "CCRI")
            pathway_met, pathway_display = _ccri_pathway_status(db, student_id)
            met = explicit_met or pathway_met or credential_met or asvab_met
            status = "Met" if met else "Missing"
            display = _join_unique([explicit_display if explicit_met else "", pathway_display if pathway_met else "", credential_display if credential_met else "", f"ASVAB {asvab_display}" if asvab_met else ""])
        elif key == "Dual Enrollment":
            transcript_met, transcript_display = _dual_enrollment_status(db, student_id)
            explicit_status, explicit_display = _generic_requirement_status(grouped.get(key, []), key)
            status = "Met" if transcript_met or explicit_status == "Met" else ("Entered" if transcript_display or explicit_status == "Entered" else "Missing")
            display = _join_unique([transcript_display, explicit_display])
        else:
            status, display = _generic_requirement_status(grouped.get(key, []), key)
        score = _best_attempt(grouped.get(key, []))["score"] if grouped.get(key) else None
        _upsert_status(db, student_id, key, status, display, score, "Requirement")

    employment_entered = bool(
        grouped.get("NCRC")
        or grouped.get("Workplace Readiness")
        or any(_employment_attempt_is_evidence(attempt) for attempt in credential_attempts)
    )
    _upsert_status(
        db,
        student_id,
        "Employment Credential",
        "Met" if employment_met else ("Entered" if employment_entered else "Missing"),
        employment_display or ("No passing credential" if employment_entered else "Missing"),
        employment_score,
        "Requirement",
    )


def _apply_completion_summary(db, student_id, met_by_category):
    complete = all(met_by_category[cat] >= need for cat, need in CATEGORY_REQUIREMENTS.items())
    _upsert_status(db, student_id, "SOLs Complete", "Met" if complete else "Missing", "Yes" if complete else "No", None, "Summary")


def _generic_requirement_status(attempts, key):
    met, display = _simple_requirement_status(attempts, key)
    if met:
        return "Met", display
    if attempts:
        return "Entered", display
    return "Missing", ""


def _simple_requirement_status(attempts, key):
    best = _best_attempt(attempts)
    if not best:
        return False, ""
    if key == "Credential Test":
        met = _credential_attempt_passes(best)
    elif key == "ASVAB":
        met = best["score"] is not None
    elif key == "Workplace Readiness":
        raw = _attempt_text(best)
        match = re.search(r"\d+(?:\.\d+)?", raw)
        met = bool(match and float(match.group(0)) >= 75) or attempt_passes(key, best["score"], best["pass_fail"], best["raw_score"])
    else:
        met = attempt_passes(key, best["score"], best["pass_fail"], best["raw_score"])
    display = best["raw_score"] or best["pass_fail"] or best["credential_name"] or ("Met" if met else "Entered")
    return met, display


def _credential_attempt_passes(attempt):
    raw = f"{attempt['raw_score'] or ''} {attempt['pass_fail'] or ''} {attempt['credential_name'] or ''}".lower()
    if "ncrc" in raw and not re.search(r"(^|[^a-z])f([^a-z]|$)", raw):
        return True
    if "wpr" in raw or "workplace readiness" in raw:
        match = re.search(r"\d+(?:\.\d+)?", raw)
        return bool(match and float(match.group(0)) >= 75)
    return attempt_passes("Credential Test", attempt["score"], attempt["pass_fail"], attempt["raw_score"])


def _employment_credential_status(credential_attempts, ncrc_attempts, wpr_attempts):
    """Return the strongest W!SE, WPR, or NCRC evidence for Employment."""
    candidates = []
    seen_attempts = set()
    for attempt in list(credential_attempts) + list(wpr_attempts):
        attempt_id = attempt["id"] if "id" in attempt.keys() else id(attempt)
        if attempt_id in seen_attempts:
            continue
        seen_attempts.add(attempt_id)
        text = _attempt_text(attempt)
        for match in re.finditer(r"(?:^|[\s,;/])(?P<failed>f\s*[-/]?\s*)?w(?:!|i)se(?:\s*[-/:]?\s*(?P<score>\d+(?:\.\d+)?))?(?P<failed_after>\s*[-/]?\s*(?:f|fail(?:ed)?|false|not passed)\b)?", text):
            score = float(match.group("score")) if match.group("score") else attempt["score"]
            explicit_failure = (attempt["pass_fail"] or "").strip().lower() in {"fail", "failed", "f", "false", "0", "no", "n", "not passed"}
            passed = match.group("failed") is None and match.group("failed_after") is None and not explicit_failure
            candidates.append((passed, score, _credential_label("W!SE", score)))
        for match in re.finditer(r"(?:^|[\s,;/])(?P<failed>f\s*[-/]?\s*)?(?:wpr|workplace readiness)(?:\s*[-/:=]?\s*(?P<score>\d+(?:\.\d+)?))?(?:\s*/\s*(?P<score_after>\d+(?:\.\d+)?))?(?P<failed_after>\s*[-/]?\s*(?:f(?!\s*(?:-\s*)?(?:ncrc|w(?:!|i)se|wpr|workplace))|fail(?:ed)?|false|not passed)\b)?", text):
            inline_scores = [float(value) for value in (match.group("score"), match.group("score_after")) if value]
            score = max(inline_scores) if inline_scores else attempt["score"]
            explicit_failure = (attempt["pass_fail"] or "").strip().lower() in {"fail", "failed", "f", "false", "0", "no", "n", "not passed"}
            passed = score is not None and score >= 75 and match.group("failed") is None and match.group("failed_after") is None and not explicit_failure
            candidates.append((passed, score, _credential_label("WPR", score)))

    ncrc_met, ncrc_display = _ncrc_status(ncrc_attempts)
    if ncrc_attempts:
        candidates.append((ncrc_met, None, "NCRC" if ncrc_met else ncrc_display))

    for attempt in credential_attempts:
        text = _attempt_text(attempt)
        if any(token in text for token in ("w!se", "wise", "wpr", "workplace readiness", "ncrc")):
            continue
        if (attempt["test_name"] or "").strip().lower() == "existing graduation grid":
            continue
        if _credential_attempt_passes(attempt):
            score = attempt["score"]
            label = attempt["credential_name"] or attempt["raw_score"] or "Credential Passed"
            candidates.append((True, score, str(label)))

    if not candidates:
        return False, "", None
    passed = [candidate for candidate in candidates if candidate[0]]
    pool = passed or candidates
    best = sorted(pool, key=lambda item: (item[1] is not None, item[1] or -1), reverse=True)[0]
    return bool(passed), best[2], best[1]


def _employment_attempt_is_evidence(attempt):
    text = _attempt_text(attempt)
    if any(token in text for token in ("w!se", "wise", "wpr", "workplace readiness", "ncrc")):
        return True
    return (attempt["test_name"] or "").strip().lower() != "existing graduation grid"


def _credential_label(name, score):
    if score is None:
        return name
    rendered = int(score) if float(score).is_integer() else score
    return f"{name}-{rendered}"


def _ncrc_status(attempts):
    if not attempts:
        return False, ""
    manual_corrections = [
        attempt for attempt in attempts
        if attempt["source_upload_id"] is None
        and (attempt["test_name"] or "").strip().lower() in {"manual grid edit", "ncrc overall result"}
        and "ncrc" in _attempt_text(attempt)
    ]
    if manual_corrections:
        latest = max(manual_corrections, key=lambda attempt: attempt["id"])
        correction_text = _attempt_text(latest)
        correction_status = (latest["pass_fail"] or "").strip().lower()
        failed = correction_status in {"fail", "failed", "f", "false", "0", "no", "n", "not passed"} or bool(
            re.search(r"(?:\bf\s*[-/]?\s*ncrc\b|\bncrc\s*[-/]?\s*f\b)", correction_text)
        )
        return (not failed), ("NCRC" if not failed else "NCRC-F")
    for attempt in attempts:
        raw = f"{attempt['raw_score'] or ''} {attempt['pass_fail'] or ''} {attempt['credential_name'] or ''}".lower()
        ncrc_markers = list(re.finditer(r"(?:^|[\s,;/])(?P<failed>f\s*[-/]?\s*)?ncrc\b(?P<failed_after>\s*[-/]?\s*(?:f(?!\s*(?:-\s*)?(?:ncrc|w(?:!|i)se|wpr|workplace))|fail(?:ed)?|false|not passed)\b)?", raw))
        if any(marker.group("failed") is None and marker.group("failed_after") is None for marker in ncrc_markers):
            return True, attempt["raw_score"] or attempt["credential_name"] or "NCRC"
    components = {"workplace": None, "graphic": None, "applied": None}
    for attempt in attempts:
        label = f"{attempt['credential_name'] or ''} {attempt['test_name'] or ''} {attempt['test_area'] or ''}".lower()
        raw = (attempt["raw_score"] or "").lower()
        target = None
        if "workplace" in label or "documents" in label or "docs" in label:
            target = "workplace"
        elif "graphic" in label:
            target = "graphic"
        elif "applied" in label or "math" in label:
            target = "applied"
        if target:
            components[target] = _ncrc_component_passes(attempt["score"], raw)
    met = all(value is True for value in components.values())
    return met, "NCRC"


def _attempt_text(attempt):
    return f"{attempt['raw_score'] or ''} {attempt['pass_fail'] or ''} {attempt['credential_name'] or ''} {attempt['test_name'] or ''} {attempt['test_area'] or ''}".lower()


def _join_unique(values):
    seen = set()
    output = []
    for value in values:
        if not value:
            continue
        if value in seen:
            continue
        seen.add(value)
        output.append(value)
    return "; ".join(output)


def _ncrc_component_passes(score, raw):
    if raw and re.search(r"(^|[^a-z])f([^a-z]|$)", raw.lower()):
        return False
    return score is not None and score >= 3


def _ccri_pathway_status(db, student_id):
    try:
        courses = db.execute(
            "SELECT course_title, attributes, final_grade, status FROM transcript_courses WHERE student_id_fk = ?",
            (student_id,),
        ).fetchall()
    except Exception:
        return False, ""
    evidence = []
    for course in courses:
        grade = (course["final_grade"] or "").upper()
        if grade == "F":
            continue
        attrs = (course["attributes"] or "").upper().split()
        title = course["course_title"] or ""
        title_lower = title.lower()
        if any(attr in {"H", "DE", "AP", "IB"} for attr in attrs) or any(term in title_lower for term in ["honors", "dual enrollment", "advanced placement", "work-based", "work based"]):
            evidence.append(title)
    if evidence:
        return True, "CCRI pathway: " + "; ".join(evidence[:3]) + ("..." if len(evidence) > 3 else "")
    return False, ""


def _dual_enrollment_status(db, student_id):
    try:
        courses = db.execute(
            "SELECT course_title, attributes, final_grade, status FROM transcript_courses WHERE student_id_fk = ?",
            (student_id,),
        ).fetchall()
    except Exception:
        return False, ""
    completed = []
    in_progress = []
    for course in courses:
        title = (course["course_title"] or "").strip()
        attrs = (course["attributes"] or "").upper().split()
        text = f"{title} {course['attributes'] or ''}".lower()
        is_dual = "DE" in attrs or "dual enrollment" in text or bool(re.search(r"\bde\b", text))
        if not is_dual or (course["final_grade"] or "").strip().upper() == "F":
            continue
        if (course["status"] or "").strip().lower() == "work in progress":
            in_progress.append(title)
        else:
            completed.append(title)
    parts = []
    if completed:
        parts.append("Completed: " + "; ".join(completed[:4]) + ("..." if len(completed) > 4 else ""))
    if in_progress:
        parts.append("In progress: " + "; ".join(in_progress[:3]) + ("..." if len(in_progress) > 3 else ""))
    return bool(completed), "; ".join(parts)
