import copy
import hashlib
import json
from datetime import datetime, timezone


FORMAT = "gic-school-template"
FORMAT_VERSION = 1
SETTING_KEYS = {
    "custom_fields_config",
    "custom_reports_config",
    "agreement_builder_config",
    "import_templates_config",
    "main_grid_columns_config",
    "custom_rule_package_versions",
}
FORBIDDEN_KEYS = {"students", "users", "password", "password_hash", "database", "uploads", "exports", "logs", "backups", "audit_log", "sessions"}


def build_template_package(db, template_name):
    configuration = {}
    for key in sorted(SETTING_KEYS):
        row = db.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
        if row and row["value"] not in (None, ""):
            try:
                configuration[key] = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                configuration[key] = row["value"]
    if isinstance(configuration.get("custom_rule_package_versions"), list):
        sanitized_versions = []
        for version in configuration["custom_rule_package_versions"]:
            if not isinstance(version, dict):
                continue
            clean = copy.deepcopy(version)
            clean.setdefault("package", {})["status"] = "draft"
            clean["package"].pop("lifecycle", None)
            sanitized_versions.append(clean)
        configuration["custom_rule_package_versions"] = sanitized_versions
    active = _json_setting(db, "active_custom_rule_package")
    draft = _json_setting(db, "custom_rule_package_draft")
    rule_package = active or draft
    if rule_package:
        rule_package = copy.deepcopy(rule_package)
        rule_package.setdefault("package", {})["status"] = "draft"
        rule_package["package"].pop("lifecycle", None)
        configuration["custom_rule_package_draft"] = rule_package
    manifest = {
        "name": str(template_name or "GIC School Template").strip(),
        "jurisdiction": (rule_package or {}).get("package", {}).get("jurisdiction", "Custom / Other State"),
        "rule_version": (rule_package or {}).get("package", {}).get("version", ""),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "contains_student_data": False,
        "activation_required": True,
    }
    core = {"format": FORMAT, "format_version": FORMAT_VERSION, "manifest": manifest, "configuration": configuration}
    return {**core, "sha256": _digest(core)}


def serialize_template_package(package):
    return json.dumps(package, indent=2, sort_keys=True).encode("utf-8")


def parse_and_validate_template_package(raw):
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8")
    if len(raw.encode("utf-8")) > 5 * 1024 * 1024:
        raise ValueError("Template package exceeds the 5 MB configuration limit.")
    try:
        package = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ValueError("Template package is not valid UTF-8 JSON.") from exc
    if not isinstance(package, dict) or package.get("format") != FORMAT or package.get("format_version") != FORMAT_VERSION:
        raise ValueError("This is not a supported GIC template package.")
    supplied = package.get("sha256", "")
    core = {key: package[key] for key in ("format", "format_version", "manifest", "configuration") if key in package}
    if not supplied or supplied != _digest(core):
        raise ValueError("Template checksum does not match. The package may be incomplete or changed.")
    configuration = package.get("configuration")
    if not isinstance(configuration, dict):
        raise ValueError("Template configuration must be an object.")
    unknown = set(configuration) - (SETTING_KEYS | {"custom_rule_package_draft"})
    if unknown:
        raise ValueError("Template contains unsupported configuration keys: " + ", ".join(sorted(unknown)))
    forbidden = _find_forbidden_keys(package)
    if forbidden:
        raise ValueError("Template contains forbidden data keys: " + ", ".join(sorted(forbidden)))
    if package.get("manifest", {}).get("contains_student_data") is not False:
        raise ValueError("Template must explicitly declare that it contains no student data.")
    return package


def template_preview(package):
    config = package["configuration"]
    return {
        "name": package["manifest"].get("name", ""),
        "jurisdiction": package["manifest"].get("jurisdiction", ""),
        "rule_version": package["manifest"].get("rule_version", ""),
        "sha256": package["sha256"],
        "sections": sorted(config),
        "counts": {
            "custom_fields": len(config.get("custom_fields_config", [])) if isinstance(config.get("custom_fields_config"), list) else 0,
            "custom_reports": len(config.get("custom_reports_config", [])) if isinstance(config.get("custom_reports_config"), list) else 0,
            "import_profiles": len(config.get("import_templates_config", [])) if isinstance(config.get("import_templates_config"), list) else 0,
            "approved_rule_versions": len(config.get("custom_rule_package_versions", [])) if isinstance(config.get("custom_rule_package_versions"), list) else 0,
        },
        "warnings": ["Imported rules remain Draft and require validation, approval, impact preview, and activation."],
    }


def apply_template_package(db, package):
    package = parse_and_validate_template_package(serialize_template_package(package))
    config = package["configuration"]
    for key in SETTING_KEYS:
        if key in config:
            db.execute("INSERT OR REPLACE INTO app_settings(key,value,updated_at) VALUES (?,?,CURRENT_TIMESTAMP)", (key, json.dumps(config[key], indent=2)))
    draft = copy.deepcopy(config.get("custom_rule_package_draft"))
    if draft:
        draft.setdefault("package", {})["status"] = "draft"
        draft["package"].pop("lifecycle", None)
        db.execute("INSERT OR REPLACE INTO app_settings(key,value,updated_at) VALUES ('custom_rule_package_draft',?,CURRENT_TIMESTAMP)", (json.dumps(draft, indent=2),))
        db.execute("INSERT OR REPLACE INTO app_settings(key,value,updated_at) VALUES ('graduation_template_type','Custom / Other State Template',CURRENT_TIMESTAMP)")
    # A template import is a draft configuration operation. It must never
    # deactivate the rules currently calculating student status or destroy the
    # rollback target. Activation remains a separate reviewed Admin action.
    return template_preview(package)


def _json_setting(db, key):
    row = db.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
    if not row or not row["value"]:
        return None
    try:
        value = json.loads(row["value"])
    except (json.JSONDecodeError, TypeError):
        return None
    return value if isinstance(value, dict) else None


def _digest(core):
    payload = json.dumps(core, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _find_forbidden_keys(value):
    found = set()
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in FORBIDDEN_KEYS:
                found.add(str(key).lower())
            found.update(_find_forbidden_keys(child))
    elif isinstance(value, list):
        for child in value:
            found.update(_find_forbidden_keys(child))
    return found
