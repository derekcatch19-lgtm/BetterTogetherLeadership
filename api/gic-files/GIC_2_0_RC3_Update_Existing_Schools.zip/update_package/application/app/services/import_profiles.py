import hashlib
import json
import re
import uuid
from datetime import datetime, timezone


def header_fingerprint(columns):
    normalized = sorted({_norm(column) for column in columns if _norm(column)})
    payload = "|".join(normalized)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def find_import_profile(profiles, source_type, columns):
    fingerprint = header_fingerprint(columns)
    source = _norm(source_type)
    candidates = [item for item in profiles if isinstance(item, dict) and item.get("active", True) and _norm(item.get("source_type")) == source]
    exact = next((item for item in candidates if item.get("header_fingerprint") == fingerprint), None)
    if exact:
        return exact, 1.0, "Exact header match"
    incoming = {_norm(column) for column in columns if _norm(column)}
    best = None
    best_score = 0.0
    for profile in candidates:
        saved = {_norm(column) for column in profile.get("headers", []) if _norm(column)}
        score = len(incoming & saved) / len(incoming | saved) if incoming or saved else 0.0
        if score > best_score:
            best, best_score = profile, score
    if best and best_score >= 0.75:
        return best, best_score, "Similar headers; confirm changed columns"
    return None, 0.0, "No saved profile matched"


def apply_import_profile(profile, columns, fallback):
    if not profile:
        return dict(fallback)
    available = {_norm(column): column for column in columns}
    result = dict(fallback)
    for field, saved_column in profile.get("mappings", {}).items():
        current = available.get(_norm(saved_column))
        if current:
            result[str(field)] = current
    return result


def save_import_profile(profiles, name, source_type, columns, mappings, transformations=None, now=None):
    name = str(name or "").strip()
    if not name:
        raise ValueError("Enter a name for the saved import profile.")
    clean_mappings = {str(field): str(column) for field, column in mappings.items() if str(column).strip()}
    timestamp = now or datetime.now(timezone.utc).isoformat()
    item = {
        "id": uuid.uuid4().hex,
        "name": name,
        "source_type": str(source_type or "").strip(),
        "header_fingerprint": header_fingerprint(columns),
        "headers": [str(column) for column in columns],
        "mappings": clean_mappings,
        "transformations": transformations or {"trim_text": True},
        "active": True,
        "created_at": timestamp,
        "updated_at": timestamp,
    }
    updated = [profile for profile in profiles if not (isinstance(profile, dict) and (_norm(profile.get("name")) == _norm(name) or (profile.get("header_fingerprint") == item["header_fingerprint"] and _norm(profile.get("source_type")) == _norm(source_type))))]
    updated.append(item)
    return updated, item


def mark_profile_used(profiles, profile_id, now=None):
    timestamp = now or datetime.now(timezone.utc).isoformat()
    updated = []
    for profile in profiles:
        item = dict(profile) if isinstance(profile, dict) else profile
        if isinstance(item, dict) and item.get("id") == profile_id:
            item["last_used_at"] = timestamp
        updated.append(item)
    return updated


def parse_profiles(raw):
    try:
        parsed = json.loads(raw or "[]")
    except (json.JSONDecodeError, TypeError):
        return []
    return [item for item in parsed if isinstance(item, dict)] if isinstance(parsed, list) else []


def _norm(value):
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())
