import json


def school_readiness(db, backup_count=0):
    settings = {row["key"]: row["value"] or "" for row in db.execute("SELECT key,value FROM app_settings").fetchall()}
    template = settings.get("graduation_template_type", "Virginia Template")
    students = _count(db, "students")
    grids = db.execute("SELECT COUNT(DISTINCT graduation_class) FROM class_grid_members").fetchone()[0]
    uploads = _count(db, "upload_history")
    users = _count(db, "users", "disabled=0")
    admins = _count(db, "users", "disabled=0 AND role='Admin'")
    backups = max(0, int(backup_count or 0))

    profile_ok = bool(settings.get("school_name", "").strip() and settings.get("school_name", "").strip() != "Your School")
    if template == "Virginia Template":
        rules_status, rules_detail, rules_link = "complete", "Virginia defaults are selected.", "/admin/graduation-rules"
    else:
        active = _object(settings.get("active_custom_rule_package", ""))
        draft = _object(settings.get("custom_rule_package_draft", ""))
        if active:
            rules_status, rules_detail = "complete", _rule_label(active, "Active custom rules")
        elif draft:
            rules_status, rules_detail = "attention", _rule_label(draft, "Custom rules are still Draft")
        else:
            rules_status, rules_detail = "needed", "No custom graduation rule package has been created."
        rules_link = "/admin/rules-builder"

    agreement = _object(settings.get("agreement_builder_config", ""))
    reports = _list(settings.get("custom_reports_config", ""))
    imports = _list(settings.get("import_templates_config", ""))
    fields = _list(settings.get("custom_fields_config", ""))

    steps = [
        _step("School Profile", "complete" if profile_ok else "needed", settings.get("school_name", "Your School") if profile_ok else "Add the school name and local profile.", "/admin/school-profile", True),
        _step("Administrator Access", "complete" if admins else "needed", f"{admins} active Admin; {users} active user account(s)." if admins else "Create at least one active Admin account.", "/admin/users", True),
        _step("Graduation Rules", rules_status, rules_detail, rules_link, True),
        _step("Student Grids", "complete" if students and grids else "needed", f"{students} students across {grids} class grid(s)." if students and grids else "Import a roster or existing graduation grid.", "/upload", True),
        _step("Import Mapping", "complete" if imports else "recommended", f"{len(imports)} saved import profile(s)." if imports else "Save a mapping after the first successful upload for repeatable imports.", "/admin/import-templates", False),
        _step("Tracking and Reports", "complete" if (template == "Virginia Template" or fields or reports) else "recommended", "Virginia reports are ready." if template == "Virginia Template" else f"{len(fields)} custom field(s); {len(reports)} custom report(s).", "/admin/custom-fields", False),
        _step("Graduation Agreement", "complete" if agreement.get("title") and (template == "Virginia Template" or agreement.get("checklist_items")) else "recommended", agreement.get("title", "Customize the school agreement and checklist."), "/admin/agreement-builder", False),
        _step("Backup Check", "complete" if backups else "recommended", f"{backups} backup file(s) detected." if backups else "Create a manual backup after setup and before the first live import.", "/admin/backups", False),
    ]
    required = [step for step in steps if step["required"]]
    completed_required = sum(step["status"] == "complete" for step in required)
    overall = "ready" if completed_required == len(required) else "setup"
    next_step = next((step for step in required if step["status"] != "complete"), next((step for step in steps if step["status"] != "complete"), None))
    return {
        "template": template,
        "overall": overall,
        "required_complete": completed_required,
        "required_total": len(required),
        "percent": round(completed_required / max(len(required), 1) * 100),
        "steps": steps,
        "next_step": next_step,
        "counts": {"students": students, "grids": grids, "uploads": uploads, "users": users},
    }


def _step(name, status, detail, link, required):
    return {"name": name, "status": status, "detail": detail, "link": link, "required": required}


def _count(db, table, where="1=1"):
    return db.execute(f"SELECT COUNT(*) FROM {table} WHERE {where}").fetchone()[0]


def _object(raw):
    try:
        value = json.loads(raw) if raw else {}
    except (TypeError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _list(raw):
    try:
        value = json.loads(raw) if raw else []
    except (TypeError, json.JSONDecodeError):
        return []
    return value if isinstance(value, list) else []


def _rule_label(package, fallback):
    metadata = package.get("package", {})
    name = metadata.get("name") or fallback
    version = metadata.get("version") or ""
    return f"{name} {version}".strip()

