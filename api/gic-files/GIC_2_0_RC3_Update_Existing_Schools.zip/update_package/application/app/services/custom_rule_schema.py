import re
from dataclasses import dataclass
from datetime import date


SCHEMA_VERSION = 1
PACKAGE_STATUSES = {"draft", "validated", "approved", "active", "superseded"}
REQUIREMENT_TYPES = {
    "credit_total",
    "subject_credits",
    "assessment",
    "credential",
    "checklist",
    "number",
    "date",
    "text",
    "calculated",
}
EVIDENCE_TYPES = {
    "transcript_course",
    "assessment_attempt",
    "credential_attempt",
    "completion_record",
    "custom_field",
    "manual_confirmation",
}
OPERATORS = {">=", ">", "<=", "<", "=", "==", "is", "is_not", "nonblank", "checked"}
RELATIONSHIP_TYPES = {"all_of", "any_of", "count_of", "alternative"}


@dataclass(frozen=True)
class RuleValidationResult:
    errors: tuple
    warnings: tuple

    @property
    def valid(self):
        return not self.errors


def new_rule_package(name, jurisdiction, version="1.0-draft"):
    return {
        "schema_version": SCHEMA_VERSION,
        "package": {
            "key": _key(name),
            "name": str(name or "Custom Graduation Rules").strip(),
            "jurisdiction": str(jurisdiction or "Custom").strip(),
            "version": str(version or "1.0-draft").strip(),
            "status": "draft",
            "effective_from": None,
            "effective_to": None,
            "cohort_start": None,
            "cohort_end": None,
        },
        "diploma_plans": [],
        "requirements": [],
        "evidence_definitions": [],
        "relationships": [],
    }


def validate_rule_package(config, allow_active=False):
    errors = []
    warnings = []
    if not isinstance(config, dict):
        return RuleValidationResult(("Rule package must be a JSON object.",), ())
    if config.get("schema_version") != SCHEMA_VERSION:
        errors.append(f"schema_version must be {SCHEMA_VERSION}.")

    package = config.get("package")
    if not isinstance(package, dict):
        errors.append("package must be an object.")
        package = {}
    for field in ("key", "name", "jurisdiction", "version", "status"):
        if not str(package.get(field) or "").strip():
            errors.append(f"package.{field} is required.")
    status = str(package.get("status") or "").lower()
    if status and status not in PACKAGE_STATUSES:
        errors.append(f"package.status must be one of: {', '.join(sorted(PACKAGE_STATUSES))}.")
    if status == "active" and not allow_active:
        errors.append("A draft schema cannot be marked active before approval and activation controls are implemented.")
    _validate_dates_and_cohorts(package, "package", errors)

    requirements = _list_of_objects(config, "requirements", errors)
    evidence = _list_of_objects(config, "evidence_definitions", errors)
    plans = _list_of_objects(config, "diploma_plans", errors)
    relationships = _list_of_objects(config, "relationships", errors)

    requirement_keys = _unique_keys(requirements, "requirements", errors)
    evidence_keys = _unique_keys(evidence, "evidence_definitions", errors)
    plan_keys = _unique_keys(plans, "diploma_plans", errors)

    for index, item in enumerate(requirements):
        prefix = f"requirements[{index}]"
        kind = str(item.get("type") or "").strip()
        if kind not in REQUIREMENT_TYPES:
            errors.append(f"{prefix}.type must be one of: {', '.join(sorted(REQUIREMENT_TYPES))}.")
        if not str(item.get("label") or "").strip():
            errors.append(f"{prefix}.label is required.")
        operator = str(item.get("operator") or "").strip()
        if operator and operator not in OPERATORS:
            errors.append(f"{prefix}.operator is not supported.")
        threshold = item.get("threshold")
        if kind in {"credit_total", "subject_credits", "number"}:
            if operator not in {">=", ">", "<=", "<", "=", "=="}:
                errors.append(f"{prefix}.operator must be numeric for {kind}.")
            if not _is_number(threshold):
                errors.append(f"{prefix}.threshold must be numeric for {kind}.")
        if kind in {"assessment", "credential"} and not item.get("evidence_keys"):
            warnings.append(f"{prefix} has no evidence_keys and cannot be calculated automatically.")
        for evidence_key in item.get("evidence_keys", []) if isinstance(item.get("evidence_keys", []), list) else []:
            if evidence_key not in evidence_keys:
                errors.append(f"{prefix}.evidence_keys references unknown evidence '{evidence_key}'.")
        scopes = item.get("diploma_scope", [])
        if scopes and not isinstance(scopes, list):
            errors.append(f"{prefix}.diploma_scope must be a list.")
        elif isinstance(scopes, list):
            for plan_key in scopes:
                if plan_key not in plan_keys:
                    errors.append(f"{prefix}.diploma_scope references unknown plan '{plan_key}'.")
        _validate_dates_and_cohorts(item, prefix, errors)

    for index, item in enumerate(evidence):
        prefix = f"evidence_definitions[{index}]"
        kind = str(item.get("type") or "").strip()
        if kind not in EVIDENCE_TYPES:
            errors.append(f"{prefix}.type must be one of: {', '.join(sorted(EVIDENCE_TYPES))}.")
        if not str(item.get("label") or "").strip():
            errors.append(f"{prefix}.label is required.")
        aliases = item.get("aliases", [])
        if aliases and not isinstance(aliases, list):
            errors.append(f"{prefix}.aliases must be a list.")
        pass_rule = item.get("pass_rule")
        if pass_rule is not None:
            if not isinstance(pass_rule, dict):
                errors.append(f"{prefix}.pass_rule must be an object.")
            else:
                operator = str(pass_rule.get("operator") or "").strip()
                if operator not in OPERATORS:
                    errors.append(f"{prefix}.pass_rule.operator is not supported.")
                if operator in {">=", ">", "<=", "<", "=", "=="} and not _is_number(pass_rule.get("threshold")):
                    errors.append(f"{prefix}.pass_rule.threshold must be numeric.")

    for index, plan in enumerate(plans):
        prefix = f"diploma_plans[{index}]"
        if not str(plan.get("name") or "").strip():
            errors.append(f"{prefix}.name is required.")
        if not _is_number(plan.get("total_credits")):
            errors.append(f"{prefix}.total_credits must be numeric.")
        keys = plan.get("requirement_keys", [])
        if not isinstance(keys, list):
            errors.append(f"{prefix}.requirement_keys must be a list.")
        else:
            for requirement_key in keys:
                if requirement_key not in requirement_keys:
                    errors.append(f"{prefix}.requirement_keys references unknown requirement '{requirement_key}'.")

    for index, relationship in enumerate(relationships):
        prefix = f"relationships[{index}]"
        kind = str(relationship.get("type") or "").strip()
        if kind not in RELATIONSHIP_TYPES:
            errors.append(f"{prefix}.type must be one of: {', '.join(sorted(RELATIONSHIP_TYPES))}.")
        parent = str(relationship.get("parent_requirement") or "").strip()
        if parent not in requirement_keys:
            errors.append(f"{prefix}.parent_requirement references unknown requirement '{parent}'.")
        children = relationship.get("child_requirements", [])
        if not isinstance(children, list) or not children:
            errors.append(f"{prefix}.child_requirements must be a non-empty list.")
            children = []
        for child in children:
            if child not in requirement_keys:
                errors.append(f"{prefix}.child_requirements references unknown requirement '{child}'.")
        if kind == "count_of":
            minimum = relationship.get("minimum")
            if not isinstance(minimum, int) or minimum < 1 or minimum > len(children):
                errors.append(f"{prefix}.minimum must be between 1 and the number of child requirements.")

    if not plans:
        warnings.append("No diploma plans are defined.")
    if not requirements:
        warnings.append("No requirements are defined.")
    return RuleValidationResult(tuple(errors), tuple(warnings))


def _list_of_objects(config, key, errors):
    value = config.get(key, [])
    if not isinstance(value, list):
        errors.append(f"{key} must be a list.")
        return []
    result = []
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            errors.append(f"{key}[{index}] must be an object.")
        else:
            result.append(item)
    return result


def _unique_keys(items, label, errors):
    keys = set()
    for index, item in enumerate(items):
        key = str(item.get("key") or "").strip()
        if not key:
            errors.append(f"{label}[{index}].key is required.")
        elif not re.fullmatch(r"[a-z][a-z0-9_]*", key):
            errors.append(f"{label}[{index}].key must use lowercase letters, numbers, and underscores.")
        elif key in keys:
            errors.append(f"{label} contains duplicate key '{key}'.")
        keys.add(key)
    return keys


def _validate_dates_and_cohorts(item, prefix, errors):
    parsed = {}
    for field in ("effective_from", "effective_to"):
        value = item.get(field)
        if value in (None, ""):
            continue
        try:
            parsed[field] = date.fromisoformat(str(value))
        except ValueError:
            errors.append(f"{prefix}.{field} must use YYYY-MM-DD.")
    if parsed.get("effective_from") and parsed.get("effective_to") and parsed["effective_from"] > parsed["effective_to"]:
        errors.append(f"{prefix}.effective_from must not be after effective_to.")
    cohorts = {}
    for field in ("cohort_start", "cohort_end"):
        value = item.get(field)
        if value in (None, ""):
            continue
        if not isinstance(value, int) or value < 2000 or value > 2200:
            errors.append(f"{prefix}.{field} must be a four-digit graduation year.")
        else:
            cohorts[field] = value
    if cohorts.get("cohort_start") and cohorts.get("cohort_end") and cohorts["cohort_start"] > cohorts["cohort_end"]:
        errors.append(f"{prefix}.cohort_start must not be after cohort_end.")


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _key(value):
    text = re.sub(r"[^a-z0-9]+", "_", str(value or "").strip().lower()).strip("_")
    return text or "custom_rules"
