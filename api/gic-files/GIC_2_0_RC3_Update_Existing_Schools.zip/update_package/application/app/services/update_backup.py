"""Create and verify a SQLite backup before a Windows application update."""

import sqlite3
import sys
from datetime import datetime
from pathlib import Path


def backup_database(source, backup_root):
    source = Path(source).resolve(strict=True)
    backup_root = Path(backup_root).resolve()
    backup_root.mkdir(parents=True, exist_ok=True)
    destination = backup_root / f"ahs_tracking_before_update_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sqlite3"
    source_db = sqlite3.connect(f"file:{source.as_posix()}?mode=ro", uri=True)
    destination_db = sqlite3.connect(destination)
    try:
        source_db.backup(destination_db)
        result = destination_db.execute("PRAGMA integrity_check").fetchone()[0]
        if str(result).lower() != "ok":
            raise sqlite3.DatabaseError(f"Backup integrity check failed: {result}")
    finally:
        destination_db.close()
        source_db.close()
    return destination


def main(argv=None):
    argv = list(argv or sys.argv[1:])
    if len(argv) != 2:
        raise SystemExit("Usage: python -m app.services.update_backup DATABASE BACKUP_FOLDER")
    print(backup_database(argv[0], argv[1]))


if __name__ == "__main__":
    main()
