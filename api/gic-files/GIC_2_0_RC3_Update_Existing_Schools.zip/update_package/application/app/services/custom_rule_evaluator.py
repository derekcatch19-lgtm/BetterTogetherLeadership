import re
from datetime import date

from .custom_rule_schema import validate_rule_package


MET_STATUSES = {"met", "complete", "completed", "pass", "passed", "yes", "true", "taken"}


def evaluate_custom_rules(config, student_snapshot):
    """Evaluate a typed custom package without changing application data."""
    validation = validate_rule_package(config, allow_active=True)
    if not validation.valid:
        raise ValueError("Rule package is not valid: " + "; ".join(validation.errors))

    package = config["package"]
    student = student_snapshot.get("student", {})
    applicable, applicability = _package_applies(package, student)
    plan = _select_plan(config.get("diploma_plans", []), student.get("diploma_type"))
    if not plan:
        return {
            "applicable": applicable,
            "applicability": applicability,
            "plan": None,
            "overall_status": "Needs Review",
            "results": [],
            "warnings": ["No diploma plan matched the fake student's diploma type."],
        }

    requirements = {item["key"]: item for item in config.get("requirements", [])}
    evidence = {item["key"]: item for item in config.get("evidence_definitions", [])}
    relationships = {item["parent_requirement"]: item for item in config.get("relationships", [])}
    plan_keys = list(plan.get("requirement_keys", []))
    evaluation_keys = _requirement_dependencies(plan_keys, relationships)
    results = {}
    for key in evaluation_keys:
        requirement = requirements[key]
        if not _requirement_applies(requirement, student, plan):
            results[key] = _result(requirement, "Not Applicable", None, [], "Requirement does not apply to this student or diploma plan.")
            continue
        if requirement["type"] == "calculated":
            continue
        results[key] = _evaluate_requirement(requirement, evidence, student_snapshot)

    pending = [key for key in evaluation_keys if requirements[key]["type"] == "calculated"]
    for _ in range(len(pending) + 1):
        changed = False
        for key in list(pending):
            relationship = relationships.get(key)
            if not relationship:
                results[key] = _result(requirements[key], "Needs Review", None, [], "No relationship defines this calculated requirement.")
                pending.remove(key)
                changed = True
                continue
            children = relationship.get("child_requirements", [])
            if not all(child in results for child in children):
                continue
            results[key] = _evaluate_relationship(requirements[key], relationship, results)
            pending.remove(key)
            changed = True
        if not changed:
            break
    for key in pending:
        results[key] = _result(requirements[key], "Needs Review", None, [], "Calculated requirement has unresolved dependencies.")

    ordered = [results[key] for key in plan_keys if key in results]
    required = [item for item in ordered if requirements[item["key"]].get("required", True) and item["status"] != "Not Applicable"]
    overall = "On Track" if applicable and required and all(item["status"] == "Met" for item in required) else "Needs Review"
    if not applicable:
        overall = "Not Applicable"
    return {
        "applicable": applicable,
        "applicability": applicability,
        "plan": {"key": plan["key"], "name": plan["name"]},
        "overall_status": overall,
        "results": ordered,
        "warnings": list(validation.warnings),
    }


def _requirement_dependencies(plan_keys, relationships):
    """Include hidden child requirements needed by displayed calculated rules."""
    ordered = list(plan_keys)
    seen = set(ordered)
    index = 0
    while index < len(ordered):
        relationship = relationships.get(ordered[index])
        if relationship:
            for child in relationship.get("child_requirements", []):
                if child not in seen:
                    seen.add(child)
                    ordered.append(child)
        index += 1
    return ordered


def _evaluate_requirement(requirement, evidence_definitions, snapshot):
    kind = requirement["type"]
    if kind == "credit_total":
        value, evidence = _credit_total(snapshot.get("courses", []))
    elif kind == "subject_credits":
        value, evidence = _subject_credits(requirement, evidence_definitions, snapshot.get("courses", []))
    elif kind in {"assessment", "credential"}:
        value, evidence = _attempt_evidence(requirement, evidence_definitions, snapshot.get("attempts", []))
    else:
        value, evidence = _custom_value(requirement, evidence_definitions, snapshot.get("custom_values", {}))
    met = _compare(value, requirement.get("operator"), requirement.get("threshold"), kind)
    status = "Met" if met else ("Missing" if value in (None, "") else "Not Met")
    explanation = _explanation(requirement, value, met)
    return _result(requirement, status, value, evidence, explanation)


def _credit_total(courses):
    evidence = []
    total = 0.0
    for course in courses:
        if not _completed_course(course):
            continue
        credits = _number(course.get("earned_credits")) or 0.0
        if credits <= 0:
            continue
        total += credits
        evidence.append({"source": "transcript", "label": course.get("course_title", "Course"), "value": credits})
    return round(total, 3), evidence


def _subject_credits(requirement, evidence_definitions, courses):
    definitions = [evidence_definitions[key] for key in requirement.get("evidence_keys", []) if key in evidence_definitions]
    aliases = []
    families = set()
    for definition in definitions:
        aliases.extend(str(alias).lower() for alias in definition.get("aliases", []))
        if definition.get("subject_family"):
            families.add(str(definition["subject_family"]).lower())
    if requirement.get("subject_family"):
        families.add(str(requirement["subject_family"]).lower())
    evidence = []
    total = 0.0
    for course in courses:
        if not _completed_course(course):
            continue
        title = str(course.get("course_title") or "").lower()
        family = str(course.get("subject_family") or "").lower()
        if not ((family and family in families) or any(alias and alias in title for alias in aliases)):
            continue
        credits = _number(course.get("earned_credits")) or 0.0
        total += credits
        evidence.append({"source": "transcript", "label": course.get("course_title", "Course"), "value": credits})
    return round(total, 3), evidence


def _attempt_evidence(requirement, evidence_definitions, attempts):
    candidates = []
    for evidence_key in requirement.get("evidence_keys", []):
        definition = evidence_definitions.get(evidence_key)
        if not definition:
            continue
        aliases = [str(alias).lower() for alias in definition.get("aliases", [])] + [str(definition.get("label") or "").lower()]
        for attempt in attempts:
            text = " ".join(str(attempt.get(field) or "") for field in ("test_name", "test_area", "credential_name")).lower()
            if not any(alias and alias in text for alias in aliases):
                continue
            score = _number(attempt.get("score"))
            passed = _pass_rule(definition.get("pass_rule"), score, attempt.get("status") or attempt.get("pass_fail"))
            candidates.append((passed, score, {"source": "attempt", "label": attempt.get("test_name") or attempt.get("credential_name") or evidence_key, "value": score if score is not None else attempt.get("status", ""), "date": attempt.get("test_date", "")}))
    if not candidates:
        return None, []
    candidates.sort(key=lambda item: (item[0], item[1] is not None, item[1] or -1), reverse=True)
    best = candidates[0]
    return ("Passed" if best[0] else (best[1] if best[1] is not None else "Not Passed")), [item[2] for item in candidates]


def _custom_value(requirement, evidence_definitions, values):
    possible = [requirement["key"], requirement.get("label", "")]
    for evidence_key in requirement.get("evidence_keys", []):
        definition = evidence_definitions.get(evidence_key, {})
        possible.extend(definition.get("aliases", []))
        possible.append(definition.get("label", ""))
    normalized = {_norm(key): value for key, value in values.items()}
    for key in possible:
        if _norm(key) in normalized:
            value = normalized[_norm(key)]
            return value, [{"source": "custom field", "label": key, "value": value}]
    return None, []


def _evaluate_relationship(requirement, relationship, results):
    children = [results[key] for key in relationship["child_requirements"]]
    met_count = sum(item["status"] == "Met" for item in children)
    kind = relationship["type"]
    if kind == "all_of":
        met = met_count == len(children)
    elif kind in {"any_of", "alternative"}:
        met = met_count >= 1
    else:
        met = met_count >= relationship["minimum"]
    evidence = [{"source": "calculation", "label": item["label"], "value": item["status"]} for item in children]
    return _result(requirement, "Met" if met else "Not Met", f"{met_count} of {len(children)}", evidence, f"{relationship['type']} relationship: {met_count} of {len(children)} child requirements met.")


def _compare(value, operator, threshold, kind):
    if kind in {"assessment", "credential"}:
        return str(value).lower() in {"passed", "pass", "met"}
    if operator in {">=", ">", "<=", "<", "=", "=="}:
        left = _number(value)
        right = _number(threshold)
        if left is None or right is None:
            return False
        return {">=": left >= right, ">": left > right, "<=": left <= right, "<": left < right, "=": left == right, "==": left == right}[operator]
    if operator == "checked":
        return str(value).strip().lower() in MET_STATUSES | {"1", "y"}
    if operator == "nonblank" or not operator:
        return value not in (None, "")
    if operator == "is":
        return str(value).strip().lower() == str(threshold).strip().lower()
    if operator == "is_not":
        return str(value).strip().lower() != str(threshold).strip().lower()
    return False


def _pass_rule(rule, score, status):
    if not rule:
        return str(status or "").strip().lower() in MET_STATUSES
    return _compare(score if score is not None else status, rule.get("operator"), rule.get("threshold"), "number")


def _package_applies(package, student):
    cohort = student.get("graduation_class")
    if package.get("cohort_start") and (not cohort or int(cohort) < int(package["cohort_start"])):
        return False, "Student cohort is before the package cohort range."
    if package.get("cohort_end") and (not cohort or int(cohort) > int(package["cohort_end"])):
        return False, "Student cohort is after the package cohort range."
    as_of = student.get("as_of_date")
    if as_of:
        current = date.fromisoformat(str(as_of))
        if package.get("effective_from") and current < date.fromisoformat(package["effective_from"]):
            return False, "Evaluation date is before the package effective date."
        if package.get("effective_to") and current > date.fromisoformat(package["effective_to"]):
            return False, "Evaluation date is after the package effective date."
    return True, "Package applies to this fake student."


def _requirement_applies(requirement, student, plan):
    scopes = requirement.get("diploma_scope", [])
    if scopes and plan["key"] not in scopes:
        return False
    cohort = student.get("graduation_class")
    if requirement.get("cohort_start") and (not cohort or int(cohort) < int(requirement["cohort_start"])):
        return False
    if requirement.get("cohort_end") and (not cohort or int(cohort) > int(requirement["cohort_end"])):
        return False
    return True


def _select_plan(plans, diploma_type):
    wanted = _norm(diploma_type)
    for plan in plans:
        if wanted in {_norm(plan.get("key")), _norm(plan.get("name"))}:
            return plan
    return plans[0] if len(plans) == 1 else None


def _completed_course(course):
    status = str(course.get("status") or "completed").strip().lower()
    return status in {"completed", "complete", "passed", "earned"} and (_number(course.get("earned_credits")) or 0) > 0


def _result(requirement, status, value, evidence, explanation):
    return {"key": requirement["key"], "label": requirement["label"], "status": status, "value": value, "evidence": evidence, "explanation": explanation}


def _explanation(requirement, value, met):
    target = f" {requirement.get('operator', '')} {requirement.get('threshold', '')}".rstrip()
    return f"Observed {value!s}; required{target}. Result: {'met' if met else 'not met'}."


def _number(value):
    if isinstance(value, bool) or value in (None, ""):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    match = re.search(r"-?\d+(?:\.\d+)?", str(value))
    return float(match.group(0)) if match else None


def _norm(value):
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())
