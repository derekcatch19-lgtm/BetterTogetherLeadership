import difflib
import json
import os
import re
import uuid
from datetime import date

import pandas as pd

from .rule_engine import normalize_area, parse_score
from .rule_packs import recompute_student_for_active_pack

CANONICAL_FIELDS = {
    "first_name": ["first name", "firstname", "student first name", "given name"],
    "last_name": ["last name", "lastname", "student last name", "surname"],
    "student_name": ["student name", "full name", "name"],
    "middle_name": ["middle name", "middle initial"],
    "student_number": ["student id", "studentid", "student number", "local student id", "sis student id", "state testing id", "state testing identifier", "state testing identifier sti", "testing identifier", "sis id"],
    "state_student_id": ["state student id", "state student number", "ssid", "state id"],
    "graduation_class": ["graduation year", "grad year", "graduation class", "cohort"],
    "grade_level": ["grade", "grade level", "current grade"],
    "test_name": ["test name", "assessment", "exam"],
    "test_area": ["test area", "subject", "area", "verified credit area", "content area", "class"],
    "score": ["score", "scale score", "scaled score", "test scaled score", "sol score", "mastery score", "class grade", "level score", "certificate level"],
    "pass_fail": ["pass fail", "pass/fail", "status", "result", "performance level", "lavc awarded"],
    "test_date": ["test date", "date"],
    "course": ["course", "course name"],
    "credential_name": ["credential name", "credential", "certification", "assessment name", "test title"],
    "diploma_type": ["diploma type", "diploma"],
    "sped_504_status": ["special education", "sped", "sp", "504", "special education / 504 status"],
    "counselor": ["counselor", "school counselor"],
    "notes": ["notes", "general notes"],
}

WIDE_SOL_COLUMNS = {
    "ESCI": ["esci", "earth science"],
    "Bio": ["bio", "biology"],
    "Chem": ["chem", "chemistry"],
    "AlgI": ["algi", "algebra i", "algebra 1"],
    "Geom": ["geom", "geometry"],
    "AlgII": ["algii", "algebra ii", "algebra 2"],
    "EngRLR": ["engrlr", "english reading"],
    "EngWrit": ["engwrit", "english writing"],
    "WGeo": ["wgeo", "world geography"],
    "WHI": ["whi", "world history i"],
    "WHII": ["whii", "world history ii"],
    "USH": ["ush", "us history", "u.s. history"],
}

WIDE_REQUIREMENT_COLUMNS = {
    "Student Service Learning Project Complete": ["slp", "service learning"],
    "CCRI": ["ccri"],
    "Credential Test": ["cred"],
    "NCRC": ["ncrc"],
    "Workplace Readiness": ["wpr", "workplace readiness"],
    "CPR/AED Complete": ["cpr", "aed"],
    "Dual Enrollment": ["dual enrollment"],
    "ASVAB": ["asvab"],
}

MANUALLY_PROTECTED_STUDENT_FIELDS = {"diploma_type", "sped_504_status", "counselor"}
MANUAL_FIELD_ALIASES = {
    "diploma_type": {"diploma_type", "diploma type", "diploma"},
    "sped_504_status": {"sped_504_status", "sped / 504 status", "sped/504 status", "special education / 504 status"},
    "counselor": {"counselor", "school counselor"},
}


def _manual_field_locked(db, student_pk, field_name):
    """Return true when a counselor/admin has explicitly confirmed this field."""
    if field_name not in MANUALLY_PROTECTED_STUDENT_FIELDS:
        return False
    aliases = {value.lower() for value in MANUAL_FIELD_ALIASES[field_name]}
    rows = db.execute(
        "SELECT field_name FROM manual_edits WHERE student_id_fk = ?",
        (student_pk,),
    ).fetchall()
    return any(str(row["field_name"] or "").strip().lower() in aliases for row in rows)


def _protected_support_upload_value(existing_value, incoming_value):
    """Do not let a generic/default N erase an established IEP or 504 value."""
    existing = _normalize_sped_504(existing_value)
    incoming = _normalize_sped_504(incoming_value)
    if existing in {"Y", "504"} and incoming in {"", "N"}:
        return existing_value
    return incoming or existing_value


def read_upload_preview(path):
    frame = _read_frame(path)
    return {
        "columns": list(frame.columns),
        "suggestions": suggest_mapping(list(frame.columns)),
        "preview": frame.head(10).fillna("").to_dict(orient="records"),
    }


def suggest_mapping(columns):
    normalized = {col: _norm(col) for col in columns}
    mapping = {}
    used_columns = set()
    # Reserve exact field/alias matches before fuzzy matching. This prevents a
    # single "Student Name" column from also being assigned as "First Name".
    for field, aliases in CANONICAL_FIELDS.items():
        accepted = {_norm(field), *(_norm(alias) for alias in aliases)}
        for column, value in normalized.items():
            if column not in used_columns and value in accepted:
                mapping[field] = column
                used_columns.add(column)
                break
    for field, aliases in CANONICAL_FIELDS.items():
        if field in mapping:
            continue
        choices = [value for column, value in normalized.items() if column not in used_columns]
        match = difflib.get_close_matches(_norm(field), choices, n=1, cutoff=0.84)
        if not match:
            for alias in aliases:
                match = difflib.get_close_matches(_norm(alias), choices, n=1, cutoff=0.84)
                if match:
                    break
        if match:
            original = next(
                col for col, value in normalized.items()
                if col not in used_columns and value == match[0]
            )
            mapping[field] = original
            used_columns.add(original)
    for field, aliases in {"diploma_type": ["dip"], "sped_504_status": ["sp"], "notes": ["notes"]}.items():
        if field not in mapping:
            for column, value in normalized.items():
                if value in aliases:
                    mapping[field] = column
                    break
    return mapping


def save_incoming_file(file_storage, upload_folder):
    safe = secure_filename(file_storage.filename)
    stored = f"{uuid.uuid4().hex}_{safe}"
    path = os.path.join(upload_folder, stored)
    file_storage.save(path)
    return safe, stored, path


def process_upload(db, path, original_filename, stored_filename, user_id, source_type, note, mapping, grid_action="", grid_class_override=""):
    frame = _read_frame(path).fillna("")
    frame = frame.rename(columns={column: _clean_header(column) for column in frame.columns})
    mapping = {field: str(column).strip() for field, column in mapping.items() if column}
    is_pba = "pba" in f"{source_type} {original_filename} {note}".lower()
    pba_component_file = bool(
        _first_existing_column(frame, ["PBA #1", "PBA Score #1", "Score #1", "First Score"])
        and _first_existing_column(frame, ["PBA #2", "PBA Score #2", "Score #2", "Second Score"])
    )
    source_text = f"{source_type} {original_filename} {note}".lower()
    is_blw = "business letter writing" in source_text or bool(re.search(r"\bblw\b", source_text))
    is_workplace_docs = "workplace documents" in source_text or "workplace docs" in source_text
    is_ncrc = "ncrc" in source_text or "national career readiness" in source_text
    is_wpr = "workplace readiness" in source_text or re.search(r"\bwpr\b", source_text)
    is_credential = "credential" in source_text and not is_ncrc and not is_wpr
    is_asvab = "asvab" in source_text or _first_existing_column(frame, ["ASVAB AFQT Score", "1st Attempt (1/29/25)", "2nd Attempt (9/24/25) (9/26/25 begins with McCormick)"])
    is_grid_upload = _is_grid_upload(source_text, frame)
    is_custom_tracking = "custom tracking" in source_text or "local tracking spreadsheet" in source_text
    grid_class_override_text = str(grid_class_override or "").strip()
    grid_class_override = _parse_graduation_class(grid_class_override_text)
    if grid_class_override_text and not grid_class_override:
        raise ValueError(
            f'Graduation class "{grid_class_override_text}" was not recognized. '
            "Enter a four-digit year such as 2027 or Class of 2027."
        )
    if is_pba and pba_component_file:
        mapping.pop("graduation_class", None)
        mapping.setdefault("test_area", _first_existing_column(frame, ["Class", "Course", "Content Area", "Subject"]))
        mapping.pop("score", None)
        mapping.setdefault("pass_fail", _first_existing_column(frame, ["LAVC Awarded (Box Checked)", "LAVC Awarded", "Passed", "Result"]))
    inferred_grad_class = _infer_grad_class(note, source_type, original_filename, stored_filename, path)
    upload_id = db.execute(
        """
        INSERT INTO upload_history
        (original_filename, stored_filename, uploaded_by, user_note, data_source_type)
        VALUES (?, ?, ?, ?, ?)
        """,
        (original_filename, stored_filename, user_id, note, source_type),
    ).lastrowid

    processed = updates = warnings = 0
    touched_students = set()
    imported_custom_columns = set()
    custom_values_by_student = {}
    for _, row in frame.iterrows():
        processed += 1
        data = {field: _cell_value(row.get(_clean_header(column), "")) for field, column in mapping.items() if column}
        # Recover familiar vendor columns even when an older mapping screen or
        # a missed selection does not submit them. Explicit mappings still win.
        for field, aliases in CANONICAL_FIELDS.items():
            if not data.get(field):
                data[field] = _cell_by_alias(row, [field, *aliases])
        composite_test_date = _student_test_date_from_parts(row)
        if composite_test_date:
            data["test_date"] = composite_test_date
        if data.get("student_name") and (not data.get("first_name") or not data.get("last_name")):
            parsed_first, parsed_last = _split_student_name(data["student_name"])
            data["first_name"] = data.get("first_name") or parsed_first
            data["last_name"] = data.get("last_name") or parsed_last
        if not data.get("diploma_type"):
            data["diploma_type"] = _cell_by_alias(row, ["dip", "diploma"])
        data["sped_504_status"] = _normalize_sped_504(
            data.get("sped_504_status") or _cell_by_alias(row, ["sp", "sped", "504"])
        )
        parsed_class = _parse_graduation_class(data.get("graduation_class"))
        if parsed_class:
            data["graduation_class"] = str(parsed_class)
        elif data.get("grade_level"):
            data["graduation_class"] = str(_grad_class_from_grade(data["grade_level"]) or "")
        row_is_pba = "pba" in f"{data.get('test_name', '')} {data.get('test_area', '')}".lower()
        if pba_component_file or row_is_pba:
            data["test_name"] = data.get("test_name") or "History PBA"
            average_score = _pba_average_score(row)
            if _has_meaningful_value(average_score):
                data["score"] = average_score
            if not data.get("graduation_class"):
                data["graduation_class"] = str(_grad_class_from_grade(row.get("Grade", "")) or "")
            if pba_component_file:
                # In the official PBA results file, the LAVC award checkbox is
                # authoritative. An unchecked/blank box is an explicit failure,
                # even when component scores are present.
                data["pass_fail"] = "Pass" if _pba_passed(row) else "Fail"
            elif _pba_passed(row):
                data["pass_fail"] = "Pass"
        if is_asvab:
            data["test_name"] = data.get("test_name") or "ASVAB"
            data["test_area"] = data.get("test_area") or "ASVAB"
            if not data.get("graduation_class"):
                data["graduation_class"] = str(_asvab_grad_class(row, source_text, inferred_grad_class) or "")
        if is_blw:
            data["test_name"] = "Business Letter Writing"
            data["test_area"] = "EngWrit"
            substitute_score, _, _ = parse_score(data.get("score"))
            if substitute_score is not None:
                data["pass_fail"] = "Pass" if substitute_score >= 3 else "Fail"
        if is_workplace_docs and not is_ncrc:
            data["test_name"] = "Workplace Documents"
            data["test_area"] = "EngRLR"
            substitute_score, _, _ = parse_score(data.get("score"))
            if substitute_score is not None:
                data["pass_fail"] = "Pass" if substitute_score >= 4 else "Fail"
        if is_ncrc:
            component = data.get("credential_name") or data.get("test_name") or data.get("test_area") or _ncrc_component_from_row(row)
            data["test_name"] = "NCRC"
            data["test_area"] = "NCRC"
            data["credential_name"] = component or "NCRC"
            if _ncrc_component_passed(data.get("score")):
                data["pass_fail"] = "Pass"
            elif data.get("score"):
                data["pass_fail"] = "Fail"
        if is_wpr:
            data["test_name"] = data.get("test_name") or "Workplace Readiness"
            data["test_area"] = "Workplace Readiness"
            data["credential_name"] = data.get("credential_name") or "Workplace Readiness"
            if _wpr_passed(data.get("score")):
                data["pass_fail"] = "Pass"
            elif data.get("score"):
                data["pass_fail"] = "Fail"
        if is_credential:
            data["test_name"] = data.get("test_name") or "Credential"
            data["test_area"] = "Credential Test"
            if data.get("credential_name") and not data.get("pass_fail"):
                data["pass_fail"] = "Pass"
        if not data.get("graduation_class") and inferred_grad_class:
            data["graduation_class"] = str(inferred_grad_class)
        if grid_class_override and grid_action != "split_by_year":
            data["graduation_class"] = str(grid_class_override)
        custom_values = {}
        if is_grid_upload or is_custom_tracking:
            custom_notes, custom_columns, custom_values = _unknown_grid_column_notes(row, mapping)
            imported_custom_columns.update(custom_columns)
            if custom_notes:
                data["notes"] = " | ".join(part for part in [data.get("notes", ""), custom_notes] if part)
        has_identity = bool(data.get("student_number") or data.get("state_student_id") or (data.get("first_name") and data.get("last_name")))
        if not has_identity or (is_grid_upload and not data.get("graduation_class")):
            _record_unmatched(db, upload_id, data, "Missing name or graduation class needed for matching.")
            warnings += 1
            continue
        student_pk, changed = _upsert_student(db, data, allow_create=is_grid_upload)
        student_pks = [student_pk] if student_pk else []
        if not student_pks:
            issue = (
                "Multiple possible students found. Add Student ID or graduation class before importing."
                if _has_multiple_student_matches(db, data)
                else "No matching student found. Review spelling, student ID, and graduation class."
            )
            _record_unmatched(db, upload_id, data, issue)
            warnings += 1
            continue
        updates += 1 if changed else 0
        for student_pk in student_pks:
            if is_grid_upload:
                student_status = db.execute("SELECT enrollment_status FROM students WHERE id=?", (student_pk,)).fetchone()
                if not student_status or (student_status["enrollment_status"] or "Active") == "Active":
                    db.execute(
                        """
                        INSERT OR IGNORE INTO class_grid_members(student_id_fk, graduation_class, source_upload_id)
                        VALUES (?, ?, ?)
                        """,
                        (student_pk, int(float(data["graduation_class"])), upload_id),
                    )
            if custom_values:
                custom_values_by_student.setdefault(student_pk, {}).update(custom_values)
            touched_students.add(student_pk)

            ncrc_updates = _insert_ncrc_attempts(db, student_pk, row, upload_id) if is_ncrc else 0
            updates += ncrc_updates
            if not is_asvab and not ncrc_updates and (
                data.get("score") or data.get("test_area") or data.get("test_name")
                or data.get("pass_fail") or data.get("credential_name")
            ):
                score, multi, failed = parse_score(data.get("score"))
                area = normalize_area(data.get("test_area"), data.get("test_name"))
                repaired = _repair_blank_score_attempt(
                    db, student_pk, area, data.get("test_name"), data.get("test_date"),
                    score, data.get("score") or data.get("credential_name"),
                    data.get("pass_fail"), data.get("course"), data.get("credential_name"),
                    upload_id, failed, multi,
                )
                if not repaired:
                    db.execute(
                        """
                        INSERT INTO test_attempts
                        (student_id_fk, test_name, test_area, score, raw_score, pass_fail, test_date, course,
                         credential_name, source_upload_id, failed_course_indicator, multiple_attempt_indicator)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            student_pk,
                            data.get("test_name"),
                            area,
                            score,
                            data.get("score") or data.get("credential_name"),
                            data.get("pass_fail"),
                            data.get("test_date"),
                            data.get("course"),
                            data.get("credential_name"),
                            upload_id,
                            1 if failed else 0,
                            1 if multi else 0,
                        ),
                    )
                updates += 1
            if is_asvab:
                updates += _insert_asvab_attempts(db, student_pk, row, upload_id)
            else:
                updates += _insert_wide_grid_attempts(db, student_pk, row, upload_id)

    for student_pk in touched_students:
        if custom_values_by_student.get(student_pk):
            _save_custom_grid_values(db, student_pk, custom_values_by_student[student_pk])
        recompute_student_for_active_pack(db, student_pk)
        if custom_values_by_student.get(student_pk) and _is_virginia_template(db):
            # Virginia status refresh rebuilds its known requirement rows. Put
            # school-defined fields back on the visible grid after that refresh;
            # the durable evidence copy was already written before calculation.
            _save_custom_grid_values(db, student_pk, custom_values_by_student[student_pk])
    if imported_custom_columns:
        _register_custom_fields(db, imported_custom_columns)

    db.execute(
        """
        UPDATE upload_history
        SET records_processed = ?, updates_made = ?, conflicts_warnings = ?
        WHERE id = ?
        """,
        (processed, updates, warnings, upload_id),
    )
    db.commit()
    return upload_id, processed, updates, warnings


def _repair_blank_score_attempt(
    db, student_pk, area, test_name, test_date, score, raw_score, pass_fail,
    course, credential_name, upload_id, failed, multi,
):
    if score is None or not area:
        return False
    existing = db.execute(
        """
        SELECT id FROM test_attempts
        WHERE student_id_fk = ? AND test_area = ? AND score IS NULL
          AND COALESCE(test_date, '') = COALESCE(?, '')
          AND LOWER(COALESCE(test_name, '')) = LOWER(COALESCE(?, ''))
        ORDER BY id
        LIMIT 1
        """,
        (student_pk, area, test_date, test_name),
    ).fetchone()
    if not existing:
        return False
    db.execute(
        """
        UPDATE test_attempts
        SET score=?, raw_score=?, pass_fail=?, course=?, credential_name=?,
            source_upload_id=?, failed_course_indicator=?,
            multiple_attempt_indicator=?
        WHERE id=?
        """,
        (
            score, raw_score, pass_fail, course, credential_name, upload_id,
            1 if failed else 0, 1 if multi else 0, existing["id"],
        ),
    )
    return True


def _unknown_grid_column_notes(row, mapping):
    mapped_columns = {str(column).strip() for column in mapping.values() if column}
    known_columns = set(mapped_columns)
    for aliases in list(WIDE_SOL_COLUMNS.values()) + list(WIDE_REQUIREMENT_COLUMNS.values()):
        column = _first_existing_column(pd.DataFrame(columns=row.index), aliases)
        if column:
            known_columns.add(column)
    notes = []
    custom_columns = []
    custom_values = {}
    for column in row.index:
        column_text = str(column).strip()
        if not column_text or column_text in known_columns:
            continue
        value = _cell_value(row.get(column, ""))
        if not _has_meaningful_value(value):
            continue
        notes.append(f"{column_text}: {value}")
        custom_columns.append(column_text)
        custom_values[column_text] = value
    return "; ".join(notes[:20]), custom_columns, custom_values


def _save_custom_grid_values(db, student_pk, values):
    fields = _custom_field_definitions(db)
    for column, value in values.items():
        field = _match_custom_field(fields, column)
        name = field.get("name", column) if field else column
        status, score = _custom_value_status(field or {"type": "text", "completion_rule": "nonblank"}, value)
        db.execute(
            """
            INSERT INTO requirement_status(student_id_fk, requirement_key, status, display_value, score, source, needs_retest, updated_at)
            VALUES (?, ?, ?, ?, ?, 'Imported Custom Grid Field', 0, CURRENT_TIMESTAMP)
            ON CONFLICT(student_id_fk, requirement_key) DO UPDATE SET
              status = excluded.status,
              display_value = excluded.display_value,
              score = excluded.score,
              source = excluded.source,
              updated_at = CURRENT_TIMESTAMP
            """,
            (student_pk, name, status, str(value), score),
        )
        db.execute(
            """
            INSERT INTO custom_field_values(student_id_fk, field_key, status, display_value, score, source, updated_at)
            VALUES (?, ?, ?, ?, ?, 'Imported Custom Grid Field', CURRENT_TIMESTAMP)
            ON CONFLICT(student_id_fk, field_key) DO UPDATE SET
              status=excluded.status, display_value=excluded.display_value,
              score=excluded.score, source=excluded.source, updated_at=CURRENT_TIMESTAMP
            """,
            (student_pk, name, status, str(value), score),
        )


def _custom_field_definitions(db):
    row = db.execute("SELECT value FROM app_settings WHERE key = 'custom_fields_config'").fetchone()
    try:
        parsed = json.loads(row["value"] or "[]") if row else []
        return [item for item in parsed if isinstance(item, dict)]
    except json.JSONDecodeError:
        return []


def _is_virginia_template(db):
    row = db.execute("SELECT value FROM app_settings WHERE key='graduation_template_type'").fetchone()
    return not row or (row["value"] or "Virginia Template") == "Virginia Template"


def _match_custom_field(fields, column):
    normalized = _norm(column)
    for field in fields:
        aliases = [field.get("name", "")] + re.split(r"[,;\n]+", field.get("import_aliases", ""))
        if normalized in {_norm(alias) for alias in aliases if str(alias).strip()}:
            return field
    return None


def _custom_value_status(field, value):
    text = str(value or "").strip()
    field_type = str(field.get("type", "text")).lower()
    rule = str(field.get("completion_rule", "nonblank")).strip().lower()
    score = None
    if field_type in {"number", "score"}:
        match = re.search(r"-?\d+(?:\.\d+)?", text)
        score = float(match.group(0)) if match else None
    if rule in {"checked", "true", "yes"} or field_type == "checkbox":
        return ("Met" if _truthy_value(text) else "Missing"), score
    threshold = re.match(r"^(>=|>|<=|<)\s*(-?\d+(?:\.\d+)?)$", rule)
    if threshold and score is not None:
        operator, target_text = threshold.groups()
        target = float(target_text)
        met = {">=": score >= target, ">": score > target, "<=": score <= target, "<": score < target}[operator]
        return ("Met" if met else "Not Met"), score
    equals = re.match(r"^equals?\s+(.+)$", rule)
    if equals:
        return ("Met" if text.lower() == equals.group(1).strip().lower() else "Not Met"), score
    return ("Met" if _has_meaningful_value(text) else "Missing"), score


def _register_custom_fields(db, columns):
    row = db.execute("SELECT value FROM app_settings WHERE key = 'custom_fields_config'").fetchone()
    try:
        existing = json.loads(row["value"] or "[]") if row else []
    except json.JSONDecodeError:
        existing = []
    existing_names = {str(item.get("name", "")).strip().lower() for item in existing if isinstance(item, dict)}
    changed = False
    for column in sorted(columns):
        if column.lower() in existing_names:
            continue
        existing.append({"name": column, "type": "notes", "options": "", "notes": "Imported from existing graduation grid"})
        existing_names.add(column.lower())
        changed = True
    if changed:
        db.execute(
            "INSERT INTO app_settings(key, value, updated_at) VALUES ('custom_fields_config', ?, CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP",
            (json.dumps(existing, indent=2),),
        )


def _record_unmatched(db, upload_id, data, issue):
    db.execute(
        """
        INSERT INTO unmatched_records
        (source_upload_id, record_type, first_name, middle_name, last_name, student_id, graduation_class, issue, raw_json)
        VALUES (?, 'Upload', ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            upload_id,
            data.get("first_name", ""),
            data.get("middle_name", ""),
            data.get("last_name", ""),
            data.get("student_number", "") or data.get("student_id", "") or data.get("state_student_id", ""),
            data.get("graduation_class", ""),
            issue,
            json.dumps(data, ensure_ascii=True),
        ),
    )


def _upsert_student(db, data, allow_create=True):
    data["first_name"] = str(data.get("first_name") or "").strip().upper()
    data["middle_name"] = str(data.get("middle_name") or "").strip().upper()
    data["last_name"] = str(data.get("last_name") or "").strip().upper()
    student_number = (data.get("student_number") or data.get("state_student_id") or "").strip() or None
    try:
        grad_class = int(float(data.get("graduation_class", "")))
    except (TypeError, ValueError):
        grad_class = None
    existing = None
    if student_number and grad_class:
        existing = db.execute(
            "SELECT * FROM students WHERE student_id = ? AND graduation_class = ? AND COALESCE(enrollment_status,'Active')='Active'",
            (student_number, grad_class),
        ).fetchone()
    if student_number and not existing:
        existing = _single_student_match(
            db,
            "SELECT * FROM students WHERE student_id = ? AND COALESCE(enrollment_status,'Active')='Active'",
            (student_number,),
        )
    if not existing:
        if grad_class:
            existing = db.execute(
                """
                SELECT * FROM students
                WHERE lower(last_name) = lower(?) AND lower(first_name) = lower(?) AND graduation_class = ?
                  AND COALESCE(enrollment_status,'Active')='Active'
                """,
                (data["last_name"], data["first_name"], grad_class),
            ).fetchone()
        else:
            existing = _single_student_match(
                db,
                """
                SELECT * FROM students
                WHERE lower(last_name) = lower(?) AND lower(first_name) = lower(?)
                  AND COALESCE(enrollment_status,'Active')='Active'
                """,
                (data["last_name"], data["first_name"]),
            )
    if not existing and not grad_class and not allow_create:
        existing = _fuzzy_single_student_match(db, data["last_name"], data["first_name"])
    if existing and grad_class is None:
        grad_class = existing["graduation_class"]
    if grad_class is None:
        return None, False
    values = (
        student_number,
        data["first_name"],
        data.get("middle_name"),
        data["last_name"],
        grad_class,
        data.get("diploma_type") or "Standard",
        _normalize_sped_504(data.get("sped_504_status")) or "N",
        data.get("counselor") or counselor_for_last_name(db, data["last_name"]),
        data.get("notes"),
    )
    if existing:
        incoming_diploma = (data.get("diploma_type") or "").strip()
        incoming_sped = _normalize_sped_504(data.get("sped_504_status"))
        incoming_counselor = (data.get("counselor") or "").strip()
        diploma_type = (
            existing["diploma_type"]
            if _manual_field_locked(db, existing["id"], "diploma_type")
            else incoming_diploma or existing["diploma_type"]
        )
        sped_504_status = (
            existing["sped_504_status"]
            if _manual_field_locked(db, existing["id"], "sped_504_status")
            else _protected_support_upload_value(existing["sped_504_status"], incoming_sped)
        )
        counselor = (
            existing["counselor"]
            if _manual_field_locked(db, existing["id"], "counselor")
            else incoming_counselor or existing["counselor"]
        )
        db.execute(
            """
            UPDATE students
            SET student_id = COALESCE(?, student_id), first_name = ?, middle_name = COALESCE(?, middle_name),
                last_name = ?, diploma_type = COALESCE(NULLIF(?, ''), diploma_type),
                sped_504_status = COALESCE(NULLIF(?, ''), sped_504_status),
                counselor = COALESCE(NULLIF(?, ''), counselor), notes = COALESCE(NULLIF(?, ''), notes),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            values[:4] + (diploma_type, sped_504_status, counselor, values[8], existing["id"]),
        )
        return existing["id"], True
    if not allow_create:
        return None, False
    student_pk = db.execute(
        """
        INSERT INTO students
        (student_id, first_name, middle_name, last_name, graduation_class, diploma_type, sped_504_status, counselor, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        values,
    ).lastrowid
    return student_pk, True


def _single_student_match(db, query, params):
    rows = db.execute(query, params).fetchmany(2)
    if len(rows) == 1:
        return rows[0]
    return None


def _has_multiple_student_matches(db, data):
    student_number = (data.get("student_number") or data.get("state_student_id") or "").strip()
    if student_number:
        matches = db.execute("SELECT id FROM students WHERE student_id = ? AND COALESCE(enrollment_status,'Active')='Active'", (student_number,)).fetchall()
        if len(matches) > 1:
            return True
    first_name = data.get("first_name", "")
    last_name = data.get("last_name", "")
    if not first_name or not last_name:
        return False
    matches = db.execute(
        "SELECT id FROM students WHERE lower(last_name)=lower(?) AND lower(first_name)=lower(?) AND COALESCE(enrollment_status,'Active')='Active'",
        (last_name, first_name),
    ).fetchall()
    return len(matches) > 1 or len(_fuzzy_student_matches(db, last_name, first_name)) > 1


def _fuzzy_single_student_match(db, last_name, first_name):
    matches = _fuzzy_student_matches(db, last_name, first_name)
    return matches[0] if len(matches) == 1 else None


def _fuzzy_student_matches(db, last_name, first_name):
    first = _letters_only(first_name)
    last = _letters_only(last_name)
    if len(first) < 3 or len(last) < 3:
        return []
    matches = []
    for student in db.execute("SELECT * FROM students WHERE COALESCE(enrollment_status,'Active')='Active'"):
        student_first = _letters_only(student["first_name"])
        student_last = _letters_only(student["last_name"])
        first_ok = first == student_first or first.startswith(student_first) or student_first.startswith(first)
        last_ok = last == student_last or last.startswith(student_last) or student_last.startswith(last)
        if first_ok and last_ok:
            matches.append(student)
    return matches


def _update_existing_student_from_upload(db, student_pk, data):
    counselor = None if _manual_field_locked(db, student_pk, "counselor") else data.get("counselor")
    db.execute(
        """
        UPDATE students
        SET student_id = COALESCE(?, student_id),
            counselor = COALESCE(NULLIF(?, ''), counselor),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (data.get("student_number") or None, counselor, student_pk),
    )


def counselor_for_last_name(db, last_name):
    text = str(last_name or "").strip().lower()
    letters = "".join(ch for ch in text if ch.isalpha())
    if not letters:
        return ""
    assignments = _counselor_assignment_text(db)
    return _match_counselor_assignment(assignments, letters)


def _counselor_assignment_text(db):
    try:
        row = db.execute("SELECT value FROM app_settings WHERE key = 'counselors'").fetchone()
    except Exception:
        return ""
    return row["value"] if row and row["value"] else ""


def _match_counselor_assignment(assignments, last_letters):
    for segment in re.split(r"[;\n]+", assignments or ""):
        cleaned = segment.strip()
        if not cleaned:
            continue
        match = re.search(
            r"(.+?)\s+(?:is\s+)?([A-Za-z]{1,3})\s*[-–]\s*([A-Za-z]{1,3})",
            cleaned,
            flags=re.I,
        )
        if not match:
            continue
        counselor, start, end = match.groups()
        if _letters_in_range(last_letters, start, end):
            return counselor.strip(" :-")
    return ""


def _letters_in_range(last_letters, start, end):
    start_key = _letters_only(start)
    end_key = _letters_only(end)
    if not start_key or not end_key:
        return False
    return last_letters[: len(start_key)] >= start_key and last_letters[: len(end_key)] <= end_key


def _is_grid_upload(source_text, frame):
    if any(token in source_text for token in ["student roster", "class list", "student list", "powerschool roster", "infinite campus roster", "skyward roster", "existing graduation grid", "graduation tracking sheet", "sol_grid", " sol grid", "current sheet"]):
        return True
    if any(token in source_text for token in [
        "state assessment", "pearson", "pba", "transcript", "workplace readiness",
        "ncrc", "credential", "cpr", "aed", "asvab", "3e documentation",
    ]):
        return False
    sol_columns = sum(1 for aliases in WIDE_SOL_COLUMNS.values() if _first_existing_column(frame, aliases))
    roster_columns = bool(_first_existing_column(frame, ["Last Name", "Last_Name"])) and bool(_first_existing_column(frame, ["First Name", "First_Name"]))
    grad_or_grade = bool(_first_existing_column(frame, ["Graduation Year", "Grad Year", "Graduation Class", "Cohort", "Grade", "Grade Level"]))
    return roster_columns and (sol_columns >= 4 or grad_or_grade) and "asvab" not in source_text


def _insert_wide_grid_attempts(db, student_pk, row, upload_id):
    updates = 0
    for area_key, aliases in WIDE_SOL_COLUMNS.items():
        value = _cell_by_alias(row, aliases, prefer_unsuffixed=True)
        if not _has_meaningful_value(value):
            continue
        score, multi, failed = parse_score(value)
        db.execute(
            """
            INSERT INTO test_attempts
            (student_id_fk, test_name, test_area, score, raw_score, pass_fail, source_upload_id,
             failed_course_indicator, multiple_attempt_indicator)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (student_pk, "Existing Graduation Grid", area_key, score, value, _pass_fail_from_value(value), upload_id, 1 if failed else 0, 1 if multi else 0),
        )
        updates += 1
    for requirement_key, aliases in WIDE_REQUIREMENT_COLUMNS.items():
        value = _cell_by_alias(
            row,
            aliases,
            prefer_unsuffixed=True,
            exact_only=requirement_key == "Credential Test",
        )
        if not _has_meaningful_value(value):
            continue
        db.execute(
            """
            INSERT INTO test_attempts
            (student_id_fk, test_name, test_area, raw_score, pass_fail, source_upload_id)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (student_pk, "Existing Graduation Grid", requirement_key, value, "Complete" if _truthy_value(value) else value, upload_id),
        )
        updates += 1
    return updates


def _insert_asvab_attempts(db, student_pk, row, upload_id):
    updates = 0
    score_columns = [
        column for column in row.index
        if "asvab" in str(column).lower()
        or "afqt" in str(column).lower()
        or "attempt" in str(column).lower()
    ]
    for column in score_columns:
        value = _cell_value(row.get(column, ""))
        if not _has_meaningful_value(value):
            continue
        score, multi, failed = parse_score(value)
        if score is None:
            continue
        db.execute(
            """
            INSERT INTO test_attempts
            (student_id_fk, test_name, test_area, score, raw_score, pass_fail, source_upload_id,
             failed_course_indicator, multiple_attempt_indicator)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (student_pk, "ASVAB", "ASVAB", score, value, "Taken", upload_id, 1 if failed else 0, 1 if multi else 0),
        )
        updates += 1
    return updates


def _insert_ncrc_attempts(db, student_pk, row, upload_id):
    components = [
        ("Workplace Documents", ["workplace documents", "workplace docs", "workkeys workplace documents"]),
        ("Graphic Literacy", ["graphic literacy", "workkeys graphic literacy"]),
        ("Applied Math", ["applied math", "workkeys applied math"]),
    ]
    updates = 0
    for component, aliases in components:
        value = _cell_by_alias(row, aliases)
        if not _has_meaningful_value(value):
            continue
        score, multi, failed = parse_score(value)
        db.execute(
            """INSERT INTO test_attempts
            (student_id_fk,test_name,test_area,score,raw_score,pass_fail,credential_name,
             source_upload_id,failed_course_indicator,multiple_attempt_indicator)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (
                student_pk, "NCRC", "NCRC", score, value,
                "Pass" if _ncrc_component_passed(value) else "Fail",
                component, upload_id, 1 if failed else 0, 1 if multi else 0,
            ),
        )
        updates += 1
    return updates


def _read_frame(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in {".xlsx", ".xlsm", ".xls"}:
        return pd.read_excel(path, dtype=str)
    if ext == ".csv":
        return pd.read_csv(path, dtype=str)
    raise ValueError("Only Excel and CSV files are supported.")


def _clean_header(value):
    return " ".join(str(value).replace("\xa0", " ").strip().split())


def _letters_only(value):
    return "".join(ch for ch in str(value or "").lower() if ch.isalpha())


def _first_existing_column(frame, names):
    normalized = {_norm(column): column for column in frame.columns}
    for name in names:
        column = normalized.get(_norm(name))
        if column:
            return str(column).strip()
    return ""


def _parse_graduation_class(value):
    text = str(value or "").strip()
    if not text:
        return None
    match = re.search(r"\b(20\d{2})\b", text)
    if not match:
        return None
    year = int(match.group(1))
    return year if 2000 <= year <= 2100 else None


def _split_student_name(value):
    text = " ".join(str(value or "").strip().split())
    if "," in text:
        last, remainder = text.split(",", 1)
        first = remainder.strip().split()[0] if remainder.strip() else ""
        return first, last.strip()
    parts = text.split()
    return (parts[0], parts[-1]) if len(parts) >= 2 else ("", "")


def _grad_class_from_grade(value, today=None):
    text = str(value or "").strip()
    try:
        grade = int(float(text))
    except (TypeError, ValueError):
        match = re.search(r"\b(8|9|10|11|12)(?:st|nd|rd|th)?\b", text, flags=re.I)
        if not match:
            return None
        grade = int(match.group(1))
    if grade not in {8, 9, 10, 11, 12}:
        return None
    today = today or date.today()
    current_school_year_end = today.year + 1 if today.month >= 7 else today.year
    return current_school_year_end + (12 - grade)


def _asvab_grad_class(row, source_text, inferred_grad_class):
    if inferred_grad_class:
        return inferred_grad_class
    grade = row.get("Grade", row.get("Grade Level", ""))
    try:
        grade_number = int(float(str(grade).strip()))
    except (TypeError, ValueError):
        grade_number = None
    if "11th" in source_text or "11th grade" in source_text:
        return _grad_class_from_grade(11)
    if "10th" in source_text or "10th grade" in source_text:
        return _grad_class_from_grade(10)
    if grade_number in {8, 9, 10, 11, 12}:
        return _grad_class_from_grade(grade_number)
    return None


def _pba_passed(row):
    award_columns = ("LAVC Awarded (Box Checked)", "LAVC Awarded")
    row_columns = getattr(row, "index", row.keys() if hasattr(row, "keys") else ())
    for column in award_columns:
        if column in row_columns:
            awarded = str(row.get(column, "")).strip().lower()
            return awarded in {"true", "t", "yes", "y", "1", "pass", "passed", "awarded", "checked"}
    average = _pba_average_score(row)
    try:
        return float(average) >= 2
    except (TypeError, ValueError):
        return False


def _pba_average_score(row):
    scores = []
    for column in ["PBA #1", "PBA #1 ", "PBA #2", "PBA #2 "]:
        value = str(row.get(column, "")).strip()
        if not value:
            continue
        try:
            scores.append(float(value))
        except ValueError:
            pass
    if len(scores) < 2:
        return ""
    average = sum(scores[:2]) / 2
    if average.is_integer():
        return str(int(average))
    return f"{average:.2f}".rstrip("0").rstrip(".")


def _ncrc_component_from_row(row):
    for aliases in [["test name", "assessment", "exam"], ["test area", "subject", "area"], ["credential name", "credential"]]:
        value = _cell_by_alias(row, aliases)
        if value:
            return value
    return ""


def _ncrc_component_passed(value):
    text = str(value or "").strip().lower()
    if re.search(r"(^|[^a-z])f([^a-z]|$)", text):
        return False
    try:
        score = float(re.search(r"\d+(?:\.\d+)?", text).group(0))
    except (AttributeError, ValueError):
        return False
    return score >= 3


def _wpr_passed(value):
    try:
        score = float(re.search(r"\d+(?:\.\d+)?", str(value or "")).group(0))
    except (AttributeError, ValueError):
        return False
    return score >= 75


def _cell_by_alias(row, aliases, prefer_unsuffixed=False, exact_only=False):
    normalized_aliases = {_norm(alias) for alias in aliases}
    exact_candidates = []
    contains_candidates = []
    for column in row.index:
        column_text = str(column)
        if prefer_unsuffixed and "." in column_text:
            continue
        norm = _norm(column_text)
        if norm in normalized_aliases:
            exact_candidates.append(column)
        elif not exact_only and any(alias and alias in norm for alias in normalized_aliases):
            contains_candidates.append(column)
    candidates = sorted(exact_candidates, key=lambda value: (len(str(value)), str(value))) + sorted(contains_candidates, key=lambda value: (len(str(value)), str(value)))
    for column in candidates:
        value = _cell_value(row.get(column, ""))
        if value:
            return value
    return ""


def _student_test_date_from_parts(row):
    month = _cell_by_alias(row, ["Student Test Month", "Test Month"])
    day = _cell_by_alias(row, ["Student Test Day", "Test Day"])
    year = _cell_by_alias(row, ["Student Test Year", "Test Year"])
    if not (month and day and year):
        return ""
    try:
        parsed = date(int(float(year)), int(float(month)), int(float(day)))
    except (TypeError, ValueError):
        return ""
    return parsed.isoformat()


def _normalize_sped_504(value):
    text = str(value or "").strip()
    upper = text.upper()
    if upper in {"", "N", "NO", "FALSE", "0"}:
        return "N"
    if upper in {"Y", "YES", "TRUE", "1", "SPED", "IEP", "SPECIAL EDUCATION"}:
        return "Y"
    if upper in {"504", "504.0"}:
        return "504"
    return ""


def _cell_value(value):
    if hasattr(value, "tolist") and not isinstance(value, str):
        values = value.tolist()
    else:
        values = [value]
    for item in values:
        text = str(item).strip()
        if _has_meaningful_value(text):
            return text
    return ""


def _infer_grad_class(*values):
    class_years = set()
    for value in values:
        class_years.update(
            int(match)
            for match in re.findall(r"class\s*(?:of)?\s*(20\d{2})", str(value), flags=re.IGNORECASE)
        )
    if len(class_years) == 1:
        return next(iter(class_years))
    if len(class_years) > 1:
        return None
    inferred_years = set()
    for value in values:
        text = str(value)
        if re.search(r"\d{4}[-_/]\d{2}[-_/]\d{2}", text):
            continue
        inferred_years.update(int(match) for match in re.findall(r"\b(20\d{2})\b", text))
    return next(iter(inferred_years)) if len(inferred_years) == 1 else None


def _has_meaningful_value(value):
    text = str(value).strip()
    return bool(text) and text.lower() not in {"nan", "none", "false", "f", "no", "n", "0"}


def _truthy_value(value):
    return str(value).strip().lower() in {"true", "t", "yes", "y", "1", "complete", "completed"}


def _pass_fail_from_value(value):
    text = str(value).strip().lower()
    if text in {"pass", "passed", "p", "yes", "y", "true", "complete", "completed"}:
        return "Pass"
    return ""


def _norm(value):
    return "".join(ch for ch in str(value).lower() if ch.isalnum())


def secure_filename(filename):
    keep = []
    for char in os.path.basename(filename):
        if char.isalnum() or char in {".", "-", "_"}:
            keep.append(char)
        elif char.isspace():
            keep.append("_")
    value = "".join(keep).strip("._")
    return value or "upload"
