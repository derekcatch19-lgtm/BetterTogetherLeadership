# Custom Rule Activation and Rollback

Implemented: September 18, 2026

This development stage connects approved custom-state rule packages to a guarded activation workflow.

## Activation safeguards

1. Only an immutable Approved version can be activated.
2. The builder evaluates all active students in read-only preview mode.
3. The preview reports current and proposed statuses, changed-student count, On Track, Needs Review, and Not Applicable totals.
4. The Admin must type `ACTIVATE`.
5. The application creates an online SQLite backup and validates its integrity before database changes are committed.
6. Requirement results and evidence explanations are stored by rule key and version.
7. Compatibility status rows are updated for grids and reports.
8. The activation is written to the audit log.

## Ongoing recalculation

After activation, imports and manual edits that use the rule-pack recomputation boundary recalculate the affected student against the active custom package. The active package remains separate from Virginia calculations.

## Rollback

When a prior active custom version exists, Admin may type `ROLLBACK`. The system creates another verified backup, restores the previous version, recalculates students, and records the event in the audit log.

The implementation remains in the isolated `GIC_Development_2.0` workspace. It has not been copied into the protected AHS application or packaged for schools.
