# Custom Rule Evaluator: Preview Foundation

Implemented: September 18, 2026

The evaluator accepts a validated typed rule package and an in-memory fake-student snapshot. It returns requirement results, evidence, explanations, applicability, diploma plan, and overall preview status.

Supported in this stage:

- total completed transcript credits;
- subject credits using course families and aliases;
- assessment and credential evidence with explicit passing rules;
- custom checklist, number, text, and date values;
- diploma scope, cohort range, and package effective dates;
- all-of, any-of, count-of, and alternative relationships;
- deterministic explanation traces.

Safety boundary:

- The evaluator does not accept a database connection.
- It does not write students, requirement statuses, settings, files, or audit records.
- Invalid packages cannot be evaluated.
- It is not connected to custom-state activation or live student calculations.

Implementation: `app/services/custom_rule_evaluator.py`

Coverage: `tests/test_custom_rule_evaluator.py` uses fake students only.
