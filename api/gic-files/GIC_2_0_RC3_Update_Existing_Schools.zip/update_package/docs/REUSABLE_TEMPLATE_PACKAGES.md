# Reusable School and State Templates

GIC administrators can export a configuration-only JSON template from **Customize > School / State Templates** and import it into another installation.

## Included

- Custom tracking fields and report definitions
- Graduation agreement configuration
- Saved import profiles
- Main-grid column choices
- Structured custom graduation rules and sanitized version history

## Excluded

- Students and test attempts
- Users, passwords, and sessions
- Uploaded source documents
- Generated reports and exports
- Audit logs and application logs
- Databases and backups
- School branding and counselor assignments

The template contains a SHA-256 checksum. Import rejects unsupported, changed, oversized, binary, or student-data-bearing packages.

## Import Workflow

1. An Admin uploads the `.json` package.
2. GIC validates its extension, content, structure, checksum, and allowlisted sections.
3. GIC displays a readable preview and counts the included configuration items.
4. The Admin types `IMPORT TEMPLATE`.
5. GIC creates an integrity-checked database backup.
6. Configuration is imported and custom rules are saved as **Draft**.
7. The Admin reviews, validates, approves, previews, and activates the rules separately.

Importing a template does not remove students or users and does not recalculate graduation status. This keeps configuration sharing separate from school data and rule activation.
