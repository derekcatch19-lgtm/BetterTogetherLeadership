# Final Usability and Release Gate

Before generating pilot packages, run:

```powershell
python tools/run_release_readiness_gate.py
```

The gate groups the automated checks into complete staff workflows:

1. Virginia graduation calculations, phase-in rules, credentials, reports, checklists, agreements, and exports.
2. Roster/grid creation, assessment updates, transcript and specialty imports, student matching, duplicates, and saved mappings.
3. Custom-state rules, validation, approval, activation, recalculation, agreements, reports, reusable templates, and setup readiness.
4. Authentication, route authorization, CSRF, upload validation, backups, and live/demo isolation.
5. Counselor edits, manual protections, enrollment lifecycle, early graduation, and student-name consistency.

The gate then runs the complete test suite, confirms the protected AHS source fingerprint, and scans the development tree for databases or school-data folders. Package ZIP contents and checksums remain a separate final gate after package generation.
