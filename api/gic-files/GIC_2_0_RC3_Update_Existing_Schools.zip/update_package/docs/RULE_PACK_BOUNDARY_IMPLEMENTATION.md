# Rule-Pack Boundary Implementation

Implemented: September 18, 2026

Scope: isolated `GIC_Development_2.0` only. The protected AHS source and live data were not modified.

## What Changed

- Added `app/services/rule_packs.py`.
- Added a registry for the existing Virginia and Custom / Other State templates.
- Wrapped the existing Virginia calculator without changing its calculation logic.
- Moved the existing custom required-field behavior behind a custom adapter.
- Routed startup refreshes, transcript imports, spreadsheet imports, and manual-edit recalculation through the active rule pack.
- Unknown template values fail closed to the custom adapter and cannot accidentally invoke Virginia rules.

## What Did Not Change

- Virginia SOL, verified-credit, LVC/CA, PBA, substitute-test, employment, 3E, retest, and display logic.
- Existing database tables or stored student data.
- Virginia setup choice, grids, reports, agreements, or exports.
- Custom mode's current tracking-field behavior.

## New Tests

- Virginia adapter preserves the existing calculator output.
- Custom adapter creates only required custom statuses and no Virginia SOL statuses.
- An unrecognized template selects the safe custom adapter.

## Next Boundary Work

The registry currently controls student recomputation. Later steps should route grid definitions, reports, agreements, exports, import profiles, and initialization through the same rule-pack interface. Each step must retain the protected Virginia baseline.
