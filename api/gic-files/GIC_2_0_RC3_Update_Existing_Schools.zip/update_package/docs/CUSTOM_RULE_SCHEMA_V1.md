# Custom Graduation Rule Schema v1

Status: development foundation only. This schema is not activated for student graduation calculations.

The schema provides typed, deterministic definitions for:

- versioned rule-package identity and jurisdiction;
- effective dates and graduating-cohort applicability;
- diploma plans and total-credit requirements;
- subject-credit, assessment, credential, checklist, number, date, text, and calculated requirements;
- evidence aliases and explicit passing rules;
- all-of, any-of, count-of, and alternative relationships;
- cross-reference, duplicate-key, threshold, date, and cohort validation.

Draft packages cannot be marked active through this validator. Activation will require a later Admin approval workflow, calculation preview, backup, audit record, and rollback support.

Implementation: `app/services/custom_rule_schema.py`

Automated coverage: `tests/test_custom_rule_schema.py`
