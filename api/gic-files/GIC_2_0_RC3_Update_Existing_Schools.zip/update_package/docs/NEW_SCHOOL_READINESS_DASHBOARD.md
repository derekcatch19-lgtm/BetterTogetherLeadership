# New School Readiness Dashboard

Administrators can open **Admin > Setup Readiness** to see a read-only checklist of the installation's actual configuration state.

## Required Milestones

- School profile
- Active administrator access
- Graduation rules appropriate to the selected template
- At least one student class grid

Virginia installations count the built-in Virginia rule template as configured. Custom-state installations require an active approved custom rule package; a draft is shown as requiring review and does not count as ready.

## Recommended Milestones

- Saved import mapping
- Custom tracking fields and reports where applicable
- Graduation agreement configuration
- Verified local backup

The dashboard links directly to the next incomplete area. It does not activate rules, edit settings, import students, or recalculate records. District-controlled server security, access permissions, protected transport, and backup retention remain district IT responsibilities.
