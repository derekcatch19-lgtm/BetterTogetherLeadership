# Vendor Security Questionnaire

**Basis:** Pilot Edition 1.2.4 source and package review, August 1, 2026.

| Question | Verified response |
|---|---|
| Is the product cloud hosted? | No. It is a local application deployed by the school/division. |
| Where is data stored? | In the configured local `GIC_DATA_DIR`, including SQLite, uploads, exports, reports, backups and logs. |
| Encrypted at rest? | Not by the application. Requires local BitLocker/encrypted storage configuration. |
| Encrypted in transit? | Not by the built-in HTTP server. Depends on local HTTPS/reverse-proxy configuration. |
| Does the product use AI? | No external AI is used by the reviewed runtime. The local rules helper uses deterministic document text extraction/keyword proposals and requires Admin approval. |
| Is student data sent to AI? | No intentional AI provider connection exists. |
| Analytics/telemetry? | None found. |
| Does vendor retain school data? | The reviewed app provides no vendor data transfer or remote access. Vendor retention under any separately approved support process requires verification. |
| Password storage? | Salted PBKDF2-HMAC-SHA256, 180,000 iterations. |
| Roles? | Admin, Counselor, Teacher Viewer (stored as Viewer). |
| Audit logs? | Yes, for key authentication, import, edit, export, user, backup and configuration actions. Not every view/print action is logged. |
| Backups? | Yes, local SQLite online backups with integrity validation. |
| Updates? | School-controlled ZIP packages; update package excludes school data. SHA-256 digest provided. No automatic online update. |
| What happens when a license expires? | No technical license-expiration mechanism was found. Commercial/license terms require verification. |
| Vulnerability reporting? | Requires vendor security contact/process to be established before commercial distribution. |
| Real data in installer? | Tests verify blank package has zero users/students/uploads and demo contains fake students. Each final artifact must still be scanned before release. |
| Operates without internet? | Yes. |
| Required ports? | TCP 5000 by default; limit to approved internal clients. Demo uses 5001. |
| Third-party libraries? | See SBOM. |
| Machine-readable SBOM? | Yes, CycloneDX JSON in this folder. |
| Antivirus scanning? | Not built in; requires district endpoint/server protection. |
| MFA/SSO? | Not Yet Implemented. |
| Remote vendor access/back door? | None found in reviewed code. |
| Data deletion/retention automation? | Limited. Depends on local policy and manual administration. |
