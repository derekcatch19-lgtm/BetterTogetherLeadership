# Blank Release Verification Form

Use the full checklist in [RELEASE_SECURITY_VERIFICATION.md](RELEASE_SECURITY_VERIFICATION.md).

- Version:
- Build date:
- Commit/release identifier:
- Test environment:
- Tester/date:
- Full package SHA-256:
- Update package SHA-256:
- Automated tests: Pass / Fail / Not run
- Dependency audit: Pass / Fail / Not run
- Secret scan: Pass / Fail / Not run
- Static analysis: Pass / Fail / Not run
- Package data scan: Pass / Fail / Not run
- Clean installation: Pass / Fail / Not run
- Local network test: Pass / Fail / Not run
- Unresolved findings:
- Local safeguards required:
- Decision: Hold / Demo only / Limited pilot / Production
- Approved by/date:
