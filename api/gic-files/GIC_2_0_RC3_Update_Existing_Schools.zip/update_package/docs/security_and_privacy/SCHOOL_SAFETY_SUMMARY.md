# Graduation Intelligence Center: School Safety Summary

**Pilot Edition 1.2.4 | Local-first school application**

GIC helps authorized school staff track graduation progress, assessments, transcripts, credentials, readiness indicators and reports. It runs on a school-controlled Windows computer or internal server. Normal operation does not require internet access, cloud storage, analytics, telemetry, external AI, or vendor access.

## Built Into the Application

- Login required before student records are shown
- Admin, Counselor and Teacher Viewer roles
- Salted PBKDF2 password hashes; no plaintext passwords
- 30-minute idle and 8-hour absolute session defaults
- Failed-login throttling and disabled-account session removal
- CSRF protection on authenticated changes
- Server-issued upload tokens and approved-directory checks
- File extension, signature, structure and size validation
- Local SQLite storage and local-only reports/exports/backups
- Audit events for major logins, uploads, edits, exports, users, backups and settings
- Online SQLite backups with integrity checks before uploads/migrations and before restore
- Viewer accounts blocked from upload, edit, delete, administration and protected exports

## School/Division Must Provide

- Approved, patched and physically secured host
- BitLocker or approved encrypted storage
- Restricted folder permissions and endpoint antivirus
- Internal-only firewall rules; no direct public exposure
- District HTTPS/reverse proxy or VPN when required
- Unique named accounts based on legitimate educational interest
- Backup protection, retention, restore testing and secure deletion
- Staff training, audit review, incident response and privacy procedures

## Important Limits

The built-in server uses HTTP, not HTTPS. Files and backups are not encrypted by GIC itself. Antivirus scanning, MFA/SSO, forced temporary-password changes, automatic retention/deletion, and prevention of screenshots/printing are not built in. Uploaded originals remain local until removed under school policy.

GIC is not represented as FERPA certified, and no installation is guaranteed completely secure. District IT and privacy leadership must approve deployment before real student data is used.

**Contacts:** Vendor support __________ | School IT __________ | Privacy __________ | Incident reporting __________
