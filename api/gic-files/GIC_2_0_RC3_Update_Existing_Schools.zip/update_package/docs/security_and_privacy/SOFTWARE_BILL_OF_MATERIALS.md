# Software Bill of Materials

**Artifact reviewed:** GIC Pilot Edition 1.2.4 portable full install  
**Runtime:** Python 3.12 on Windows  
**Generated:** August 1, 2026

Versions below were read from the final 1.2.4 portable ZIP runtime. License labels are based on package metadata/common project licensing and should receive formal legal review before commercial distribution.

| Component | Version | Purpose | Relationship | License (detectable) | External service |
|---|---:|---|---|---|---|
| Python | 3.12 | Runtime/standard library/SQLite HTTP server | Platform | PSF | None |
| pandas | 3.0.1 | Tabular imports/rules documents | Direct | BSD-3-Clause | None |
| openpyxl | 3.1.5 | Excel read/write | Direct | MIT | None |
| reportlab | 4.4.9 | PDF generation | Direct | BSD-style | None |
| pdfplumber | 0.11.9 | PDF text/table extraction | Direct | MIT | None |
| numpy | 2.3.5 | pandas numerical dependency | Transitive | BSD-3-Clause (bundled notices apply) | None |
| pdfminer.six | 20251230 | PDF parsing | Transitive | MIT | None |
| pypdfium2 | 5.12.1 | PDF rendering dependency | Transitive | BSD-3-Clause/Apache-2.0 components; verify | None |
| Pillow | 12.2.0 | Image handling | Transitive | HPND | None |
| cryptography | 49.0.0 | PDF/runtime cryptographic dependency | Transitive | Apache-2.0 OR BSD-3-Clause | None |
| cffi | 2.1.0 | Native interface dependency | Transitive | MIT | None |
| pycparser | 3.0 | cffi dependency | Transitive | BSD-3-Clause | None |
| charset-normalizer | 3.4.9 | Text encoding dependency | Transitive | MIT | None |
| et_xmlfile | 2.0.0 | openpyxl XML dependency | Transitive | MIT | None |
| python-dateutil | 2.9.0.post0 | Date handling | Transitive | Apache-2.0 OR BSD-3-Clause | None |
| six | 1.17.0 | Compatibility dependency | Transitive | MIT | None |
| typing_extensions | 4.16.0 | Typing compatibility | Transitive | PSF-2.0 | None |
| tzdata | 2026.3 | Time-zone data | Transitive | Apache-2.0 | None |

The source `requirements.txt` specifies minimum versions rather than a locked set. The portable artifact embeds fixed versions, but reproducible commercial builds should use a hash-locked dependency manifest, automated vulnerability scan, license review, and signed release provenance.

Machine-readable CycloneDX: [`gic-pilot-1.2.4.cdx.json`](gic-pilot-1.2.4.cdx.json).
