# Security Architecture and Data Flow

## Reviewed Components

- **Runtime:** Python 3.12 portable runtime on Windows; Python 3.11+ supported by nonportable setup guidance.
- **Server:** Python `ThreadingHTTPServer` and `BaseHTTPRequestHandler` in `app/local_server.py`.
- **Application entry:** `run.py` calls `app.local_server.main()`.
- **Database:** SQLite (`ahs_tracking.sqlite3`) with foreign keys enabled.
- **Parsing/report libraries:** pandas, openpyxl, pdfplumber/pdfminer, ReportLab, Pillow/pypdfium2 and dependencies.
- **Browser:** modern browser on host or approved internal network.

```text
Authorized browser
       |
localhost or internal school network
       |  HTTP by default; district TLS proxy optional/required by policy
       v
GIC local application server (port 5000 default)
       |
       +-- SQLite database
       +-- uploads / pending_uploads
       +-- reports / exports
       +-- backups / logs / settings

Approved update ZIP ----> school-controlled manual installation
                         (no student record transmission)
```

## Data Directories and Configuration

`GIC_DATA_DIR` should point to the school-controlled data root. Fallbacks are `AHS_DATA_DIR`, a legacy `instance` database, then source-relative `data`. `GIC_HOST`/`AHS_HOST` defaults to `127.0.0.1`; `GIC_PORT`/`AHS_PORT` defaults to `5000`. Session defaults are controlled by `GIC_SESSION_IDLE_MINUTES` (30) and `GIC_SESSION_ABSOLUTE_HOURS` (8). Upload request limit uses `GIC_MAX_REQUEST_MB` (512). Automatic backup count uses `GIC_MAX_AUTOMATIC_BACKUPS` (40). The unused prototype Flask secret and its fallback value were removed in Pilot 1.2.5; active sessions use server-side random tokens.

## Authentication and Authorization Flow

Login performs a parameterized username lookup, verifies salted PBKDF2, checks `disabled`, applies an IP-based failure throttle, writes an audit event, and creates a 256-bit-style URL-safe random in-memory session ID and CSRF token. Each authenticated request reloads current role/disabled state from SQLite. Route handlers enforce `is_admin`, `can_edit`, or `can_export` server-side.

The session cookie is `HttpOnly` and `SameSite=Strict`. It is not `Secure` over the built-in HTTP service. District TLS termination is required when policy demands encrypted network transport.

## Upload Flow

Browser multipart upload -> random server filename in `pending_uploads` -> size/extension/signature/container/content validation -> move into local `uploads` -> per-session random preview token -> approved-directory revalidation -> column preview/confirmation -> pre-upload backup -> parameterized import -> recalculation/audit/unmatched queue. Browser-submitted filesystem paths are not trusted.

## Report and Export Flow

Authenticated views query SQLite with fixed SQL and parameters. Admin/Counselor export routes show a privacy warning, generate local Excel/PDF, retain an export copy, audit it, and return a download. Viewer exports are rejected server-side. Browser printing/screenshot capture cannot be prevented.

## Backup, Restore, and Migration Flow

SQLite online backup API creates a consistent database copy, followed by `PRAGMA integrity_check`. Startup creates a backup before schema migrations. Restore validates integrity and required tables, creates a pre-restore backup, performs online copy, then validates again. Backup files are not encrypted by GIC.

## Logging and Errors

`audit_log` records actor, role, action, detail, IP and timestamp. `logs/error.log` receives exception type/message and local traceback. No automatic crash upload exists. Logs should be restricted and sanitized before support use.

## Network and External Services

The active application has no intentional outbound HTTP client, analytics, telemetry, email, cloud storage, external AI, or remote support connection. Python/socket functionality is used to listen locally and validate demo port availability. Internet access is not required. No automatic update check exists.

## Database Safety

Normal values use SQLite placeholders. Dynamic SQL is limited to internal allowlisted/constructed identifiers and placeholder counts. Upload paths use resolved approved-directory checks. HTML output is escaped by default. Headers include no-store, nosniff, frame denial, same-origin referrer policy, permissions policy, and a restrictive CSP; CSP currently permits inline scripts for local UI actions.

## Deployment Boundary

District IT owns OS patching, endpoint protection, storage encryption, NTFS ACLs, TLS, firewall/VPN, physical controls, monitoring, retention and incident response. Direct public-internet exposure is unsupported.
