# Completed Release Verification: Pilot Edition 1.2.4

- **Build:** Pilot Edition 1.2.4 - July 29, 2026
- **Review date:** August 1, 2026
- **Environment:** Windows, Python 3.12, temporary/fake test databases
- **Tester:** Codex-assisted source/package review; school IT approval not performed
- **Full ZIP SHA-256:** `5A8E293DDE434C29464A9D9D3FF616855C3A1B3DBE55E6245877FBA77A07D9E3`
- **Update ZIP SHA-256:** `A7F1EB2707371863081E6EE42FF95BBE8F9D73019E96ECD8E61E5A3B3BE14531`

| Area | Result | Evidence/limitation |
|---|---|---|
| Authentication/hashing | Pass | Salted PBKDF2 verification test and source review |
| Admin/Counselor/Viewer route enforcement | Pass with gap | Server-side checks verified; no exhaustive HTTP route matrix test for every route |
| Session timeout/logout/disabled users | Source verified | Defaults 30 minutes/8 hours; no timed end-to-end wait test |
| Failed login | Source verified | 5/IP/15-minute in-memory throttle; resets on restart |
| CSRF | Pass | `test_csrf_token_injection_and_validation` |
| Upload token/path validation | Pass | `safe_child` tests and source-issued token review |
| File signatures/content | Pass | CSV/Office acceptance; executable/invalid PDF rejection tests |
| SQL/input handling | Source/static review | Parameterized values used; no independent penetration test |
| Backups/restores | Pass | Online backup and corrupt restore rejection test |
| Migrations/update preservation | Partial | Pre-migration backup verified; full install upgrade rehearsal not repeated in this audit |
| Reports/exports | Pass | Every report/class export, PDFs, letters, agreements, checklists tests |
| Demo/live separation | Pass | Eight demo isolation tests |
| Outbound connections | Pass by reference search | No intentional outbound client/service found |
| Secret scan | Pass with finding | No private keys/API keys found; default fallback secret string exists and should be removed/required before commercial distribution |
| Dependency vulnerability audit | Not completed | No vulnerability database scanner was available offline |
| SBOM | Pass | Final ZIP runtime inventory and CycloneDX JSON created |
| Package cleanliness | Previously tested; recheck required | Blank/demo tests pass. Final public artifact must be rescanned after documentation is added |
| HTTPS/encryption at rest | Requires Local Configuration | Built-in service is HTTP; SQLite/backups are not application-encrypted |

## Automated Result

`python -m unittest discover -s tests -p 'test*.py' -v`: **49 passed, 0 failed** in 6.166 seconds.

## Decision

**Ready for a limited internal pilot only after district safeguards and signed local checklist.** This is not a compliance certification. Do not expose the built-in server to the public internet. Commercial distribution should wait for the unresolved items in `SECURITY_TEST_RESULTS.md`.
