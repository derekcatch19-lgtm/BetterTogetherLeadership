# Incident Response Guide

1. **Identify and contain.** Record what occurred; stop the affected upload/export/process. Do not destroy evidence.
2. **Disable affected accounts.** Admin should disable suspected accounts and reset credentials. Disabling invalidates active GIC sessions.
3. **Disconnect unauthorized exposure.** Remove public forwarding, isolate the host, or restrict firewall access as directed by IT.
4. **Preserve evidence.** Copy audit/error logs and relevant system/security logs to approved evidence storage. Record hashes when possible.
5. **Notify leadership.** Contact school IT, privacy, administration, and incident-response contacts.
6. **Determine scope.** Identify students, fields, files, dates, accounts, exports, backups, and systems potentially affected.
7. **Recover.** Remove malicious files and restore only from an integrity-checked, verified backup under IT direction.
8. **Document actions.** Keep a timeline, decisions, evidence, and responsible parties.
9. **Follow notification requirements.** Use school/division, Virginia, federal, insurer, law-enforcement, and contractual procedures as applicable.
10. **Contact vendor safely.** Use fake/de-identified examples and sanitized logs unless an approved written data-sharing process exists.

## Incident Record

| Field | Details |
|---|---|
| Date/time detected | |
| Reported by | |
| Systems affected | |
| Users affected | |
| Data potentially affected | |
| Immediate containment | |
| Evidence preserved | |
| Notifications | |
| Resolution | |
| Follow-up actions/owner/date | |
