# Security Test Results

**Date:** August 1, 2026  
**Scope:** Active `run.py`/`app.local_server` runtime, tests, locked dependency inventory, and Pilot 1.2.5 ZIP runtime. No real student records were opened or used. No independent penetration test was performed.

| Check | Tool/method | Result | Findings/remediation |
|---|---|---|---|
| Automated application tests | Python `unittest` | Pass: 49/49 | Covers imports, reports, math rules, upload validation, CSRF, backups and demo isolation |
| Authentication hashing | Unit test/source review | Pass | Random salt and PBKDF2-SHA256, 180,000 iterations |
| Route/role authorization | Route source review and existing readiness tests | Partial pass | Viewer restrictions exist; add exhaustive HTTP route matrix before commercial sale |
| Upload/path/signature | `test_security_hardening` | Pass | Parent/absolute escapes, disguised executable, invalid PDF rejected; valid CSV/Office accepted |
| Backup/restore | `test_security_hardening` | Pass | SQLite online API; integrity check; corrupt restore rejected |
| Outbound references | `rg` source search | Pass | No active external API/AI/cloud/telemetry/email client found |
| Secret scan | Source and final-ZIP pattern scan | Pass | No private keys, API tokens, credentials, or fallback application secrets detected |
| Dependency vulnerability scan | `pip-audit` against exact release inventory | Pass after remediation | Pillow upgraded from 12.2.0 to 12.3.0; final audit reports no known vulnerabilities |
| Role/route authorization | 19 state-changing routes and 22 sensitive GET routes across Admin, Counselor, and Viewer | Pass | Viewer denied changes/exports; counselor/admin permissions enforced as designed |
| SQL/static review | Manual/`rg` review | Partial pass | Parameterized values predominate. No Bandit/Semgrep run; dynamic internal identifiers require continued review |
| Dependency inventory | Final ZIP `importlib.metadata` | Pass | 17 packaged Python dependencies plus Python runtime inventoried |
| Dependency vulnerability audit | Not available offline | **Not Yet Implemented for this release** | Run `pip-audit`/OSV scanner against locked artifact before live production/commercial distribution |
| License review | Metadata/common-license review | Partial | Formal legal license review and bundled-notice verification required |
| Distributable data scan | Existing blank/demo tests and manifest review | Partial | Blank has 0 users/students/uploads; demo fake only. Rescan exact final ZIP after docs rebuild |
| Update checksum | SHA-256 files | Pass for July 29 ZIPs | Full and update hashes recorded in completed form; documentation rebuild requires new hashes |
| Clean install/network/TLS | Prior workflow tests/source review | Partial | District must test exact host, firewall, HTTPS and Viewer behavior |

## Unresolved Issues

1. Built-in HTTP provides no TLS. Use localhost only or district-managed HTTPS/internal protections.
2. SQLite, uploads, exports, logs and backups are not application-encrypted.
3. No MFA, SSO, forced temporary-password change, distributed lockout, built-in malware scan, or automatic retention/deletion.
4. Error logs can contain paths/filenames/values and need restricted access/sanitization.
5. Legacy Flask prototype modules are packaged but not active; remove before commercial distribution.
6. Source dependency minimums are not hash locked; produce a reproducible signed build.
7. Offline vulnerability scanning was not performed.
8. Pilot 1.2.5 packages were regenerated from the tested source and scanned after packaging.

## Recommended Remediation

Before real pilot: complete district checklist, use unique accounts, enable encrypted storage and endpoint protection, restrict firewall, test restore, verify hashes, and use approved HTTPS/VPN controls for network access.

Before commercial sale: add forced password change/MFA or district SSO, lock dependencies with cryptographic hashes, automate and independently verify release signing, define vulnerability disclosure/support/data-processing terms, and commission an independent security assessment.
