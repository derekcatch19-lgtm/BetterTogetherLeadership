# Local Deployment Security Checklist

Use before real student data. Mark each item and retain the signed copy.

## A. Host Computer / Server
- [ ] Dedicated or formally approved host
- [ ] Supported Windows version and current security patches
- [ ] District antivirus/endpoint protection enabled
- [ ] BitLocker or approved encrypted storage enabled where available
- [ ] Administrative rights restricted
- [ ] Automatic screen lock configured
- [ ] Host and backup media physically secured
- [ ] Host remains powered on only as operationally required

## B. Network
- [ ] Internal network access only
- [ ] Not directly exposed to the public internet
- [ ] Firewall restricts port 5000 to approved networks/hosts
- [ ] Approved local hostname or static/reserved IP configured
- [ ] HTTPS reverse proxy configured when required by IT
- [ ] Remote access limited to approved VPN/school controls
- [ ] Unnecessary ports closed
- [ ] `GIC_HOST`, `GIC_PORT`, and `GIC_DATA_DIR` explicitly configured

## C. Application
- [ ] First Admin account created securely; no default/demo account remains
- [ ] Fake/demo data is separate from production
- [ ] Unique named accounts issued; passwords meet district policy
- [ ] 30-minute idle and 8-hour absolute session behavior tested
- [ ] Admin and Counselor permissions tested
- [ ] Teacher Viewer cannot upload, edit, delete, manage, or export
- [ ] Export warning and download controls tested
- [ ] Audit log reviewed after test actions
- [ ] Backup location confirmed and restore tested
- [ ] Release version and SHA-256 verified

## D. Data
- [ ] Installer verified to contain no real student records
- [ ] Database, uploads, reports, exports, logs, and backups have restricted ACLs
- [ ] Retention periods defined for source uploads and generated records
- [ ] Secure deletion process documented
- [ ] Off-host backup process approved
- [ ] Removable-drive use prohibited or specifically approved and encrypted
- [ ] Support process requires fake/de-identified material by default

## E. Final Approval

| Field | Entry |
|---|---|
| Application version | |
| Server/host | |
| Data location | |
| Backup location | |
| Date tested | |
| Tested by | |
| Approved by | |
| Approved for pilot | Yes / No |
| Approved for production | Yes / No |

Notes: ______________________________________________________________________
