# Safety, Privacy, and Security Documentation

Reviewed build: **Pilot Edition 1.2.4 - July 29, 2026**. Review date: **August 1, 2026**.

This package describes verified application behavior and the controls a school or division must configure. It is not a legal opinion, a certification, or a guarantee of complete security.

- [Security Overview](GRADUATION_INTELLIGENCE_SECURITY_OVERVIEW.md)
- [Local Deployment Checklist](LOCAL_DEPLOYMENT_SECURITY_CHECKLIST.md)
- [Release Security Verification](RELEASE_SECURITY_VERIFICATION.md)
- [Data Privacy and Handling Guide](DATA_PRIVACY_AND_HANDLING_GUIDE.md)
- [Incident Response Guide](INCIDENT_RESPONSE_GUIDE.md)
- [Security Architecture and Data Flow](SECURITY_ARCHITECTURE_AND_DATA_FLOW.md)
- [Vendor Security Questionnaire](VENDOR_SECURITY_QUESTIONNAIRE.md)
- [Software Bill of Materials](SOFTWARE_BILL_OF_MATERIALS.md)
- [Security Test Results](SECURITY_TEST_RESULTS.md)
- [One-Page School Safety Summary](SCHOOL_SAFETY_SUMMARY.md)
- [Completed 1.2.4 Verification](RELEASE_VERIFICATION_1.2.4_COMPLETED.md)
- [Blank Verification Form](RELEASE_VERIFICATION_BLANK.md)
- [Combined Print Document](SECURITY_AND_PRIVACY_PACKAGE.html)
- [Consolidated Word Document](GIC_Pilot_1.2.4_Safety_Privacy_and_Security_Package.docx)
- [CycloneDX SBOM](gic-pilot-1.2.4.cdx.json)
