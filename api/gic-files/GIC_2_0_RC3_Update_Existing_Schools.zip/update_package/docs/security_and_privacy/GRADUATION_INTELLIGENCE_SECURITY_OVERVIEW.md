# Graduation Intelligence Center
## Safety, Privacy, and Security Overview

**Reviewed version:** Pilot Edition 1.2.4 - July 29, 2026  
**Review date:** August 1, 2026

This document describes the reviewed code. It does not state that the product is FERPA certified and does not guarantee that an installation is completely secure.

## 1. Product Overview

Graduation Intelligence Center (GIC) is a Python 3 local browser application for counselors, administrators, and authorized view-only staff. It imports rosters, graduation grids, assessments, transcripts/course histories, credentials, readiness evidence, CPR data, and local spreadsheets; calculates configured progress; and creates class grids, reports, checklists, agreements, Excel files, and PDFs.

It can run on one Windows computer at `127.0.0.1:5000`, or on an approved internal server by binding to a local network interface. Internet access is not required for normal operation. The host must remain running while other users access it.

Potential records include names, local/state IDs, graduation class, diploma type, counselor, SPED/504 indicator, test results and dates, course history, grades, credits, credentials, CPR/readiness evidence, notes, flags, uploaded documents, and audit metadata.

## 2. Local-First Architecture

The active entry point is `run.py`, which starts `app/local_server.py`. The database is SQLite at `GIC_DATA_DIR/ahs_tracking.sqlite3`. Subfolders under the same configured data directory hold `uploads`, `pending_uploads`, `exports`, `reports`, `backups`, and `logs`; `settings.json` may also be stored there. The default source-tree fallback is `data`, or a legacy `instance` database when present. Production launchers should set `GIC_DATA_DIR` explicitly.

| Feature | Current behavior | School configuration needed |
|---|---|---|
| Database | Local SQLite file | Restrict NTFS permissions; enable disk encryption |
| Uploads | Validated and retained locally | Set retention and endpoint scanning |
| Reports/exports | Generated locally; exports retained in data folder | Protect and delete under policy |
| Backups | Local online SQLite backups with integrity check | Protect, encrypt, copy off-host if approved, test restore |
| External APIs | None found in active runtime | No configuration |
| Update checks | No automatic network update check | Obtain and verify packages through approved channel |
| Analytics/telemetry | None found | No configuration |
| Email | No email service | Use only approved school systems for exports |
| Cloud storage | No built-in cloud storage | Any cloud synchronization is controlled by district/OS |
| HTTPS | Not provided by the built-in server | Required local configuration for protected network transport |

No intentional outbound HTTP client, cloud SDK, analytics, telemetry, crash reporting, external AI, or email integration was found in the active application. `socket` is used for local port checks/server operation and `urllib.parse` only parses local URLs.

## 3. Data Flow

```text
School export file
  -> browser upload to local application
  -> server-side type/signature/path validation
  -> local preview and authorized confirmation
  -> local parsing and SQLite storage
  -> authorized browser display
  -> local export only when an authorized user confirms
```

Data can leave GIC when an authorized user downloads/prints an export, when IT copies a backup, when OS backup/sync software copies the data directory, when a user sends a screenshot or support file, or if IT exposes the server/network. GIC does not itself send student data to Better Together Leadership or an external service.

## 4. FERPA-Conscious Design

Student pages require authentication. Access is role-based. Schools must grant accounts only for legitimate educational interest, periodically review access, disable former staff, and train users. Downloaded files, printed reports, screenshots, uploads, and backups remain education records. Local operation reduces external transfer; it does not remove school obligations.

## 5. User Roles

| Permission | Admin | Counselor | Teacher Viewer |
|---|:---:|:---:|:---:|
| View students, grids, reports | Yes | Yes | Yes |
| Edit/add/match students | Yes | Yes | No |
| Upload/import | Yes | Yes | No |
| Download Excel/PDF exports | Yes | Yes | No |
| Generate/print browser reports | Yes | Yes | View/print page available* |
| Save report to student record | Yes | Yes | No |
| Delete class grids | Yes | No | No |
| Manage users/settings/rules | Yes | No | No |
| Backup/restore | Yes | No | No |
| View audit log | Yes | No | No |

\*Viewer routes permit viewing report pages and browser printing. The application blocks protected export downloads but cannot technically prevent screenshots, browser printing, or photography. Local policy remains necessary.

## 6. Authentication and Sessions

- Passwords use PBKDF2-HMAC-SHA256 with a random 16-byte-equivalent hexadecimal salt and 180,000 iterations.
- Passwords are not logged or displayed. Minimum length is 10 characters.
- Admin creates, disables/enables, and resets users. A reset immediately invalidates that user's active sessions.
- Disabled users cannot sign in and active sessions are invalidated.
- Sessions are random server-side tokens held in memory, with 30-minute idle and 8-hour absolute defaults configurable by environment variables.
- Cookie: `HttpOnly`, `SameSite=Strict`, path `/`. `Secure` is not set because the built-in server is HTTP; HTTPS termination requires local configuration.
- Five failed attempts from one client IP in 15 minutes trigger a 15-minute in-memory throttle. This resets on application restart and is not a distributed lockout.
- Logout removes the server session. Sessions do not survive a server restart.
- **Not Yet Implemented:** forced change of temporary passwords, password complexity beyond length, MFA, per-user failed-login lockout, shared-account prevention, self-service reset.

## 7. File Upload Security

Data uploads allow `.csv`, `.xlsx`, `.xlsm`, `.xls`, and `.pdf`; rules documents additionally allow `.docx`, `.txt`, `.html`, and `.htm`. The request limit defaults to 512 MB. Names are sanitized and stored with random prefixes outside static web content.

The server checks extensions, ambiguous/dangerous double extensions, file size, PDF/Office/OLE signatures, Office structure, ZIP expansion/entry limits, binary content in text, and CSV readability. Office macros are rejected. Pending processing uses a random per-session upload token with a 30-minute expiry and revalidates the path beneath the approved upload folder. Malformed files produce validation errors and rejected uploads are audited. Exact assessment duplicates are fingerprinted by import logic.

The application does not provide built-in antivirus scanning. Schools should use endpoint and server security controls approved by their IT department.

## 8. Audit Logging

Verified audit actions include successful/failed login; rejected and completed upload; student/grid edits and creation; unmatched-record resolution; class deletion; exports; saved reports; user create/reset/enable/disable; backup/restore; school profile; rules, testing-window, custom-field/report/agreement/import/grid configuration; and CSRF rejection.

Logs include username/role, action, brief detail, client IP, and timestamp. Passwords, password hashes, CSRF/session tokens, and file contents are intentionally excluded. Some detail strings include filenames, student database IDs, notes, or usernames and must therefore be protected. Ordinary page views and browser printing are not comprehensively logged.

## 9. Backups and Recovery

The application creates an online SQLite backup before startup migrations, uploads, restore, and class deletion. Admin can create a manual backup and restore only after typing `RESTORE`. Backups receive `PRAGMA integrity_check`; restore validates required tables, creates a pre-restore backup, and validates the restored database.

Automatic database backups default to the 40 newest; manual backups are not automatically pruned. Backups contain identifiable data and are not application-encrypted. Access, off-host copies, retention, secure deletion, and restore drills require local policy. Uploads, exports, reports, and logs are not included in the SQLite backup.

## 10. Updates

Application code and school data are separated. Update packages exclude `school_data`/data, databases, users, uploads, reports, exports, backups, and logs. Startup backs up the database before migrations. Schools choose when to install an update and should verify its SHA-256 file. Student data is not sent to the vendor during update unless the school deliberately shares it.

## 11. Known Limitations

- Encryption at rest requires BitLocker or district storage controls.
- HTTPS/TLS requires a district reverse proxy or equivalent; direct built-in HTTP is not encrypted in transit.
- File/folder ACLs, firewall, VPN, endpoint protection, monitoring, and physical security require local configuration.
- Built-in antivirus, MFA, SSO, forced password changes, account uniqueness/shared-account prevention, automatic secure deletion, and comprehensive view/print audit events are not implemented.
- The in-memory session/throttle store is single-process and resets on restart.
- Uploaded originals are retained until local deletion policy removes them.
- Error logs can contain exception messages, paths, filenames, or field values; sanitize before support sharing.
- Portable USB copies can be lost, duplicated, or run on unmanaged devices. Do not place real data on removable media without written approval and encryption.
- Do not expose port 5000 directly to the public internet.
- Legacy Flask prototype files remain in the source tree but are not launched by `run.py`; remove or formally retire them before commercial distribution to reduce review ambiguity.
- The staging `dist_ready` runtime observed during this audit lagged the final 1.2.4 ZIP; release automation should rebuild and attest one canonical package.

## 12. School Responsibilities

The school/division approves installation; secures and patches the host; limits administrative and physical access; configures firewall, HTTPS, hostname, VPN and endpoint protection; assigns accounts by legitimate educational interest; reviews audit logs; disables departing staff; protects exports/backups; sets retention and deletion rules; tests restore; trains users; and follows its incident response and notification obligations.

## 13. Security Contacts

- Vendor support contact: ______________________________
- School IT contact: __________________________________
- School privacy contact: ______________________________
- Incident reporting contact: __________________________
