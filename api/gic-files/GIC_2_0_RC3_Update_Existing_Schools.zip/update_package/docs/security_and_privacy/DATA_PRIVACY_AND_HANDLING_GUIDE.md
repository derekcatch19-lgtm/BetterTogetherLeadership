# Data Privacy and Handling Guide

## Data Processed

GIC may process student identity and enrollment information; graduation class/diploma/counselor; disability/504 indicator; courses, grades and credits; assessment names, scores, dates, attempts and performance levels; credentials, CPR, service/readiness evidence; graduation status, notes and flags; uploaded transcripts and spreadsheets; generated reports; and user/audit metadata.

Supported imports include CSV, Excel, PDF, and rule documents in Word/text/HTML formats. Exports include Excel, PDF, browser print output, and retained SQLite backups. Uploaded originals are retained locally unless removed under school policy.

## Ownership and Purpose

The school/division controls its records and determines authorized purposes, access, retention, correction, disclosure, and deletion. Use GIC only for approved educational administration. Do not reuse records for unrelated purposes.

## Access and Exports

Use unique accounts and least privilege. Teacher Viewers can see records but cannot edit/upload/export. Admins and Counselors can export; Admins manage users and backups. Exports remain protected education records. Store them only on approved encrypted school systems and delete them when no longer needed.

Do not email student exports through personal or unapproved email. Do not post identifiable screenshots in tickets, presentations, websites, or messaging systems. Crop/redact names, IDs, dates of birth, disability indicators, scores, and unique combinations.

## Backups, Retention, and Disposal

Backups contain identifiable records and require the same protection as the active database. Schools must define retention for database records, uploads, exports, reports, logs, and backups. Application deletion does not remove prior backups. Before disposal, remove or cryptographically erase all copies under district procedure, including synchronized folders and removable media.

## Support and Troubleshooting

Schools should not email or upload identifiable student files to Better Together Leadership unless a written, approved support process and data agreement are in place.

Default support materials should use:
- screenshots with names and identifiers hidden;
- fake/demo data;
- sanitized error logs;
- column names without student rows;
- de-identified examples.

Error logs may contain local paths, filenames, exception text, or values involved in a failure. Review and sanitize them before sharing.

## Incident Reporting

Immediately report suspected unauthorized access, lost media, misdirected exports, compromised accounts, malware, or public exposure to school IT/privacy leadership. Preserve logs and follow the [Incident Response Guide](INCIDENT_RESPONSE_GUIDE.md).
