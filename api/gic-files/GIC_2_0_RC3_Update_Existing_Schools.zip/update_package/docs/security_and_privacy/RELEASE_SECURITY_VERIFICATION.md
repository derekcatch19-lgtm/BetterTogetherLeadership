# Release Security Verification Procedure

Complete one copy for every release. Evidence should identify commands, test names, hashes, screenshots, or signed review records. `Pass` means tested for this exact artifact; `N/A` requires an explanation.

| Item | Pass | Fail | N/A | Evidence/notes | Date | Tester |
|---|:---:|:---:|:---:|---|---|---|
| Authentication and password hashing | [ ] | [ ] | [ ] | | | |
| Admin authorization | [ ] | [ ] | [ ] | | | |
| Counselor authorization | [ ] | [ ] | [ ] | | | |
| Teacher Viewer restrictions | [ ] | [ ] | [ ] | | | |
| Session idle/absolute timeout | [ ] | [ ] | [ ] | | | |
| Logout/disabled-user invalidation | [ ] | [ ] | [ ] | | | |
| Failed-login protections | [ ] | [ ] | [ ] | | | |
| CSRF on authenticated state changes | [ ] | [ ] | [ ] | | | |
| Input/HTML validation | [ ] | [ ] | [ ] | | | |
| SQL injection protections | [ ] | [ ] | [ ] | | | |
| File extension/signature/content checks | [ ] | [ ] | [ ] | | | |
| Upload token and path traversal checks | [ ] | [ ] | [ ] | | | |
| Audit events and sensitive-data exclusions | [ ] | [ ] | [ ] | | | |
| Error handling/log sanitization | [ ] | [ ] | [ ] | | | |
| Online backup and integrity check | [ ] | [ ] | [ ] | | | |
| Restore validation and warning | [ ] | [ ] | [ ] | | | |
| Pre-migration backup and migration | [ ] | [ ] | [ ] | | | |
| Update preserves existing data | [ ] | [ ] | [ ] | | | |
| Excel/PDF/report exports | [ ] | [ ] | [ ] | | | |
| No real data in distributables | [ ] | [ ] | [ ] | | | |
| Blank/demo/update separation | [ ] | [ ] | [ ] | | | |
| No external student-data transmission | [ ] | [ ] | [ ] | | | |
| Dependency vulnerability scan | [ ] | [ ] | [ ] | | | |
| Secret/credential scan | [ ] | [ ] | [ ] | | | |
| Static code analysis | [ ] | [ ] | [ ] | | | |
| Clean installation | [ ] | [ ] | [ ] | | | |
| Internal-network/TLS configuration | [ ] | [ ] | [ ] | | | |

## Release Identification

- Version: ____________________
- Build date: _________________
- Commit/release identifier: __________________________
- Full package SHA-256: _________________________________________________
- Update package SHA-256: _______________________________________________
- Test environment: _____________________________________________________
- Tester: _____________________ Date: ______________
- Reviewer/approver: ________________________________
- Decision: [ ] Hold  [ ] Demo only  [ ] Limited pilot  [ ] Production
