# Custom Agreements and Reports

Implemented: September 18, 2026

Active custom-state rule packages now drive custom graduation agreements and saved reports. Virginia installations continue using the established Virginia agreement and report paths.

## Custom agreements

- Checklist rows come from the student's active diploma plan or the Admin-selected checklist items.
- Statuses and explanations come from versioned custom calculation results.
- Configured title, introduction, course-completion language, support options, signatures, and footer are used.
- Support options may name requirement keys and are checked when one of those requirements is unmet.
- Individual preview, batch printing, PDF export, and saved student-record copies use the custom definition.
- The active rule package name and version appear on the agreement for auditability.

## Custom reports

- Reports may use active custom-rule requirements, custom tracking fields, or overall Custom Graduation Status.
- One or two conditions may be combined with AND or OR.
- Class filtering, browser printing, and Excel export remain available through the Reports page.
- Saved definitions retain selected output-column and sort metadata for later report-layout expansion.

All implementation and tests use the isolated development workspace and fake data only.
