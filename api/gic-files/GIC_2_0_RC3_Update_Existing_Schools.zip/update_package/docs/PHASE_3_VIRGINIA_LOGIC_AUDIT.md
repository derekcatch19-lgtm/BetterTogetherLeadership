# Phase 3 Virginia Logic Audit

Checked: September 18, 2026

Scope: isolated `GIC_Development_2.0` source. This is an architecture and ownership audit. No live AHS data was read or modified, and no calculation behavior was changed during this phase.

## Executive Finding

GIC already has a useful state-independent shell: users, sessions, roles, students, class membership, uploads, matching, audit events, backups, exports, custom fields, configurable grid columns, custom reports, and a rules-review wizard. Virginia and custom modes are visibly separated at the grid and upload-completion boundaries.

The actual graduation decision engine is still a Virginia engine. `recompute_student_status()` directly imports Virginia EOC phase-in logic and encodes SOL subjects, verified-credit families, LVC/CA rules, substitute tests, PBA behavior, required participation, retesting, credentials, CCRI, and SOL completion. In Custom / Other State mode, GIC does not run those rules; it creates simple required custom-field statuses. The approved custom-rules JSON is therefore descriptive configuration, not yet an executable graduation rules package.

The safest architecture is not to generalize the Virginia functions in place. Preserve them as a versioned `VirginiaRulePack` behind a state-neutral rule-pack interface, then build a generic deterministic rule evaluator beside it. Existing Virginia fixtures become compatibility tests for that extraction.

## A. Core GIC Functionality That Should Work Everywhere

These capabilities are state-independent and should remain in the platform core:

| Capability | Current implementation | Assessment |
|---|---|---|
| Local application and data paths | `app/local_server.py` startup, `GIC_DATA_DIR`, data subfolders | Reusable core |
| Authentication and roles | sessions, password hashing, Admin/Counselor/Viewer authorization | Reusable core |
| Student identity and cohort membership | `students`, `class_grid_members` | Reusable, though some defaults are Virginia-specific |
| Student lifecycle | Active, Transferred Out, Graduated, original cohort, early graduate | Reusable core |
| Upload safety | upload tokens, approved paths, signature validation | Reusable core |
| File parsing and mapping | canonical field suggestions, preview, confirmation | Reusable core with provider profiles layered above it |
| Student matching and troubleshooter | exact/fuzzy matching and unmatched queue | Reusable core |
| Attempt/evidence ledger | `test_attempts` | Reusable if renamed conceptually to assessment/evidence attempts |
| Requirement result storage | `requirement_status` | Reusable, but keys need namespacing and rule provenance |
| Transcript storage | `student_documents`, `transcript_courses` | Reusable; course taxonomy should be configurable |
| Custom tracking fields | `custom_fields_config` and imported custom values | Good foundation, not yet a rules engine |
| Grid composition | `main_grid_columns_config`, custom grid renderer | Reusable core |
| Custom reports | `custom_reports_config` | Reusable foundation |
| Rules document review | local extraction, draft, review, approval | Reusable onboarding workflow |
| Audit, backup, restore | audit log and SQLite online backup | Reusable core |
| Export infrastructure | Excel/PDF generation | Reusable; content definitions need rule-pack ownership |

## B. Virginia Configuration and Rules

### 1. Virginia rule engine

Primary file: `app/services/rule_engine.py`.

Hard-coded Virginia behavior includes:

- SOL subject keys: `ESCI`, `Bio`, `Chem`, `AlgI`, `Geom`, `AlgII`, `EngRLR`, `EngWrit`, `WGeo`, `WHI`, `WHII`, and `USH`.
- Verified-credit families and required counts: English 2, Math 1, Science 1, History 1.
- Required federal participation markers for Algebra I, Biology, and English Reading.
- Default SOL passing score of 400 where no phase-in rule applies.
- Invalid/non-test score handling above 600.
- LVC/credit-accommodation band and eligibility logic, including SPED/504 and senior handling.
- Multiple-attempt `#` and failed-course `*` display semantics.
- Reading substitute via Workplace Documents and writing substitute via Business Letter Writing.
- History PBA/LAVC pass and failure rules, including numeric PBA average threshold 2.
- Category-level “verified credit met in subject area” behavior.
- Virginia retesting behavior, including delayed History retesting.
- `SOLs Complete`, possible LVC flags, and verified-credit status language.
- Credential, NCRC, Workplace Readiness, W!SE, ASVAB, CCRI, dual-enrollment, CPR, virtual-course, and service-learning status calculations.

This file should become the implementation body of a Virginia rules package, not the generic engine.

### 2. Virginia EOC phase-in

Primary file: `app/services/virginia_eoc_phase_in.py`.

Hard-coded Virginia behavior includes:

- State name, testing windows, school-year date ranges, rule versions, and source descriptions.
- Phase-in subjects: Algebra I, Geometry, Algebra II, and EOC Reading.
- Passing, proficient, advanced, and LAVC floor thresholds by window.
- Initial-attempt rule locking and preservation of previously earned credit.
- Pearson-date review language and Virginia testing-window assignment.
- Virginia course-to-EOC matching and LAVC eligibility details.

The database tables `testing_windows`, `eoc_subject_rules`, `eoc_rule_overrides`, and `eoc_migration_runs` are structurally useful, but their names and assumptions are EOC-specific. Keep them for Virginia compatibility first; introduce generic rule-assignment tables separately rather than performing a risky immediate rename.

### 3. Virginia readiness and credential model

Primary files: `app/services/three_e.py` and the lower portion of `app/services/rule_engine.py`.

Hard-coded behavior includes:

- 3E Enrollment, Employment, and Enlistment scoring and labels.
- Virginia evidence choices and point values.
- ASVAB score bands.
- Credential, WPR, NCRC, W!SE, CTE-completer, work-based-learning, dual-enrollment, AP/IB/Cambridge/CLEP, and honors evidence.
- Recommended next-opportunity language.

This should be a named Virginia readiness module. A generic product should support a configurable readiness framework without assuming every state uses 3E.

### 4. Virginia diploma and transcript assumptions

Primary files: `app/local_server.py` and `app/services/transcript_parser.py`.

Hard-coded behavior includes:

- Standard diploma: 22 credits; Advanced diploma: 26 credits.
- English, Math, Science, and History credit-family totals.
- Virginia course names such as AFDA, US & VA History, Economics and Personal Finance, and the current Credit/SOL Checklist taxonomy.
- Advanced-track inference from honors, dual-enrollment, and foreign-language progression.
- English 12 and U.S. Government agreement language.
- Virtual-course inference and checklist rows.

Transcript parsing itself belongs in core. Course aliases, subject families, diploma plans, and checklist layouts belong in the active rule package or school course-catalog configuration.

### 5. Virginia reports and presentation

Primary files: `app/local_server.py` and `app/services/exports.py`.

Virginia-owned content includes:

- Missing verified-credit reports, possible LVC, SOL retake window, SOL completion, and Credit/SOL Checklist.
- Virginia class-grid assessment columns and colors.
- Graduation Agreement references to VDOE requirements, verified credits, SOLs, PBA, LVC, substitute tests, English 12, and U.S. Government.
- 3E reports and Excel columns.
- SOL attempt history labels and score coloring.

Report generation, filtering, printing, and export are core. Report definitions, columns, completion predicates, language, and colors should be supplied by the active rule package.

### 6. Virginia import assumptions

Primary file: `app/services/upload_parser.py`.

Virginia-owned mappings include:

- Wide SOL grid columns and aliases.
- PBA component columns and LAVC indicators.
- Pearson published-report date fields.
- BLW, Workplace Documents, WPR, NCRC, ASVAB, credential, and CPR source recognition.
- Score parsing conventions and graduation-grid symbols.

The canonical mapping mechanism is core. These aliases and transformations should become versioned import profiles delivered by the Virginia package.

## C. School/District-Specific Configuration

The following should never be embedded in a state rules package:

- School/division name, logo, colors, principal, footer, and signature titles.
- Counselor names and alphabetical assignment ranges.
- “Cougar” branding and Scholars Club naming/history.
- Local success-class names and support-plan options.
- Local attendance, fee, device, discipline, parent-meeting, intervention, and senior-project fields.
- Local report names and selected grid columns.
- Local course aliases that differ from state terminology.
- Saved import mappings for a district's SIS and recurring reports.

Current school-specific references include `Cougar Success` in agreement rendering, Cougar Scholars reports/history, and genericization substitutions in `tools/create_dist_package.py`. Packaging-time text replacement is fragile. These values should come from school profile/settings at render time.

## Current Separation That Already Works

- Setup explicitly selects `Virginia Template` or `Custom / Other State Template`.
- Class grids branch to Virginia or custom rendering.
- Spreadsheet imports run Virginia recomputation only under the Virginia template.
- Transcript imports run Virginia recomputation only under the Virginia template.
- Existing-grid unknown columns can become custom tracking fields.
- Custom fields support checkbox, text, number, date, dropdown, score, and notes with simple completion rules.
- Custom grid columns and custom reports are stored in settings.
- Rules documents are analyzed locally and require administrator approval.

These boundaries are valuable and should be retained.

## Architectural Gaps

1. **No rule-pack interface.** Template selection is checked with string comparisons in server, upload, and export code.
2. **Approved custom rules are not executable.** Diploma and requirement JSON can seed fields, but there is no deterministic evaluator for credit groups, alternatives, dependencies, or completion totals.
3. **Requirement keys are global strings.** `requirement_status` has no rule-pack ID, version, calculation trace, or approval version.
4. **Virginia recomputation is destructive.** It deletes and recreates all requirement statuses for a student. This is acceptable inside the Virginia package but cannot become the generic extension model.
5. **Schema defaults imply Virginia.** New students default to `Standard`; the default template is Virginia; database filename remains `ahs_tracking.sqlite3`; `cougar_scholar_history` is school-branded.
6. **Reports are a mixed registry.** Generic, Virginia, 3E, and AHS reports share one static `REPORTS` dictionary.
7. **Presentation knows rule semantics.** Grid cells, colors, attempt details, agreement supports, and checklist course matching contain Virginia decisions.
8. **Import detection and transformation are coupled.** Provider recognition, Virginia normalization, student matching, and persistence run in one upload pipeline.
9. **Rules provenance is incomplete.** Results need active package/version, rule ID, evidence IDs, calculation time, and an explanation trace.
10. **No safe recalculation preview.** Activating a changed rule package should show affected counts and sample differences before committing results.

## Recommended Target Architecture

### Core platform

Core owns identity, evidence, imports, transcripts, custom values, authorization, audit, backup, UI shell, exports, and a state-neutral calculation coordinator.

Suggested interface:

```text
RulePack
  metadata()                 -> id, state, version, effective dates
  requirement_definitions() -> diploma plans and requirement graph
  import_profiles()          -> aliases and row transformations
  course_taxonomy()          -> aliases and credit families
  calculate(student, evidence, transcript, config)
                             -> requirement results plus explanation trace
  grid_definition()          -> columns, labels, colors, details
  report_definitions()       -> filters, columns, actions
  agreement_definition()     -> rows, supports, language
```

### Virginia package

Move current behavior behind `VirginiaRulePack` with no initial logic rewrite. It should call the existing rule engine, EOC phase-in service, 3E service, Virginia transcript taxonomy, Virginia reports, and Virginia agreement definitions. The first milestone is behavior-preserving extraction.

### Generic deterministic package

Build a schema-driven evaluator for administrator-approved rules:

- credit totals and subject-group minimums;
- required and alternative requirements;
- all-of, any-of, count-of, and threshold expressions;
- assessment/credential pass thresholds;
- date-effective rules and cohort applicability;
- evidence precedence and manual confirmation;
- calculated fields and local checklist items;
- clear explanation traces.

Document analysis may propose this configuration, but activation remains an Admin action and student results are produced only by deterministic rules.

## Safe Migration Sequence

1. Add a rule-pack registry and selector while leaving Virginia behavior unchanged.
2. Wrap the current Virginia calculator in `VirginiaRulePack`; do not refactor its internals yet.
3. Add rule-pack metadata/version and calculation-trace tables without changing existing status rows.
4. Route recomputation, grid definition, reports, agreement, and exports through the selected rule pack.
5. Move Virginia report definitions and UI labels out of the core server.
6. Move Virginia import aliases and transformations into Virginia import profiles.
7. Build and validate the generic deterministic evaluator with fake non-Virginia fixtures.
8. Add preview/diff/approval before activating a new rule version.
9. Replace packaging-time Cougar text substitution with school settings.
10. Migrate legacy AHS-branded history only after verified exports and rollback tests exist.

## Compatibility Contract for Virginia

Before and after each extraction step, the same fake Virginia dataset must produce identical:

- requirement statuses, scores, display values, LVC types, and retest flags;
- EOC locked rules and review reasons;
- class-grid cells and colors;
- graduation needs and agreement rows;
- 3E points and evidence;
- reports and report membership;
- Excel/PDF output values;
- attempt history and duplicate suppression.

The existing protected baseline and its Virginia workflow tests are the starting contract. Add golden-result snapshots before moving logic.

## Phase 3 Conclusion

Virginia can become a rules package without weakening the current application, but this should be an extraction project, not a rewrite. The next implementation phase should add only the rule-pack boundary and a behavior-preserving Virginia adapter. The generic evaluator should follow after Virginia output equivalence is proven.
