# Phase 2 Workflow Verification

Checked: September 18, 2026

Scope: isolated `GIC_Development_2.0` workspace using fake data only. The protected AHS source and live data were not used or modified.

## Result

The current Virginia application passed its automated release baseline and the major browser workflows exercised in this phase. Three narrowly scoped workflow fixes were then implemented in the isolated development copy only.

- Complete automated suite: 111 tests passed.
- Targeted workflow/security suite: 53 tests passed.
- Browser setup, login, account creation, role restrictions, grid, student profile, agreement, and report checks completed.
- HTTP server log showed no application exceptions or HTTP 500 responses during the browser run.

## Browser Workflows Verified

1. First-time setup created a Virginia installation and initial Admin account.
2. Admin login and logout worked.
3. Admin created a Counselor and Teacher Viewer account.
4. Counselor login worked and allowed working access.
5. Counselor access to Admin user management was rejected with HTTP 403.
6. Teacher Viewer login showed the view-only notice.
7. Teacher Viewer access to Upload was rejected with HTTP 403.
8. Teacher Viewer access to protected Excel exports was rejected with HTTP 403.
9. A fake Class of 2031 grid was created with five synthetic students.
10. A fake Virginia assessment file updated existing students without creating duplicates.
11. The class grid showed calculated requirement status, employment evidence, 3E status, and SOL completion.
12. Student profile showed requirement status, EOC phase-in details, attempt history, manual edit controls, transcript progress, and 3E details.
13. Graduation Agreement rendered from the student's current status.
14. The employment-needs report correctly included only students without qualifying evidence.

## Automated Coverage Confirmed

- Virginia 2026-27 and later EOC phase-in boundaries
- Highest-score and multiple-attempt display
- Duplicate-attempt suppression
- LVC/CA and SPED/504 recalculation
- Reading and writing substitute tests
- History PBA pass/fail behavior
- Employment credentials, WPR, W!SE, and NCRC components
- Transcript course matching and Credit/SOL checklist accuracy
- Graduation Agreement and student PDF generation
- Every report and class Excel export
- Batch letters, agreements, and checklists
- Roster, grid, assessment, credential, transcript, and support-status imports
- Manual-field persistence after later uploads
- Student transfer, graduation, and restoration lifecycle
- Role/route authorization matrix
- CSRF enforcement, upload signature checks, path validation, online backup, and restore validation
- Blank-install, fake-demo, and live/demo isolation safeguards

## Findings To Address Before Promotion

### Phase 2 implementation status

- Finding 1 corrected in development: one-of pathway requirements now report the strongest met evidence without also saying the requirement is still needed.
- Finding 2 corrected in development: Existing Graduation Grid mapping now confirms detected dates or warns that undated scores will be preserved and may remain `Review Required`; the application does not guess a test date.
- Finding 3 corrected in development: the Delete Class action is rendered only for an Admin. Server-side authorization remains enforced.
- Finding 4 intentionally deferred: AHS keeps its Cougar wording. Generic naming belongs in the separately configured distribution edition and must not overwrite the AHS profile.
- Regression coverage added for all three implemented fixes.

### 1. Graduation Agreement can show contradictory pathway language

Severity: High for counselor clarity.

The test student had an earned NCRC credential. The agreement marked the CTE Credential / Pathway Requirement as `Yes`, but the notes also said pathway evidence was still needed. A row should never say both met and still needed.

Likely area: agreement-data and requirement-note generation in `app/local_server.py`.

Recommended test: a credential-only student should receive `Yes` with notes naming the credential and no missing-pathway sentence.

### 2. Existing-grid scores without true test dates require review

Severity: Medium; this is primarily a data-quality and onboarding issue.

Scores imported from the synthetic existing graduation grid appeared correctly, but the Virginia EOC phase-in panel flagged some as having a missing or invalid Pearson Test Date. The warning is safer than guessing a testing window, but schools need clear guidance that historical-grid scores may require dates before phase-in calculations can be fully audited.

Likely areas: existing-grid import mapping, upload preview guidance, and Virginia EOC rule-detail display.

Recommended test: import a historical grid with and without a valid test-date column and verify the preview clearly distinguishes deterministic calculation from review-required records.

### 3. Counselor sees a Delete Class link that only Admin can use

Severity: Low; authorization remains secure.

The Counselor class-grid page displayed `Delete Class`. Selecting it correctly returned HTTP 403. The link should be hidden for non-Admins to avoid confusion.

Likely area: Virginia class-grid action construction in `app/local_server.py`.

Recommended test: assert the delete link is absent in Counselor and Teacher Viewer HTML while the Admin link remains available.

### 4. Virginia/AHS support-plan wording remains school-specific

Severity: Low for the protected AHS edition; important for the general distribution edition.

The Virginia agreement still contains `Cougar Success` wording. This is appropriate for the AHS edition but must remain configurable or use generic labels in packages intended for other schools.

Likely areas: agreement rendering and school-profile/agreement configuration.

## Residual Test Gaps

- No full visual comparison was performed across multiple desktop and mobile viewport sizes.
- Browser printing and downloaded file opening were covered primarily by generation/parsing tests rather than manual printer-driver testing.
- Large transcript batches and very large assessment files were not load-tested in this phase.
- Accessibility was inspected through browser semantics, but a dedicated WCAG audit has not yet been run.
- Failed-login lockout is implemented and covered structurally, but this browser run did not intentionally lock the shared localhost client for 15 minutes.

## Recommendation

Keep the protected AHS release unchanged. The three general workflow defects are corrected in the isolated 2.0 workspace. Preserve school-specific naming through configuration when the general distribution edition is prepared, rerun the protected baseline after each development change, and promote only after side-by-side Virginia verification.
