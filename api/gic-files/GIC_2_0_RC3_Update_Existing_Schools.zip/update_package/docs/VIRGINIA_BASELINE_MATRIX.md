# Virginia Protected Baseline Matrix

This matrix records the behavior that must remain stable while GIC is improved. All scenarios use fictional students and temporary databases.

| Area | Protected behavior | Automated coverage |
|---|---|---|
| Virginia EOC windows | Initial valid attempt locks the applicable date-effective standard | `test_virginia_eoc_phase_in.py` |
| Math and Reading phase-in | Boundary scores and future standards are evaluated against the locked rule | `test_virginia_eoc_phase_in.py` |
| Administrative score codes | Values above 600 remain missing and never replace a valid score | `test_virginia_eoc_phase_in.py` |
| Highest score | Highest relevant score is displayed for the subject family | release and support-status tests |
| Multiple attempts | `#` appears only for distinct attempts that remain below the applicable passing standard | phase-in and release tests |
| Duplicate evidence | Grid and longitudinal copies do not create false attempts; different full dates remain distinct | phase-in tests |
| LVC/CA | SPED/504 and senior rules use the established eligibility conditions | support and phase-in tests |
| SPED/504 preservation | Generic uploads do not erase an established support designation | support refresh and manual-field tests |
| Reading substitute | Workplace Documents 4+ meets Reading while retaining Reading participation rules | release and import tests |
| Writing substitute | BLW 3+ meets Writing and combines with the highest failed Writing SOL | release and import tests |
| History PBA | Awarded/passing PBA is green; failed or sub-2 PBA remains red | history PBA tests |
| Employment credentials | WPR, W!SE and NCRC component/legacy rules retain their expected outcomes | employment credential tests |
| Transcript courses | Exact completed course titles populate the correct checklist item | release and pilot-readiness tests |
| 3E readiness | Enrollment, Employment and Enlistment evidence is calculated and displayed | pilot-readiness and release tests |
| Early graduation | Active class and original cohort remain separately represented | early-graduation tests |
| Transfer/graduated status | Inactive students leave active grids while cohort records remain | lifecycle tests |
| Imports | Rosters create grids; assessments update existing students; ambiguous identities are quarantined | roster and compatibility tests |
| Reports and exports | Expected Excel/PDF outputs generate from fictional records | release candidate tests |
| Authentication/roles | Admin, Counselor and Viewer route permissions remain enforced | role authorization tests |
| Security controls | CSRF, upload validation, sessions and demo/live isolation retain tested behavior | security and demo-isolation tests |
| Backup | SQLite online backup and validation retain tested behavior | security-hardening tests |

## Promotion Rule

A future development build must pass the full automated suite. Any changed expected result must be documented, approved, and shown not to weaken Virginia accuracy before an AHS package is generated.

