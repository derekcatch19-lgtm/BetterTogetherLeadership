# Phase 4 Multi-State Scaling Review

Checked: September 18, 2026

Scope: the isolated `GIC_Development_2.0` workspace and fake-data tests only. No live AHS data or installation was used or changed.

## Executive Result

GIC has a credible multi-state onboarding prototype, not yet a complete multi-state graduation platform. A new school can select Custom / Other State, upload local rules documents, receive local heuristic suggestions, edit and approve a proposal, create custom tracking fields, choose grid columns, import a roster or existing grid, populate fields by aliases, and run simple custom reports.

The remaining gap is execution. Approved rules currently seed tracking fields and lists, but they do not become a complete deterministic graduation calculator. Several configuration screens also store JSON that is not yet connected to runtime behavior. The safest next step is the rule-pack boundary identified in Phase 3, followed by a validated custom-rule schema and evaluator.

## End-to-End Capability Matrix

| Desired workflow | Current status | Evidence and limitation |
|---|---|---|
| Create school and Admin | Working | First-time setup stores school profile and hashed Admin credentials. |
| Select Virginia or custom state | Working | Setup branches between `Virginia Template` and `Custom / Other State Template`. There is no state catalog yet. |
| Select an existing saved template | Missing | Only Virginia or one active custom configuration can be selected. There is no template library. |
| Upload rules documents | Working | PDF, DOCX, XLS/XLSX, CSV, TXT, and HTML are validated and read locally. |
| Analyze documents locally | Partially working | Keyword/sentence heuristics identify candidate language. This protects privacy but is not semantic document understanding and can miss tables, exceptions, footnotes, and cohort rules. |
| Show source evidence and confidence | Working at basic level | Recommendations retain source filename and High/Needs Review confidence. Page citations and exact source locations are not retained. |
| Readable Admin review | Working | Structured text areas replace raw-JSON-only review; raw JSON is collapsed. |
| Add/edit/delete individual proposed rules | Partial | Admin can edit lines or remove text. There are no structured row controls, requirement types, thresholds, applicability, or dependencies. |
| Validate before approval | Incomplete | The page displays a message but does not block approval of empty, contradictory, or incomplete rules. |
| Approve and activate | Working as configuration save | Admin action changes template to Custom and stores the approved JSON. It does not create an executable rule version. |
| Preserve Virginia/custom separation | Working | Custom imports do not run Virginia SOL calculations. Automated coverage verifies this separation. |
| Generate tracking fields | Working at basic level | Approved items become required custom fields, generally using `nonblank` completion. Numeric credit requirements lose their thresholds. |
| Generate grid columns | Working at basic level | Base columns plus the first eight requirements are selected. Admin may show/hide fields. Reordering and safe rename are missing. |
| Generate reports | Working at basic level | One missing-item report is generated per requirement and simple one-field filters work. Multi-filter logic is missing. |
| Generate custom agreement | Not connected | Agreement JSON is seeded and editable, but the standard agreement renderer does not consume it. |
| Generate custom profile | Partial | Custom statuses appear through generic requirement data and manual editing, but visibility/type-specific controls are incomplete. |
| Generate custom dashboard | Missing | No dashboard definition is created from approved rules. |
| Generate import mappings | Not connected | Import-template JSON can be saved, but upload preview does not load or apply those templates. |
| Import roster/create grids without active rules | Working | Grid creation is state-independent and statuses can be calculated later. |
| Import existing grid and retain unknown fields | Working | Unknown populated columns can become custom fields and values. Conflict review remains basic. |
| Suggest spreadsheet mappings | Working at basic level | Canonical aliases and fuzzy matching suggest fields; Admin confirms. Suggestions are not source-profile aware. |
| Save confirmed mapping for reuse | Missing in workflow | Storage screen exists, but confirmed upload mappings are not offered for saving or automatically reused. |
| Calculate graduation status | Incomplete for custom states | Current custom “On Track” means no configured requirement status is missing. It does not evaluate diploma credits, alternatives, cohort rules, or dependencies. |
| Apply activated rules to existing students | Partial | Required fields are added without deleting students. Existing evidence is not comprehensively re-evaluated against structured rules. |
| Export custom grid | Working | Selected custom grid columns export to Excel. |
| Export custom reports to Excel/PDF | Partial | Excel/report output exists; browser printing may produce PDF, but there is no complete custom PDF export definition. |
| Save/share reusable state-school template | Missing | Active configuration cannot yet be exported, signed, imported, versioned, or selected by another school. |

## Strengths Worth Preserving

1. **Local-only document handling.** Rules documents and student information are not sent to an external model or cloud service.
2. **Administrator approval boundary.** Draft recommendations do not become active automatically.
3. **State separation.** Custom mode avoids accidental Virginia SOL calculation.
4. **State-independent grid creation.** Schools can create students and cohorts before their rules are finalized.
5. **Custom evidence ingestion.** Existing-grid unknown columns and configured aliases can populate local tracking fields.
6. **Practical counselor controls.** Grid visibility and simple missing-item reports already provide value without a full rules engine.
7. **Auditability foundation.** Setup and configuration changes are logged.

## High-Risk Gaps

### 1. Approval does not mean executable rules

`graduation_rules_config` is stored, but custom graduation status is derived from whether custom `requirement_status` rows are marked complete. Diploma totals, subject credit counts, assessment alternatives, and state-specific pathways are not evaluated.

Risk: a school may interpret “Active - Admin Approved” as meaning that GIC is calculating its graduation rules when it is mainly tracking seeded checklist fields.

Required correction: clearly label current custom rules as tracking configuration until the deterministic evaluator is available. The future activation flow must distinguish Draft, Validated, Approved, Active, and Superseded versions.

### 2. Structured requirements are flattened into text

The review form turns credit requirements into lines and `rules_config_from_review_form()` stores them as names with empty objects. Diploma total credits are stored as `None`. `seed_custom_setup_from_rules()` then creates mostly `nonblank` fields.

Risk: “English: 4 credits” can become a checkbox-like field instead of an auditable credit calculation.

Required correction: use typed requirements with numeric thresholds, evidence sources, operators, diploma applicability, cohort/effective dates, and all-of/any-of relationships.

### 3. Validation is advisory only

The review page can display “No structured requirements were detected,” but the approval button remains usable. There is no duplicate, contradiction, threshold, or reference validation.

Required correction: server-side schema validation must block activation and return field-specific errors. An approval preview should summarize what will be tracked and calculated.

### 4. Import templates are not wired into imports

`import_templates_config` is only edited and stored. The upload preview uses global aliases and fuzzy matching, not the selected saved profile.

Required correction: allow “Use saved mapping,” detect likely profile from headers/source type, show differences, and save the confirmed mapping after a successful import.

### 5. Custom agreement builder is not wired into rendering

The builder stores title, text, checklist items, supports, signatures, and footer. Custom student and batch agreements still use the Virginia-oriented agreement pipeline.

Required correction: render custom agreements from the active rule package and school agreement definition, with a preview before activation.

## Product and Usability Findings

- The setup sequence is distributed across several Admin pages. A progress checklist should show completed and remaining steps.
- “Validate” is visually represented as a wizard step but is not a separate durable state or action.
- Generated fields default to the first eight grid columns, which can overwhelm a grid and does not distinguish summary from detail.
- Custom fields can be updated by entering the same name, but renaming a field does not migrate existing status keys, report filters, grid columns, or agreement references.
- Deleting a field removes its definition but does not provide a clear impact preview for existing student values or reports.
- Custom reports support one filter. Schools will need AND/OR groups, class filters, diploma filters, sorting, selected columns, and saved export layouts.
- There is no configuration version history, rollback, comparison, or effective-date support.
- Rules-document retention is indefinite and lacks an Admin retention/delete control.
- The document analyzer does not retain page/section coordinates, making legal/rules review harder.
- Raw JSON editors remain for agreements and import templates; these are not suitable as the primary interface for most school administrators.

## Recommended Multi-State Data Model

Add versioned configuration without replacing current Virginia tables initially:

```text
rule_packs
  id, key, name, jurisdiction, version, status, effective_from,
  effective_to, approved_by, approved_at, source_summary

requirement_definitions
  id, rule_pack_id, key, label, type, operator, threshold,
  unit, required, diploma_scope, cohort_scope, display_order

requirement_relationships
  parent_requirement_id, child_requirement_id,
  relationship_type (all_of, any_of, count_of, alternative)

evidence_definitions
  id, rule_pack_id, key, evidence_type, aliases,
  subject_family, pass_rule, date_rule

calculation_results
  student_id, rule_pack_id, rule_version, requirement_key,
  status, value, explanation_json, calculated_at

saved_import_profiles
  id, name, source_type, header_fingerprint, mappings_json,
  transformations_json, active
```

Keep `requirement_status` as the compatibility/read model while the new calculation results are introduced. This reduces migration risk.

## Recommended Administrator Workflow

1. Choose Virginia, saved template, or Build New.
2. Enter jurisdiction, school, applicable cohorts, and effective school year.
3. Upload authoritative documents.
4. Review extracted source sections and recommendations.
5. Convert recommendations into typed requirements.
6. Resolve validation errors and warnings.
7. Preview generated grid, profile, agreement, reports, and import fields.
8. Run a fake-student calculation simulation.
9. Approve a named immutable version.
10. Preview impact on existing students.
11. Activate with backup and audit record.
12. Retain rollback to the previous active version.

## Ordered Implementation Plan

### 1. Add the rule-pack boundary

Create a registry and Virginia adapter as specified in Phase 3. Risk: medium. Virginia outputs must remain byte/value equivalent where practical.

### 2. Define and validate a custom rule schema

Support diploma plans, credit groups, thresholds, required/alternative items, effective dates, evidence types, and relationships. Risk: medium. No activation yet.

### 3. Replace line-based review with structured requirement rows

Allow add, edit, delete, source evidence, confidence, type, threshold, and applicability. Risk: low to medium.

### 4. Implement blocking validation and lifecycle states

Draft -> Validated -> Approved -> Active -> Superseded. Risk: medium.

### 5. Implement deterministic custom calculation

Evaluate only approved typed rules and emit explanation traces. Risk: high; use fake-state fixtures first.

### 6. Add activation preview and rollback

Show affected student counts and sample differences, create a backup, then activate. Risk: high.

### 7. Connect saved import profiles

Header fingerprint, profile suggestion, mapping confirmation, transformations, and save/reuse. Risk: medium.

### 8. Connect custom agreement and report definitions

Generate previewable student/batch agreements and richer reports from the active package. Risk: medium.

### 9. Add reusable template export/import

Package rules, fields, reports, agreements, import profiles, source citations, and version metadata without users or students. Risk: medium.

### 10. Add onboarding readiness dashboard

Show rules status, validation, roster/grid status, mappings, test simulation, backup, and go-live checklist. Risk: low.

## Phase 4 Conclusion

GIC is close enough to support controlled custom tracking pilots, but not yet to claim automatic graduation determination for arbitrary states. The next implementation should establish the rule-pack boundary and typed custom-rule schema while preserving the working Virginia engine unchanged. Once those exist, the current wizard can evolve from a field generator into a trustworthy multi-state configuration system.
