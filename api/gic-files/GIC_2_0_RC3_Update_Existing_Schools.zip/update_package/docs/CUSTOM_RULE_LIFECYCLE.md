# Custom Rule Lifecycle

Implemented: September 18, 2026

The structured custom-state rules builder now supports controlled lifecycle states without activating rules against student records.

## States available in this stage

- **Draft:** editable configuration.
- **Validated:** passed server-side schema checks and received a SHA-256 definition fingerprint.
- **Approved:** the validated fingerprint was verified and an immutable version snapshot was stored.
- **Active:** intentionally unavailable until impact preview, automatic backup, activation audit, and rollback are complete.
- **Superseded:** reserved for the later activation/rollback stage.

Any edit removes the validation attestation and returns the package to Draft. Approval is refused if the definition changed after validation. Approved snapshots are stored separately from the editable draft in `custom_rule_package_versions`.

No student record, active rule pack, Virginia calculation, report, or grid is changed by validation or approval.
