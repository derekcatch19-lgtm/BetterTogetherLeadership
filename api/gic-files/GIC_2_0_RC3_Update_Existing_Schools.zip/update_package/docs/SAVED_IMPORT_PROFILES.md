# Saved Import Profiles

Implemented: September 18, 2026

The upload workflow can now save and reuse confirmed spreadsheet column mappings.

## Workflow

1. Upload a representative roster, grid, assessment, credential, completion, or local spreadsheet.
2. The system computes a SHA-256 fingerprint from normalized column headers.
3. Profiles are considered only when their data-source type matches the selected upload type.
4. An exact fingerprint is applied automatically. A sufficiently similar header set is suggested with a message requiring the user to confirm changed columns.
5. The mapping page still allows every field to be reviewed and changed before processing.
6. An Admin may save the confirmed mapping after a successful import.
7. The Admin Import Profile Manager lists mappings and allows profiles to be enabled, disabled, or deleted.

Profiles contain header names, canonical field mappings, source type, local timestamps, and transformation metadata. They do not contain student rows or uploaded documents.

Virginia's existing aliases and fallback mapping remain available. A profile supplements those suggestions and cannot cross into a different source type.
