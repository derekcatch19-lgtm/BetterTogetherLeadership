# English Progress Tracker

Shared, login-protected English progress tracker for `10.18.30.86:5053`.

Course tabs: English 9, English 9 Honors, English 10, English 10 Honors,
English 11, English 12, DE 111, DE 112, DE 245, and DE 246.

Historical Virginia SOL fields: 6th Grade Reading, 7th Grade Reading,
8th Grade Reading, EOC Reading, and EOC Writing. When multiple attempts exist
for one test, the grid and staff exports show the highest attempt while the
complete history remains in shared data and JSON backups.

The primary readiness projection is the Grade 11 EOC Reading SOL. It uses the
newest pretest/benchmark, current course grade, and attendance with adjustable
weights and thresholds.

The main grid includes Q1, Q2, S1, Q3, Q4, S2, and Current Grade columns.
It also includes percentage-based Pre-Test, Benchmark 1-3, and Post-Test
columns. Post-Test uploads are separate from whole-number Historical SOL imports.

Roster text imports automatically recognize UTF-8, UTF-16, and Windows-1252
files as well as comma-, tab-, and semicolon-separated columns.

Roster imports support concurrent course enrollment. A student can appear in
both DE 111 and DE 112, or in both DE 245 and DE 246, without either course
record replacing the other.

See `START-HERE.txt` for installation instructions.
