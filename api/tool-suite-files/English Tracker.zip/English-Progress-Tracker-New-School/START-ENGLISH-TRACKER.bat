@echo off
title English Progress Tracker Server - Port 5053
cd /d "%~dp0"
set "ENGLISH_TRACKER_PORT=5053"
if exist "%~dp0portable-python\python.exe" (
  "%~dp0portable-python\python.exe" -u "%~dp0server.py"
) else (
  echo The included portable Python runtime is missing.
  echo Please extract every file from the ZIP before starting the tracker.
)
pause
