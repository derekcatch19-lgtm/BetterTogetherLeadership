@echo off
echo No installation is required. Portable Python is included with the tracker.
echo Start the program with START-MATH-TRACKER.bat.
pause
