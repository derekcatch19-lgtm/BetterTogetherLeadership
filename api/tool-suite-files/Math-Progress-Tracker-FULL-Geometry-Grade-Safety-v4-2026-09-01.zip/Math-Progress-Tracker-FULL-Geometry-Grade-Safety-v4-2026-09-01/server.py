from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import urlparse
import hashlib, hmac, json, os, secrets, sqlite3, time

BASE_DIR = Path(__file__).resolve().parent
PUBLIC_DIR = BASE_DIR / "public"
DATA_DIR = BASE_DIR / "server-data"
DB_PATH = DATA_DIR / "accounts.db"
PORT = int(os.environ.get("MATH_TRACKER_PORT", "5051"))
SESSIONS = {}
SESSION_SECONDS = 8 * 60 * 60

def db():
    DATA_DIR.mkdir(exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310000)
    return salt.hex() + ":" + digest.hex()

def valid_password(password, stored):
    try:
        salt, expected = stored.split(":", 1)
        actual = hash_password(password, bytes.fromhex(salt)).split(":", 1)[1]
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False

def initialize():
    with db() as con:
        con.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE COLLATE NOCASE, display_name TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'teacher', active INTEGER NOT NULL DEFAULT 1, must_change INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        con.execute("CREATE TABLE IF NOT EXISTS tracker_state (id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_by INTEGER)")
        if not con.execute("SELECT 1 FROM users LIMIT 1").fetchone():
            password = secrets.token_urlsafe(10)
            con.execute("INSERT INTO users(username,display_name,password_hash,role,must_change) VALUES(?,?,?,?,1)", ("admin", "Tracker Administrator", hash_password(password), "admin"))
            print("\nFIRST-TIME ADMIN ACCOUNT")
            print("Username: admin")
            print("Temporary password: " + password)
            print("Sign in and change this password immediately.\n")
        if not con.execute("SELECT 1 FROM tracker_state WHERE id=1").fetchone():
            initial_file=BASE_DIR / "INITIAL-TRACKER-DATA.json"
            if initial_file.exists():
                try:
                    initial=json.loads(initial_file.read_text(encoding="utf-8"))
                    if isinstance(initial.get("subjects"),dict):
                        con.execute("INSERT INTO tracker_state(id,data,revision) VALUES(1,?,1)",(json.dumps(initial,separators=(",",":")),))
                        print("Initial shared tracker data loaded into the server database.")
                except Exception as exc:
                    print("Initial tracker data could not be loaded:",exc)

class TrackerHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs): super().__init__(*args, directory=str(PUBLIC_DIR), **kwargs)
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        super().end_headers()
    def send_json(self, status, obj, cookie=None):
        payload=json.dumps(obj).encode()
        self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(payload)))
        if cookie: self.send_header("Set-Cookie", cookie)
        self.end_headers(); self.wfile.write(payload)
    def body(self):
        try: return json.loads(self.rfile.read(int(self.headers.get("Content-Length","0"))))
        except Exception: return {}
    def user(self):
        cookie=SimpleCookie(self.headers.get("Cookie","")); token=cookie.get("tracker_session")
        session=SESSIONS.get(token.value) if token else None
        if not session or session["expires"] < time.time(): return None
        session["expires"] = time.time()+SESSION_SECONDS
        with db() as con: row=con.execute("SELECT id,username,display_name,role,active,must_change FROM users WHERE id=?",(session["uid"],)).fetchone()
        return dict(row) if row and row["active"] else None
    def require(self, admin=False):
        user=self.user()
        if not user: self.send_json(401,{"error":"Sign in required"}); return None
        if admin and user["role"]!="admin": self.send_json(403,{"error":"Administrator access required"}); return None
        return user
    def do_GET(self):
        path=urlparse(self.path).path
        if path=="/health": return self.send_json(200,{"status":"ok","port":PORT})
        if path=="/api/me":
            user=self.user(); return self.send_json(200,{"user":user}) if user else self.send_json(401,{"error":"Sign in required"})
        if path=="/api/users":
            if not self.require(True): return
            with db() as con: rows=[dict(x) for x in con.execute("SELECT id,username,display_name,role,active,must_change,created_at FROM users ORDER BY display_name")]
            return self.send_json(200,{"users":rows})
        if path=="/api/state":
            if not self.require(): return
            with db() as con: row=con.execute("SELECT data,revision,updated_at FROM tracker_state WHERE id=1").fetchone()
            if not row: return self.send_json(200,{"state":None,"revision":0,"updated_at":None})
            try: data=json.loads(row["data"])
            except Exception: return self.send_json(500,{"error":"The shared tracker database could not be read"})
            return self.send_json(200,{"state":data,"revision":row["revision"],"updated_at":row["updated_at"]})
        if path not in ("/login.html","/auth.js","/auth.css") and not self.user():
            self.send_response(302); self.send_header("Location","/login.html"); self.end_headers(); return
        super().do_GET()
    def do_POST(self):
        path=urlparse(self.path).path; data=self.body()
        if path=="/api/login":
            with db() as con: row=con.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE",(str(data.get("username","")).strip(),)).fetchone()
            if not row or not row["active"] or not valid_password(str(data.get("password","")),row["password_hash"]): return self.send_json(401,{"error":"Incorrect username or password"})
            token=secrets.token_urlsafe(32); SESSIONS[token]={"uid":row["id"],"expires":time.time()+SESSION_SECONDS}
            return self.send_json(200,{"ok":True},f"tracker_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_SECONDS}")
        if path=="/api/logout":
            cookie=SimpleCookie(self.headers.get("Cookie","")); token=cookie.get("tracker_session")
            if token: SESSIONS.pop(token.value,None)
            return self.send_json(200,{"ok":True},"tracker_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0")
        if path=="/api/change-password":
            user=self.require();
            if not user:return
            password=str(data.get("password",""))
            if len(password)<10:return self.send_json(400,{"error":"Password must be at least 10 characters"})
            with db() as con: con.execute("UPDATE users SET password_hash=?,must_change=0 WHERE id=?",(hash_password(password),user["id"]))
            return self.send_json(200,{"ok":True})
        if path=="/api/users":
            if not self.require(True):return
            username=str(data.get("username","")).strip(); name=str(data.get("display_name","")).strip(); password=str(data.get("password","")); role=data.get("role","teacher")
            if not username or not name or len(password)<10 or role not in ("teacher","admin"):return self.send_json(400,{"error":"Enter a name, username, role, and temporary password of at least 10 characters"})
            try:
                with db() as con: con.execute("INSERT INTO users(username,display_name,password_hash,role) VALUES(?,?,?,?)",(username,name,hash_password(password),role))
            except sqlite3.IntegrityError:return self.send_json(409,{"error":"That username already exists"})
            return self.send_json(201,{"ok":True})
        if path.startswith("/api/users/"):
            if not self.require(True):return
            try: uid=int(path.rsplit("/",1)[1])
            except:return self.send_json(400,{"error":"Invalid user"})
            fields=[]; values=[]
            if "active" in data: fields.append("active=?"); values.append(1 if data["active"] else 0)
            if data.get("password"):
                if len(str(data["password"]))<10:return self.send_json(400,{"error":"Password must be at least 10 characters"})
                fields.extend(["password_hash=?","must_change=1"]); values.append(hash_password(str(data["password"])))
            if not fields:return self.send_json(400,{"error":"No change supplied"})
            values.append(uid)
            with db() as con: con.execute("UPDATE users SET "+",".join(fields)+" WHERE id=?",values)
            return self.send_json(200,{"ok":True})
        self.send_json(404,{"error":"Not found"})

    def do_PUT(self):
        path=urlparse(self.path).path
        if path!="/api/state": return self.send_json(404,{"error":"Not found"})
        user=self.require()
        if not user:return
        data=self.body(); state=data.get("state")
        if not isinstance(state,dict) or not isinstance(state.get("subjects"),dict): return self.send_json(400,{"error":"Invalid tracker data"})
        if user["role"]!="admin":
            with db() as con: existing=con.execute("SELECT data FROM tracker_state WHERE id=1").fetchone()
            if existing:
                try:
                    old=json.loads(existing["data"])
                    old_ids={str(s.get("_id")) for rows in old.get("subjects",{}).values() for s in rows if s.get("_id")}
                    new_ids={str(s.get("_id")) for rows in state.get("subjects",{}).values() for s in rows if s.get("_id")}
                    if old_ids-new_ids:return self.send_json(403,{"error":"Only an administrator can archive or delete a student"})
                except Exception:return self.send_json(500,{"error":"Could not validate student deletion permissions"})
        encoded=json.dumps(state,separators=(",",":"))
        if len(encoded)>50*1024*1024:return self.send_json(413,{"error":"Tracker data exceeds the 50 MB server limit"})
        with db() as con:
            row=con.execute("SELECT revision FROM tracker_state WHERE id=1").fetchone(); revision=(row["revision"]+1) if row else 1
            con.execute("INSERT INTO tracker_state(id,data,revision,updated_at,updated_by) VALUES(1,?,?,CURRENT_TIMESTAMP,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data,revision=excluded.revision,updated_at=CURRENT_TIMESTAMP,updated_by=excluded.updated_by",(encoded,revision,user["id"]))
        return self.send_json(200,{"ok":True,"revision":revision})

if __name__=="__main__":
    initialize(); server=ThreadingHTTPServer(("0.0.0.0",PORT),TrackerHandler)
    print(f"Math Progress Tracker: http://0.0.0.0:{PORT}")
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
