@echo off
title Math Progress Tracker Server - Port 5051
cd /d "%~dp0"
set "MATH_TRACKER_PORT=5051"
if exist "%~dp0portable-python\python.exe" (
  "%~dp0portable-python\python.exe" "%~dp0server.py"
) else (
  echo The included portable Python runtime is missing.
  echo Please extract every file from the ZIP before starting the tracker.
)
pause
