@echo off
cd /d "%~dp0"
"%~dp0portable-python\python.exe" -m py_compile "%~dp0server.py"
if errorlevel 1 goto failed
if exist "%~dp0portable-node\node.exe" (
  "%~dp0portable-node\node.exe" "%~dp0tests\tracker-tests.js"
) else (
  echo Browser rule tests are included in tests\tracker-tests.js.
  echo Run them with Node.js when available.
)
pause
exit /b 0
:failed
echo Tests failed.
pause
exit /b 1
