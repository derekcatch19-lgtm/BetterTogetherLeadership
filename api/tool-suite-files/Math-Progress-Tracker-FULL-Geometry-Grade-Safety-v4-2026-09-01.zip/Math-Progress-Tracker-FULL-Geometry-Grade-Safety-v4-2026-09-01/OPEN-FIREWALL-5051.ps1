$ErrorActionPreference = "Stop"
$ruleName = "Math Progress Tracker TCP 5051"

if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule `
        -DisplayName $ruleName `
        -Direction Inbound `
        -Protocol TCP `
        -LocalPort 5051 `
        -Action Allow `
        -Profile Domain,Private
}

Write-Host "Firewall access is enabled for TCP port 5051 on Domain and Private networks."
Write-Host "Server addresses:"
Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike "127.*" -and $_.AddressState -eq "Preferred" } |
    ForEach-Object { Write-Host ("  http://" + $_.IPAddress + ":5051") }
