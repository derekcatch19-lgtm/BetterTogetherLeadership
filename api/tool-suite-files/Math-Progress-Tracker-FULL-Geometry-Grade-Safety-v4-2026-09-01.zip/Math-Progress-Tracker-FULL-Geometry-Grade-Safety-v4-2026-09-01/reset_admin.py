from pathlib import Path
import hashlib, secrets, sqlite3

base = Path(__file__).resolve().parent
database = base / "server-data" / "accounts.db"
if not database.exists():
    print("No account database was found. Start the tracker once first.")
    raise SystemExit(1)

password = secrets.token_urlsafe(12)
salt = secrets.token_bytes(16)
digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310000)
stored = salt.hex() + ":" + digest.hex()

with sqlite3.connect(database) as con:
    row = con.execute("SELECT id FROM users WHERE username='admin' COLLATE NOCASE").fetchone()
    if row:
        con.execute("UPDATE users SET password_hash=?,active=1,must_change=1,role='admin' WHERE id=?", (stored, row[0]))
    else:
        con.execute("INSERT INTO users(username,display_name,password_hash,role,active,must_change) VALUES('admin','Tracker Administrator',?,'admin',1,1)", (stored,))

print()
print("ADMINISTRATOR PASSWORD RESET")
print("Username: admin")
print("Temporary password: " + password)
print("Sign in and create a permanent password when prompted.")
print()
