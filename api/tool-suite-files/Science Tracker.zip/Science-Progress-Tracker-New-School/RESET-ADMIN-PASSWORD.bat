@echo off
title Reset Science Progress Tracker Administrator
cd /d "%~dp0"
if exist "%~dp0portable-python\python.exe" (
  "%~dp0portable-python\python.exe" -u "%~dp0reset_admin.py"
) else (
  echo The portable-python folder is missing. Extract the complete ZIP again.
)
pause
