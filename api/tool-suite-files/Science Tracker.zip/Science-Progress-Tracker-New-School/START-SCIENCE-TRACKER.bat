@echo off
title Science Progress Tracker Server - Port 5052
cd /d "%~dp0"
set "SCIENCE_TRACKER_PORT=5052"
if exist "%~dp0portable-python\python.exe" (
  "%~dp0portable-python\python.exe" -u "%~dp0server.py"
) else (
  echo The included portable Python runtime is missing.
  echo Please extract every file from the ZIP before starting the tracker.
)
pause
