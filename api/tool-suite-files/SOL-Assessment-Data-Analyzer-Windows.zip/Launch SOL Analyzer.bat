@echo off
setlocal
set "APP_DIR=%~dp0"
set "PYTHON_EXE=C:\Users\Teacher\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
set "APP_URL=http://127.0.0.1:8765/"

if not exist "%PYTHON_EXE%" (
  where py >nul 2>nul
  if %errorlevel%==0 (
    set "PYTHON_EXE=py"
  ) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
      set "PYTHON_EXE=python"
    ) else (
      echo Python was not found.
      echo Install Python 3.11 or newer, then run this launcher again.
      echo.
      echo Download Python from:
      echo https://www.python.org/downloads/windows/
      echo.
      echo During install, check "Add python.exe to PATH".
      pause
      exit /b 1
    )
  )
)

echo Checking required local Python packages...
"%PYTHON_EXE%" -c "import pandas, openpyxl" >nul 2>nul
if not %errorlevel%==0 (
  echo This app needs pandas and openpyxl.
  echo.
  echo I can try to install them now using pip.
  echo This requires internet access on this computer.
  echo.
  choice /C YN /M "Install pandas and openpyxl now"
  if errorlevel 2 (
    echo.
    echo Run this command once in Command Prompt or PowerShell, then launch again:
    echo.
    echo   "%PYTHON_EXE%" -m pip install pandas openpyxl
    echo.
    pause
    exit /b 1
  )
  "%PYTHON_EXE%" -m pip install pandas openpyxl
  if not %errorlevel%==0 (
    echo.
    echo The package install did not finish successfully.
    echo Try this command in Command Prompt or PowerShell:
    echo.
    echo   "%PYTHON_EXE%" -m pip install pandas openpyxl
    echo.
    pause
    exit /b 1
  )
  "%PYTHON_EXE%" -c "import pandas, openpyxl" >nul 2>nul
  if not %errorlevel%==0 (
    echo.
    echo pandas/openpyxl still could not be loaded.
    echo.
    pause
    exit /b 1
  )
)

echo.
echo Starting SOL Assessment Data Analyzer...
echo If your browser does not open, go to:
echo %APP_URL%
echo.

start "" "%APP_URL%"
"%PYTHON_EXE%" "%APP_DIR%server.py"
if not %errorlevel%==0 (
  echo.
  echo The analyzer stopped because of an error.
  echo Please copy the message above if you need help.
  echo.
  pause
  exit /b 1
)
