from __future__ import annotations

import base64
import cgi
import io
import json
import math
import os
import re
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import pandas as pd
from openpyxl import Workbook
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter


APP_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = int(os.environ.get("SOL_ANALYZER_PORT", "8765"))

CANONICAL_FIELDS = {
    "student": "Student Name or ID",
    "teacher": "Teacher / Group",
    "group_name": "Group Name",
    "delivery_group": "Delivery Group",
    "subject": "Subject",
    "sol": "SOL / Standard",
    "descriptor": "Item Descriptor",
    "level": "Question Level",
    "result": "Correct / Incorrect",
}

REQUIRED_FIELDS = ["descriptor", "level", "sol", "result"]

FIELD_ALIASES = {
    "student": [
        "student",
        "student name",
        "student id",
        "studentid",
        "ssid",
        "local id",
        "state testing identifier",
    ],
    "teacher": ["teacher", "teacher name", "instructor", "group", "class", "section"],
    "group_name": ["group name", "groupname", "reporting group", "test group"],
    "delivery_group": ["delivery group", "deliverygroup", "delivery"],
    "subject": ["subject", "course", "test", "test subject", "assessment subject", "content area"],
    "sol": ["sol", "standard", "standards", "reporting category", "objective", "strand"],
    "descriptor": [
        "item descriptor",
        "itemdescriptor",
        "descriptor",
        "item description",
        "question descriptor",
        "skill",
        "item",
    ],
    "level": ["question level", "level", "difficulty", "item difficulty", "cognitive level"],
    "result": [
        "correct incorrect",
        "correct/incorrect",
        "correct incorrect flag",
        "correct",
        "incorrect",
        "item result",
        "itemresult",
        "response",
        "result",
        "response result",
        "points earned",
        "score",
    ],
}

CORRECT_VALUES = {"correct", "cor", "corr", "c", "yes", "y", "1", "true", "100%", "100", "1.0"}
INCORRECT_VALUES = {"incorrect", "inc", "i", "no", "n", "0", "false", "0%", "0.0"}
INVALID_SHEET_CHARS = re.compile(r"[:\\/?*\[\]]")


def normalize_header(value: Any) -> str:
    text = str(value or "").strip().lower()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text


def detect_columns(columns: list[str]) -> dict[str, str]:
    normalized = {col: normalize_header(col) for col in columns}
    used: set[str] = set()
    detected: dict[str, str] = {}

    for field, aliases in FIELD_ALIASES.items():
        for alias in aliases:
            alias_norm = normalize_header(alias)
            exact = next(
                (col for col, norm in normalized.items() if col not in used and norm == alias_norm),
                None,
            )
            if exact:
                detected[field] = exact
                used.add(exact)
                break

    for field, aliases in FIELD_ALIASES.items():
        if field in detected:
            continue
        alias_norm = [normalize_header(alias) for alias in aliases]
        fuzzy = next(
            (
                col
                for col, norm in normalized.items()
                if col not in used
                and any(
                    len(alias) >= 4 and re.search(rf"(^|\s){re.escape(alias)}($|\s)", norm)
                    for alias in alias_norm
                )
            ),
            None,
        )
        if fuzzy:
            detected[field] = fuzzy
            used.add(fuzzy)

    if "teacher" not in detected:
        if "group_name" in detected:
            detected["teacher"] = detected["group_name"]
        elif "delivery_group" in detected:
            detected["teacher"] = detected["delivery_group"]

    return detected


def read_table(file_bytes: bytes, filename: str) -> pd.DataFrame:
    suffix = Path(filename).suffix.lower()
    stream = io.BytesIO(file_bytes)
    if suffix == ".csv":
        return pd.read_csv(stream, dtype=str, keep_default_na=False)
    if suffix == ".xlsx":
        return pd.read_excel(stream, dtype=str, keep_default_na=False, engine="openpyxl")
    if suffix == ".xls":
        raise ValueError(".xls files require optional xlrd support. Please save as .xlsx or .csv.")
    raise ValueError("Unsupported file type. Upload a .csv or .xlsx file.")


def level_to_hml(value: Any) -> str | None:
    text = str(value or "").strip().lower()
    if not text:
        return None
    if text in {"h", "high", "hard"}:
        return "H"
    if text in {"m", "medium", "moderate", "med"}:
        return "M"
    if text in {"l", "low", "easy"}:
        return "L"
    if text.startswith("h"):
        return "H"
    if text.startswith("m"):
        return "M"
    if text.startswith("l") or text.startswith("e"):
        return "L"
    return None


def result_to_bool(value: Any) -> bool | None:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return None
    text = str(value).strip().lower()
    if not text:
        return None
    if text in CORRECT_VALUES:
        return True
    if text in INCORRECT_VALUES:
        return False
    try:
        number = float(text.replace("%", ""))
        if "%" in text:
            return number >= 99.999
        if number in {0.0, 1.0}:
            return number == 1.0
    except ValueError:
        pass
    return None


def clean_text(value: Any, fallback: str = "Unspecified") -> str:
    text = str(value or "").strip()
    return text if text else fallback


def normalize_data(df: pd.DataFrame, mapping: dict[str, str]) -> tuple[pd.DataFrame, list[str]]:
    missing = [CANONICAL_FIELDS[field] for field in REQUIRED_FIELDS if not mapping.get(field)]
    if missing:
        raise ValueError("Required columns are missing: " + ", ".join(missing))

    normalized = pd.DataFrame()
    normalized["Item Descriptor"] = df[mapping["descriptor"]].map(clean_text)
    normalized["Level"] = df[mapping["level"]].map(level_to_hml)
    normalized["SOL"] = df[mapping["sol"]].map(clean_text)
    normalized["IsCorrect"] = df[mapping["result"]].map(result_to_bool)
    normalized["Student Name"] = (
        df[mapping["student"]].map(clean_text) if mapping.get("student") else "Unknown Student"
    )

    teacher_col = mapping.get("teacher") or mapping.get("group_name") or mapping.get("delivery_group")
    normalized["Teacher/Group"] = (
        df[teacher_col].map(clean_text) if teacher_col else "All Students"
    )
    normalized["Subject"] = df[mapping["subject"]].map(clean_text) if mapping.get("subject") else "All Subjects"

    warnings: list[str] = []
    invalid_levels = int(normalized["Level"].isna().sum())
    invalid_results = int(normalized["IsCorrect"].isna().sum())
    if invalid_levels:
        warnings.append(f"{invalid_levels} row(s) had question levels that could not be standardized.")
    if invalid_results:
        warnings.append(f"{invalid_results} row(s) had result values that could not be interpreted.")

    normalized = normalized.dropna(subset=["Level", "IsCorrect"])
    if normalized.empty:
        raise ValueError("No valid rows were found after standardizing level and result values.")
    normalized["IsCorrect"] = normalized["IsCorrect"].astype(bool)
    return normalized, warnings


def grouped_summary(df: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    summary = (
        df.groupby(group_cols, dropna=False)["IsCorrect"]
        .agg(TimesAsked="size", TimesCorrect="sum")
        .reset_index()
    )
    summary["TimesCorrect"] = summary["TimesCorrect"].astype(int)
    summary["TimesIncorrect"] = summary["TimesAsked"] - summary["TimesCorrect"]
    summary["PercentCorrect"] = summary["TimesCorrect"] / summary["TimesAsked"]
    return summary.sort_values(group_cols).reset_index(drop=True)


def display_summary(frame: pd.DataFrame) -> pd.DataFrame:
    return frame.rename(
        columns={
            "TimesAsked": "Times Asked",
            "TimesCorrect": "Times Correct",
            "TimesIncorrect": "Times Incorrect",
            "PercentCorrect": "Percent Correct",
        }
    )


def percent_or_blank(correct: int, asked: int) -> float | str:
    return round(correct / asked, 4) if asked else ""


def best_label(frame: pd.DataFrame, group_col: str, ascending: bool) -> str:
    if frame.empty:
        return ""
    ordered = frame.sort_values(
        ["PercentCorrect", "TimesAsked", group_col],
        ascending=[ascending, False, True],
    )
    return str(ordered.iloc[0][group_col])


def make_focus_area(weakest_sol: str, weakest_descriptor: str, percent_correct: float) -> str:
    if not weakest_sol and not weakest_descriptor:
        return ""
    if percent_correct >= 0.85:
        return "Extend and maintain high performance"
    label = " / ".join(part for part in [weakest_sol, weakest_descriptor] if part)
    return f"Small-group review: {label}"


def student_summary(normalized: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    by_student = normalized.groupby(["Teacher/Group", "Student Name"], dropna=False)
    for (teacher, student), student_df in by_student:
        total_questions = int(len(student_df))
        total_correct = int(student_df["IsCorrect"].sum())
        total_incorrect = total_questions - total_correct

        level_values: dict[str, float | str] = {}
        for level in ["H", "M", "L"]:
            level_df = student_df[student_df["Level"] == level]
            level_values[level] = percent_or_blank(int(level_df["IsCorrect"].sum()), int(len(level_df)))

        by_sol = grouped_summary(student_df, ["SOL"])
        by_descriptor = grouped_summary(student_df, ["Item Descriptor"])
        weakest_sol = best_label(by_sol, "SOL", True)
        weakest_descriptor = best_label(by_descriptor, "Item Descriptor", True)
        strongest_sol = best_label(by_sol, "SOL", False)
        percent_correct = total_correct / total_questions if total_questions else 0

        rows.append(
            {
                "Teacher/Group": teacher,
                "Student Name": student,
                "Total Questions": total_questions,
                "Total Correct": total_correct,
                "Total Incorrect": total_incorrect,
                "Percent Correct": round(percent_correct, 4),
                "High Level Percent Correct": level_values["H"],
                "Medium Level Percent Correct": level_values["M"],
                "Low Level Percent Correct": level_values["L"],
                "Weakest SOL": weakest_sol,
                "Weakest Item Descriptor": weakest_descriptor,
                "Strongest SOL": strongest_sol,
                "Recommended Focus Area": make_focus_area(weakest_sol, weakest_descriptor, percent_correct),
            }
        )

    return pd.DataFrame(rows).sort_values(["Teacher/Group", "Student Name"]).reset_index(drop=True)


def student_weaknesses(normalized: pd.DataFrame) -> pd.DataFrame:
    frame = grouped_summary(
        normalized,
        ["Teacher/Group", "Student Name", "SOL", "Item Descriptor", "Level"],
    )
    frame = frame[frame["TimesAsked"] >= 2].sort_values(
        ["Teacher/Group", "Student Name", "PercentCorrect", "TimesAsked", "SOL", "Item Descriptor"],
        ascending=[True, True, True, False, True, True],
    )
    return display_summary(frame)[
        ["Teacher/Group", "Student Name", "SOL", "Item Descriptor", "Level", "Times Asked", "Times Correct", "Percent Correct"]
    ].reset_index(drop=True)


def performance_band(percent_correct: float) -> str:
    if percent_correct < 0.5:
        return "Students Below 50%"
    if percent_correct < 0.7:
        return "Students 50-69%"
    if percent_correct < 0.85:
        return "Students 70-84%"
    return "Students 85%+"


def intervention_groups(normalized: pd.DataFrame) -> pd.DataFrame:
    student_area = grouped_summary(
        normalized,
        ["Teacher/Group", "Student Name", "SOL", "Item Descriptor", "Level"],
    )
    rows: list[dict[str, Any]] = []
    for (teacher, sol, descriptor, level), area_df in student_area.groupby(
        ["Teacher/Group", "SOL", "Item Descriptor", "Level"],
        dropna=False,
    ):
        buckets = {
            "Students Below 50%": [],
            "Students 50-69%": [],
            "Students 70-84%": [],
            "Students 85%+": [],
        }
        for _, row in area_df.sort_values("Student Name").iterrows():
            buckets[performance_band(float(row["PercentCorrect"]))].append(str(row["Student Name"]))
        if buckets["Students Below 50%"] or buckets["Students 50-69%"]:
            focus = "Reteach and guided practice"
        elif buckets["Students 70-84%"]:
            focus = "Targeted practice to reach mastery"
        else:
            focus = "Extension or spiral review"
        rows.append(
            {
                "Teacher/Group": teacher,
                "SOL": sol,
                "Item Descriptor": descriptor,
                "Level": level,
                "Students Below 50%": ", ".join(buckets["Students Below 50%"]),
                "Students 50-69%": ", ".join(buckets["Students 50-69%"]),
                "Students 70-84%": ", ".join(buckets["Students 70-84%"]),
                "Students 85%+": ", ".join(buckets["Students 85%+"]),
                "Suggested Grouping Focus": focus,
            }
        )
    return pd.DataFrame(rows).sort_values(["Teacher/Group", "SOL", "Item Descriptor", "Level"]).reset_index(drop=True)


def summary_records(frame: pd.DataFrame, limit: int | None = None) -> list[dict[str, Any]]:
    rows = frame.head(limit).to_dict(orient="records") if limit else frame.to_dict(orient="records")
    for row in rows:
        if "PercentCorrect" in row:
            row["PercentCorrect"] = round(float(row["PercentCorrect"]), 4)
    return rows


def calculate(normalized: pd.DataFrame, min_times_asked: int) -> dict[str, Any]:
    by_descriptor = grouped_summary(normalized, ["Item Descriptor", "Level", "SOL"])
    qualified = by_descriptor[by_descriptor["TimesAsked"] >= min_times_asked]
    strengths = qualified.sort_values(
        ["PercentCorrect", "TimesAsked", "Item Descriptor"],
        ascending=[False, False, True],
    ).head(10)
    weaknesses = qualified.sort_values(
        ["PercentCorrect", "TimesAsked", "Item Descriptor"],
        ascending=[True, False, True],
    ).head(10)

    overall = {
        "TimesAsked": int(len(normalized)),
        "TimesCorrect": int(normalized["IsCorrect"].sum()),
    }
    overall["TimesIncorrect"] = overall["TimesAsked"] - overall["TimesCorrect"]
    overall["PercentCorrect"] = round(overall["TimesCorrect"] / overall["TimesAsked"], 4)

    return {
        "overall": overall,
        "byTeacher": summary_records(grouped_summary(normalized, ["Teacher/Group"])),
        "bySubject": summary_records(grouped_summary(normalized, ["Subject"])),
        "bySOL": summary_records(grouped_summary(normalized, ["SOL"])),
        "byDescriptor": summary_records(grouped_summary(normalized, ["Item Descriptor"])),
        "byLevel": summary_records(grouped_summary(normalized, ["Level"])),
        "byDescriptorLevelSOL": summary_records(by_descriptor),
        "byTeacherDescriptorLevelSOL": summary_records(
            grouped_summary(normalized, ["Teacher/Group", "Item Descriptor", "Level", "SOL"])
        ),
        "topStrengths": summary_records(strengths, 5),
        "topWeaknesses": summary_records(weaknesses, 5),
        "threshold": min_times_asked,
    }


def clean_sheet_name(name: str, existing: set[str]) -> str:
    cleaned = INVALID_SHEET_CHARS.sub("", str(name)).strip().strip("'") or "Sheet"
    cleaned = re.sub(r"\s+", " ", cleaned)
    base = cleaned[:31]
    candidate = base
    index = 2
    while candidate in existing:
        suffix = f" {index}"
        candidate = base[: 31 - len(suffix)] + suffix
        index += 1
    existing.add(candidate)
    return candidate


def write_summary_table(ws, start_row: int, title: str, rows: list[dict[str, Any]]) -> int:
    ws.cell(start_row, 1, title).font = Font(bold=True, size=12)
    headers = ["Item Descriptor", "Level", "SOL", "TimesAsked", "TimesCorrect", "TimesIncorrect", "PercentCorrect"]
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(start_row + 1, col_idx, header.replace("Times", "Times "))
        cell.font = Font(bold=True)
    for row_idx, row in enumerate(rows, start_row + 2):
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row_idx, col_idx, row.get(header, ""))
            if header == "PercentCorrect":
                cell.number_format = "0.0%"
    return start_row + len(rows) + 4


def add_analysis_sheet(wb: Workbook, summary: dict[str, Any]) -> None:
    ws = wb.create_sheet("Summary")
    ws["A1"] = "Overall Totals"
    ws["A1"].font = Font(bold=True, size=12)
    rows = [
        ("Times Asked", summary["overall"]["TimesAsked"]),
        ("Times Correct", summary["overall"]["TimesCorrect"]),
        ("Times Incorrect", summary["overall"]["TimesIncorrect"]),
        ("Percent Correct", summary["overall"]["PercentCorrect"]),
        ("Strength/Weakness Threshold", summary["threshold"]),
    ]
    for idx, (label, value) in enumerate(rows, 2):
        ws.cell(idx, 1, label)
        ws.cell(idx, 2, value)
    ws["B5"].number_format = "0.0%"
    next_row = write_summary_table(ws, 8, "Top Strengths", summary["topStrengths"])
    write_summary_table(ws, next_row, "Top Weaknesses", summary["topWeaknesses"])
    format_sheet(ws)


def format_sheet(ws) -> None:
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for cell in ws[1]:
        cell.font = Font(bold=True)

    for col_idx, column_cells in enumerate(ws.columns, 1):
        values = [str(cell.value or "") for cell in column_cells]
        width = min(max(len(value) for value in values) + 2, 48)
        ws.column_dimensions[get_column_letter(col_idx)].width = max(width, 12)

    percent_columns = [
        cell.column
        for cell in ws[1]
        if "percent" in str(cell.value or "").strip().lower()
    ]
    for col_idx in percent_columns:
        letter = get_column_letter(col_idx)
        for cell in ws[letter][1:]:
            cell.number_format = "0.0%"
        if ws.max_row < 2:
            continue
        ws.conditional_formatting.add(
            f"{letter}2:{letter}{ws.max_row}",
            ColorScaleRule(
                start_type="num",
                start_value=0,
                start_color="F8696B",
                mid_type="num",
                mid_value=0.7,
                mid_color="FFEB84",
                end_type="num",
                end_value=1,
                end_color="63BE7B",
            ),
        )


def add_detail_sheet(wb: Workbook, title: str, frame: pd.DataFrame, existing: set[str]) -> None:
    ws = wb.create_sheet(clean_sheet_name(title, existing))
    export = display_summary(frame)
    headers = ["Item Descriptor", "Level", "SOL", "Times Asked", "Times Correct", "Times Incorrect", "Percent Correct"]
    ws.append(headers)
    for _, row in export[headers].iterrows():
        ws.append(list(row))
    format_sheet(ws)


def add_frame_sheet(
    wb: Workbook,
    title: str,
    frame: pd.DataFrame,
    existing: set[str],
    headers: list[str] | None = None,
) -> None:
    ws = wb.create_sheet(clean_sheet_name(title, existing))
    export = display_summary(frame)
    selected_headers = headers or list(export.columns)
    export = export.reindex(columns=selected_headers)
    ws.append(selected_headers)
    for _, row in export[selected_headers].iterrows():
        ws.append(list(row))
    format_sheet(ws)


def add_student_analysis_sheets(wb: Workbook, normalized: pd.DataFrame, existing: set[str]) -> None:
    add_frame_sheet(
        wb,
        "Teacher Student Summary",
        student_summary(normalized),
        existing,
        [
            "Teacher/Group",
            "Student Name",
            "Total Questions",
            "Total Correct",
            "Total Incorrect",
            "Percent Correct",
            "High Level Percent Correct",
            "Medium Level Percent Correct",
            "Low Level Percent Correct",
            "Weakest SOL",
            "Weakest Item Descriptor",
            "Strongest SOL",
            "Recommended Focus Area",
        ],
    )
    add_frame_sheet(
        wb,
        "Teacher Student by SOL",
        grouped_summary(normalized, ["Teacher/Group", "Student Name", "SOL"]),
        existing,
        ["Teacher/Group", "Student Name", "SOL", "Times Asked", "Times Correct", "Times Incorrect", "Percent Correct"],
    )
    add_frame_sheet(
        wb,
        "Teacher Student by Level",
        grouped_summary(normalized, ["Teacher/Group", "Student Name", "Level"]),
        existing,
        ["Teacher/Group", "Student Name", "Level", "Times Asked", "Times Correct", "Times Incorrect", "Percent Correct"],
    )
    add_frame_sheet(wb, "Teacher Student Weaknesses", student_weaknesses(normalized), existing)
    add_frame_sheet(wb, "Intervention Groups", intervention_groups(normalized), existing)


def create_workbook(
    normalized: pd.DataFrame,
    summary: dict[str, Any],
    include_student_tabs: bool = True,
    has_student_column: bool = False,
) -> bytes:
    wb = Workbook()
    wb.remove(wb.active)
    existing: set[str] = set()

    subjects = sorted(normalized["Subject"].dropna().unique().tolist())
    if len(subjects) <= 1:
        frame = grouped_summary(normalized, ["Item Descriptor", "Level", "SOL"])
        add_detail_sheet(wb, "Overall", frame, existing)
    else:
        for subject in subjects:
            frame = grouped_summary(
                normalized[normalized["Subject"] == subject],
                ["Item Descriptor", "Level", "SOL"],
            )
            add_detail_sheet(wb, f"Overall {subject}", frame, existing)

    for teacher in sorted(normalized["Teacher/Group"].dropna().unique().tolist()):
        frame = grouped_summary(
            normalized[normalized["Teacher/Group"] == teacher],
            ["Item Descriptor", "Level", "SOL"],
        )
        add_detail_sheet(wb, str(teacher), frame, existing)

    if include_student_tabs and has_student_column:
        add_student_analysis_sheets(wb, normalized, existing)

    add_analysis_sheet(wb, summary)
    output = io.BytesIO()
    wb.save(output)
    return output.getvalue()


def make_preview(df: pd.DataFrame) -> list[dict[str, str]]:
    return df.head(8).fillna("").astype(str).to_dict(orient="records")


def parse_upload(handler: BaseHTTPRequestHandler) -> tuple[bytes, str, dict[str, str]]:
    form = cgi.FieldStorage(
        fp=handler.rfile,
        headers=handler.headers,
        environ={
            "REQUEST_METHOD": "POST",
            "CONTENT_TYPE": handler.headers.get("Content-Type"),
        },
    )
    file_field = form["file"] if "file" in form else None
    if file_field is None or not getattr(file_field, "filename", ""):
        raise ValueError("No file was uploaded.")
    file_bytes = file_field.file.read()
    if not file_bytes:
        raise ValueError("The uploaded file is empty.")
    fields = {
        key: form.getvalue(key)
        for key in form.keys()
        if key not in {"file"} and isinstance(form.getvalue(key), str)
    }
    return file_bytes, file_field.filename, fields


class Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        if self.path in {"/", "/index.html"}:
            self.send_file(APP_DIR / "index.html", "text/html; charset=utf-8")
            return
        self.send_error(404)

    def do_POST(self) -> None:
        try:
            if self.path == "/api/inspect":
                self.inspect()
            elif self.path == "/api/report":
                self.report()
            else:
                self.send_error(404)
        except Exception as exc:
            self.send_json({"error": str(exc), "trace": traceback.format_exc()}, status=400)

    def inspect(self) -> None:
        file_bytes, filename, _ = parse_upload(self)
        df = read_table(file_bytes, filename)
        if df.empty:
            raise ValueError("The uploaded file has no rows.")
        columns = [str(col) for col in df.columns]
        suggestions = detect_columns(columns)
        self.send_json(
            {
                "filename": filename,
                "rowCount": int(len(df)),
                "columns": columns,
                "suggestions": suggestions,
                "preview": make_preview(df),
                "requiredFields": REQUIRED_FIELDS,
                "fieldLabels": CANONICAL_FIELDS,
            }
        )

    def report(self) -> None:
        file_bytes, filename, fields = parse_upload(self)
        df = read_table(file_bytes, filename)
        if df.empty:
            raise ValueError("The uploaded file has no rows.")
        mapping = {}
        for field in CANONICAL_FIELDS:
            value = fields.get(f"map_{field}", "")
            if value:
                mapping[field] = value
        min_times_asked = max(1, int(fields.get("minTimesAsked", "10") or 10))
        include_student_tabs = fields.get("includeStudentTabs", "1") == "1"
        normalized, warnings = normalize_data(df, mapping)
        summary = calculate(normalized, min_times_asked)
        has_student_column = bool(mapping.get("student"))
        if include_student_tabs and not has_student_column:
            warnings.append("Student-level tabs were requested, but no Student Name or Student ID column was mapped.")
        workbook = create_workbook(normalized, summary, include_student_tabs, has_student_column)
        safe_stem = re.sub(r"[^A-Za-z0-9_-]+", "-", Path(filename).stem).strip("-") or "sol-assessment"
        self.send_json(
            {
                "warnings": warnings,
                "summary": summary,
                "workbookFileName": f"{safe_stem}-analysis.xlsx",
                "workbookBase64": base64.b64encode(workbook).decode("ascii"),
            }
        )

    def send_file(self, path: Path, content_type: str) -> None:
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"SOL Assessment Data Analyzer running at http://{HOST}:{PORT}")
    if os.environ.get("SOL_ANALYZER_NO_BROWSER") != "1":
        webbrowser.open(f"http://{HOST}:{PORT}")
    server.serve_forever()


if __name__ == "__main__":
    main()
