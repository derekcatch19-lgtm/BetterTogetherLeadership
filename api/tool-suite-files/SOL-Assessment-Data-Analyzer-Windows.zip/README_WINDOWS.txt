SOL Assessment Data Analyzer - Windows
=====================================

This is a local-only, code-only analyzer. Uploaded student data stays on the
computer running the app. The app does not send student-level data to OpenAI or
any external service.

How to use
----------

1. Unzip the folder.
2. Open the unzipped folder.
3. Double-click "Launch SOL Analyzer.bat".
4. Your browser should open to:

   http://127.0.0.1:8765/

5. Upload a CSV or XLSX file, confirm the column mapping, and generate the
   Excel workbook.

Requirements
------------

If you are running this outside Codex, the computer needs:

- Python 3.11 or newer
- pandas
- openpyxl

If the launcher says pandas/openpyxl are missing, run this once in Command
Prompt or PowerShell:

python -m pip install pandas openpyxl

Then double-click "Launch SOL Analyzer.bat" again.

FERPA note
----------

The app processes files locally. Keep original files and exported workbooks in
school-approved storage, especially when they include student names or IDs.
