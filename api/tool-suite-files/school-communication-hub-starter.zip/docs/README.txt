PLACE SCHOOL DOCUMENTS IN THIS FOLDER.

Use the filenames listed in the main README.md, or update each URL in school.config.js to match the document you upload.

Do not upload passwords, student records, private medical information, or the complete confidential crisis plan.
