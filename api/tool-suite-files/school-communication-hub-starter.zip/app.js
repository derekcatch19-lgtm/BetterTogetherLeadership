(() => {
  const config = window.SCHOOL_HUB;
  const app = document.querySelector("#app");
  const storageKey = "school-hub-announcements-v1";

  const escapeHtml = (value = "") => String(value).replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  })[character]);
  const today = () => new Date().toLocaleDateString("en-CA", { timeZone: "America/New_York" });
  const prettyDate = (value) => new Date(`${value}T12:00:00`).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  const getAnnouncements = () => JSON.parse(localStorage.getItem(storageKey) || "[]");
  const setAnnouncements = (items) => localStorage.setItem(storageKey, JSON.stringify(items));
  const routeParts = () => (location.hash.replace(/^#\/?/, "") || "home").split("/");
  const isPlaceholder = (url) => !url || url === "#";

  function applyBrand() {
    const colors = config.school.colors;
    document.documentElement.style.setProperty("--navy", colors.navy);
    document.documentElement.style.setProperty("--blue", colors.blue);
    document.documentElement.style.setProperty("--sky", colors.sky);
    document.documentElement.style.setProperty("--gold", colors.gold);
    document.title = `${config.school.name} Communication Hub`;
    document.querySelector("#school-name").textContent = config.school.name;
    document.querySelector("#footer-school").textContent = config.school.name;
    document.querySelector("#footer-tagline").textContent = config.school.tagline;
    document.querySelector("#brand-logo").src = config.school.logo;
  }

  function card(item, meta = "Resource") {
    const placeholder = isPlaceholder(item.url);
    const tag = placeholder ? "article" : "a";
    const href = placeholder ? "" : ` href="${escapeHtml(item.url)}"`;
    return `<${tag} class="card ${placeholder ? "placeholder" : ""}"${href}>
      <p class="meta">${escapeHtml(item.owner || meta)}</p>
      <h3>${escapeHtml(item.title)}</h3>
      <p>${escapeHtml(item.description || item.text || "Add content here.")}</p>
      <p class="action">${placeholder ? "Coming soon" : "Open"}</p>
    </${tag}>`;
  }

  function heading(eyebrow, title, description, includeDate = false) {
    return `<div class="page-head"><div><p class="eyebrow">${escapeHtml(eyebrow)}</p><h1>${escapeHtml(title)}</h1><p class="lede">${escapeHtml(description)}</p></div>${includeDate ? `<div class="date-chip">${new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</div>` : ""}</div>`;
  }

  function section(title, items, meta) {
    return `<section class="section"><div class="section-heading"><h2>${escapeHtml(title)}</h2><span>${items.length} items</span></div><div class="grid">${items.map((item) => card(item, meta)).join("")}</div></section>`;
  }

  function activeAnnouncements(filter = () => true) {
    const date = today();
    return getAnnouncements().filter((item) => item.status === "approved" && item.startDate <= date && item.endDate >= date && filter(item));
  }

  function announcementMarkup(item, showActions = false) {
    const audiences = [item.online && "Online", item.school && "School", item.school && item.block].filter(Boolean);
    return `<article class="announcement" data-id="${item.id}">
      <div class="announcement-head"><div><h3>${escapeHtml(item.heading)}</h3><p>${escapeHtml(item.message)}</p></div><span class="badge ${item.status}">${escapeHtml(item.status)}</span></div>
      <div class="badges">${audiences.map((value) => `<span class="badge">${escapeHtml(value)}</span>`).join("")}<span class="badge">${prettyDate(item.startDate)} - ${prettyDate(item.endDate)}</span></div>
      <p class="meta">Submitted by ${escapeHtml(item.staffMember)}</p>
      ${showActions ? `<div class="button-row"><button class="button success" data-action="approve" data-id="${item.id}">Approve</button><button class="button danger" data-action="delete" data-id="${item.id}">Delete</button></div>` : ""}
    </article>`;
  }

  function renderHome() {
    const announcements = activeAnnouncements((item) => item.online);
    app.innerHTML = `<div class="hero-band"><div class="hero-inner">${heading("Communication Hub", config.school.name, config.school.tagline, true)}</div></div>
      <div class="page">
        <section><div class="section-heading"><h2>Today's Announcements</h2><a href="#/communication/today">View communication hub</a></div>
          <div class="panel">${announcements.length ? announcements.map((item) => announcementMarkup(item)).join("") : `<div class="empty">No online announcements are posted for today.</div>`}</div>
        </section>
        ${section("Quick Access", config.quickAccess, "Quick Access")}
      </div>`;
  }

  const communicationTabs = [
    ["today", "Today's Announcements"], ["submit", "Submit Announcement"], ["online", "Online"],
    ["archive", "Archive"], ["daily", "Daily Message"], ["presenter", "Presenter"], ["approvals", "Approvals"]
  ];

  function communicationNav(active) {
    return `<div class="tabs" role="tablist">${communicationTabs.map(([route, label]) => `<button type="button" class="${route === active ? "active" : ""}" data-route="${route}">${label}</button>`).join("")}</div>`;
  }

  function renderCommunication(view = "today") {
    if (view === "presenter") return renderPresenter("morning");
    const date = today();
    let content = "";
    if (view === "today") {
      const items = activeAnnouncements((item) => item.school);
      content = items.length ? items.map((item) => announcementMarkup(item)).join("") : `<div class="empty">No approved school announcements are active today.</div>`;
    } else if (view === "online") {
      const items = activeAnnouncements((item) => item.online);
      content = items.length ? items.map((item) => announcementMarkup(item)).join("") : `<div class="empty">No approved online announcements are active today.</div>`;
    } else if (view === "archive") {
      const items = getAnnouncements().filter((item) => item.endDate < date || item.status === "archived");
      content = items.length ? items.map((item) => announcementMarkup(item)).join("") : `<div class="empty">The announcement archive is empty.</div>`;
    } else if (view === "approvals") {
      const items = getAnnouncements().filter((item) => item.status === "pending");
      content = `<p class="notice"><strong>Template note:</strong> Connect authentication before using approvals in production.</p>${items.length ? items.map((item) => announcementMarkup(item, true)).join("") : `<div class="empty">No announcements are waiting for approval.</div>`}`;
    } else if (view === "daily") {
      content = `<div class="grid two"><article class="card"><p class="meta">Morning</p><h3>Morning Message Framework</h3><p>${escapeHtml(config.dailyMessages.morning)}</p></article><article class="card"><p class="meta">Fourth Block</p><h3>Afternoon Message Framework</h3><p>${escapeHtml(config.dailyMessages.afternoon)}</p></article></div>`;
    } else if (view === "submit") {
      content = submissionForm();
    }
    app.innerHTML = `<div class="page">${heading("School Communication", communicationTabs.find(([key]) => key === view)?.[1] || "Communication Hub", "Post, review, present, and find school announcements in one consistent workflow.", true)}${communicationNav(view)}<div class="panel">${content}</div></div>`;
    bindCommunication(view);
  }

  function submissionForm() {
    return `<form id="announcement-form">
      <div class="form-grid">
        <div class="field"><label for="staff-member">Your name</label><input id="staff-member" name="staffMember" required /></div>
        <div class="field"><label for="heading">Announcement heading</label><input id="heading" name="heading" required /></div>
        <div class="field full"><label for="message">Announcement</label><textarea id="message" name="message" rows="6" required></textarea></div>
        <div class="field"><label for="start-date">Start date</label><input id="start-date" name="startDate" type="date" value="${today()}" required /></div>
        <div class="field"><label for="end-date">End date</label><input id="end-date" name="endDate" type="date" value="${today()}" required /></div>
        <fieldset class="field full"><legend>Audience</legend><div class="checks"><label><input type="checkbox" name="online" checked /> Online announcement</label><label><input type="checkbox" name="school" checked /> School announcement</label></div></fieldset>
        <div class="field"><label for="block">School announcement time</label><select id="block" name="block"><option value="morning">Morning</option><option value="afternoon">Afternoon</option><option value="both">Morning and afternoon</option></select></div>
        <div class="field"><label for="attachment">Flyer or image (integration placeholder)</label><input id="attachment" name="attachment" type="file" accept="image/*,.pdf" /></div>
      </div>
      <p class="notice">Choose school announcements only for information relevant to a meaningful portion of the student body. All submissions enter the approval queue.</p>
      <div class="button-row"><button class="button" type="submit">Submit for approval</button></div>
      <p id="form-result" role="status"></p>
    </form>`;
  }

  function bindCommunication(view) {
    document.querySelectorAll("[data-route]").forEach((button) => button.addEventListener("click", () => { location.hash = `#/communication/${button.dataset.route}`; }));
    document.querySelectorAll("[data-action]").forEach((button) => button.addEventListener("click", () => {
      const items = getAnnouncements();
      const index = items.findIndex((item) => item.id === button.dataset.id);
      if (index < 0) return;
      if (button.dataset.action === "approve") items[index].status = "approved";
      if (button.dataset.action === "delete") items.splice(index, 1);
      setAnnouncements(items);
      renderCommunication("approvals");
    }));
    if (view === "submit") document.querySelector("#announcement-form").addEventListener("submit", (event) => {
      event.preventDefault();
      const form = new FormData(event.currentTarget);
      if (!form.get("online") && !form.get("school")) {
        document.querySelector("#form-result").textContent = "Choose at least one audience.";
        return;
      }
      const items = getAnnouncements();
      items.unshift({
        id: crypto.randomUUID(), staffMember: form.get("staffMember"), heading: form.get("heading"), message: form.get("message"),
        startDate: form.get("startDate"), endDate: form.get("endDate"), online: Boolean(form.get("online")), school: Boolean(form.get("school")),
        block: form.get("block"), status: "pending", createdAt: new Date().toISOString()
      });
      setAnnouncements(items);
      event.currentTarget.reset();
      document.querySelector("#form-result").innerHTML = `<p class="notice">Announcement saved to the approval queue.</p>`;
    });
  }

  function renderPresenter(block) {
    const items = activeAnnouncements((item) => item.school && (item.block === block || item.block === "both"));
    const opening = block === "morning" ? config.dailyMessages.morning : config.dailyMessages.afternoon;
    app.innerHTML = `<div class="presenter"><div class="toolbar"><button class="button ${block === "morning" ? "secondary" : ""}" data-block="morning">Morning</button><button class="button ${block === "afternoon" ? "secondary" : ""}" data-block="afternoon">Afternoon</button><button class="button secondary" onclick="window.print()">Print</button><a class="button secondary" href="#/communication/today">Exit presenter</a></div><h2>${block === "morning" ? "Morning" : "Afternoon"} Announcements</h2><p>${escapeHtml(opening)}</p>${items.length ? items.map((item) => announcementMarkup(item)).join("") : `<p>No approved ${block} announcements are active.</p>`}</div>`;
    document.querySelectorAll("[data-block]").forEach((button) => button.addEventListener("click", () => renderPresenter(button.dataset.block)));
  }

  function renderStaff(focus = "") {
    app.innerHTML = `<div class="page">${heading("Staff Resources", "Staff Hub", "Find schedules, forms, contacts, instructional tools, and onboarding support quickly.")}
      <div class="toolbar"><input id="staff-search" type="search" placeholder="Search staff resources, forms, or contacts" aria-label="Search Staff Hub" /></div>
      <div id="staff-content">
        ${section("Quick Access", config.quickAccess, "Quick Access")}
        ${section("Staff Resources", config.staffResources, "Staff Resource")}
        ${section("Forms Center", config.forms, "Form")}
        <section class="section" id="contacts"><div class="section-heading"><h2>Who Do I Contact?</h2><span>${config.contacts.length} contacts</span></div><div class="grid">${config.contacts.map(contactCard).join("")}</div></section>
        ${section("New Teacher Corner", config.newTeacher, "New Teacher")}
        ${section("Staff Recognition", config.recognition, "Recognition")}
      </div>
    </div>`;
    const search = document.querySelector("#staff-search");
    search.addEventListener("input", () => filterStaff(search.value));
    if (focus === "contacts") document.querySelector("#contacts")?.scrollIntoView();
  }

  function contactCard(contact) {
    return `<article class="card contact-card" data-search="${escapeHtml(Object.values(contact).join(" ").toLowerCase())}"><p class="meta">${escapeHtml(contact.area)}</p><h3>${escapeHtml(contact.name)}</h3><p>${escapeHtml(contact.role)}</p><dl><dt>Handles</dt><dd>${escapeHtml(contact.responsibilities)}</dd><dt>Email</dt><dd><a href="mailto:${escapeHtml(contact.email)}">${escapeHtml(contact.email)}</a></dd><dt>Phone</dt><dd>${escapeHtml(contact.phone)}</dd><dt>Location</dt><dd>${escapeHtml(contact.location)}</dd></dl></article>`;
  }

  function filterStaff(value) {
    const query = value.trim().toLowerCase();
    document.querySelectorAll("#staff-content .card").forEach((element) => {
      element.hidden = Boolean(query) && !element.textContent.toLowerCase().includes(query) && !(element.dataset.search || "").includes(query);
    });
  }

  function renderSearchPage(kind) {
    const map = {
      handbook: ["Reference", "Searchable Handbook", "Search policies, procedures, and staff expectations.", config.handbookTopics],
      instruction: ["Teaching & Learning", "Instructional Toolkit", "Planning, curriculum, PLC, and classroom resources.", config.instructionalTools],
      data: ["Assessment", "Data & Assessment Tools", "Find assessment calendars, reports, protocols, and analysis tools.", config.dataTools]
    };
    const [eyebrow, title, description, items] = map[kind];
    app.innerHTML = `<div class="page">${heading(eyebrow, title, description)}<div class="toolbar"><input id="page-search" type="search" placeholder="Search ${title.toLowerCase()}" /></div><div id="page-grid" class="grid">${items.map((item) => card(item, kind)).join("")}</div></div>`;
    document.querySelector("#page-search").addEventListener("input", (event) => {
      const query = event.target.value.toLowerCase();
      document.querySelectorAll("#page-grid .card").forEach((element) => { element.hidden = !element.textContent.toLowerCase().includes(query); });
    });
  }

  function renderCalendar() {
    app.innerHTML = `<div class="page">${heading("Dates & Events", "School Calendar", "Connect the school's Google Calendar, Microsoft calendar, or published calendar link here.", true)}<div class="panel"><div class="empty"><strong>Calendar connection ready</strong><br />Replace the placeholder link in <code>school.config.js</code> or embed your approved calendar.</div></div></div>`;
  }

  function updateNavigation(route) {
    document.querySelectorAll("nav a").forEach((link) => link.toggleAttribute("aria-current", link.getAttribute("href") === `#/${route}` || (route === "communication" && link.getAttribute("href") === "#/communication")));
    document.querySelector("#primary-nav").classList.remove("open");
    document.querySelector("#menu-button").setAttribute("aria-expanded", "false");
  }

  function render() {
    const [route, view] = routeParts();
    updateNavigation(route);
    if (route === "communication") renderCommunication(view || "today");
    else if (route === "staff") renderStaff(view || "");
    else if (["handbook", "instruction", "data"].includes(route)) renderSearchPage(route);
    else if (route === "calendar") renderCalendar();
    else renderHome();
    window.scrollTo(0, 0);
    app.focus({ preventScroll: true });
  }

  document.querySelector("#menu-button").addEventListener("click", () => {
    const nav = document.querySelector("#primary-nav");
    nav.classList.toggle("open");
    document.querySelector("#menu-button").setAttribute("aria-expanded", String(nav.classList.contains("open")));
  });
  window.addEventListener("hashchange", render);
  applyBrand();
  render();
})();
