window.SCHOOL_HUB = {
  school: {
    name: "Your School Name",
    shortName: "YSH",
    tagline: "One place for current information, forms, and support.",
    logo: "assets/logo-placeholder.svg",
    colors: {
      navy: "#12304a",
      blue: "#176b87",
      sky: "#d8eef2",
      gold: "#e7ad35"
    }
  },

  quickAccess: [
    { title: "Daily Announcements", description: "Current schoolwide announcements.", url: "#/communication/today" },
    { title: "Staff Handbook", description: "Policies, expectations, and procedures.", url: "#/handbook" },
    { title: "Weekly Staff Update", description: "The current weekly memo.", url: "docs/weekly-staff-update.pdf" },
    { title: "Staff Calendar", description: "School events and important dates.", url: "#/calendar" },
    { title: "Instructional Toolkit", description: "Planning and teaching resources.", url: "#/instruction" },
    { title: "Data & Assessment Tools", description: "Assessment and data resources.", url: "#/data" }
  ],

  staffResources: [
    { title: "Bell Schedule", description: "Current daily and special schedules.", url: "docs/bell-schedule.pdf" },
    { title: "Duty Schedule", description: "Staff duty assignments and locations.", url: "docs/duty-schedule.pdf" },
    { title: "Staff Work Calendar", description: "Contract and work-day calendar.", url: "docs/staff-work-calendar.pdf" },
    { title: "School Map", description: "Campus and room maps.", url: "docs/school-map.pdf" },
    { title: "Emergency Procedures", description: "Concise staff response procedures.", url: "docs/emergency-procedures.pdf" },
    { title: "Phone Directory", description: "Staff extensions and locations.", url: "docs/phone-directory.pdf" },
    { title: "Technology Help", description: "Technology help and work orders.", url: "#" },
    { title: "Maintenance Request", description: "Maintenance and facility work orders.", url: "#" }
  ],

  forms: [
    { title: "Leave Information", owner: "Human Resources", description: "Leave process and absence reporting.", url: "#" },
    { title: "Professional Leave Form", owner: "Administration", description: "Download, print, and submit for approval.", url: "docs/professional-leave-form.pdf" },
    { title: "Purchase Order Process", owner: "Bookkeeper", description: "Purchasing steps and required approvals.", url: "docs/purchase-order-process.pdf" },
    { title: "Work Order Request", owner: "Operations", description: "Request technology or maintenance support.", url: "#" },
    { title: "Facility Request", owner: "Administration", description: "Request use of school facilities.", url: "docs/facility-request.pdf" },
    { title: "Field Trip Information", owner: "Administration", description: "Planning forms and approval steps.", url: "docs/field-trip-request.pdf" },
    { title: "Fundraiser Information", owner: "Administration", description: "Fundraiser application and expectations.", url: "docs/fundraiser-request.pdf" },
    { title: "Timesheet Information", owner: "Payroll", description: "Timesheet and extra-duty guidance.", url: "docs/timesheet-information.pdf" },
    { title: "Device Request", owner: "Technology", description: "Request student or staff device support.", url: "#" }
  ],

  contacts: [
    { area: "Attendance", name: "Contact Name", role: "Attendance Secretary", responsibilities: "Attendance corrections, notes, and daily questions", email: "attendance@example.org", phone: "Ext. 0000", location: "Main Office" },
    { area: "Testing", name: "Contact Name", role: "Testing Coordinator", responsibilities: "Testing schedules, accommodations, and materials", email: "testing@example.org", phone: "Ext. 0000", location: "Office" },
    { area: "Discipline", name: "Contact Name", role: "Assistant Principal", responsibilities: "Student conduct and administrative support", email: "admin@example.org", phone: "Ext. 0000", location: "Office" },
    { area: "Technology", name: "Contact Name", role: "Technology Support", responsibilities: "Accounts, devices, classroom technology, and tickets", email: "technology@example.org", phone: "Ext. 0000", location: "Tech Office" },
    { area: "Counseling", name: "Contact Name", role: "School Counselor", responsibilities: "Academic, social-emotional, and scheduling support", email: "counseling@example.org", phone: "Ext. 0000", location: "Counseling Office" },
    { area: "Payroll / Timesheets", name: "Contact Name", role: "Bookkeeper", responsibilities: "Timesheets, payroll questions, and purchase orders", email: "payroll@example.org", phone: "Ext. 0000", location: "Main Office" }
  ],

  newTeacher: [
    { title: "First Week Checklist", description: "Keys, badge, mailbox, schedule, duty assignment, safety routes, and required accounts.", url: "docs/new-teacher-checklist.pdf" },
    { title: "Technology Setup", description: "Email, device, classroom display, printer, and required applications.", url: "docs/technology-setup.pdf" },
    { title: "Student Information System", description: "Attendance, grades, rosters, and family communication.", url: "#" },
    { title: "Learning Management System", description: "Courses, assignments, content, and feedback.", url: "#" },
    { title: "Lesson Plan Expectations", description: "Required plan elements and instructional best practices.", url: "docs/lesson-plan-expectations.pdf" },
    { title: "Substitute Plans", description: "What to prepare and where to keep emergency plans.", url: "docs/substitute-plan-guide.pdf" },
    { title: "Who to Ask", description: "Administrative and office responsibilities.", url: "#/staff/contacts" }
  ],

  recognition: [
    { title: "Celebration of the Week", text: "Add this week's staff or school celebration here." },
    { title: "Birthdays", text: "Connect a calendar or list current staff birthdays here." },
    { title: "Welcome New Staff", text: "Add new staff names and roles here." },
    { title: "One Thing to Know", text: "Add one concise weekly reminder here." }
  ],

  handbookTopics: [
    { title: "Attendance Procedures", summary: "Add the school's attendance procedures and staff responsibilities.", keywords: "attendance tardy absence" },
    { title: "Emergency Procedures", summary: "Add concise, staff-facing directions for each emergency response.", keywords: "emergency lockdown evacuation shelter" },
    { title: "Leave Procedures", summary: "Explain how staff request leave and arrange coverage.", keywords: "leave absence substitute" },
    { title: "Student Supervision", summary: "Add expectations for classrooms, hallways, duties, and transitions.", keywords: "supervision duty hallway" },
    { title: "Technology and Acceptable Use", summary: "Add account, device, privacy, and acceptable-use expectations.", keywords: "technology device privacy" }
  ],

  instructionalTools: [
    { title: "Curriculum & Standards", description: "Standards, pacing, and curriculum documents.", url: "docs/curriculum-standards.pdf" },
    { title: "Lesson Planning", description: "Templates, expectations, and planning support.", url: "docs/lesson-plan-template.docx" },
    { title: "PLC Resources", description: "Agendas, protocols, and collaborative planning tools.", url: "docs/plc-resources.pdf" },
    { title: "Formative Assessment", description: "Checks for understanding and response strategies.", url: "docs/formative-assessment.pdf" },
    { title: "Intervention & Enrichment", description: "Student support and extension resources.", url: "docs/intervention-enrichment.pdf" }
  ],

  dataTools: [
    { title: "Benchmark Data", description: "Open the school's benchmark platform or reporting guide.", url: "#" },
    { title: "Summative Data", description: "Assessment reports and end-of-course resources.", url: "#" },
    { title: "Data Meeting Protocol", description: "A repeatable process for reviewing evidence and planning next steps.", url: "docs/data-meeting-protocol.pdf" },
    { title: "Assessment Calendar", description: "Testing windows and key deadlines.", url: "docs/assessment-calendar.pdf" }
  ],

  dailyMessages: {
    morning: "Welcome. Add the school's rotating morning message, pledge, moment of silence, daily message, announcements, and closing here.",
    afternoon: "Add a concise fourth-block opening, approved announcements, and a finish-strong closing here."
  }
};
